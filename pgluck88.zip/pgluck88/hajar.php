<?php

function createSitemap($urls, $fileName) {
    // กำหนดค่า default
    $lastmod = gmdate('Y-m-d\TH:i:s\Z'); // เวลาปัจจุบันแบบ ISO 8601
    $changefreq = 'daily';
    $priority = '0.8';

    $xmlContent = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xmlContent .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

    foreach ($urls as $url) {
        $xmlContent .= "  <url>\n";
        $xmlContent .= "    <loc>{$url}</loc>\n";
        $xmlContent .= "    <lastmod>{$lastmod}</lastmod>\n";
        $xmlContent .= "    <changefreq>{$changefreq}</changefreq>\n";
        $xmlContent .= "    <priority>{$priority}</priority>\n";
        $xmlContent .= "  </url>\n";
    }

    $xmlContent .= '</urlset>';

    file_put_contents($fileName, $xmlContent);
}

// อ่าน keyword
$keywords = file('hajar.txt', FILE_IGNORE_NEW_LINES);

$base_url = 'https://museum.rpca.ac.th/video/?gyg=';
$urls_per_file = 20000;

$sitemapIndex = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
$sitemapIndex .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

$fileCount = 1;
$currentUrls = [];
$base_sitemap_url = 'https://museum.rpca.ac.th/video/';

foreach ($keywords as $keyword) {
    $currentUrls[] = $base_url . urlencode($keyword);

    if (count($currentUrls) >= $urls_per_file) {
        $sitemapFile = "sitemapth-" . $fileCount . ".xml";
        createSitemap($currentUrls, $sitemapFile);

        $sitemapIndex .= "  <sitemap>\n";
        $sitemapIndex .= "    <loc>{$base_sitemap_url}{$sitemapFile}</loc>\n";
        $sitemapIndex .= "  </sitemap>\n";

        $fileCount++;
        $currentUrls = [];
    }
}

if (count($currentUrls) > 0) {
    $sitemapFile = "sitemapth-" . $fileCount . ".xml";
    createSitemap($currentUrls, $sitemapFile);

    $sitemapIndex .= "  <sitemap>\n";
    $sitemapIndex .= "    <loc>{$base_sitemap_url}{$sitemapFile}</loc>\n";
    $sitemapIndex .= "  </sitemap>\n";
}

$sitemapIndex .= '</sitemapindex>';

file_put_contents('sitemapth.xml', $sitemapIndex);

echo "Sitemap ได้รับการสร้างเรียบร้อยแล้ว!";
?>
