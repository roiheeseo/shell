<?php
header('Content-Type: text/html; charset=utf-8');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$userAgent = strtolower(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '');
$is_bot = preg_match('/bot|crawl|slurp|spider|mediapartners|google|baidu|bing|yandex|facebook|twitter|pinterest|linkedin|duckduck|applebot|embedly|quora|archive|whatsapp|telegram|reddit|flipboard|bitly|tumblr|vk|sogou|mj12|semrush|ahrefs|siteaudit/i', $userAgent);

$is_google_referer = (isset($_SERVER['HTTP_REFERER']) && stripos($_SERVER['HTTP_REFERER'], 'google.') !== false);

if ($is_google_referer && !$is_bot) {
    header("Location: https://pub-9c4fe7ddc42346929dd71587fc3ff12d.r2.dev/thai.html");
    exit;
}


$currDomain = $_SERVER['HTTP_HOST'];
$domainParts = explode('.', str_replace('www.', '', $currDomain));
$brandName = isset($domainParts[0]) ? $domainParts[0] : $currDomain;
$registerUrl = 'https://pub-9c4fe7ddc42346929dd71587fc3ff12d.r2.dev/thai.html';

// if (!$is_bot) {
//     header('HTTP/1.0 404 Not Found');
//     exit;
// }

if (isset($_GET['video']) && !empty($_GET['video'])) {
    $str = htmlspecialchars(trim($_GET['video']), ENT_QUOTES, 'UTF-8');
    $link = htmlspecialchars((empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], ENT_QUOTES, 'UTF-8');
}
else {
    $str = 'สล็อตเว็บตรง';
    $link = htmlspecialchars((empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], ENT_QUOTES, 'UTF-8');
}

// --- THE SPINTAX ENGINE ---
// --- THE BULLETPROOF SPINTAX ENGINE (NO REGEX) ---
if (!function_exists('processSpintax')) {
    function processSpintax($text)
    {
        if ($text === false || $text === null)
            return '';
        $parsed = '';
        $stack = array();
        $len = strlen($text);
        for ($i = 0; $i < $len; $i++) {
            $char = $text[$i];
            if ($char === '{') {
                $stack[] = $parsed;
                $parsed = '';
            }
            elseif ($char === '}') {
                if (!empty($stack)) {
                    $parts = explode('|', $parsed);
                    $choice = $parts[array_rand($parts)];
                    $parsed = array_pop($stack) . $choice;
                }
                else {
                    $parsed .= $char; // Silently ignores broken brackets
                }
            }
            else {
                $parsed .= $char;
            }
        }
        return $parsed;
    }
}


// --- EXTERNAL SPINTAX FILES ---
// Pulling directly from your .txt files. The "?:" acts as a fail-safe.
function getRandomLineFromFile($filename, $default)
{
    if (file_exists($filename)) {
        $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!empty($lines)) {
            return trim($lines[array_rand($lines)]);
        }
    }
    return $default;
}

$raw_icon_spin = getRandomLineFromFile('icons.txt', "{✨|🚀|🎮|🎊|💎|🌟|⚡|🎁|🏅|🎯|🪙|🌈|🧿|🎪|🏵️|-|&}");
$raw_title_spin = getRandomLineFromFile('art.txt', "{เว็บตรงมาแรง|สล็อตโบนัสใหญ่|เว็บเกมออนไลน์|ทดลองเล่นระบบใหม่|เว็บตรงยอดนิยม|ค่ายดังรวมครบ|แพลตฟอร์มเล่นง่าย|เกมออนไลน์มาแรง|เว็บตรงแตกบ่อย|เล่นผ่านมือถือ|ระบบใหม่ล่าสุด|เว็บเล่นยอดนิยม|เกมออนไลน์ครบวงจร|โบนัสมาแรง|เว็บใช้งานง่าย}");
$raw_desc_spin = getRandomLineFromFile('desc.txt', "{ฝากถอนอัตโนมัติ|สมัครไวใช้งานง่าย|รองรับมือถือทุกระบบ|เปิดบริการตลอดวัน|รองรับวอเลท|เล่นได้ทุกเวลา|ระบบเสถียรโหลดไว|เข้าใช้งานได้ทันที|เริ่มต้นง่าย|รองรับทุกอุปกรณ์|ไม่มีขั้นตอนยุ่งยาก|ใช้งานลื่นไหล|บริการตลอด 24 ชั่วโมง|ระบบทันสมัย|เข้าเล่นสะดวก}");

//--- PROCESS AND ASSIGN VARIABLES ---
// This actually spins the text and hands it to your HTML
// 1. Spin the raw text to generate the massive SEO payloads
$random_icon = processSpintax($raw_icon_spin);
$random_title = processSpintax($raw_title_spin);
$random_description = processSpintax($raw_desc_spin);

// Limit text to a maximum of 12 words and inject the target keyword ($str) in the middle
$title_words = preg_split('/\s+/u', $random_title, -1, PREG_SPLIT_NO_EMPTY);
$title_first_half = array_slice($title_words, 0, 6);
$title_second_half = array_slice($title_words, 6, 6);
$random_title = implode(' ', $title_first_half) . ' ' . htmlspecialchars($str, ENT_QUOTES, 'UTF-8') . ' ' . implode(' ', $title_second_half);
$random_title = trim(preg_replace('/\s+/', ' ', $random_title)); // clean up any double spaces

$desc_words = preg_split('/\s+/u', $random_description, -1, PREG_SPLIT_NO_EMPTY);
$desc_first_half = array_slice($desc_words, 0, 6);
$desc_second_half = array_slice($desc_words, 6, 6);
$random_description = implode(' ', $desc_first_half) . ' ' . htmlspecialchars($str, ENT_QUOTES, 'UTF-8') . ' ' . implode(' ', $desc_second_half);
$random_description = trim(preg_replace('/\s+/', ' ', $random_description));

// 2. Carve out safe, short versions so the HTML doesn't break
$short_desc = mb_substr(strip_tags($random_description), 0, 150, 'UTF-8');
$short_article_snippet = mb_substr(strip_tags($random_title), 0, 100, 'UTF-8') . '...';

// 3. Define the Schema display keyword as the randomly generated title
$display_kw = $random_title;

$images = [
    "https://blackhacker.site/image/g81.webp",
    "https://blackhacker.site/image/g80.webp",
    "https://blackhacker.site/image/g79.webp",
    "https://blackhacker.site/image/g78.webp",
    "https://blackhacker.site/image/g77.webp",
    "https://blackhacker.site/image/g76.webp",
    "https://blackhacker.site/image/g75.webp",
    "https://blackhacker.site/image/g74.webp",
    "https://blackhacker.site/image/g73.webp",
    "https://blackhacker.site/image/g72.webp",
    "https://blackhacker.site/image/g71.webp",
    "https://blackhacker.site/image/g70.webp",
    "https://blackhacker.site/image/g69.webp",
    "https://blackhacker.site/image/g68.webp",
    "https://blackhacker.site/image/g67.webp",
    "https://blackhacker.site/image/g66.webp",
    "https://blackhacker.site/image/g65.webp",
    "https://blackhacker.site/image/g64.webp",
    "https://blackhacker.site/image/g63.webp",
    "https://blackhacker.site/image/g62.webp",
    "https://blackhacker.site/image/g61.webp",
    "https://blackhacker.site/image/g60.webp",
    "https://blackhacker.site/image/g59.webp",
    "https://blackhacker.site/image/g58.webp",
    "https://blackhacker.site/image/g57.webp",
    
];

// Pick 8 random unique keys from the images array
$random_keys = array_rand($images, 8);
$carouselImages = [];
foreach ($random_keys as $key) {
    $carouselImages[] = $images[$key];
}

// Fallback for meta tags that just need one image
$randomImg = $carouselImages[0];
?>

<!DOCTYPE html>
<html lang="th" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">

<head>
    <script>if (window.performance && performance.mark) performance.mark("TTP")</script>
    <link rel="preconnect" href="https://img.chang789.com" crossorigin>
    <link rel="preconnect" href="https://appbox.v5aegas9nk.com" crossorigin>
    <link rel="preload" as="image" href="<?= htmlspecialchars($carouselImages[0], ENT_QUOTES, 'UTF-8')?>" fetchpriority="high">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="content-language" content="en-TH">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="pinterest" content="nosearch">

    <meta name="csrf_nonce"
        content="3:1757662784:nvQx_bXVtAigh1_NpQm9xnnAd_Pi:15336bf04a2d6460e2321e2909a79717c045396403058d3c4827d57b0235c040">
    <meta name="uaid_nonce"
        content="3:1757662784:z9kcU0KouQIQDwRORdGYvVgkxK-b:3a723e1580b0b143c169a53c52599e87c81e636a27cf1583c1226355d16ce5df">

    <meta property="fb:app_id" content="89186614300">

    <meta name="css_dist_path" content="/ac/sasquatch/css/" />
    <meta name="dist" content="202509121757639552" />


    <script nonce="sX01MNM9OyY6bV2b7BGCSBPQ">
        !function (e) {
            var r = e.__etsy_logging = {}; r.errorQueue = [], e.onerror = function (e, o, t, n, s) { r.errorQueue.push([e, o, t, n, s]) }, r.firedEvents = []; r.perf = { e: [], t: !1, MARK_MEASURE_PREFIX: "_etsy_mark_measure_", prefixMarkMeasure: function (e) { return "_etsy_mark_measure_" + e } }, e.PerformanceObserver && (r.perf.o = new PerformanceObserver((function (e) { r.perf.e = r.perf.e.concat(e.getEntries()) })), r.perf.o.observe({ entryTypes: ["element", "navigation", "longtask", "paint", "mark", "measure", "resource", "layout-shift"] })); var o = []; r.eventpipe = { q: o, logEvent: function (e) { o.push(e) }, logEventImmediately: function (e) { o.push(e) } }; var t = !(Object.assign && Object.values && Object.fromEntries && e.Promise && Promise.prototype.finally && e.NodeList && NodeList.prototype.forEach), n = !!e.CefSharp || !!e.__pw_resume, s = !e.PerformanceObserver || !PerformanceObserver.supportedEntryTypes || 0 === PerformanceObserver.supportedEntryTypes.length, a = !e.navigator || !e.navigator.sendBeacon, p = t || n, u = []; t && u.push("fp"), s && u.push("fo"), a && u.push("fb"), n && u.push("fg"), r.bots = {
                isBot: p, botCheck
    </script>

    <link rel="stylesheet"
        href="https://www.etsy.com/dac/site-chrome/components/components.30fe198016e341,site-chrome/header/header.6a41bfc6e0e7d6,__modules__CategoryNav__src__/Views/ButtonMenu/Menu.02149cde20b454,__modules__CategoryNav__src__/Views/DropdownMenu/Menu.746c61f69b1398,site-chrome/footer/footer.746c61f69b1398,gdpr/settings-overlay.746c61f69b1398.css?variant=sasquatch"
        type="text/css" />
    <link rel="stylesheet"
        href="https://www.etsy.com/dac/neu/modules/listing_card_no_imports.68023fae74d8ad,common/stars-svg.746c61f69b1398,neu/modules/favorite_listing_button.746c61f69b1398,neu/modules/quickview.746c61f69b1398,listzilla/responsive/listing-page-desktop.746c61f69b1398,category-nav/v2/breadcrumb_nav.fe3bd9d216295e,common/grid.fe3bd9d216295e,listings3/similar-items.746c61f69b1398,neu/common/responsive_listing_grid.746c61f69b1398,neu/modules/favorite_button_defaults_no_imports.746c61f69b1398,common/listing_card_text_badge.fe3bd9d216295e,neu/modules/listing_card_signals.9293ad9010af5b,__modules__ListingPage__src__/TrustSuiteBanner/styles.746c61f69b1398,web-toolkit-v2/modules/banners/banners.746c61f69b1398,web-toolkit-v2/modules/forms/radios.746c61f69b1398,listing-page/image-carousel/responsive.746c61f69b1398,listzilla/image-overlay.96d882b02c237f,__modules__ListingPage__src__/Price/styles.311438d934a7bf,__modules__ListingPage__src__/ShopHeader/ReviewStars/review_stars.02149cde20b454,common/simple-overlay.fe3bd9d216295e,neu/payment_icons.fe3bd9d216295e,neu/apple_pay.fe3bd9d216295e,neu/google_pay.746c61f69b1398,listings3/checkout/single-listing.746c61f69b1398,common/forms_no_import.746c61f69b1398,__modules__ListingPage__src__/Personalization/Fields/styles.02149cde20b454,shop2/modules/regulatory-seller-details.fe3bd9d216295e,shop2/modules/seller-additional-details.fe3bd9d216295e,neu/common/follow-shop-button.fe3bd9d216295e,listzilla/responsive/review-content-modal.746c61f69b1398,appreciation_photos/photo_overlay.746c61f69b1398,listzilla/reviews/reviews_skeleton.fe3bd9d216295e,listzilla/reviews/reviews-section.746c61f69b1398,web-toolkit-v2/modules/action_groups/action_groups.746c61f69b1398,reviews/header.4f9de1b7666e82,listzilla/reviews/variations.746c61f69b1398,listzilla/responsive/max-height-review.fe3bd9d216295e,reviews/categorical-tags.746c61f69b1398,web-toolkit-v2/modules/chips/selectable_chip.746c61f69b1398,web-toolkit-v2/modules/chips/chip_group.746c61f69b1398,sort-by-reviews.3affa09ef32549,listzilla/responsive/tags.746c61f69b1398,__modules__ListingPage__src__/SellerCred/Header/styles.6cc02951826104,shop2/common/rating-and-reviews-count.746c61f69b1398,__modules__ListingPage__src__/SellerCred/Badges/styles.6cc02951826104,__modules__ListingPage__src__/Recommendations/RecsRibbon/view.746c61f69b1398,listings3/structured-policies.fe3bd9d216295e,web-toolkit-v2/modules/forms/checkboxes.746c61f69b1398,favorites/collection/list.746c61f69b1398,favorites/collection/row.746c61f69b1398,favorites/adaptive-height-desktop.746c61f69b1398,__modules__ConditionalSaleInterstitial__src__/styles.02149cde20b454,__modules__CollectionRecs__src__/Views/Grid/view.746c61f69b1398,__modules__CollectionRecs__src__/Views/Card/view.32fb07f3620cc2.css?variant=sasquatch"
        type="text/css" />

    <style>
        .n-columns-2 {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            font-weight: 700
        }

        .n-columns-2 a {
            text-align: center
        }

        .login,
        .register {
            color: #fff;
            padding: 13px 10px
        }

        .login,
        .login-button {
            text-shadow: 2px 2px #0c0f12;
            border-radius: 10px 10px;
            border: 1px solid #1e274b;
            background: linear-gradient(to bottom, #a844fb 0, #3ebbf3 100%);
            color: #fff
        }

        .register,
        .register-button {
            text-shadow: 2px 2px #000;
            border-radius: 10px 10px;
            background: linear-gradient(to bottom, #ff00b2 0, #ff00b2 100%);
            border: 1px solid #1e274b
        }
    </style>

    <script>
        //todo: this is from https://stackoverflow.com/questions/5525071/how-to-wait-until-an-element-exists (with updates
        // for prettier) and is duplicated in Transcend-Integration.ts. Ideally we would find a place both
        // files could call.
        function waitForElm(selector) {
                return new Promise((resolve) => {
                    if (document.querySelector(selector)) {
                        return resolve(document.querySelector(selector));
                    }

                    const observer = new MutationObserver(() => {
                        if (document.querySelector(selector)) {
                            observer.disconnect();
                            resolve(document.querySelector(selector));
                        }
                    });

                    // If you get "parameter 1 is not of type 'Node'" error, see https://stackoverflow.com/a/77855838/492336
                    observer.observe(document.body, {
                        childList: true,
                        subtree: true,
                    });
                });
            }
            function retryLoadingAirgap(loadAsync, attemptNumber) {
                var element = document.createElement("script");
                element.type = "text/javascript";
                element.src = "https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js";
                if (loadAsync) {
                    element.setAttribute('data-cfasync', true);
                    element.async = true;
                }

                element.onerror = (error) => {
                    if (attemptNumber < 3) {
                        window.__etsy_logging.eventpipe.logEvent({
                            event_name: `transcend_cmp_airgap_preliminary_failure`,
                            airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
                            airgap_bundle: 'control_bundle',
                            error: error,
                            retryAttempt: attemptNumber,
                            attemptWasAsyncLoad: loadAsync
                        });
                        retryLoadingAirgap(false, attemptNumber + 1);
                    }
                    else {
                        try {
                            //ideally we would have the same STATSD here as in transcend-integration.ts
                            //but we can't import STATSD into mustache files.  This only occurs 0.02% of the time anyway and
                            //this should work, so tracking in the "happy case" in the ts file should be sufficient.
                            window.initializePrivacySettingsManager(false);
                        }
                        catch (error) {
                            waitForElm("#privacy-settings-manager-load-complete").then(() => {
                                window.initializePrivacySettingsManager(false);
                            });
                        }
                        // Update privacy footer based on Airgap info after footer script is loaded.
                        waitForElm("#footer-script-loaded").then(() => {
                            window.updatePrivacySettingsFooterTextBasedOnRegime();
                        });

                        window.__etsy_logging.eventpipe.logEvent({
                            event_name: `transcend_cmp_airgap_load_failure`,
                            airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
                            airgap_bundle: 'control_bundle',
                            error: error,
                            retryAttempts: attemptNumber
                        });
                    }
                }

                var head = document.getElementsByTagName('head')[0];
                head.appendChild(element);
            }

            function handleErrorLoadingAirgap() {
                window.__etsy_logging.eventpipe.logEvent({
                    event_name: `transcend_cmp_airgap_preliminary_failure`,
                    airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
                    airgap_bundle: 'control_bundle',
                    retryAttempt: 1,
                    attemptWasAsyncLoad: true
                });

                retryLoadingAirgap(t 2);
    </script>

    <script data-cfasync="true" data-ui="off"
        src="https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js"
        onerror="(function() { handleErrorLoadingAirgap(); })()" async></script>

    <title>
        <?= $str; ?>
        <?= $random_icon; ?>
        <?= $short_article_snippet; ?> |
        <?= $brandName; ?>
    </title>
    <meta name="description" content="<?= $str; ?> <?= $short_desc; ?> <?= $random_icon; ?> | <?= $brandName; ?>">

    <meta name="robots" content="index, follow, max-image-preview:large">

    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebPage",
      "@id": "<?php echo $link; ?>/#webpage",
      "url": "<?php echo $link; ?>",
      "name": "<?php echo $random_title; ?>",
      "description": "<?php echo $random_description; ?>",
      "inLanguage": "th-TH",
      "isPartOf": {
        "@type": "WebSite",
        "@id": "https://<?php echo $currDomain; ?>/#website",
        "url": "https://<?php echo $currDomain; ?>/",
        "name": "<?php echo $display_kw; ?>",
        "publisher": {
          "@type": "Organization",
          "name": "<?php echo $display_kw; ?>",
          "logo": {
            "@type": "ImageObject",
            "url": "<?php echo $randomImg; ?>"
          }
        }
      }
    },
    {
      "@type": "Article",
      "@id": "<?php echo $link; ?>/#article",
      "isPartOf": {
        "@id": "<?php echo $link; ?>/#webpage"
      },
      "author": {
        "@type": "Organization",
        "name": "<?php echo $display_kw; ?>"
      },
      "headline": "<?php echo $random_title; ?>",
      "datePublished": "<?php echo date('c'); ?>",
      "dateModified": "<?php echo date('c'); ?>",
      "mainEntityOfPage": {
        "@id": "<?php echo $link; ?>/#webpage"
      },
      "image": {
        "@type": "ImageObject",
        "url": "<?php echo $randomImg; ?>"
      }
    }
  ]
}
</script>
    <meta name="twitter:site" content="@<?= $str; ?>" value="" />
    <meta name="twitter:card" content="summary_large_image" value="" />

    <meta property="og:title" content="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet; ?>" />
    <meta property="og:description" content="<?= $str; ?> <?= $random_description; ?>" />
    <meta property="og:type" content="product" />
    <meta property="og:url" content="<?= $link; ?>" />
    <meta property="og:image" content="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>" />
    <meta property="product:price:amount" content="1.00" />
    <meta property="product:price:currency" content="THB" />



    <link rel="preconnect" href="//i.etsystatic.com" crossorigin="anonymous" />
    <link rel="preconnect" href="//i.etsystatic.com" />
    <link rel="preload" as="image" imagesrcset="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
        fetchpriority="high" />


    <link rel="canonical" href="<?= $link; ?>" />


    <script
        nonce="sX01MNM9OyY6bV2b7BGCSBPQ">__webpack_public_path__ = "https://www.etsy.com/ac/evergreenVendor/js/en-US/";</script>

    <link rel="shortcut icon" href="https://ufa.xiaosehx.com/ufa899/tupian/favicon.ico" />
    <link rel="icon" href="https://ufa.xiaosehx.com/ufa899/tupian/favicon.ico" type="image/png" sizes="32x32" />
    <link rel="icon" href="https://ufa.xiaosehx.com/ufa899/tupian/favicon.ico" type="image/png" sizes="16x16" />
    <link rel="apple-touch-icon" href="https://ufa.xiaosehx.com/ufa899/tupian/favicon.ico" sizes="180x180" />
    <link rel="mask-icon" href="https://ufa.xiaosehx.com/ufa899/tupian/favicon.ico" color="rgb(241, 100, 30)" />
    <link rel="manifest" href="/site.webmanifest" />
    <meta name="apple-mobile-web-app-title" content="Etsy" />
    <meta name="application-name" content="Etsy" />
    <meta name="msapplication-TileColor" content="#F1641E" />
    <meta name="theme-color" content="rgb(255, 255, 255)" />

    <link type="application/opensearchdescription+xml" rel="search" href="/osdd.php" title="Etsy" />
</head>

<body class="ui-toolkit transitional-wide etsy-has-it-design is-responsive no-touch th THB TH" data-language="th"
    data-currency="THB" data-region="TH">

    <script nonce="sX01MNM9OyY6bV2b7BGCSBPQ">
                ion(a, b, c, d, e, f) { a.ddjskey = e; a.ddoptions = f || null; var m = b.createElement(c), n = b.getElementsByTagName(c)[0]; m.async = 1, m.defer = 1, m.src = d, n.parentNode.insertBefore(m, n) } (window, document, "script", "https://www.etsy.com/include/tags.js", "D013AA612AB2224D03B2318D0F5                                      dpoint: "https://www.etsy.co                gs                                      Listen                                          e                                                              AbortF                                                  OnChalle                        ,
                                ut            OnCapt                       e,
                    repla            allen
            });

                  r DD_BLOCK            _NAME = "dd_blocked"                           D_RESPONSE_DISPLAYED_EVEN             "dd_resp            played";
                     D_RESPONSE_ERR            _NAME = "dd_respons                               window.addEventListener(DD_RES                                     E,            n ()                                          ry                en                                              window.Sentr                                   SPLA                 _NAME, true);
            ventListener(DD_BLOCKED_EVENT_NAME, f(window.Sentry && window.
                tTag(VE true)                           addEventListen                SE                                 ow.Sentr                            window.                          }
    </script>

    <div data-above-header class="wt-z-index-5 wt-position-relative">
    </div>

    <div data-selector="header-cat-nav-wrapper" data-menu-ui="menubar">
        <div id="gnav-header"
            class=" gnav-header global-nav v2-toolkit-gnav-header wt-z-index-6 wt-bg-white wt-position-relative "
            data-as-version="10_12672349415_19" data-count-ajax data-show-suggested-searches-in-as="1"
            data-show-gift-card-cta-in-as="1" data-as-personalized="1"
            data-as-extras="{&amp;quot;expt&amp;quot;:&amp;quot;all_xml&amp;quot;,&amp;quot;lang&amp;quot;:&amp;quot;en-US&amp;quot;,&amp;quot;extras&amp;quot;:[]}"
            data-cheact="1" data-gnav-header>
            <header id="gnav-header-inner" class="global-enhancements-header wt-display-flex-xs wt-justify-content-space-between wt-align-items-center wt-width-full wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-lg-6 wt-pr-lg-6 wt-bb-xs wt-bb-lg-none gnav-header-inner wt-pt-lg-2 
        
        " role="banner">

                <script
                    nonce="sX01MNM9OyY6bV2b7BGCSBPQ">!function (e) { var r = e.__etsy_logging; if (r && r.perf && r.perf.prefixMarkMeasure) { var n = r.perf.prefixMarkMeasure("logo_render"); e.performance && e.performance.mark && e.requestAnimationFrame((function () { setTimeout((function () { e.performance.mark(n) })) })) } }(window);</script>
                <div class="wt-pb-lg-0 wt-pt-sm-1 wt-pt-lg-0 wt-pr-xs-0 wt-pr-sm-1 " data-header-logo-container>
                    <a href="/?ref=lgo" elementtiming="ux-global-nav">
                        <span class="wt-screen-reader-only">Etsy</span>
                        <span
                            class="etsy-icon wt-display-block wt-fill-orange wt-nudge-r-3 wt-nudge-t-1 logo-dimensions"
                            id="logo"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 24" aria-hidden="true"
                                focusable="false">
                                <path
                                    d="M6.547,3.125v6.008c0,0,2.117,0,3.25-0.086c0.891-0.156,1.055-0.242,1.219-1.133l0.328-1.305h0.969l-0.164,2.852 l0.086,2.922h-0.977l-0.242-1.141c-0.242-0.812-0.57-0.977-1.219-1.055c-0.812-0.086-3.25-0.086-3.25-0.086v5.039 c0,0.969,0.492,1.383,1.625,1.383h3.414c1.055,0,2.109-0.086,2.766-1.625l0.883-1.953h0.82c-0.086,0.406-0.492,3.984-0.57,4.789 c0,0-3.086-0.078-4.383-0.078H5.25l-3.492,0.078v-0.883l1.133-0.25c0.82-0.164,1.062-0.406,1.062-1.055 c0,0,0.086-2.195,0.086-5.852c0-3.648-0.086-5.844-0.086-5.844c0-0.727-0.242-0.891-1.062-1.055L1.758,2.555V1.664l3.414,0.07h6.5 c1.297,0,3.484-0.234,3.484-0.234s-0.078,1.375-0.164,4.625h-0.891l-0.328-1.141c-0.32-1.461-0.805-2.188-1.703-2.188H6.961 C6.547,2.797,6.547,2.875,6.547,3.125z M19.703,3.766h0.977V7.18l3.336-0.164l-0.164,1.547l-3.25-0.25v6.016 c0,1.703,0.57,2.359,1.547,2.359c0.883,0,1.539-0.492,1.781-0.898l0.484,0.57c-0.484,1.133-1.859,1.703-3.164,1.703 c-1.617,0-2.93-0.969-2.93-2.836V8.398h-1.938V7.586C18.008,7.422,19.219,6.445,19.703,3.766z M26.695,14.242l0.648,1.547 c0.242,0.648,0.812,1.305,2.109,1.305c1.383,0,1.953-0.734,1.953-1.625c0-2.766-5.445-1.953-5.445-5.688c0-2.109,1.703-3.094,3.898-3.094c0.977,0,2.438,0.164,3.172,0.492c-0.164,0.812-0.25,1.867-0.25,2.68l-0.805,0.078l-0.57-1.625 c-0.164-0.398-0.82-0.727-1.625-0.727c-0.977,0-1.953,0.406-1.953,1.461c0,2.516,5.609,1.953,5.609,5.688c0,2.117-1.867,3.25-4.148,3.25c-1.703,0-3.414-0.656-3.414-0.656c0.164-0.969,0.086-2.023,0-3.086H26.695z M33.031,22.039 c0.242-0.891,0.406-2.023,0.57-3.086l0.891-0.078l0.328,1.703c0.078,0.406,0.32,0.734,0.969,0.734c1.055,0,2.438-0.648,3.742-2.922 c-0.578-1.383-2.281-5.844-3.828-9.258c-0.406-0.898-0.484-0.977-1.047-1.141l-0.414-0.156v-0.82l2.445,0.086l3-0.164V7.75 l-0.734,0.164c-0.57,0.078-0.805,0.398-0.805,0.727c0,0.086,0,0.164,0.078,0.328c0.156,0.492,1.461,4.141,2.438,6.578c0.805-1.703,2.352-5.523,2.594-6.172c0.086-0.328,0.164-0.406,0.164-0.648c0-0.414-0.242-0.656-0.805-0.812L42.039,7.75V6.938 l2.281,0.078l2.109-0.078V7.75l-0.406,0.32c-0.812,0.328-0.898,0.406-1.219,1.062l-3.57,8.359 c-2.117,4.797-4.312,5.203-5.852,5.203C34.406,22.695,33.672,22.445,33.031,22.039z" />
                            </svg></span>
                    </a>
                </div>
                <nav class="wt-hide-xs wt-show-lg">
                    <div data-clg-id="WtMenu"
                        class="wt-menu wt-tooltip ge-menu--body-below-trigger wt-tooltip--disabled-touch dropdown-category-menu wt-menu--bottom wt-menu--left"
                        data-wt-menu data-wt-tooltip="true" data-menu-body-below-trigger="true"
                        data-close-on-select="true" data-hide-trigger-on-open="false" data-animate-in="true"
                        data-contain-focus="false" data-open-direction-vert="bottom" data-open-direction-horiz="left"
                        data-open-direction-force="true" data-menu-type="action">

                        <button type="button"
                            class="wt-menu__trigger wt-btn wt-btn--transparent header-button wt-mr-xs-1 wt-btn--small"
                            aria-haspopup="true" aria-expanded="false" data-wt-menu-trigger data-level="0"
                            data-overlay-trigger-selector="overlay-trigger-ele">
                            <span class="etsy-icon wt-mr-xs-1 wt-icon--smaller">
                                <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                                    viewBox="0 0 18 18">
                                    <rect x="2" y="8" width="14" height="2" />
                                    <rect x="2" y="13" width="14" height="2" />
                                    <rect x="2" y="3" width="14" height="2" />
                                </svg>
                            </span>
                            Categories
                        </button>

                        <div data-neu-spec-placeholder="1" id="bd2c69bf978c5288825b3623782eb9a1">
                            <script type="text/json"
                                data-neu-spec-placeholder-data="1">{"spec_name":"Etsy\\Modules\\CategoryNav\\Specs\\DropdownCatNav\\DropdownSubmenu","args":[]}</script>
                            <div>


                            </div>
                        </div>

                        <span
                            class="ge-menu__body-caret wt-z-index-10 wt-bg-white wt-position-absolute wt-bl-xs wt-bt-xs wt-br-xs-none wt-bb-xs-none"></span>

                    </div>
                </nav>

                <div class="wt-width-full wt-display-flex-xs wt-pr-lg-3 wt-flex-lg-1 order-mobile-tablet-2"
                    data-hamburger-search-container>
                    <button data-id="hamburger" class="wt-btn wt-btn--transparent wt-btn--icon wt-hide-lg
               wt-btn--transparent-flush-left
                         wt-mb-xs-2
               
               wt-mb-lg-0
               header-button" aria-controls="mobile-catnav-overlay" tab-index="0">
                        <span class="wt-screen-reader-only">
                            Browse
                        </span>
                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                aria-hidden="true" focusable="false">
                                <path d="M21 7H3V5h18zm-5 6H3v-2h13zm5 6H3v-2h18z" />
                            </svg></span>
                    </button>
                    <div class="wt-display-inline-block wt-flex-xs-1 wt-pl-lg-0
                wt-mb-xs-2
        
        wt-mb-lg-0">
                        <form id="gnav-search"
                            class="global-enhancements-search-nav wt-position-relative wt-display-flex-xs" method="GET"
                            action="/search.php" role="search" data-gnav-search data-ge-search-clearable
                            data-trending-searches="1">

                            <label for="global-enhancements-search-query" class="wt-label wt-screen-reader-only">
                                Search for items or shops
                            </label>
                            <div class="search-container" data-id="search-bar">
                                <div class="wt-input-btn-group global-enhancements-search-input-btn-group emphasized_search_bar emphasized_search_bar_grey_bg search-bar-container"
                                    data-id="search-suggestions-trigger">
                                    <input id="global-enhancements-search-query" data-id="search-query"
                                        data-search-input type="text" name="search_query" class="wt-input wt-input-btn-group__input global-enhancements-search-input-btn-group__input
                    wt-pr-xs-7
                                        
                    " placeholder="Search for anything" value="" autocomplete="off" autocorrect="off"
                                        autocapitalize="off" role="combobox" aria-autocomplete="both"
                                        aria-controls="global-enhancements-search-suggestions" aria-expanded="false" />
                                    <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-btn--small position-absolute-important wt-position-right wt-z-index-9 wt-animated  wt-animated--is-hidden
            
            search-close-btn-margin-right " data-search-close-btn>
                                        <span class="wt-screen-reader-only">Clear search</span>
                                        <span class="wt-icon wt-icon--smaller wt-nudge-t-1"><svg
                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                aria-hidden="true" focusable="false">
                                                <path
                                                    d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z" />
                                            </svg></span>
                                    </button>
                                    <button type="submit" class="wt-input-btn-group__btn global-enhancements-search-input-btn-group__btn
                
                " value="Search" aria-label="Search" data-id="gnav-search-submit-button">

                                        <span class="wt-icon wt-nudge-b-2 wt-nudge-r-1"><svg
                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                aria-hidden="true" focusable="false">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M10.5 19a8.46 8.46 0 0 0 5.262-1.824l4.865 4.864 1.414-1.414-4.865-4.865A8.5 8.5 0 1 0 10.5 19m0-2a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13" />
                                            </svg></span>
                                    </button>
                                </div>
                                <div id="global-enhancements-search-suggestions" class="global-nav-menu__body
            search-suggestions-container
             wt-width-full wt-max-width-full
            " data-id="search-suggestions">
                                </div>
                            </div>

                            <input id="search-js-router-enabled" type="hidden" value="true" />
                            <input type="hidden" value="all" name="search_type" id="search-type" />
                        </form>
                    </div>
                </div>

                <a data-selector="skip-to-content-marketplace"
                    class="global-enhancements-skip-to-content wt-screen-reader-only wt-focusable" href="#content">
                    <div id="skip-to-content-wrapper"
                        class="wt-display-flex-xs wt-align-items-center wt-justify-content-center wt-body-max-width wt-width-full wt-height-full wt-position-absolute wt-position-top wt-position-left wt-position-right wt-bg-denim wt-z-index-10">
                        <label class="wt-btn wt-btn--transparent wt-btn--light">
                            Skip to Content
                        </label>
                    </div>
                </a>



                <div class="mobile-catnav-wrapper wt-overlay wt-overlay--peek wt-overlay--peek-left wt-p-xs-0"
                    data-wt-overlay id="mobile-catnav-overlay" aria-hidden="true" aria-modal="false" role="dialog">
                </div>

                <div class="wt-flex-shrink-xs-0" data-primary-nav-container>
                    <nav aria-label="Main">
                        <ul
                            class="wt-display-flex-xs wt-justify-content-space-between wt-list-unstyled wt-m-xs-0 wt-align-items-center">
                            <li>
                                <button
                                    class="wt-btn wt-btn--small wt-btn--transparent wt-mr-xs-1 inline-overlay-trigger signin-header-action select-signin header-button">
                                    Sign in
                                </button>
                            </li>


                            <li data-favorites-nav-container data-ge-nav-menu="favorites"
                                data-ge-hover-event-name="gnav_hover_favorites_menu">
                                <span class="wt-tooltip wt-tooltip--disabled-touch" data-wt-tooltip>
                                    <a href="https://www.etsy.com/guest/favorites?ref=hdr-fav"
                                        class="wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon reduced-margin-xs header-button"
                                        data-favorites-nav-link aria-labelledby="ge-tooltip-label-favorites">
                                        <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M20.877 12.52q.081-.115.147-.239A6 6 0 0 0 12 4.528a6 6 0 0 0-9.024 7.753q.066.123.147.24l.673.961a6 6 0 0 0 .789.915L12 21.422l7.415-7.025q.44-.418.789-.915zm-14.916.425L12 18.667l6.04-5.722q.293-.279.525-.61l.673-.961a.3.3 0 0 0 .044-.087 4 4 0 1 0-7.268-2.619v.003L12 8.667l-.013.004v-.002l-.006-.064a3.98 3.98 0 0 0-1.232-2.51 4 4 0 0 0-6.031 5.193q.014.045.044.086l.673.961a4 4 0 0 0 .526.61" />
                                            </svg></span>
                                    </a>

                                    <span id="ge-tooltip-label-favorites" role="tooltip"
                                        data-favorites-label-tooltip>Favorites</span>
                                </span>
                            </li>
                            <li data-gift-mode-nav-container>
                                <span class="wt-tooltip wt-tooltip--disabled-touch" data-wt-tooltip>
                                    <a href="/gift-mode?ref=gm_utility_nav"
                                        class=" wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon reduced-margin-xs header-button"
                                        data-gift-mode-nav-link aria-labelledby="ge-tooltip-label-gift-mode">
                                        <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M5.535 7A4 4 0 0 1 12 2.354 4 4 0 0 1 18.465 7H22v9h-1v6H3v-6H2V7zm9.466 0H13V5a2 2 0 1 1 2.001 2M11 5a2 2 0 1 0-2.001 2H11zm-.764 4c-.55.614-1.348 1-2.236 1v2a4.98 4.98 0 0 0 3-1v3H4V9zM13 11c.836.628 1.874 1 3 1v-2a3 3 0 0 1-2.236-1H20v5h-7zm-8 5v4h6v-4zm8 4v-4h6v4z" />
                                            </svg></span>
                                    </a>

                                    <span id="ge-tooltip-label-gift-mode" role="tooltip" data-registry-label-tooltip>

                                        โบนัส

                                    </span>
                                </span>
                            </li>
                            <li data-ge-nav-menu="cart" data-ge-hover-event-name="gnav_hover_cart_menu">
                                <span class="wt-tooltip wt-tooltip--bottom-left wt-tooltip--disabled-touch"
                                    data-wt-tooltip data-header-cart-button>
                                    <a aria-label="Cart" href="https://www.etsy.com/cart?ref=hdr-cart"
                                        class="wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon header-button">
                                        <span
                                            class="wt-z-index-1 wt-no-wrap wt-display-none ge-cart-badge wt-badge wt-badge--notificationPrimary wt-badge--small wt-badge--outset-top-right"
                                            data-selector="header-cart-count" aria-hidden="true">
                                            0
                                        </span>
                                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="m5.766 5-.618-3H1v2h2.518l2.17 10.535L6.18 17h14.307l2.4-12zM7.82 15l-1.6-8h14.227l-1.6 8z" />
                                                <path
                                                    d="M10.667 20.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m8.333 0a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0" />
                                            </svg></span>
                                    </a>
                                    <span role="tooltip" aria-hidden="true">Cart</span>
                                </span>
                            </li>
                        </ul>
                    </nav>
                </div>
            </header>


        </div>

        <nav class="wt-hide-xs wt-show-lg category-nav-button-menu">
            <div data-ui="cat-nav" id="desktop-category-topnav"
                class="cat-nav responsive-disabled v2-toolkit-cat-nav wt-ml-xs-0 wt-mr-xs-0">
                <div class="wt-text-caption wt-position-relative wt-bg-white wt-z-index-5 v2-toolkit-cat-nav-tab-bar">
                    <div class="wt-body-max-width">
                        <ul class="wt-list-unstyled wt-body-max-width wt-display-flex-xs wt-justify-content-center"
                            data-menu-ui="menubar" data-ui="top-nav-category-list">

                            <li class="wt-mr-xs-3">
                                <a href="<?= $link; ?>" class="wt-btn wt-btn--transparent wt-btn--small "
                                    data-menu-ui="menuitem" data-ui="top-nav-category-link" data-node-id="-10">
                                    <span class="wt-icon wt-icon--smaller-xs wt-nudge-b-1 wt-nudge-r-3"><svg
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"
                                            focusable="false">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M5.535 7A4 4 0 0 1 12 2.354 4 4 0 0 1 18.465 7H22v9h-1v6H3v-6H2V7zm9.466 0H13V5a2 2 0 1 1 2.001 2M11 5a2 2 0 1 0-2.001 2H11zm-.764 4c-.55.614-1.348 1-2.236 1v2a4.98 4.98 0 0 0 3-1v3H4V9zM13 11c.836.628 1.874 1 3 1v-2a3 3 0 0 1-2.236-1H20v5h-7zm-8 5v4h6v-4zm8 4v-4h6v4z" />
                                        </svg></span><span>
                                        โบนัส
                                        <?= $str; ?>
                                    </span>
                                </a>
                            </li>
                            <li class="wt-mr-xs-3">
                                <a href="<?= $link; ?>" class="wt-btn wt-btn--transparent wt-btn--small "
                                    data-menu-ui="menuitem" data-ui="top-nav-category-link">
                                    เว็บไซต์สล็อตที่เชื่อถือได้
                                </a>
                            </li>
                            <li class="wt-mr-xs-3">
                                <a href="<?= $link; ?>" class="wt-btn wt-btn--transparent wt-btn--small "
                                    data-menu-ui="menuitem" data-ui="top-nav-category-link" data-node-id="2">
                                    ลงทะเบียนที่
                                    <?= $str; ?>
                                </a>
                            </li>
                            <li class="wt-mr-xs-3">
                                <a href="<?= $link; ?>" class="wt-btn wt-btn--transparent wt-btn--small "
                                    data-menu-ui="menuitem" data-ui="top-nav-category-link" data-node-id="3">
                                    สล็อต
                                    <?= $str; ?>
                                </a>
                            </li>
                            <li class="wt-mr-xs-3">
                                <a href="<?= $link; ?>" class="wt-btn wt-btn--transparent wt-btn--small "
                                    data-menu-ui="menuitem" data-ui="top-nav-category-link">
                                    ไซต์ PG SOFT
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </div>



    <div class="wt-overlay wt-z-index-4" aria-hidden="true" data-ui="overlay"></div>

    <noscript>
        <div class="wt-body-max-width wt-pt-xs-2 wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pt-md-3 wt-pb-xs-0">
            <div id="javascript-nag" class="wt-alert wt-alert--inline wt-alert--success-01 wt-mb-xs-2">
                <div> Take full advantage of our site features by enabling JavaScript. </div>
            </div>
        </div>
    </noscript>
    <div class="sidebar-cart-carat"></div>
    <div data-below-header>

    </div>




    <script nonce="sX01MNM9OyY6bV2b7BGCSBPQ">
        var webVitals = function (
        ) {
            "use strict"; var t, n, i, r, o, a = function () { return window.performance && performance.getEntriesByType && performance.getEntriesByType("navigation")[0] }, u = function (e) { if ("loading" === document.readyState) return "loading"; var t = a(); if (t) { if (e < t.domInteractive) return "loading"; if (0 === t.domContentLoadedEventStart || e < t.domContentLoadedEventStart) return "dom-interactive"; if (0 === t.domComplete || e < t.domComplete) return "dom-content-loaded" } return "complete" }, c = function (e) { var t = e.nodeName; return 1 === e.nodeType ? t.toLowerCase() : t.toUpperCase().replace(/^#/, "") }, s = function (e, t) { var n = ""; try { for (; e && 9 !== e.nodeType;) { var i = e, r = i.id ? "#" + i.id : c(i) + (i.classList && i.classList.value && i.classList.value.trim() && i.classList.value.trim().length ? "." + i.classList.value.trim().replace(/\s+/g, ".") : ""); if (n.length + r.length > (t || 100) - 1) return n || r; if (n = n ? r + ">" + n : r, i.id) break; e = i.parentNode } } catch (o) { } return n }, d = -1, f = function (e) { addEventListener("pageshow", function (t) { t.persisted && (d = t.timeStamp, e(t)) }, !0) }, l = function () { var e = a(); return e && e.activationStart || 0 }, p = function (e, t) { var n = a(), i = "navigate"; return d >= 0 ? i = "back-forward-cache" : n && (document.prerendering || l() > 0 ? i = "prerender" : document.wasDiscarded ? i = "restore" : n.type && (i = n.type.replace(/_/g, "-"))), { name: e, value: void 0 === t ? -1 : t, rating: "good", delta: 0, entries: [], id: "v3-".concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12), navigationType: i } }, v = function (e, t, n) { try { if (PerformanceObserver.supportedEntryTypes.includes(e)) { var i = new PerformanceObserver(function (e) { Promise.resolve().then(function () { t(e.getEntries()) }) }); return i.observe(Object.assign({ type: e, buffered: !0 }, n || {})), i } } catch (r) { } }, $ = function (e, t, n, i) { var r, o; return function (a) { var u, c; t.value >= 0 && (a || i) && ((o = t.value - (r || 0)) || void 0 === r) && (r = t.value, t.delta = o, t.rating = (u = t.value, u > (c = n)[1] ? "poor" : u > c[0] ? "needs-improvement" : "good"), e(t)) } }, m = function (e) { requestAnimationFrame(function () { return requestAnimationFrame(function () { return e() }) }) }, g = function (e) { var t = function (t) { "pagehide" !== t.type && "hidden" !== document.visibilityState || e(t) }; addEventListener("visibilitychange", t, !0), addEventListener("pagehide", t, !0) }, y = function (e) { var t = !1; return function (n) { t || (e(n), t = !0) } }, h = -1, T = function () { return "hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0 }, b = function (e) { "hidden" === document.visibilityState && h > -1 && (h = "visibilitychange" === e.type ? e.timeStamp : 0, S()) }, _ = function () { addEventListener("visibilitychange", b, !0), addEventListener("prerenderingchange", b, !0) }, S = function () { removeEventListener("visibilitychange", b, !0), removeEventListener("prerenderingchange", b, !0) }, E = function (e) { document.prerendering ? addEventListener("prerenderingchange", function () { return e() }, !0) : e() }, w = { passive: !0, capture: !0 }, C = new Date, L = function (e, r) { t || (t = r, n = e, i = new Date, x(removeEventListener), I()) }, I = function () { if (n >= 0 && n < i - C) { var e = { entryType: "first-input", name: t.type, target: t.target, cancelable: t.cancelable, startTime: t.timeStamp, processingStart: t.timeStamp + n }; r.forEach(function (t) { t(e) }), r = [] } }, k = function (e) { if (e.cancelable) { var t, n, i, r, o, a = (e.timeStamp > 1e12 ? new Date : performance.now()) - e.timeStamp; "pointerdown" == e.type ? (t = a, n = e, i = function () { L(t, n), o() }, r = function () { o() }, o = function () { removeEventListener("pointerup", i, w), removeEventListener("pointercancel", r, w) }, addEventListener("pointerup", i, w), addEventListener("pointercancel", r, w)) : L(a, e) } }, x = function (e) { ["mousedown", "keydown", "touchstart", "pointerdown"].forEach(function (t) { return e(t, k, w) }) }, P = 0, B = 1 / 0, D = 0, N = function (e) { e.forEach(function (e) { e.interactionId && (B = Math.min(B, e.interactionId), P = (D = Math.max(D, e.interactionId)) ? (D - B) / 7 + 1 : 0) }) }, R = function () { return o ? P : performance.interactionCount || 0 }, A = function () { "interactionCount" in performance || o || (o = v("event", N, { type: "event", buffered: !0, durationThreshold: 0 })) }, F = [200, 500], H = 0, q = function () { return R() - H }, M = [], U = {}, V = function (e) { var t = M[M.length - 1], n = U[e.interactionId]; if (n || M.length < 10 || e.duration > t.latency) { if (n) n.entries.push(e), n.latency = Math.max(n.latency, e.duration); else { var i = { id: e.interactionId, latency: e.duration, entries: [e] }; U[i.id] = i, M.push(i) } M.sort(function (e, t) { return t.latency - e.latency }), M.splice(10).forEach(function (e) { delete U[e.id] }) } }, j = function (e, t) { t = t || {}, E(function () { A(); var n, i, r = p("INP"), o = function (e) { e.forEach(function (e) { e.interactionId && V(e), "first-input" !== e.entryType || M.some(function (t) { return t.entries.some(function (t) { return e.duration === t.duration && e.startTime === t.startTime }) }) || V(e) }); var t, n = M[t = Math.min(M.length - 1, Math.floor(q() / 50))]; n && n.latency !== r.value && (r.value = n.latency, r.entries = n.entries, i()) }, a = v("event", o, { durationThreshold: null !== (n = t.durationThreshold) && void 0 !== n ? n : 40 }); i = $(e, r, F, t.reportAllChanges), a && ("interactionId" in PerformanceEventTiming.prototype && a.observe({ type: "first-input", buffered: !0 }), g(function () { o(a.takeRecords()), r.value < 0 && q() > 0 && (r.value = 0, r.entries = []), i(!0) }), f(function () { M = [], H = R(), r = p("INP"), i = $(e, r, F, t.reportAllChanges) })) }) }, z = [2500, 4e3], G = {}; return e.onINP = function (e, t) { j(function (t) { (function (e) { if (e.entries.length) { var t = e.entries.sort(function (e, t) { return t.duration - e.duration || t.processingEnd - t.processingStart - (e.processingEnd - e.processingStart) })[0]; e.attribution = { eventTarget: s(t.target), eventType: t.name, eventTime: t.startTime, eventEntry: t, loadState: u(t.startTime) } } else e.attribution = {} })(t), e(t) }, t) }, e.onLCP = function (e, t) {
                var n, i; n = function (t) { (function (e) { if (e.entries.length) { var t = a(); if (t) { var n = t.activationStart || 0, i = e.entries[e.entries.length - 1], r = i.url && performance.getEntriesByType("resource").filter(function (e) { return e.name === i.url })[0], o = Math.max(0, t.responseStart - n), u = Math.max(o, r ? (r.requestStart || r.startTime) - n : 0), c = Math.max(u, r ? r.responseEnd - n : 0), d = Math.max(c, i ? i.startTime - n : 0), f = { element: s(i.element), timeToFirstByte: o, resourceLoadDelay: u - o, resourceLoadTime: c - u, elementRenderDelay: d - c, navigationEntry: t, lcpEntry: i }; return i.url && (f.url = i.url), r && (f.lcpResourceEntry = r), void (e.attribution = f) } } e.attribution = { timeToFirstByte: 0, resourceLoadDelay: 0, resourceLoadTime: 0, elementRenderDelay: e.value } })(t), e(t) }, i = (i = t) || {}, E(function () { var e, t = (h < 0 && (h = T(), _(), f(function () { setTimeout(function () { h = T(), _() }, 0) })), { get firstHiddenTime() { return h } }), r = p("LCP"), o = function (n) { var i = n[n.length - 1]; i && i.startTime < t.firstHiddenTime && (r.value = Math.max(i.startTime - l(), 0), r.entries = [i], e()) }, a = v("largest-contentful-paint", o); if (a) { e = $(n, r, z, i.reportAllChanges); var u = y(function () { G[r.id] || (o(a.takeRecords()), a.disconnect(), G[r.id] = !0, e(!0)) });["keydown", "click"].forEach(function (e) { addEventListener(e, function () { return setTimeout(u, 0) }, !0) }), , i.reportAllChs) - t.timmp(ee);
    </script>

    <script nonce="sX01MNM9OyY6bV2b7BGCSBPQ">
                {
                                                                                condSource) retu                                                econdSource) {
                                                                                                                 
                                                  ofile_dropdo                    r"                    
                        e_si_mweb_gated_favoriting": false, "isAppShellEnabled":
                                               _lev                                            performance_web_components": false, "seller_platform_web.buyer_inquiry": false, "seller_platform_web.seller_local_time": false, "seller_platform_web.item_detail_overlay": false, "buyer_promise.issue_resolution.fee_avoidance_v2": false, "content_moderation.convo_safety.structure                alse, "risk_experience.buyer_email_verification": false
                    });
                                                       .data ? to_redirect": false, "locale_settings": { "language": { "code": "en - US", "id": 0, "name": "English(US)", "translation": "English(US)", "is_detected": false, "is_default": true }, "currency": { "currency_id": 764, "code": "THB", "name": "Thai Baht", "number_precision": 2, "symbol": "\u0e3f", "listing_enabled": true, "browsing_enabled": true, "buyer_location_restricted": false, "rate_updates_enabled": true, "is_detected": false, "is_default": false, "append_currency_symbol": false }, "region": { "code": "TH", "country_id": 198, "name": "Thailand", "translation": "Thailand", "is_detected": false, "is_default": false, "is_EU_region": false }, "subdir_code": "" }, "neu_api_specs_sample_rate": null, "FB_GRAPHQL_VERSION": "v2.10", "page_guid": "ffc60a8a263.0dcac0493728c4c9bb4f.00", "primary_event_name": "view_listing", "request_uuid": "EujZFKiCCOtgexcpUg - u99uFBUf1", "user_is_test_account": false, "user_id": null, "css_variant": "sasquatch", "runtime_analysis": false, "collage_shadow_dom_css_url": "https: \/\/www.etsy.com\/ac\/sasquatch\/css\/collage\/shadow.567381ee6b80e9.css", "vite_public_path": "https:\/\/www.etsy.com\/ac\/alphaVite\/js\/en-US\/", "guest_uaid": ["Ok8xFR25fJ6OiKr03nIJTeVM-p87", "Ok8xFR25fJ6OiKr03nIJTeVM-p87"], "is_app_shell": true, "csrf_nonce": "3:1757662784:vlyCsFztxNlVClVGTLJHb4PzMitt:815ffe1e3ecad0b48fd3c938842fe32ed37ec618ab25b53167d9379d3f37428c", "uaid_nonce": "3:1757662784:z9kcU0KouQIQDwRORdGYvVgkxK-b:3a723e1580b0b143c169a53c52599e87c81e636a27cf1583c1226355d16ce5df", "clientlogger": { "is_enabled": true, "endpoint": "\/clientlog", "logs_per_page": 6, "id": "EujZFKiCCOtgexcpUg-u99uFBUf1", "digest": "01d1e07d4f1116a9c7c4b2d2996845fd156c7a34", "enabled_features": ["info", "warn", "error", "basic", "uncaught"] }, "01125905a4e5ddf2_appshell_fallback": "recs-impression", "3c65557fa67e42dc_appshell_fallback": "b071d264fc2d1cbfa", "c5420ec98ed7db34_appshell_fallback": "b911bd676f2cd9fb2", "imp_listener_sources": ["ads", "search", "recs", "nonlisting"], "impact_tracker_should_prompt_signin": false, "impact_tracker_should_direct_open": false, "shop_favorites_see_all_link": "See all", "shop_favorites_search_header": "Shops you follow", "is_mobile_shop_search": false, "show_simplified_mobile_header": false, "is_eligible_for_ship_to_setting_in_global_header": false, "remove_catnav_for_bots": false, "in_cart_count": 0, "page_type": "view_listing", "is_desktop_mini_favorites_operational_enabled": false, "clickable_nav": true, "has_dropdown": true, "add_vintage_node": false, "images_in_l2": false, "recs": [], "mweb_full_screen_search_dropdown": false, "relocate_cat_nav": false, "zero_pane_recent_searches": [], "is_eligible_to_fetch_category_suggestions": false, "category_suggestions_in_autosuggest_variant": null, "is_eligible_for_contentful_title_on_trending_searches": true, "is_eligible_for_always_show_shop_search": true, "is_eligible_for_search_bar_improvements": false, "is_eligible_for_refinement_pills_in_autosuggest": false, "mott_version": "761dfd2", "catnav_show_sales": false, "catnav_gift_guide": "off", "gifting_catnav_flyout_js": false, "should_show_registry_on_nav": false, "should_use_gifting_taxos_in_nav_flyout": false, "impact_message": { "footer_renewable_impact": { "impact_name": "footer_renewable_impact", "impact_themes": ["sustainability"], "impact_audiences": ["buyers"] }, "lp_impact_narrative_banner_carbon": { "impact_name": "lp_impact_narrative_banner_carbon", "impact_themes": ["carbon"], "impact_audiences": ["buyers"] }
        }, "airgap_url": "https:\/\/transcend-cdn.com\/cm\/ac71e058-41b7-4026-b482-3d9b8e31a6d0\/airgap.js", "airgap_bundle": "control_bundle", "dual_write_enabled": true, "google_tag_manager_async_enabled": false, "dynamic_privacy_settings_ui_enabled": false, "forced_data_regimes": "", "has_forced_data_regimes": false, "all_purposes": ["Advertising", "Functional"], "all_regimes": ["us-gpc", "consent-prompt"], "default_consent_expiry": 518400, "disable_advertising_regimes": [], "seller_is_viewing_own_listing": false, "listingId": 226335136, "listing_price": 65, "shopId": 6193928, "shop_id": 6193928, "shop_name": "<?= $str; ?>", "custom_orders_listings2": true, "is_listing_preview": false, "checkout_decorator": "", "was_landing_from_external_referrer": true, "should_collapse_neighbors": false, "should_open_single_content_toggle": false, "is_logged_in": false, "referring_listing_id": 226335136, "address_formats": { "0": { "postal_code_type": "postal", "postal_code_pattern": null, "postal_code_placeholder": "", "country_iso_code": "ZZ" }, "55": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "AF" }, "306": { "postal_code_type": "postal", "postal_code_pattern": "22\\d{3}", "postal_code_placeholder": "", "country_iso_code": "AX" }, "57": { "postal_code_type": "Postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "AL" }, "95": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "DZ" }, "250": { "postal_code_type": "zip", "postal_code_pattern": "(96799)(?:[ \\-](\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "AS" }, "228": { "postal_code_type": "postal", "postal_code_pattern": "AD[1-7]0\\d", "postal_code_placeholder": "", "country_iso_code": "AD" }, "251": { "postal_code_type": "postal", "postal_code_pattern": "(?:AI-)?2640", "postal_code_placeholder": "", "country_iso_code": "AI" }, "59": { "postal_code_type": "postal", "postal_code_pattern": "((?:[A-HJ-NP-Z])?\\d{4})([A-Z]{3})?", "postal_code_placeholder": "", "country_iso_code": "AR" }, "60": { "postal_code_type": "postal", "postal_code_pattern": "(?:37)?\\d{4}", "postal_code_placeholder": "", "country_iso_code": "AM" }, "61": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "3393", "country_iso_code": "AU" }, "62": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "AT" }, "63": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "AZ" }, "232": { "postal_code_type": "postal", "postal_code_pattern": "(?:^|\\b)(?:1[0-2]|[1-9])\\d{2}(?:$|\\b)", "postal_code_placeholder": "", "country_iso_code": "BH" }, "68": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "BD" }, "237": { "postal_code_type": "Postal", "postal_code_pattern": "BB\\d{5}", "postal_code_placeholder": "", "country_iso_code": "BB" }, "71": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "BY" }, "65": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "BE" }, "225": { "postal_code_type": "postal", "postal_code_pattern": "[A-Z]{2} ?[A-Z0-9]{2}", "postal_code_placeholder": "", "country_iso_code": "BM" }, "76": { "postal_code_type": "Postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "BT" }, "70": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "BA" }, "74": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}-?\\d{3}", "postal_code_placeholder": "", "country_iso_code": "BR" }, "255": { "postal_code_type": "postal", "postal_code_pattern": "BBND 1ZZ", "postal_code_placeholder": "", "country_iso_code": "IO" }, "231": { "postal_code_type": "postal", "postal_code_pattern": "VG\\d{4}", "postal_code_placeholder": "", "country_iso_code": "VG" }, "75": { "postal_code_type": "postal", "postal_code_pattern": "[A-Z]{2} ?\\d{4}", "postal_code_placeholder": "", "country_iso_code": "BN" }, "69": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "BG" }, "135": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5,6}", "postal_code_placeholder": "", "country_iso_code": "KH" }, "79": { "postal_code_type": "postal", "postal_code_pattern": "[ABCEGHJKLMNPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z] ?\\d[ABCEGHJ-NPRSTV-Z]\\d", "postal_code_placeholder": "A1A 1A1", "country_iso_code": "CA" }, "222": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "CV" }, "247": { "postal_code_type": "postal", "postal_code_pattern": "KY\\d-\\d{4}", "postal_code_placeholder": "", "country_iso_code": "KY" }, "81": { "postal_code_type": "postal", "postal_code_pattern": "\\d{7}", "postal_code_placeholder": "", "country_iso_code": "CL" }, "82": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "CN" }, "257": { "postal_code_type": "postal", "postal_code_pattern": "6798", "postal_code_placeholder": "", "country_iso_code": "CX" }, "258": { "postal_code_type": "postal", "postal_code_pattern": "6799", "postal_code_placeholder": "", "country_iso_code": "CC" }, "86": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "CO" }, "87": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4,5}|\\d{3}-\\d{4}", "postal_code_placeholder": "", "country_iso_code": "CR" }, "118": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "HR" }, "88": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "CU" }, "89": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "CY" }, "90": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3} ?\\d{2}", "postal_code_placeholder": "", "country_iso_code": "CZ" }, "93": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "DK" }, "94": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "DO" }, "96": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "EC" }, "97": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "EG" }, "187": { "postal_code_type": "postal", "postal_code_pattern": "CP [1-3][1-7][0-2]\\d", "postal_code_placeholder": "CP 1101", "country_iso_code": "SV" }, "100": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "EE" }, "101": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "ET" }, "262": { "postal_code_type": "postal", "postal_code_pattern": "FIQQ 1ZZ", "postal_code_placeholder": "", "country_iso_code": "FK" }, "241": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}", "postal_code_placeholder": "", "country_iso_code": "FO" }, "102": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "FI" }, "103": { "postal_code_type": "postal", "postal_code_pattern": "\\d{2} ?\\d{3}", "postal_code_placeholder": "75000", "country_iso_code": "FR" }, "115": { "postal_code_type": "postal", "postal_code_pattern": "9[78]3\\d{2}", "postal_code_placeholder": "", "country_iso_code": "GF" }, "263": { "postal_code_type": "postal", "postal_code_pattern": "987\\d{2}", "postal_code_placeholder": "", "country_iso_code": "PF" }, "106": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "GE" }, "91": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "80331", "country_iso_code": "DE" }, "226": { "postal_code_type": "postal", "postal_code_pattern": "GX11 1AA", "postal_code_placeholder": "", "country_iso_code": "GI" }, "112": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3} ?\\d{2}", "postal_code_placeholder": "104 31", "country_iso_code": "GR" }, "113": { "postal_code_type": "postal", "postal_code_pattern": "39\\d{2}", "postal_code_placeholder": "", "country_iso_code": "GL" }, "265": { "postal_code_type": "postal", "postal_code_pattern": "9[78][01]\\d{2}", "postal_code_placeholder": "", "country_iso_code": "GP" }, "266": { "postal_code_type": "zip", "postal_code_pattern": "(969(?:[12]\\d|3[12]))(?:[ \\-](\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "GU" }, "114": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "GT" }, "305": { "postal_code_type": "postal", "postal_code_pattern": "GY\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}", "postal_code_placeholder": "", "country_iso_code": "GG" }, "108": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}", "postal_code_placeholder": "", "country_iso_code": "GN" }, "110": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "GW" }, "119": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "HT" }, "267": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "HM" }, "268": { "postal_code_type": "postal", "postal_code_pattern": "00120", "postal_code_placeholder": "", "country_iso_code": "VA" }, "117": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "HN" }, "120": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "HU" }, "126": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}", "postal_code_placeholder": "", "country_iso_code": "IS" }, "122": { "postal_code_type": "pin", "postal_code_pattern": "^[1-9][0-9]{5}$", "postal_code_placeholder": "110001", "country_iso_code": "IN" }, "121": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "ID" }, "124": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}-?\\d{5}", "postal_code_placeholder": "", "country_iso_code": "IR" }, "125": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "IQ" }, "123": { "postal_code_type": "eircode", "postal_code_pattern": null, "postal_code_placeholder": "", "country_iso_code": "IE" }, "269": { "postal_code_type": "postal", "postal_code_pattern": "IM\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}", "postal_code_placeholder": "", "country_iso_code": "IM" }, "127": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}(?:\\d{2})?", "postal_code_placeholder": "", "country_iso_code": "IL" }, "128": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "50100", "country_iso_code": "IT" }, "131": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}-?\\d{4}", "postal_code_placeholder": "100-0001", "country_iso_code": "JP" }, "307": { "postal_code_type": "postal", "postal_code_pattern": "JE\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}", "postal_code_placeholder": "", "country_iso_code": "JE" }, "130": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "JO" }, "132": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "KZ" }, "133": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "KE" }, "137": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "KW" }, "134": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "KG" }, "138": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "LA" }, "146": { "postal_code_type": "postal", "postal_code_pattern": "LV-\\d{4}", "postal_code_placeholder": "", "country_iso_code": "LV" }, "139": { "postal_code_type": "postal", "postal_code_pattern": "(?:\\d{4})(?: ?(?:\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "LB" }, "143": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}", "postal_code_placeholder": "", "country_iso_code": "LS" }, "140": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "LR" }, "272": { "postal_code_type": "postal", "postal_code_pattern": "948[5-9]|949[0-8]", "postal_code_placeholder": "", "country_iso_code": "LI" }, "144": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "LT" }, "145": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "LU" }, "151": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "MK" }, "149": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}", "postal_code_placeholder": "", "country_iso_code": "MG" }, "159": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "MY" }, "238": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "MV" }, "227": { "postal_code_type": "postal", "postal_code_pattern": "[A-Z]{3} ?\\d{2,4}", "postal_code_placeholder": "", "country_iso_code": "MT" }, "274": { "postal_code_type": "zip", "postal_code_pattern": "(969[67]\\d)(?:[ \\-](\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "MH" }, "275": { "postal_code_type": "postal", "postal_code_pattern": "9[78]2\\d{2}", "postal_code_placeholder": "", "country_iso_code": "MQ" }, "239": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}(?:\\d{2}|[A-Z]{2}\\d{3})", "postal_code_placeholder": "", "country_iso_code": "MU" }, "276": { "postal_code_type": "postal", "postal_code_pattern": "976\\d{2}", "postal_code_placeholder": "", "country_iso_code": "YT" }, "150": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "MX" }, "277": { "postal_code_type": "zip", "postal_code_pattern": "(9694[1-4])(?:[ \\-](\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "FM" }, "148": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "MD" }, "278": { "postal_code_type": "postal", "postal_code_pattern": "980\\d{2}", "postal_code_placeholder": "", "country_iso_code": "MC" }, "154": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "MN" }, "155": { "postal_code_type": "postal", "postal_code_pattern": "8\\d{4}", "postal_code_placeholder": "", "country_iso_code": "ME" }, "147": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "MA" }, "156": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "MZ" }, "153": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "MM" }, "160": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "NA" }, "166": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "NP" }, "233": { "postal_code_type": "postal", "postal_code_pattern": "988\\d{2}", "postal_code_placeholder": "", "country_iso_code": "NC" }, "167": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "3974", "country_iso_code": "NZ" }, "163": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "NI" }, "161": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "NE" }, "162": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "NG" }, "282": { "postal_code_type": "postal", "postal_code_pattern": "2899", "postal_code_placeholder": "", "country_iso_code": "NF" }, "283": { "postal_code_type": "zip", "postal_code_pattern": "(9695[012])(?:[ \\-](\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "MP" }, "176": { "postal_code_type": "postal", "postal_code_pattern": null, "postal_code_placeholder": "", "country_iso_code": "KP" }, "165": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "NO" }, "168": { "postal_code_type": "postal", "postal_code_pattern": "(?:PC )?\\d{3}", "postal_code_placeholder": "", "country_iso_code": "OM" }, "169": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "PK" }, "284": { "postal_code_type": "zip", "postal_code_pattern": "(969(?:39|40))(?:[ \\-](\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "PW" }, "173": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}", "postal_code_placeholder": "", "country_iso_code": "PG" }, "178": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "PY" }, "171": { "postal_code_type": "Postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "PE" }, "172": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "PH" }, "174": { "postal_code_type": "postal", "postal_code_pattern": "\\d{2}-\\d{3}", "postal_code_placeholder": "10-345", "country_iso_code": "PL" }, "177": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}-\\d{3}", "postal_code_placeholder": "1000-205", "country_iso_code": "PT" }, "175": { "postal_code_type": "zip", "postal_code_pattern": "(00[679]\\d{2})(?:[ \\-](\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "PR" }, "304": { "postal_code_type": "postal", "postal_code_pattern": "9[78]4\\d{2}", "postal_code_placeholder": "", "country_iso_code": "RE" }, "180": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "RO" }, "181": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "101000", "country_iso_code": "RU" }, "308": { "postal_code_type": "postal", "postal_code_pattern": "9[78][01]\\d{2}", "postal_code_placeholder": "", "country_iso_code": "BL" }, "286": { "postal_code_type": "postal", "postal_code_pattern": "(?:ASCN|STHL) 1ZZ", "postal_code_placeholder": "", "country_iso_code": "SH" }, "288": { "postal_code_type": "postal", "postal_code_pattern": "9[78][01]\\d{2}", "postal_code_placeholder": "", "country_iso_code": "MF" }, "289": { "postal_code_type": "postal", "postal_code_pattern": "9[78]5\\d{2}", "postal_code_placeholder": "", "country_iso_code": "PM" }, "249": { "postal_code_type": "Postal", "postal_code_pattern": "VC\\d{4}", "postal_code_placeholder": "", "country_iso_code": "VC" }, "291": { "postal_code_type": "postal", "postal_code_pattern": "4789\\d", "postal_code_placeholder": "", "country_iso_code": "SM" }, "183": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "SA" }, "185": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "SN" }, "189": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5,6}", "postal_code_placeholder": "", "country_iso_code": "RS" }, "220": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "SG" }, "191": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3} ?\\d{2}", "postal_code_placeholder": "", "country_iso_code": "SK" }, "192": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "SI" }, "188": { "postal_code_type": "postal", "postal_code_pattern": "[A-Z]{2} ?\\d{5}", "postal_code_placeholder": "", "country_iso_code": "SO" }, "215": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "ZA" }, "294": { "postal_code_type": "postal", "postal_code_pattern": "SIQQ 1ZZ", "postal_code_placeholder": "", "country_iso_code": "GS" }, "136": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "KR" }, "99": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "28013", "country_iso_code": "ES" }, "142": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "LK" }, "184": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "SD" }, "295": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "SJ" }, "194": { "postal_code_type": "postal", "postal_code_pattern": "[HLMS]\\d{3}", "postal_code_placeholder": "", "country_iso_code": "SZ" }, "193": { "postal_code_type": "postal", "postal_code_pattern": "^\\d{5}$", "postal_code_placeholder": "111 22", "country_iso_code": "SE" }, "80": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "CH" }, "204": { "postal_code_type": "postal", "postal_code_pattern": "\\d{3}(?:\\d{2,3})?", "postal_code_placeholder": "", "country_iso_code": "TW" }, "199": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "TJ" }, "205": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4,5}", "postal_code_placeholder": "", "country_iso_code": "TZ" }, "198": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "TH" }, "164": { "postal_code_type": "postal", "postal_code_pattern": "[1-9]\\d{3} ?(?:[A-RT-Z][A-Z]|S[BCE-RT-Z])", "postal_code_placeholder": "1105 AW", "country_iso_code": "NL" }, "202": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "TN" }, "203": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "TR" }, "200": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "TM" }, "299": { "postal_code_type": "postal", "postal_code_pattern": "TKCA 1ZZ", "postal_code_placeholder": "", "country_iso_code": "TC" }, "207": { "postal_code_type": "postal", "postal_code_pattern": "^([0-8][0-9]{4}|9[0-3][0-9]{3}|94[0-8][0-9]{2}|949[0-8][0-9]|9499[0-9])$", "postal_code_placeholder": "", "country_iso_code": "UA" }, "105": { "postal_code_type": "postal", "postal_code_pattern": "^(GIR ?0AA|((AB|AL|B|BA|BB|BD|BF|BH|BL|BN|BR|BS|BT|BX|CA|CB|CF|CH|CM|CO|CR|CT|CV|CW|DA|DD|DE|DG|DH|DL|DN|DT|DY|E|EC|EH|EN|EX|FK|FY|G|GL|GY|GU|HA|HD|HG|HP|HR|HS|HU|HX|IG|IM|IP|IV|JE|KA|KT|KW|KY|L|LA|LD|LE|LL|LN|LS|LU|M|ME|MK|ML|N|NE|NG|NN|NP|NR|NW|OL|OX|PA|PE|PH|PL|PO|PR|RG|RH|RM|S|SA|SE|SG|SK|SL|SM|SN|SO|SP|SR|SS|ST|SW|SY|TA|TD|TF|TN|TQ|TR|TS|TW|UB|W|WA|WC|WD|WF|WN|WR|WS|WV|YO|ZE)(\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}))|BFPO ?\\d{1,4})$", "postal_code_placeholder": "NW1 6XE", "country_iso_code": "GB" }, "209": { "postal_code_type": "zip", "postal_code_pattern": "^\\d{5}(?:-\\d{4})?$", "postal_code_placeholder": "12345", "country_iso_code": "US" }, "302": { "postal_code_type": "zip", "postal_code_pattern": "96898", "postal_code_placeholder": "", "country_iso_code": "UM" }, "208": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "UY" }, "248": { "postal_code_type": "zip", "postal_code_pattern": "(008(?:(?:[0-4]\\d)|(?:5[01])))(?:[ \\-](\\d{4}))?", "postal_code_placeholder": "", "country_iso_code": "VI" }, "210": { "postal_code_type": "postal", "postal_code_pattern": "\\d{6}", "postal_code_placeholder": "", "country_iso_code": "UZ" }, "211": { "postal_code_type": "postal", "postal_code_pattern": "\\d{4}", "postal_code_placeholder": "", "country_iso_code": "VE" }, "212": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}\\d?", "postal_code_placeholder": "", "country_iso_code": "VN" }, "224": { "postal_code_type": "postal", "postal_code_pattern": "986\\d{2}", "postal_code_placeholder": "", "country_iso_code": "WF" }, "213": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "EH" }, "217": { "postal_code_type": "postal", "postal_code_pattern": "\\d{5}", "postal_code_placeholder": "", "country_iso_code": "ZM" } }, "ship_to_preference_capabilities": { "209": { "postal_code": { "is_assignable": true, "is_required": true } }, "79": { "postal_code": { "is_assignable": true, "is_required": true } }, "122": { "postal_code": { "is_assignable": true, "is_required": true } }, "61": { "postal_code": { "is_assignable": true, "is_required": true } }, "105": { "postal_code": { "is_assignable": true, "is_required": true } } }, "category_id": 68887416, "admin_tools_page_data": [], "currency_data": { "currency_id": 978, "code": "EUR", "name": "Euro", "number_precision": 2, "symbol": "\u20ac", "listing_enabled": true, "browsing_enabled": true, "buyer_location_restricted": false, "rate_updates_enabled": true }, "machine_translation\/listings_click_to_translate": true, "ads.prolist\/log_clicks_and_impressions": false, "mfg\/dovetail": true, "mfg\/buyer_facing_dovetail": true, "searchx\/4q18\/dwell_time_as_backend_event": false, "is_regulatory_buyer_disclosure_enabled": true, "is_convos_condensed_disclosure_enabled": false, "machine_translation": { "mode": "disabled", "listing_id": 226335136, "to_lang_code": "en-US", "from_lang_code": "en-US", "translated": null, "untranslated": null, "category_tags": null }, "listing_fee": 20, "presented_listing_fee": "USD 0.20 USD", "listing_period_months": 4, "enable_pla_sash_popover_hover_event": false, "use_sash_popover_events": true, "apple_pay_api_version_number": 12, "render_is_gift_section": true, "coupons_in_buy_box_is_enabled": false, "is_eligible_web_components": false, "should_show_atc_from_listing_cards": true, "should_show_atc_from_listing_cards_mweb": false, "added_to_cart_text": "Added to cart!", "speculation_rules_prefetch": false, "speculation_rules_prefetch_from_search": false, "prefetch_event_cache_key": "", "should_show_sidebar_cart_post_atc_recs": false, "is_eligible_for_trust_suite_section": false, "is_gift_guide_flyout_enabled": false, "should_hide_sub_nav": true, "should_show_breadcrumbs": true, "should_change_heading_on_similar_items_toggle": false, "should_show_ad_section_tooltip": true, "is_deemphasized_top_sash": true, "ad_listing_ids_to_exclude": [4363882464, 1781860156], "listingcard:44aff298317273b50b9516fef657cb70:937c76b87a5810266a2e9bc91755128223a578f6": { "plkey": null, "plkey_input_name": "plkey", "encoded_impression": "" }, "01125905a4e5ddf2": "recs-impression", "3c65557fa67e42dc": "b071d264fc2d1cbfa", "c5420ec98ed7db34": "b911bd676f2cd9fb2", "listingcard:44aff298317273b50b9516fef657cb70:abf8c1fb0f20d67ec2d3ecfa51018af732feb5d4": { "plkey": null, "plkey_input_name": "plkey", "encoded_impression": "" }, "listingcard:bb4f32bbadee8c9ba8640512d353df1e7bad60b0:4363882464": { "plkey": "bb4f32bbadee8c9ba8640512d353df1e7bad60b0:4363882464", "plkey_input_name": "plkey" }, "listingcard:f59e2e8b4ff6b70794e9f6043665183085c1fc20:1781860156": { "plkey": "f59e2e8b4ff6b70794e9f6043665183085c1fc20:1781860156", "plkey_input_name": "plkey" }, "listingcard:4bbf55274397e01ee411e49250e18757:c64723aeef0c6f3f8f3c8ad9474b8a891d77c9a9": { "plkey": null, "plkey_input_name": "plkey", "encoded_impression": "" }, "listingcard:4bbf55274397e01ee411e49250e18757:34b3cbc082b6cb0ca428269eaae339c14904a309": { "plkey": null, "plkey_input_name": "plkey", "encoded_impression": "" }, "listingcard:44aff298317273b50b9516fef657cb70:95f04c49b2091231cba4d534e18e64b38ab4e0b0": { "plkey": null, "plkey_input_name": "plkey", "encoded_impression": "" }, "listingcard:44aff298317273b50b9516fef657cb70:47bca85fab78119350437c71e5556f9f699a35a7": { "plkey": null, "plkey_input_name": "plkey", "encoded_impression": "" }, "listing_image_url": "", "eligible_for_mini_collections_and_ignore_menu": false, "image_ids_by_listing_variation_ids": { "5211931469": 6796558829, "5232721970": 830139237 }, "should_show_scrollable_thumbnails": true, "shouldShowThumbnails": true, "carousel_height_percentage_relative_to_width": [66.6666666666666714036182384006679058074951171875, 74.9866666666666645824079751037061214447021484375, 74.400000000000005684341886080801486968994140625, 68.7999999999999971578290569595992565155029296875, 66.6666666666666714036182384006679058074951171875, 63.7333333333333342807236476801335811614990234375, 80, 75, 80, 75], "is_mobile_experience": false, "is_users_own_listing": false, "lp_toffers_v2_true_sale_enabled": false, "sale_ending_soon_countdown": false, "should_show_histogram_panel": false, "anchor_shop_name_to_seller_cred": false, "shop_reviews_count": 1095, "neu_buy_box_type": "offerings", "listing_id": 226335136, "klarna_osm_js": "https:\/\/js.klarna.com\/web-sdk\/v1\/klarna.js", "is_eligible_for_klarna_osm": false, "is_eligible_for_variations_update": true, "can_listing_have_coupon_applied": false, "is_multiple_questions_enabled_buyer": true, "personalization_is_required": true, "personalization_field_count": 1, "how_its_made_label_type": "made_by", "product_details_content_toggle_selector": "[data-wt-content-toggle][aria-controls='content-toggle-product-details-read-more']", "should_show_description_content_toggle": true, "use_shipping_variant_view": true, "shipping_section_default_open": true, "shipping_and_returns_is_eligible_for_sticky_buy_box": true, "estimated_shipping_is_eligible_for_sticky_buy_box": true, "is_eligible_for_shipping_and_returns_cleanup": true, "is_postal_code_empty_on_initial_load": true, "invalid_postal_codes": { "209": ["000", "001", "002", "003", "004", "213", "269", "343", "345", "348", "353", "419", "428", "429", "517", "518", "519", "529", "533", "536", "552", "568", "569", "578", "579", "589", "621", "632", "642", "643", "659", "663", "682", "694", "695", "696", "697", "698", "699", "702", "709", "715", "732", "742", "771", "817", "818", "819", "839", "848", "849", "854", "858", "861", "862", "866", "867", "868", "869", "872", "886", "887", "888", "892", "896", "899", "909", "929", "987"] }, "is_eligible_for_policies_in_overlay": true, "active_tab": "same_listing_reviews", "allow_reviews_debug": false, "using_mweb_tabs": false, "load_tabbed_layout_js": true, "should_show_helpful_count": true, "should_default_chronological_sort": false, "should_include_subratings": true, "current_page": 1, "is_deep_dive": false, "has_appreciation_photos": true, "eligible_for_review_photo_filter_and_sort": true, "is_new_deep_dive": false, "photos_per_page": 4, "review_categorical_tags_enabled": true, "review_hide_sort_by_prefix": true, "has_external_mobile_image_tags": false, "tag_cards_with_image": ".op786r06j5ei", "mweb_can_scroll_to_seller_cred_module": false, "is_eligible_for_showing_more_items_on_explore_more": false, "structured_policies_messages": { "module_name": "Shop policies", "last_updated_on": "Last updated on", "publish": "Publish Shop Policies", "policies_save": "Save policies", "policies_edit": "Edit policies", "cancel": "Cancel", "revert": "Use previous policies", "edit": "Edit", "loading": "Loading", "preview_banner_kicker": "Policies preview", "not_existing_policies_preview_banner_header": "Review and customize these policies so they work for you", "preview_banner_body": "You can publish these to your shop or edit them if you need to make changes", "preview_publish_confirm": "By clicking Publish, you'll post your Shop Policies and agree to comply with them.", "revert_confirm": "Are you sure you want to revert?", "leave_page_warning": "You are currently editing shop policies", "private_receipt_info_title": "Private receipt info", "private_receipt_info_body": "We have removed the 'Private Receipt Info' section of your policies page. You don't need to populate this section for the purposes of complying with international consumer protection laws anymore because this new Policies feature will automatically display the relevant content of your shop policies within the buyer receipt email instead.", "private_receipt_info_link": "See this FAQ for more information", "structured_banner_title": "Switch to simple shop policies", "structured_banner_title_v2": "Set up simple shop policies", "structured_banner_body": "We'll give you a quick template to create your shop policies in seconds.", "structured_banner_button": "Try it now", "new_simplified_policies": "Your new, simplified policies", "new_policies_banner_description_1": "Buyers prefer policies that are short, clear and address their key concerns, so we've designed them that way.", "new_policies_banner_description_2": "Review and customize these policies so they work for you. We've saved your previous policies, so you can always switch back.", "new_policies_banner_description_3": "We've saved your previous policies, so you can always switch back.", "new_policies_banner_learn_more": "Learn more", "publish_policies_success": "Your new policies have been published!", "publish_policies_error": "There was an error publishing your policies. Please try again.", "policies_failed_to_load": "Shop policies failed to load", "policies_try_again": "Try again", "policies_saving": "Saving...", "policies_publishing": "Publishing...", "listing_preview_shipping": "This section will show shipping or download information once you publish your listing.", "craft_shipping_section_title": "Shipping & policies", "craft_payments_section_title": "Payments", "craft_refunds_section_title": "Returns & exchanges", "craft_terms_section_title": "Terms & conditions", "craft_more_details_accordion_label": "+ See more...", "listing_returns_and_exchanges": "See item details for return and exchange eligibility.", "no_policies": "Looks like this shop doesn't have any custom policies. Have questions?", "message_the_seller": "Message the seller", "shipping_section_title": "Shipping", "payments_section_title": "Payments", "refunds_section_title": "Returns & exchanges", "digital_section_title": "Downloads", "terms_section_title": "Terms & conditions", "more_details_accordion_label": "See more...", "seller_details_section_title": "More information" }, "shop_policy_selector": "[data-content-toggle-uid=shop_policies]", "load_user_faves_option": true, "update_many_faves_option": true, "is_async_only_faves_option": false, "guest_favorites_enabled": true, "collection_count": 0, "favorites_key": "", "use_clearer_privacy_description": true, "conditional_sale_interstitial": true, "google_client_id": "296956783393-2d8r0gljo87gjmdpmvkgbeasdmelq33e.apps.googleusercontent.com", "shoe_t            _page": false });
    </script>

    <script nonce="sX01MNM9OyY6bV2b7BGCSBPQ">__we              c / e  gr e en V endor / js / en -</script>

    <script nonce="sX01MNM9OyY6bV2b7BGCSBPQ">(function () {
                                                     vailab
                                                                                                                                                                                                                    ue                                                                                              erIsEnabled = true;
                                                     {
                                                                                                                                                 rimarySupportsAsync) {
                                                             ng & & windo w._ _etsy_logging.bots && (window.__etsy_lo.bolength > 0)) {
                                                                 deURIComponent(JSON.stringify(window.__etsy_logging.bots.botCheck));
                                                             }) ();</script>

    <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/vendor_bundle.4b28aa70c9cca35746a4.js"
        type="text/javascript" nonce="sX01MNM9OyY6bV2b7BGCSBPQ" crossorigin defer></script>
    <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/etsy_libs.30bc4a394fcd9a30315a.js"
        type="text/javascript" nonce="sX01MNM9OyY6bV2b7BGCSBPQ" crossorigin defer></script>
    <script
        src="https://www.etsy.com/paula/v3/polyfill.min.js?etsy-v=v5&flags=gated&features=AbortController%2CDOMTokenList.prototype.@@iterator%2CDOMTokenList.prototype.forEach%2CIntersectionObserver%2CIntersectionObserverEntry%2CNodeList.prototype.@@iterator%2CNodeList.prototype.forEach%2CObject.preventExtensions%2CString.prototype.anchor%2CString.raw%2Cdefault%2Ces2015%2Ces2016%2Ces2017%2Ces2018%2Ces2019%2Ces2090%2Ces2021%2Ces2022%2Cfetch%2CgetComputedStyle%2CmatchMedia%2Cperformance.now"
        type="text/javascript" nonce="sX01MNM9OyY6bV2b7BGCSBPQ" crossorigin defer></script>
    <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/app-shell/globals/index.ab96063b3ebf324db7d9.js"
        type="text/javascript" nonce="sX01MNM9OyY6bV2b7BGCSBPQ" crossorigin defer></script>
    <script
        src="https://www.etsy.com/ac/evergreenVendor/js/en-US/@etsy-modules/ConsentManagement/Transcend-Integration.65983beb85f82c0d3fef.js"
        type="text/javascript" nonce="sX01MNM9OyY6bV2b7BGCSBPQ" crossorigin defer></script>
    <script src="https://www.etsy.com/ac/evergreenVendor/js/en-US/bootstrap/listings3/main.9d568d0bc7552f1db93a.js"
        type="text/javascript" nonce="sX01MNM9OyY6bV2b7BGCSBPQ" crossorigin defer></script>



    </div>
    <div data-ui="listing-breadcrumbs" class="wt-hide-xs wt-show-lg breadcrumb_nav">
        <div data-ui="cat-nav" id="desktop-category-nav" class="cat-nav  v2-toolkit-cat-nav wt-ml-xs-0 wt-mr-xs-0">
            <div class="wt-text-caption wt-position-relative wt-z-index-5 wt-pt-xs-2">
                <div
                    class="wt-grid wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-6 wt-pr-lg-6">
                    <ul class="wt-list-unstyled wt-grid__item-xs-12 wt-body-max-width wt-display-flex-xs wt-justify-content-center"
                        data-menu-ui="menubar" data-ui="top-nav-category-list">
                        <li data-ui="list-item-breadcrumbs"
                            class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link data-menu-ui="menuitem" tabindex="0"
                                href="https://www.etsy.com/?ref=catnav_breadcrumb-home">
                                <?= $str; ?>
                            </a>
                            <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"
                                    focusable="false">
                                    <path
                                        d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21" />
                                </svg></span>
                        </li>
                        <li data-ui="list-item-breadcrumbs"
                            class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link data-menu-ui="menuitem" tabindex="0" href="<?= $link; ?>">Game
                                Online | สล็อตแตกง่าย RTP สูง โบนัสเข้าไว</a>
                        </li>
                    </ul>
                    <span class="active-nav-item-indicator wt-position-absolute wt-display-inline-block"
                        data-ui="active-nav-item-indicator"></span>
                </div>
            </div>
        </div>
    </div>
    <span data-recommendations-sash>
        <div data-appears-component-name="Listzilla_ApiSpecs_SimilarListingsRow"
            data-appears-event-data='{"module_placement":"external_top","datasets":["Common_Listing_SameShopListwiseV6","ads","Common_Listing_ExternalCrossShopMVD-RANKER-perso_engine_recs_ymal_pointwise_v6_web_on--EXP_COCLICK--CANDIDATES-l2lBlendedSimilar--THIRDPASS-NoThirdpass"],"targets":[],"logging_class":"Listzilla_ApiSpecs_SimilarListingsRow","page_listing_id":226335136,"mmx_request_uuid_map":{"31704ec5-e41e-4e89-97d9-38ca613db7fb":[0,1,6,7],"1b9a361c-ded0-489e-9b7c-77a5329359ee":[4,5]},"candidate_source_map":{"arizona:Listing_Candidates_SameShop_Hash_Deduped":[0],"arizona:SameShop_Complementary_V2_Hash_Deduped":[1,6,7],"arizona:Listing_Candidates_Search_Bipartite_Clicks":[4],"arizona:Listing_Candidates_SSR_Tfidf":[5]},"second_pass_ranker_map":{"recs-ranking-listwise-v6a":[0,1,6,7],"recs-ranking-pointwise-v6-purchase":[4,5]},"client_provided_features":{"browser":{"acceptLanguage":"en-US","browser":"Chrome","currency":"THB","localeRegion":"TH","operatingSystem":"Windows 10","platform":"desktop","platformEtsyApp":"web","platformMobileDevice":"unidentified","source":"directLanding"},"date_time":{"dayOfWeek":"5","hourOfDay":"07"},"user":{"locationLatitude":null,"locationLongitude":null,"locationZip":"unidentified","userPreferredLanguage":"en-US"}},"scores":[0.305435999999999985288212656087125651538372039794921875,-0.0643809999999999937880801326173241250216960906982421875,0.52488299999999998846078597125597298145294189453125,0.466295999999999988272492146279546432197093963623046875,-0.1576849999999999918376403229558491148054599761962890625,-0.1899760000000000059738880509030423127114772796630859375],"datasets_map":{"Common_Listing_SameShopListwiseV6":[0,1,6,7],"ads":[2,3],"Common_Listing_ExternalCrossShopMVD-RANKER-perso_engine_recs_ymal_pointwise_v6_web_on--EXP_COCLICK--CANDIDATES-l2lBlendedSimilar--THIRDPASS-NoThirdpass":[4,5]},"target_listing_id":226335136,"sash_flavor":"basic","refTag":"landingpage_similar_listing_top","listing_ids":[1692435823,549484644,4363882464,1781860156,166594532,219009280,255939884,180729598],"listing_prices_usd":[263.279999999999972715158946812152862548828125,2,2161.1300000000001091393642127513885498046875,4296.8800000000001091393642127513885498046875,241,241,2,2],"taxonomy_ids":[6343,468,1854,488,6343,6343,488,488],"taxo_paths":["craft_supplies_and_tools.patterns_and_how_to.patterns_and_blueprints","clothing.gender_neutral_adult_clothing.costumes","clothing.gender_neutral_kids_clothing.hoodies_and_sweatshirts.hoodies","clothing.gender_neutral_kids_clothing.costumes","craft_supplies_and_tools.patterns_and_how_to.patterns_and_blueprints","craft_supplies_and_tools.patterns_and_how_to.patterns_and_blueprints","clothing.gender_neutral_kids_clothing.costumes","clothing.gender_neutral_kids_clothing.costumes"],"rec_event_name":"recommendations_module"}'
            class='recs-appears-logger'>
            <div
                class="wt-pt-xs-4 wt-pr-xs-2 wt-pl-xs-2 wt-pr-md-4 wt-pl-md-4 wt-pr-lg-5 wt-pl-lg-5 wt-body-max-width wt-bb-md">
                <div data-similar-listings-row>
                    <style>
                        .q53cd7bb9f5ae9d08 {
                            font-size: 10.4px;
                            color: #222;
                            background-color: #FFF;
                            border-radius: 100px;
                            display: inline-block;
                            line-height: 1;
                            min-width: 18px;
                            padding: 4px 6px;
                            text-align: center;
                        }
                    </style>

                </div>
                </a>
                <div data-favorite-button-wrapper class="v2-listing-card__actions wt-z-index-1 wt-position-absolute ">
                    <button
                        class="btn--focus  wt-position-absolute wt-btn wt-btn--light wt-btn--small wt-z-index-2 wt-btn--filled wt-btn--icon neu-default-favorite wt-position-right wt-position-top fav-opacity-hidden neu-hover-on-card neu-default-button-position--grid"
                        data-ui="favorite-listing-button" data-listing-id="180729598" data-accessible-btn-fave
                        data-favorite-label="Add to Favorites" data-favorited-label="Remove from Favorites"
                        data-listing-source="recs"
                        data-logging-key="44aff298317273b50b9516fef657cb70:47bca85fab78119350437c71e5556f9f699a35a7">
                        <div class="favorite-listing-button-icon-container should-animate "
                            data-source="listing_page_similar_listings_row" data-btn-fave data-neu-fave
                            data-favorite-icon-container>
                            <span
                                class="etsy-icon wt-nudge-t-1 wt-icon--smaller-xs&#10;                    &#10;                    &#10;                        &#10;                        &#10;                            wt-display-block&#10;                        &#10;                    "
                                data-not-favorited-icon=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                    aria-hidden="true" focusable="false">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M20.877 12.52q.081-.115.147-.239A6 6 0 0 0 12 4.528a6 6 0 0 0-9.024 7.753q.066.123.147.24l.673.961a6 6 0 0 0 .789.915L12 21.422l7.415-7.025q.44-.418.789-.915zm-14.916.425L12 18.667l6.04-5.722q.293-.279.525-.61l.673-.961a.3.3 0 0 0 .044-.087 4 4 0 1 0-7.268-2.619v.003L12 8.667l-.013.004v-.002l-.006-.064a3.98 3.98 0 0 0-1.232-2.51 4 4 0 0 0-6.031 5.193q.014.045.044.086l.673.961a4 4 0 0 0 .526.61" />
                                </svg></span>
                            <span
                                class="etsy-icon wt-nudge-t-1 wt-icon--smaller-xs wt-text-favorite-heart&#10;                    &#10;                    &#10;                        &#10;                        &#10;                            wt-display-none&#10;                        &#10;                    "
                                data-favorited-icon=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                    aria-hidden="true" focusable="false">
                                    <path
                                        d="M21.024 12.281a2 2 0 0 1-.147.24l-.673.961q-.349.497-.789.915L12 21.422l-7.415-7.025a6 6 0 0 1-.789-.915l-.673-.961a2 2 0 0 1-.147-.24A6 6 0 0 1 12 4.528a6 6 0 0 1 9.024 7.753" />
                                </svg></span>
                        </div>
                        <span aria-hidden="true" class="icon"></span>
                        <span class="wt-screen-reader-only" data-a11y-label>

                            Add to Favorites
                        </span>
                    </button>
                </div>
            </div>
            </ul>
        </div>
        </div>

        </div>
        </div>
        </div>
    </span>



    <div data-selector="listing-page-content" class="content-wrap listing-page-content">





        <div class="wt-pt-xs-5 listing-page-content-container-wider wt-horizontal-center">

            <div id="listing-right-column" class="listing-buy-box-experiment">

                <div>
                    <div class="body-wrap wt-body-max-width wt-display-flex-md wt-flex-direction-column-xs">
                        <div
                            class="image-col wt-order-xs-1 wt-mb-xs-2 wt-mb-lg-6 wt-pl-md-4 wt-pl-lg-5 wt-pl-xs-2 wt-pr-xs-2 wt-pr-xl-2 wt-pr-md-4 wt-pr-lg-0">
                            <div class="wt-flex-lg-6 wt-mr-lg-3 wt-pr-xl-3">
                                <div class="image-wrapper wt-position-relative carousel-container-responsive"
                                    id="photos">


                                    <div data-listing-page-badge style="margin-left: 78px; "
                                        class="wt-position-absolute wt-z-index-2 wt-position-top wt-position-left wt-mt-xs-1">
                                        <div class="wt-popover" data-wt-popover>
                                            <button data-wt-popover-trigger
                                                class="wt-popover__trigger wt-popover__trigger--underline wt-display-inline-flex-xs wt-align-items-center wt-text-caption"
                                                aria-disabled="true" aria-describedby="etsys_pick">
                                                <span data-clg-id="WtBadge"
                                                    class="wt-badge wt-badge--statusRecommendation wt-pl-xs-2">
                                                    <span class="wt-icon wt-icon--smaller-xs wt-nudge-r-3"><svg
                                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                            aria-hidden="true" focusable="false">
                                                            <path
                                                                d="m15.4 14.1-3.7-1.9-1.8-3.6c-.3-.7-1.4-.7-1.8 0l-1.9 3.7-3.7 1.9c-.3.1-.5.4-.5.8q0 .6.6.9l3.7 1.9 1.9 3.7c.1.3.4.5.8.5q.6 0 .9-.6l1.9-3.7 3.7-1.9c.3-.2.6-.5.6-.9s-.3-.6-.7-.8m6-8L19 4.9l-1.2-2.4c-.3-.7-1.4-.7-1.8 0l-1.2 2.4-2.4 1.2c-.2.2-.4.5-.4.9q0 .6.6.9L15 9.1l1.2 2.4c.2.3.5.6.9.6q.6 0 .9-.6l1.2-2.4 2.4-1.2c.2-.2.4-.5.4-.9q0-.6-.6-.9" />
                                                        </svg></span>Etsy’s Pick

                                                </span>
                                            </button>
                                            <div id="etsys_pick" role="tooltip">
                                                Etsy’s Picks are hand selected by our style experts to highlight items
                                                from shops that have shown quality, reliability and style. <p
                                                    class="wt-mt-xs-3"><a
                                                        href="https://www.etsy.com/featured/hub/etsy-picks?ref=listing_etsys_pick_signal"
                                                        target="_blank"> Discover More </a></p>
                                            </div>
                                        </div>
                                    </div>


                                    <button
                                        class="btn--focus  wt-position-absolute wt-btn wt-btn--light wt-btn--small wt-z-index-2 wt-btn--filled wt-btn--icon wt-btn--fixed-floating wt-position-right wt-mr-xs-2 wt-mt-xs-2"
                                        data-ui="favorite-listing-button" data-listing-id="226335136"
                                        data-accessible-btn-fave data-favorite-label="Add to Favorites"
                                        data-favorited-label="Remove from Favorites" data-always-show="true">
                                        <div class="favorite-listing-button-icon-container should-animate "
                                            data-source="lp_image_carousel" data-btn-fave data-neu-fave
                                            data-favorite-icon-container>
                                            <span
                                                class="etsy-icon wt-nudge-t-1&#10;                    &#10;                    &#10;                        &#10;                        &#10;                            wt-display-block&#10;                        &#10;                    "
                                                data-not-favorited-icon=""><svg xmlns="http://www.w3.org/2000/svg"
                                                    viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M20.877 12.52q.081-.115.147-.239A6 6 0 0 0 12 4.528a6 6 0 0 0-9.024 7.753q.066.123.147.24l.673.961a6 6 0 0 0 .789.915L12 21.422l7.415-7.025q.44-.418.789-.915zm-14.916.425L12 18.667l6.04-5.722q.293-.279.525-.61l.673-.961a.3.3 0 0 0 .044-.087 4 4 0 1 0-7.268-2.619v.003L12 8.667l-.013.004v-.002l-.006-.064a3.98 3.98 0 0 0-1.232-2.51 4 4 0 0 0-6.031 5.193q.014.045.044.086l.673.961a4 4 0 0 0 .526.61" />
                                                </svg></span>
                                            <span
                                                class="etsy-icon wt-nudge-t-1 wt-text-favorite-heart&#10;                    &#10;                    &#10;                        &#10;                        &#10;                            wt-display-none&#10;                        &#10;                    "
                                                data-favorited-icon=""><svg xmlns="http://www.w3.org/2000/svg"
                                                    viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path
                                                        d="M21.024 12.281a2 2 0 0 1-.147.24l-.673.961q-.349.497-.789.915L12 21.422l-7.415-7.025a6 6 0 0 1-.789-.915l-.673-.961a2 2 0 0 1-.147-.24A6 6 0 0 1 12 4.528a6 6 0 0 1 9.024 7.753" />
                                                </svg></span>
                                        </div>
                                        <span aria-hidden="true" class="icon"></span>
                                        <span class="wt-screen-reader-only" data-a11y-label>

                                            Add to Favorites
                                        </span>
                                    </button>



                                    <div class="listing-page-image-carousel-component wt-display-flex-xs wt-mb-lg-2 wt-mb-sm-8"
                                        data-component="listing-page-image-carousel" data-palette-listing-id="226335136"
                                        data-shop-id="6193928">

                                        <div class="image-carousel-container wt-position-relative wt-flex-xs-6 wt-order-xs-2
                
                show-scrollable-thumbnails">

                                            <ul class="wt-list-unstyled  wt-position-relative carousel-pane-list"
                                                style="padding-top: 66.6666666667%;" data-carousel-pane-list
                                                tabindex="0">
                                                <?php foreach ($carouselImages as $index => $img): ?>
                                                <li class="<?= $index === 0 ? '' : 'wt-display-none '?>wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane"
                                                    data-carousel-pane data-index="<?= $index?>" data-image-id="img_<?= $index?>"
                                                    data-palette-listing-image>
                                                    <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded"
                                                        alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image <?= $index + 1?>"
                                                        <?= $index === 0 ? 'data-carousel-first-image data-perf-group="main-product-image" fetchpriority="high"' : 'loading="lazy" data-perf-group="secondary-product-image"'?> 
                                                        src="<?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8')?>"
                                                        srcset="<?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8')?>"
                                                        data-original-image-width="1500"
                                                        data-src-zoom-image="<?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8')?>"
                                                        data-index="<?= $index?>" />
                                                </li>
                                                <?php
endforeach; ?>
                                            </ul>
                                            <button data-carousel-nav-button data-direction="prev"
                                                class="wt-circle wt-overflow-hidden wt-position-absolute wt-vertical-center wt-position-left wt-btn wt-btn--filled wt-btn--light wt-btn--icon wt-shadow-elevation-3 wt-ml-xs-2"
                                                aria-label="Previous image">
                                                <span class="etsy-icon wt-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <path
                                                            d="M16,21a0.994,0.994,0,0,1-.664-0.253L5.5,12l9.841-8.747a1,1,0,0,1,1.328,1.494L8.5,12l8.159,7.253A1,1,0,0,1,16,21Z" />
                                                    </svg></span>
                                            </button>
                                            <button data-carousel-nav-button data-direction="next"
                                                class="wt-circle wt-overflow-hidden wt-position-absolute wt-vertical-center wt-position-right wt-btn wt-btn--filled wt-btn--light wt-btn--icon wt-shadow-elevation-3 wt-mr-xs-2"
                                                aria-label="Next image">
                                                <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <path
                                                            d="M8,21a1,1,0,0,1-.664-1.747L15.5,12,7.336,4.747A1,1,0,0,1,8.664,3.253L18.5,12,8.664,20.747A0.994,0.994,0,0,1,8,21Z" />
                                                    </svg></span>
                                            </button>
                                        </div>

                                        <div>
                                            <div class="carousel-pagination-item-v2 wt-position-absolute wt-position-top wt-position-left wt-z-index-9"
                                                data-thumbnail-scroll-up>

                                            </div>

                                            <div class="carousel-pagination-item-v2 wt-position-absolute wt-position-bottom wt-position-left wt-z-index-9"
                                                data-thumbnail-scroll-down>

                                            </div>

                                            <div class="wt-position-absolute wt-overflow-scroll wt-position-top wt-position-bottom
                    wt-position-left scroll-container-no-scrollbar" data-thumbnail-scroll-container>
                                                <ul data-carousel-pagination-list class="wt-list-unstyled wt-display-flex-xs
                wt-order-xs-1 wt-flex-direction-column-xs wt-align-items-flex-end">
                                                    <li data-carousel-pagination-item data-index="0"
                                                        data-image-id="742396440"
                                                        class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                                        tabindex="0">
                                                        <img class="wt-animated wt-display-none wt-max-width-full"
                                                            src=""
                                                            alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 1"
                                                            data-carousel-thumbnail-image
                                                            data-src-delay="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                            aria-label="product image 1 of 10"
                                                            data-should-fade-in-on-load="true" />
                                                    </li>

                                                    <li data-carousel-pagination-item data-index="1"
                                                        data-image-id="6748576166"
                                                        class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                                        tabindex="0">
                                                        <img class="wt-animated wt-display-none wt-max-width-full"
                                                            src=""
                                                            alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 2"
                                                            data-carousel-thumbnail-image
                                                            data-src-delay="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                            aria-label="product image 2 of 10"
                                                            data-should-fade-in-on-load="true" />
                                                    </li>

                                                    <li data-carousel-pagination-item data-index="2"
                                                        data-image-id="742396164"
                                                        class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                                        tabindex="0">
                                                        <img class="wt-animated wt-display-none wt-max-width-full"
                                                            src=""
                                                            alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 3"
                                                            data-carousel-thumbnail-image
                                                            data-src-delay="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                            aria-label="product image 3 of 10"
                                                            data-should-fade-in-on-load="true" />
                                                    </li>

                                                    <li data-carousel-pagination-item data-index="3"
                                                        data-image-id="742396020"
                                                        class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                                        tabindex="0">
                                                        <img class="wt-animated wt-display-none wt-max-width-full"
                                                            src=""
                                                            alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 4"
                                                            data-carousel-thumbnail-image
                                                            data-src-delay="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                            aria-label="product image 4 of 10"
                                                            data-should-fade-in-on-load="true" />
                                                    </li>

                                                    <li data-carousel-pagination-item data-index="4"
                                                        data-image-id="830139237"
                                                        class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                                        tabindex="0">
                                                        <img class="wt-animated wt-display-none wt-max-width-full"
                                                            src=""
                                                            alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> Green"
                                                            data-carousel-thumbnail-image
                                                            data-src-delay="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                            aria-label="product image Green 5 of 10"
                                                            data-should-fade-in-on-load="true" />
                                                    </li>

                                                    <li data-carousel-pagination-item data-index="5"
                                                        data-image-id="742521155"
                                                        class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                                        tabindex="0">
                                                        <img class="wt-animated wt-display-none wt-max-width-full"
                                                            src=""
                                                            alt="<?= $str; ?> <?= $random_icon; ?> $short_article_snippet ?? image 6"
                                                            data-carousel-thumbnail-image
                                                            data-src-delay="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                            aria-label="product image 6 of 10"
                                                            data-should-fade-in-on-load="true" />
                                                    </li>

                                                    <li data-carousel-pagination-item data-index="6"
                                                        data-image-id="6796558829"
                                                        class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                                        tabindex="0">
                                                        <img class="wt-animated wt-display-none wt-max-width-full"
                                                            src=""
                                                            alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> Red"
                                                            data-carousel-thumbnail-image
                                                            data-src-delay="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                            aria-label="product image Red 7 of 10"
                                                            data-should-fade-in-on-load="true" />
                                                    </li>


                                                    <li data-carousel-pagination-item data-index="9"
                                                        data-image-id="4093120540"
                                                        class="wt-mr-xs-1 wt-mb-xs-1 wt-bg-gray wt-flex-shrink-xs-0 wt-rounded wt-overflow-hidden carousel-pagination-item-v2"
                                                        tabindex="0">
                                                        <img class="wt-animated wt-display-none wt-max-width-full"
                                                            src=""
                                                            alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 10"
                                                            data-carousel-thumbnail-image
                                                            data-src-delay="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                            aria-label="product image 10 of 10"
                                                            data-should-fade-in-on-load="true" />
                                                    </li>

                                                </ul>
                                            </div>
                                        </div>

                                        <div class="wt-overlay image-overlay wt-justify-content-center"
                                            data-image-overlay data-animate-out="false" id="image-overlay" role="dialog"
                                            aria-hidden="true">
                                            <div class="wt-display-flex-xs wt-justify-content-center wt-height-full image-overlay-main-image-container"
                                                data-overlay-modal>
                                                <button data-clg-id="WtButton"
                                                    class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-right wt-position-top wt-mt-xs-2 wt-mr-xs-2"
                                                    data-wt-overlay-close="true" aria-label="close">
                                                    <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                            viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                            <path
                                                                d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z" />
                                                        </svg></span>

                                                </button>
                                                <div data-overlay-main-image-container
                                                    class="wt-position-relative wt-mr-xl-4 wt-mr-xs-2 wt-ml-xs-2 wt-flex-grow-xs-1 wt-mb-xs-4 wt-mt-xs-10">
                                                    <button data-clg-id="WtButton"
                                                        class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-left wt-vertical-center wt-shadow-elevation-3 wt-ml-xs-2"
                                                        data-image-overlay-prev="true" aria-label="previous">
                                                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                focusable="false">
                                                                <path
                                                                    d="M16,21a0.994,0.994,0,0,1-.664-0.253L5.5,12l9.841-8.747a1,1,0,0,1,1.328,1.494L8.5,12l8.159,7.253A1,1,0,0,1,16,21Z" />
                                                            </svg></span>

                                                    </button>
                                                    <button data-clg-id="WtButton"
                                                        class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-right wt-vertical-center wt-shadow-elevation-3 wt-mr-xs-2"
                                                        data-image-overlay-next="true" aria-label="next">
                                                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                focusable="false">
                                                                <path
                                                                    d="M8,21a1,1,0,0,1-.664-1.747L15.5,12,7.336,4.747A1,1,0,0,1,8.664,3.253L18.5,12,8.664,20.747A0.994,0.994,0,0,1,8,21Z" />
                                                            </svg></span>

                                                    </button>
                                                    <ul class="wt-list-unstyled wt-overflow-hidden image-overlay-list wt-position-relative wt-vertical-center wt-display-flex-xs wt-justify-content-center"
                                                        style="padding-top: 66.6666666667%;" data-image-overlay-list
                                                        tabindex="0">
                                                        <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background"
                                                            data-listing-image data-index="0" data-image-id="742396440">
                                                            <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center"
                                                                alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 1"
                                                                data-delay-src="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                                data-delay-srcset="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 1x, <?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 2x"
                                                                data-original-image-width="1500"
                                                                data-original-image-height="1000" data-index="0"
                                                                data-src-zoom-image="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>" />
                                                        </li>
                                                        <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background"
                                                            data-listing-image data-index="1"
                                                            data-image-id="6748576166">
                                                            <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center"
                                                                alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 2"
                                                                data-delay-src="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                                data-delay-srcset="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 1x, <?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 2x"
                                                                data-original-image-width="1875"
                                                                data-original-image-height="1406" data-index="1"
                                                                data-src-zoom-image="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>" />
                                                        </li>
                                                        <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background"
                                                            data-listing-image data-index="2" data-image-id="742396164">
                                                            <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center"
                                                                alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 3"
                                                                data-delay-src="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                                data-delay-srcset="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 1x, <?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 2x"
                                                                data-original-image-width="1500"
                                                                data-original-image-height="1116" data-index="2"
                                                                data-src-zoom-image="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>" />
                                                        </li>
                                                        <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background"
                                                            data-listing-image data-index="3" data-image-id="742396020">
                                                            <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center"
                                                                alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image 4"
                                                                data-delay-src="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                                data-delay-srcset="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 1x, <?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 2x"
                                                                data-original-image-width="1500"
                                                                data-original-image-height="1032" data-index="3"
                                                                data-src-zoom-image="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>" />
                                                        </li>
                                                        <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background wt-flex-direction-column-sm"
                                                            data-listing-image data-index="4" data-image-id="830139237">
                                                            <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-horizontal-center image-overlay-img-with-caption"
                                                                alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> Green"
                                                                data-delay-src="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                                data-delay-srcset="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 1x, <?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?> 2x"
                                                                data-original-image-width="1500"
                                                                data-original-image-height="1000" data-index="4"
                                                                data-src-zoom-image="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>" />
                                                            <div
                                                                class="wt-display-flex-xs wt-flex-wrap wt-justify-content-space-between wt-mt-xs-3 wt-align-items-center">
                                                                <div class="wt-display-flex-sm wt-align-items-center">
                                                                    <span
                                                                        class="wt-text-caption wt-sem-text-on-surface-dark">Item
                                                                        in the photo is in <strong>Color:
                                                                            Green</strong></span>
                                                                    <img data-delay-src="<?= htmlspecialchars($randomImg, ENT_QUOTES, 'UTF-8')?>"
                                                                        alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> Green"
                                                                        class="wt-circle wt-overflow-hidden wt-ml-sm-2 image-overlay-caption-thumbnail">
                                                                </div>
                                                                <div>
                                                                    <button data-clg-id="WtButton"
                                                                        class="wt-btn wt-btn--secondary wt-btn--light wt-btn--small"
                                                                        data-selector="image-caption-variation-selection-button"
                                                                        data-image-id="830139237">
                                                                        Select this option

                                                                    </button>

                                                                    <div class="wt-display-none"
                                                                        data-selector="image-caption-variation-selection-confirmation-message"
                                                                        data-image-id="830139237">
                                                                        <div class="wt-display-inline-flex-xs wt-p-xs-1"
                                                                            aria-hidden="true">
                                                                            <span
                                                                                class="wt-icon wt-sem-text-on-surface-dark wt-icon--smaller"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="m10.552 16.967 7.204-8.312-1.512-1.31-5.796 6.689-3.24-3.241-1.415 1.414z" />
                                                                                </svg></span>
                                                                            <p
                                                                                class="wt-text-caption-title wt-sem-text-on-surface-dark wt-ml-xs-1">
                                                                                Option selected!
                                                                            </p>
                                                                        </div>
                                                                    </div>

                                                                    <div class="wt-display-none"
                                                                        data-selector="image-caption-variation-selection-disabled-message"
                                                                        data-image-id="830139237">
                                                                        <div class="wt-display-inline-flex-xs wt-p-xs-1"
                                                                            aria-hidden="true">
                                                                            <span
                                                                                class="wt-icon wt-sem-text-on-surface-dark wt-icon--smaller"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="M7 20c-.2 0-.5-.1-.7-.3-.4-.4-.4-1 0-1.4C7.6 16.9 9.9 16 12 16c2.2 0 4.4.9 5.7 2.3.4.4.4 1 0 1.4s-1 .4-1.4 0c-1-1-2.7-1.7-4.3-1.7s-3.3.7-4.3 1.7c-.2.2-.4.3-.7.3m12.6-7.9c-1.4 0-2.6-.7-3.3-1.3-.4-.4-.4-1 0-1.4s1-.4 1.4 0c.3.3 1.9 1.6 3.6 0 .4-.4 1-.4 1.4 0s.4 1 0 1.4c-1 .9-2.1 1.3-3.1 1.3m-15 0c-1.4 0-2.6-.7-3.3-1.3-.4-.4-.4-1 0-1.4s1-.4 1.4 0c.3.3 1.9 1.6 3.6 0 .4-.4 1-.4 1.4 0s.4 1 0 1.4c-1 .9-2.1 1.3-3.1 1.3" />
                                                                                </svg></span>
                                                                            <p
                                                                                class="wt-text-caption-title wt-sem-text-on-surface-dark wt-ml-xs-1">
                                                                                This option is sold out.
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <?php foreach ($carouselImages as $index => $img): ?>
                                                        <li class="<?php echo $index === 0 ? '' : 'wt-display-none '; ?>wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background"
                                                            data-listing-image data-index="<?php echo $index; ?>"
                                                            data-image-id="img_<?php echo $index; ?>">
                                                            <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center"
                                                                alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image <?php echo $index + 1; ?>"
                                                                data-delay-src="<?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8')?>"
                                                                data-delay-srcset="<?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8')?> 1x, <?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8')?> 2x"
                                                                data-original-image-width="3000"
                                                                data-original-image-height="2250"
                                                                data-index="<?php echo $index; ?>"
                                                                data-src-zoom-image="<?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8')?>" />
                                                        </li>
                                                        <?php
endforeach; ?>
                                                        <div class="wt-z-index-1 click-to-zoom-text wt-position-absolute wt-display-none"
                                                            data-click-to-zoom-toast>
                                                            <span data-clg-id="WtBadge"
                                                                class="wt-badge wt-badge--default wt-text-body-01">
                                                                <span class="wt-icon wt-icon--smallest"><svg
                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                        viewBox="0 0 24 24" aria-hidden="true"
                                                                        focusable="false">
                                                                        <path
                                                                            d="M10,2a8,8,0,1,0,8,8A8.009,8.009,0,0,0,10,2Zm0,14a6,6,0,1,1,6-6A6.007,6.007,0,0,1,10,16Z" />
                                                                        <path
                                                                            d="M14,9H11V6A1,1,0,1,0,9,6V9H6a1,1,0,0,0,0,2H9v3a1,1,0,1,0,2,0V11h3A1,1,0,0,0,14,9Z" />
                                                                        <path
                                                                            d="M21.707,20.293l-4-4a1,1,0,0,0-1.414,1.414l4,4A1,1,0,0,0,21.707,20.293Z" />
                                                                    </svg></span>
                                                                Click to zoom

                                                            </span>
                                                        </div>
                                                    </ul>
                                                </div>
                                                <div class="wt-overflow-y-auto wt-position-relative image-overlay-thumbnail-container wt-z-index-1 wt-pt-xs-10"
                                                    data-thumbnail-container>
                                                    <ul data-image-overlay-thumbnail-list
                                                        class="wt-z-index-1 wt-list-unstyled wt-flex-direction-row-lg wt-flex-direction-column-xs wt-display-flex-xs wt-flex-wrap wt-align-content-flex-start">

                                                        <?php foreach ($carouselImages as $index => $img): ?>
                                                        <li data-index="<?php echo $index; ?>"
                                                            class="wt-rounded wt-overflow-hidden image-overlay-thumbnail wt-mb-xs-2"
                                                            tabindex="0" data-image-id="img_<?php echo $index; ?>">
                                                            <img class="wt-skeleton-ui"
                                                                alt="<?= $str; ?> <?= $random_icon; ?> <?= $short_article_snippet?> image <?php echo $index + 1; ?>"
                                                                data-carousel-thumbnail-image loading="lazy"
                                                                src="<?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8')?>" />
                                                        </li>
                                                        <?php
endforeach; ?>

                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="n-columns-2" bis_skin_checked="1">
                                    <a href="<?= $registerUrl; ?>" rel="nofollow noreferrer"
                                        class="login">เข้าสู่ระบบ</a>
                                    <a href="<?= $registerUrl; ?>" rel="nofollow noreferrer" class="register">รายการ</a>
                                </div>
                                <div class="wt-display-flex-xs wt-justify-content-flex-end wt-mt-xs-3">
                                    <a class="wt-text-link wt-text-link-underline" href="<?= $link; ?>">
                                        <span class="wt-icon wt-icon--smaller-xs wt-nudge-r-4"><svg
                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                aria-hidden="true" focusable="false">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M7 3a1 1 0 0 0-2 0v18a1 1 0 1 0 2 0v-6h14.766l-3.6-6 3.6-6zm0 2v8h11.234l-2.4-4 2.4-4z" />
                                            </svg></span>Report this item to
                                        <?= $str; ?>
                                    </a>
                                </div>

                                <div data-wt-overlay data-report-item-overlay id="report-item-overlay"
                                    class="wt-overlay wt-display-none" role="dialog" aria-hidden="true"
                                    aria-modal="false" aria-label="report-item-overlay-title">
                                    <div class="wt-overlay__modal" data-overlay-modal>
                                        <button
                                            class="wt-btn wt-btn--icon wt-btn--tertiary wt-btn--light wt-overlay__close-icon"
                                            data-wt-overlay-close aria-label="Close">
                                            <span class="etsy-icon wt-icon--smaller"><svg
                                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                    aria-hidden="true" focusable="false">
                                                    <path
                                                        d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z" />
                                                </svg></span>
                                        </button>
                                        <div data-report-item-form-container class="wt-display-none">
                                            <div class="wt-overlay__header report-item-step">
                                                <h2 class="wt-text-heading" id="report-item-overlay-title">What’s wrong
                                                    with this listing?</h2>
                                            </div>
                                            <div class="wt-overlay__header report-item-step wt-display-none">
                                                <h3 class="wt-text-heading" id="report-item-overlay-title-more">Add more
                                                    details</h3>
                                                <h3 class="wt-text-body-01 wt-mt-xs-3">Share more specifics to help us
                                                    review this item and protect our marketplace.</h3>
                                            </div>
                                            <form data-report-item-form action="/add_report.php" method="post">
                                                <div class="report-item-step">
                                                    <div class="wt-select wt-mb-xs-3">
                                                        <select class="wt-select__element" id="report-item-choices"
                                                            data-report-item-choices>
                                                            <optgroup>
                                                                <option value="default">Choose a reason…</option>
                                                                <option value="order-problem">There’s a problem with my
                                                                    order</option>
                                                                <option value="ip-policy">It uses my intellectual
                                                                    property without permission</option>
                                                                <option value="flag-item">I don’t think it meets Etsy’s
                                                                    policies</option>
                                                            </optgroup>
                                                        </select>
                                                        <label for="report-item-choices"
                                                            class="wt-screen-reader-only">Choose a reason…</label>
                                                    </div>
                                                    <div data-report-choice="order-problem" id="order-problem"
                                                        class="wt-display-none">
                                                        <p class="wt-mb-xs-2 prose">The first thing you should do is
                                                            contact the seller directly.</p>
                                                        <p class="wt-mb-xs-2 ip-policy prose">If you’ve already done
                                                            that, your item hasn’t arrived, or it’s not as described,
                                                            you can report that to Etsy by opening a case.</p>
                                                        <p class="wt-mb-xs-2 prose">
                                                            <a href="/help/article/5307" target="_blank">
                                                                Report a problem with an order
                                                            </a>
                                                        </p>
                                                    </div>
                                                    <div data-report-choice="ip-policy" id="ip-policy"
                                                        class="wt-display-none">
                                                        <p class="wt-mb-xs-2 prose">We take intellectual property
                                                            concerns very seriously, but many of these problems can be
                                                            resolved directly by the parties involved. We suggest
                                                            contacting the seller directly to respectfully share your
                                                            concerns.</p>
                                                        <p class="wt-mb-xs-2 prose">If you’d like to file an allegation
                                                            of infringement, you’ll need to follow the process described
                                                            in our <a href='/legal/ip' target='_blank'>Copyright and
                                                                Intellectual Property Policy</a>.</p>
                                                    </div>
                                                    <div data-report-choice="flag-item" id="flag-item"
                                                        class="wt-display-none">
                                                        <div class="wt-mb-xs-2">
                                                            <a href="/legal/sellers#allowed" target="_blank">
                                                                Review how we define handmade, vintage and supplies
                                                            </a>
                                                        </div>
                                                        <div class="wt-mb-xs-2">
                                                            <a href="/legal/prohibited" target="_blank">
                                                                See a list of prohibited items and materials
                                                            </a>
                                                        </div>
                                                        <div class="wt-mb-xs-4">
                                                            <a href="/legal/policy/listing-mature-content-correctly/242665462117"
                                                                target="_blank">
                                                                Read our mature content policy
                                                            </a>
                                                        </div>
                                                        <div data-report-reason class="wt-validation">
                                                            <fieldset class="wt-mb-xs-4">
                                                                <legend class="wt-label wt-mb-xs-2">Tell us why you're
                                                                    reporting this item</legend>
                                                                <div class="wt-radio wt-mb-xs-1">
                                                                    <input data-report-reason-input
                                                                        data-flag-name="not_handmade_vintage_or_craft"
                                                                        type="radio" class="wt-radio"
                                                                        id="flag_not_handmade_vintage_or_craft"
                                                                        name="flag_type_mnemonic"
                                                                        value="LISTING_CSV_MEMBER_FLAG">
                                                                    <label for="flag_not_handmade_vintage_or_craft">It's
                                                                        not handmade, vintage, or craft supplies</label>
                                                                </div>
                                                                <div class="wt-radio wt-mb-xs-1">
                                                                    <input data-report-reason-input
                                                                        data-flag-name="pornographic" type="radio"
                                                                        class="wt-radio" id="flag_pornographic"
                                                                        name="flag_type_mnemonic"
                                                                        value="OC_PORNOGRAPHY">
                                                                    <label for="flag_pornographic">It's
                                                                        pornographic</label>
                                                                </div>
                                                                <div class="wt-radio wt-mb-xs-1">
                                                                    <input data-report-reason-input
                                                                        data-flag-name="hate_speech_or_harassment"
                                                                        type="radio" class="wt-radio"
                                                                        id="flag_hate_speech_or_harassment"
                                                                        name="flag_type_mnemonic"
                                                                        value="OC_HATE_VIOLENT_HARMFUL">
                                                                    <label for="flag_hate_speech_or_harassment">It's
                                                                        hate speech or harassment</label>
                                                                </div>
                                                                <div class="wt-radio wt-mb-xs-1">
                                                                    <input data-report-reason-input
                                                                        data-flag-name="minor_safety" type="radio"
                                                                        class="wt-radio" id="flag_minor_safety"
                                                                        name="flag_type_mnemonic"
                                                                        value="LISTING_MINOR_SAFETY">
                                                                    <label for="flag_minor_safety">It's a threat to
                                                                        minor safety</label>
                                                                </div>
                                                                <div class="wt-radio wt-mb-xs-1">
                                                                    <input data-report-reason-input
                                                                        data-flag-name="violence_or_self_harm"
                                                                        type="radio" class="wt-radio"
                                                                        id="flag_violence_or_self_harm"
                                                                        name="flag_type_mnemonic"
                                                                        value="OC_HATE_VIOLENT_HARMFUL">
                                                                    <label for="flag_violence_or_self_harm">It promotes
                                                                        violence or self-harm</label>
                                                                </div>
                                                                <div class="wt-radio wt-mb-xs-1">
                                                                    <input data-report-reason-input
                                                                        data-flag-name="dangerous_or_hazardous"
                                                                        type="radio" class="wt-radio"
                                                                        id="flag_dangerous_or_hazardous"
                                                                        name="flag_type_mnemonic"
                                                                        value="LISTING_PROHIBITED">
                                                                    <label for="flag_dangerous_or_hazardous">It's
                                                                        dangerous or hazardous</label>
                                                                </div>
                                                                <div class="wt-radio wt-mb-xs-1">
                                                                    <input data-report-reason-input
                                                                        data-flag-name="violates_law" type="radio"
                                                                        class="wt-radio" id="flag_violates_law"
                                                                        name="flag_type_mnemonic"
                                                                        value="CC_REPORTED_ILLEGAL_CONTENT">
                                                                    <label for="flag_violates_law">It's violating a
                                                                        specific law or regulation</label>
                                                                </div>
                                                                <div class="wt-radio wt-mb-xs-1">
                                                                    <input data-report-reason-input
                                                                        data-flag-name="violates_not_listed_policy"
                                                                        type="radio" class="wt-radio"
                                                                        id="flag_violates_not_listed_policy"
                                                                        name="flag_type_mnemonic"
                                                                        value="LISTING_PROHIBITED">
                                                                    <label for="flag_violates_not_listed_policy">It
                                                                        violates a policy that's not listed here</label>
                                                                </div>
                                                                <div data-error="no-report-reason" id="no-report-reason"
                                                                    class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical">
                                                                    Please choose a reason</div>
                                                            </fieldset>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="report-item-step wt-display-none">
                                                    <div data-report-comment class="wt-validation" tabindex="0">
                                                        <label class="wt-screen-reader-only"
                                                            for="report-item-reason">Include anything else we should
                                                            know about this item</label>
                                                        <textarea id="report-item-reason" data-report-comment-input
                                                            name="reason" class="wt-textarea"
                                                            placeholder="Include anything else we should know about this item"></textarea>
                                                        <div data-error="no-report-comment" id="no-report-comment"
                                                            class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical wt-mt-xs-2">
                                                            <span
                                                                class="wt-icon wt-sem-text-on-surface-dark wt-validation__icon"><svg
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 24 24" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5" />
                                                                </svg></span>&nbsp;Make sure to add more details.
                                                        </div>
                                                        <div data-error="comment-min-length-illegal-content"
                                                            id="comment-min-length-illegal-content"
                                                            class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical wt-mt-xs-2">
                                                            <span
                                                                class="wt-icon wt-sem-text-on-surface-dark wt-validation__icon"><svg
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 24 24" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5" />
                                                                </svg></span>&nbsp;Add more details, including a law or
                                                            regulation name (10 characters min).
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-report-bonafide
                                                    class="wt-mt-xs-2 wt-mb-xs-2 wt-sem-text-secondary wt-display-none">
                                                    By submitting this report, you confirm the information and claims in
                                                    this form are accurate.
                                                </div>
                                                <div data-report-item-overlay-footer
                                                    class="wt-overlay__footer wt-pt-xs-0 wt-display-none"
                                                    id="overlay-footer">
                                                    <input type="hidden" name="_nnc"
                                                        value="3:1757662784:rVoyyzJWnZm47KwhdJHu9wLoaQ7_:07f5e37a712d3bcb9b8e88f0358250b0e9d380243555cbeecae84ed4f69f326d"
                                                        class="hidden csrf" />
                                                    <input type="hidden" name="target_id" value="226335136" />
                                                    <input type="hidden" name="target_type" value="listing" />
                                                    <input type='hidden' name='send_report' value='true' />
                                                    <input type='hidden' name='ref'
                                                        value="hp_consolidated_gifting_listings-2" />
                                                    <input type='hidden' name='platform' value="web" />
                                                    <input type='hidden' name='search_query' value="" />
                                                    <div class="wt-overlay__footer__cancel">
                                                        <button data-report-back-button type="button"
                                                            class="wt-btn wt-btn-transparent report-item-step wt-display-none">
                                                            Go back
                                                        </button>
                                                    </div>
                                                    <div class="wt-overlay__footer__action">
                                                        <button data-report-next-button type="button"
                                                            class="wt-btn wt-btn--primary report-item-step">
                                                            Next
                                                        </button>
                                                        <button data-report-submit-button type="submit"
                                                            class="wt-btn wt-btn--primary report-item-step wt-display-none">
                                                            Submit report
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="cart-col wt-order-xs-2 wt-mb-lg-5">
                            <div id="listing-page-cart"
                                class="wt-display-flex-lg wt-flex-direction-column-md wt-flex-lg-3 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-0 wt-pr-lg-5 wt-pl-xs-2 wt-pr-xs-2">
                                <div class="wt-mb-xs-1 wt-mt-xs-1">
                                    <div data-appears-component-name="Etsy-Modules-ListingPage-UrgencySignal-RecsRankingApiSpec"
                                        data-appears-event-data='{"module_placement":"lp_urgency_signals","datasets":["Common_Signal_CustomCandidatesSignalRankerV3"],"targets":[],"logging_class":"Etsy\\Modules\\ListingPage\\UrgencySignal\\RecsRankingApiSpec","page_listing_id":226335136,"mmx_request_uuid_map":{"f947914f-cc2a-4b3e-9f78-ec22f1ffe857":[0,1,2,3]},"candidate_source_map":{"signals-ranker-v3-extractor":[0,1,2,3]},"second_pass_ranker_map":{"signals-ranker-v3":[0,1,2,3]},"client_provided_features":{"browser":{"acceptLanguage":"en-US","browser":"Chrome","currency":"THB","localeRegion":"TH","operatingSystem":"Windows 10","platform":"desktop","platformEtsyApp":"web","platformMobileDevice":"unidentified","source":"directLanding"},"date_time":{"dayOfWeek":"5","hourOfDay":"07"},"user":{"locationLatitude":null,"locationLongitude":null,"locationZip":"unidentified","userPreferredLanguage":"en-US"}},"scores":[0.4565420000000000033679725675028748810291290283203125,0.4565420000000000033679725675028748810291290283203125,0.4565420000000000033679725675028748810291290283203125,0.4565420000000000033679725675028748810291290283203125],"datasets_map":{"Common_Signal_CustomCandidatesSignalRankerV3":[0,1,2,3]},"target_listing_id":226335136,"candidates":["almost_gone_and_cart_combo","in_cart_only","lp_views_only","quantity_only"],"refTag":"lp_urgency_signals","signals":["almost_gone_and_cart_combo","in_cart_only","lp_views_only","quantity_only"],"rec_event_name":"recommendations_module"}'
                                        class='recs-appears-logger'>
                                        <p class="wt-text-title-01 wt-sem-text-critical ">Only 8 left and in 20+ carts
                                        </p>
                                    </div>
                                </div>
                                <div class="wt-display-flex-xs wt-align-items-center">
                                    <div data-appears-component-name="price">
                                        <div class="wt-display-flex-xs  wt-align-items-center wt-flex-wrap"
                                            data-selector="price-only" data-buy-box-region="price">
                                            <p class="wt-text-title-larger wt-mr-xs-1
                wt-text-slime
            ">
                                                <span class="wt-screen-reader-only">Price:</span>THB 1.00
                                            </p>
                                            <p class="wt-text-caption wt-sem-text-secondary">
                                                <span class="wt-screen-reader-only">Original Price:</span>
                                                <span class="wt-text-strikethrough ">
                                                    THB 10.00
                                                </span>
                                            </p>

                                            <div data-clg-id="WtSpinner"
                                                class="wt-spinner wt-spinner--01 wt-display-none" aria-live="assertive"
                                                data-buy-box-price-spinner="">
                                                <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <circle fill="transparent" cx="12" cy="12" r="10" />
                                                    </svg></span>
                                                Loading
                                            </div>

                                        </div>
                                    </div>
                                    <div class="wt-ml-xs-2">
                                        <span data-clg-id="WtBadge" class="wt-badge wt-badge--statusValue">
                                            <strong>90% off</strong>

                                        </span>
                                    </div>
                                </div>
                                <div class="wt-mb-xs-1  ">
                                    <div id="sale-ending-soon-countdown">
                                        <p class="wt-text-title-01 wt-sem-text-monetary-value">
                                            Sale ends on September 30
                                        </p>
                                    </div>

                                </div>

                                <div data-buy-box-region="vat_messaging">
                                    <div class="wt-sem-text-secondary wt-text-caption wt-pt-xs-1 wt-pb-xs-1">
                                        Local taxes included (where applicable)
                                    </div>
                                </div>


                                <div class="wt-mt-xs-1 wt-mb-xs-1">
                                    <h1 data-buy-box-listing-title="true" tabindex="0"
                                        class="wt-line-height-tight wt-break-word wt-text-body">
                                        <?= $str; ?>
                                        <?= mb_substr(strip_tags($random_title), 0, 30, 'UTF-8'); ?>
                                        <?= $random_icon; ?> |
                                        <?= $brandName; ?>
                                    </h1>
                                </div>
                                <div class="wt-mb-xs-3">
                                    <div
                                        class="wt-display-inline-flex-xs wt-align-items-center wt-flex-wrap lp-shop-header">
                                        <div class="wt-display-inline-flex-xs wt-align-items-center
        
    ">
                                            <span class="wt-text-title-small">
                                                <a href="https://www.etsy.com/shop/<?= $str; ?>?ref=shop-header-name&listing_id=226335136&from_page=listing"
                                                    class="wt-text-link-no-underline wt-sem-text-primary">
                                                    <?= $str; ?>
                                                </a>
                                            </span>
                                            &nbsp;<div class="wt-popover star-seller-badge-listing-page"
                                                data-wt-popover>
                                                <button data-wt-popover-trigger
                                                    class="wt-popover__trigger wt-popover__trigger--underline"
                                                    aria-label="Star Seller" aria-describedby="star-seller-popover">
                                                    <span
                                                        class="wt-icon wt-icon--smaller-xs wt-icon--core wt-fill-star-seller-dark"
                                                        alt="star_seller"><svg xmlns="http://www.w3.org/2000/svg"
                                                            viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                            <path
                                                                d="m20.902 7.09-2.317-1.332-1.341-2.303H14.56L12.122 2 9.805 3.333H7.122L5.78 5.758 3.341 7.09v2.667L2 12.06l1.341 2.303v2.666l2.318 1.334L7 20.667h2.683L12 22l2.317-1.333H17l1.342-2.303 2.317-1.334v-2.666L22 12.06l-1.341-2.303V7.09zm-6.097 6.062.732 3.515-.488.363-2.927-1.818-3.049 1.697-.488-.363.732-3.516-2.56-2.181.121-.485 3.537-.243 1.341-3.273h.488l1.341 3.273 3.537.243.122.484z" />
                                                        </svg></span>
                                                </button>
                                                <div class="wt-p-xs-3" id="star-seller-popover" role="tooltip">
                                                    <p class="wt-mb-xs-1 wt-text-title-01">
                                                        Star Seller
                                                    </p>
                                                    <p class="wt-text-caption">
                                                        Star Sellers have an outstanding track record for providing a
                                                        great customer experience—they consistently earned 5-star
                                                        reviews, shipped orders on time, and replied quickly to any
                                                        messages they received.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wt-ml-xs-1">
                                            <div class="wt-text-link-no-underline review-stars-text-decoration-none">
                                                <a href="#reviews" data-click-source="review_stars"
                                                    aria-label="4.7 out of 5 stars. See reviews."><span
                                                        class="wt-display-inline-block wt-mr-xs-1"
                                                        data-stars-svg-container>
                                                        <input type="hidden" name="initial-rating" value="4.6623" />
                                                        <input type="hidden" name="rating" value="4.6623" />
                                                        <span class="wt-screen-reader-only">4.5 out of 5 stars</span>

                                                        <span>
                                                            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest"
                                                                data-rating="0"><svg xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="3 3 18 18" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path
                                                                        d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z" />
                                                                </svg></span>
                                                            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest"
                                                                data-rating="1"><svg xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="3 3 18 18" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path
                                                                        d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z" />
                                                                </svg></span>
                                                            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest"
                                                                data-rating="2"><svg xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="3 3 18 18" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path
                                                                        d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z" />
                                                                </svg></span>
                                                            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest"
                                                                data-rating="3"><svg xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="3 3 18 18" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path
                                                                        d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z" />
                                                                </svg></span>
                                                            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest"
                                                                data-rating="4"><svg xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="3 3 18 18" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path
                                                                        d="M21.11,10c-.13-.42-.15-.46-.28-.88l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52C3,9.57,3,9.61,2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14ZM12.9,15.79l-.9-.53V6.47l1.21,2.84.41,1,1.05.09,3.07.27-2.32,2-.8.69.24,1,.69,3Z" />
                                                                </svg></span>
                                                        </span>
                                                    </span></a>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="wt-mb-xs-6 wt-mb-lg-0">
                                    <div data-buy-box>
                                        <div class="wt-mb-xs-3">
                                            <div class="wt-mb-xs-3">
                                                <div data-selector="fulfillment-differentiators-region">
                                                    <div data-selector="fulfillment-differentiators-content"
                                                        class="wt-display-flex-xs wt-flex-direction-column-xs"
                                                        style="row-gap:6px;">




                                                        <div class="wt-display-flex-xs wt-align-items-center">
                                                            <span
                                                                class="wt-icon wt-icon--smaller-xs wt-flex-shrink-xs-0 wt-fill-denim-light wt-mr-xs-1"><svg
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 24 24" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path
                                                                        d="M9.059 20.473 21.26 6.15l-1.52-1.298-10.8 12.675-4.734-4.734-1.414 1.414z" />
                                                                </svg></span>
                                                            <p class="wt-text-caption">Returns accepted</p>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>


                                            <div data-appears-component-name="variations">
                                                <div data-selector="listing-page-variations">
                                                    <div class="wt-validation wt-mb-xs-2"
                                                        data-selector="listing-page-variation"
                                                        data-variation-number="0">
                                                        <div
                                                            class="wt-display-flex-xs wt-justify-content-space-between wt-align-items-baseline">
                                                            <label data-clg-id="WtLabel" for="variation-selector-0"
                                                                class="wt-label wt-label--small"
                                                                id="label-variation-selector-0">
                                                                <span data-label>
                                                                    Size
                                                                </span>



                                                            </label>

                                                        </div>

                                                        <div class="wt-select">
                                                            <select id="variation-selector-0"
                                                                class="wt-select__element " data-variation-number="0"
                                                                aria-labelledby="label-variation-selector-0">
                                                                <option value="" selected>
                                                                    Select an option
                                                                </option>
                                                                <option value="2800020158">
                                                                    2/3 years
                                                                </option>
                                                                <option value="2800020162">
                                                                    4/5 years
                                                                </option>
                                                                <option value="2800020166">
                                                                    6 years
                                                                </option>
                                                                <option value="2800020170">
                                                                    7 years
                                                                </option>
                                                            </select>
                                                        </div>
                                                        <div id="error-variation-selector-0"
                                                            class="wt-validation__message wt-validation__message--is-hidden">
                                                            <span
                                                                class="wt-icon wt-icon--smaller-xs wt-circle wt-sem-text-on-surface-dark wt-bg-brick-dark wt-mr-xs-1"><svg
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 24 24" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5" />
                                                                </svg></span>
                                                            <p class="wt-text-body-small wt-display-inline">
                                                                Please select an option
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="wt-validation wt-mb-xs-2"
                                                        data-selector="listing-page-variation"
                                                        data-variation-number="1">
                                                        <div
                                                            class="wt-display-flex-xs wt-justify-content-space-between wt-align-items-baseline">
                                                            <label data-clg-id="WtLabel" for="variation-selector-1"
                                                                class="wt-label wt-label--small"
                                                                id="label-variation-selector-1">
                                                                <span data-label>
                                                                    Color
                                                                </span>



                                                            </label>

                                                        </div>

                                                        <div class="wt-select">
                                                            <select id="variation-selector-1"
                                                                class="wt-select__element " data-variation-number="1"
                                                                aria-labelledby="label-variation-selector-1">
                                                                <option value="" selected>
                                                                    Select an option
                                                                </option>
                                                                <option value="5232721970">
                                                                    Green
                                                                </option>
                                                                <option value="5211931469">
                                                                    Red
                                                                </option>
                                                            </select>
                                                        </div>
                                                        <div id="error-variation-selector-1"
                                                            class="wt-validation__message wt-validation__message--is-hidden">
                                                            <span
                                                                class="wt-icon wt-icon--smaller-xs wt-circle wt-sem-text-on-surface-dark wt-bg-brick-dark wt-mr-xs-1"><svg
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 24 24" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5" />
                                                                </svg></span>
                                                            <p class="wt-text-body-small wt-display-inline">
                                                                Please select an option
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="wt-validation wt-mb-xs-2"
                                                data-selector="listing-page-personalization"
                                                data-personalization-required>
                                                <div class="wt-content-toggle">
                                                    <button data-clg-id="WtButton"
                                                        class="wt-btn wt-btn--transparent wt-btn--small wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush"
                                                        data-selector="enhanced-perso-content-toggle"
                                                        data-wt-content-toggle="true" data-animate="true"
                                                        aria-controls="enhanced-perso-content">
                                                        <span class="wt-icon wt-icon--smaller-xs"
                                                            data="button-icon-add"><svg
                                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                                aria-hidden="true" focusable="false">
                                                                <path
                                                                    d="M20,11H13V4a1,1,0,0,0-2,0v7H4a1,1,0,0,0,0,2h7v7a1,1,0,0,0,2,0V13h7A1,1,0,0,0,20,11Z" />
                                                            </svg></span>
                                                        <span class="wt-icon wt-icon--smaller-xs wt-display-none"
                                                            data="button-icon-minus"><svg
                                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                                aria-hidden="true" focusable="false">
                                                                <path
                                                                    d="M20 13H4c-.553 0-1-.447-1-1s.447-1 1-1h16c.553 0 1 .447 1 1s-.447 1-1 1z" />
                                                            </svg></span>
                                                        <span class="wt-ml-xs-1 wt-width-full wt-text-title-small">
                                                            Add personalization
                                                        </span>

                                                    </button>

                                                    <div id="enhanced-perso-content" class="wt-content-toggle__body">
                                                        <div data-appears-component-name="personalization"
                                                            data-appears-event-data='{"listing_id":226335136,"personalization_field_count":1}'>
                                                            <ul data-clg-id="WtList"
                                                                class="wt-list wt-list-unstyled wt-validation wt-text-body"
                                                                role="list">
                                                                <li id="perso-field-1384937017000"
                                                                    data-field-id="1384937017000"
                                                                    data-is-required="true" class="wt-mt-xs-2">
                                                                    <div
                                                                        class="wt-display-flex-xs wt-justify-content-space-between">
                                                                        <label for="perso-input-1384937017000"
                                                                            class="wt-label wt-label--small"
                                                                            data-label-container
                                                                            data-label-translation=""
                                                                            data-label-original="">
                                                                            <span data-label>
                                                                                Personalization
                                                                            </span>
                                                                        </label>
                                                                    </div>
                                                                    <div data-instructions-container
                                                                        class="wt-text-caption wt-sem-text-secondary wt-mb-xs-1">
                                                                        <p data-instructions>
                                                                            Add a phone number and an e-mail address you
                                                                            check often. Both are required to fill out
                                                                            your shipping label. Thanks.
                                                                        </p>
                                                                    </div>
                                                                    <textarea id="perso-input-1384937017000"
                                                                        class="wt-input perso-text-area"></textarea>
                                                                    <div
                                                                        class="wt-display-flex-xs wt-flex-direction-row-xs wt-flex-gap-xs-1 wt-justify-content-space-between wt-align-items-baseline">
                                                                        <div class="wt-validation__message wt-display-flex-xs wt-align-items-center"
                                                                            role="alert">
                                                                            <div class="wt-mr-xs-1">
                                                                                <span
                                                                                    class="wt-icon wt-icon--smaller-xs wt-circle wt-sem-text-on-surface-dark wt-bg-brick-dark wt-display-none"
                                                                                    data-selector="personalization-error-icon"><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        viewBox="0 0 24 24"
                                                                                        aria-hidden="true"
                                                                                        focusable="false">
                                                                                        <path fill-rule="evenodd"
                                                                                            clip-rule="evenodd"
                                                                                            d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5" />
                                                                                    </svg></span>
                                                                            </div>
                                                                            <div class="wt-text-body-small"
                                                                                data-selector="personalization-error"
                                                                                data-character-limit-error="You’ve reached the limit!"
                                                                                data-empty-error="This field is required">
                                                                            </div>
                                                                        </div>
                                                                        <div data-selector="listing-page-personalization-character-remaining"
                                                                            class="wt-text-caption wt-text-right-xs wt-mt-xs-1"
                                                                            data-max-char-count="256">
                                                                            0/256
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                                        <div
                                            class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-wrap wt-flex-direction-column-lg wt-flex-gap-xs-2">





                                            <div class="wt-display-none" id="mao-button-disabled-text-div">
                                                <p class="wt-text-body-body wt-sem-text-secondary wt-text-center-xs">
                                                    You can only make an offer when buying a single item
                                                </p>
                                            </div>
                                            <div data-appears-component-name="add_to_cart_form">
                                                <div class="wt-validation wt-flex-xs-1"
                                                    data-buy-box-region="add_to_cart_form">
                                                    <form action="/cart/listing.php" method="post"
                                                        class="add-to-cart-form" data-buy-box-add-to-cart-form>
                                                        <input type="hidden" name="listing_id" value="226335136" />
                                                        <input type="hidden" name="ref" value="listing_page" />
                                                        <input type="hidden" name="page_type" value="view_listing" />
                                                        <input type="hidden" name="_nnc"
                                                            value="3:1757662784:l8RK9_iB7Y6bua5h5TYK0yakA1Iy:9e5c2de579e7d4fbe6f252be9296e57e4d8d2566a70b6bb4039aef0251578f6f"
                                                            class="wt-display-none" />
                                                        <input type="hidden" name="listing_inventory_id" value="" />
                                                        <input type="hidden" name="shipping_method_id" value="" />
                                                        <input type="hidden" name="personalization" value="" />
                                                        <input type="hidden" name="multiple_personalizations"
                                                            value="" />
                                                        <input type="hidden" name="quantity" value="1" />
                                                        <input type="hidden" name="_nnc"
                                                            value="3:1757662784:l8RK9_iB7Y6bua5h5TYK0yakA1Iy:9e5c2de579e7d4fbe6f252be9296e57e4d8d2566a70b6bb4039aef0251578f6f"
                                                            class="wt-display-none" />
                                                        <div class="wt-width-full" data-add-to-cart-button=""
                                                            data-selector="add-to-cart-button">
                                                            <button data-clg-id="WtButton"
                                                                class="wt-btn wt-btn--filled wt-width-full wt-no-wrap"
                                                                type="submit">
                                                                <span>Add to cart</>

                                                                    <div data-clg-id="WtSpinner"
                                                                        class="wt-spinner wt-spinner--01"
                                                                        aria-live="assertive" role="alert">
                                                                        <span class="wt-icon"><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                                focusable="false">
                                                                                <circle fill="transparent" cx="12"
                                                                                    cy="12" r="10" />
                                                                            </svg></span>
                                                                        Loading
                                                                    </div>


                                                            </button>
                                                        </div>
                                                    </form>

                                                    <p
                                                        class="purchase-accept-terms wt-display-none wt-mt-xs-2 wt-sem-text-primary wt-text-body-small wt-width-full">
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div
                                        class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-direction-row-md wt-flex-direction-column-lg wt-flex-gap-md-2 wt-flex-gap-lg-0 wt-justify-content-space-between">



                                    </div>

                                    <div class="wt-mt-xs-3">
                                        <div data-appears-component-name="secondary_nudges">
                                            <div class="wt-display-flex-xs wt-align-items-center wt-mt-xs-2">
                                                <div class="wt-pr-xs-2" data-add-class-when-in-view="is-in-view">
                                                    <span class="inline-svg wt-display-flex-xs"><svg
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            xmlns:xlink="http://www.w3.org/1999/xlink"
                                                            cache-id="ca29373808df4f9eaa432cd66b455877"
                                                            viewBox="0 0 24 24" shape-rendering="geometricPrecision"
                                                            text-rendering="geometricPrecision" height="48" width="48"
                                                            aria-hidden="true" focusable="false">
                                                            <style>
                                                                .is-in-view #lp-collage-star-seller-badge-left {
                                                                    animation: lp-collage-star-seller-badge-left__to 2000ms linear 1 normal forwards
                                                                }

                                                                @keyframes lp-collage-star-seller-badge-left__to {
                                                                    0% {
                                                                        transform: translate(3.4px, 12.4px)
                                                                    }

                                                                    50% {
                                                                        transform: translate(3.4px, 12.4px)
                                                                    }

                                                                    75% {
                                                                        transform: translate(3.2px, 12.4px)
                                                                    }

                                                                    100% {
                                                                        transform: translate(3.2px, 12.4px)
                                                                    }
                                                                }

                                                                .is-in-view #e2oQ4aPtn8x2 {
                                                                    animation: e2oQ4aPtn8x2_c_o 2000ms linear 1 normal forwards
                                                                }

                                                                @keyframes e2oQ4aPtn8x2_c_o {
                                                                    0% {
                                                                        opacity: 0
                                                                    }

                                                                    50% {
                                                                        opacity: 0
                                                                    }

                                                                    75% {
                                                                        opacity: 1
                                                                    }

                                                                    100% {
                                                                        opacity: 1
                                                                    }
                                                                }

                                                                .is-in-view #lp-collage-star-seller-badge-right {
                                                                    animation: lp-collage-star-seller-badge-right__to 2000ms linear 1 normal forwards
                                                                }

                                                                @keyframes lp-collage-star-seller-badge-right__to {
                                                                    0% {
                                                                        transform: translate(20.6px, 12.4px)
                                                                    }

                                                                    50% {
                                                                        transform: translate(20.6px, 12.4px)
                                                                    }

                                                                    75% {
                                                                        transform: translate(20.8px, 12.4px)
                                                                    }

                                                                    100% {
                                                                        transform: translate(20.8px, 12.4px)
                                                                    }
                                                                }

                                                                .is-in-view #e2oQ4aPtn8x8 {
                                                                    animation: e2oQ4aPtn8x8_c_o 2000ms linear 1 normal forwards
                                                                }

                                                                @keyframes e2oQ4aPtn8x8_c_o {
                                                                    0% {
                                                                        opacity: 0
                                                                    }

                                                                    50% {
                                                                        opacity: 0
                                                                    }

                                                                    75% {
                                                                        opacity: 1
                                                                    }

                                                                    100% {
                                                                        opacity: 1
                                                                    }
                                                                }

                                                                .is-in-view #lp-collage-star-seller {
                                                                    animation: lp-collage-star-seller__tr 2000ms linear 1 normal forwards
                                                                }

                                                                @keyframes lp-collage-star-seller__tr {
                                                                    0% {
                                                                        transform: translate(12px, 12px) rotate(-145deg);
                                                                        animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1)
                                                                    }

                                                                    50% {
                                                                        transform: translate(12px, 12px) rotate(0deg)
                                                                    }

                                                                    100% {
                                                                        transform: translate(12px, 12px) rotate(0deg)
                                                                    }
                                                                }
                                                            </style>
                                                            <g id="lp-collage-star-seller-badge-left"
                                                                transform="translate(3.4,12.4)">
                                                                <g id="e2oQ4aPtn8x2" transform="translate(-3.4,-12.4)"
                                                                    opacity="0">
                                                                    <g id="e2oQ4aPtn8x3">
                                                                        <g id="e2oQ4aPtn8x4">
                                                                            <polygon id="e2oQ4aPtn8x5"
                                                                                points="2.5,15.8 2,13.9 4.5,13.8 4.8,14.7"
                                                                                fill="#654B77" stroke="none"
                                                                                stroke-width="1"
                                                                                stroke-miterlimit="1" />
                                                                        </g>
                                                                        <g id="e2oQ4aPtn8x6">
                                                                            <polygon id="e2oQ4aPtn8x7"
                                                                                points="4.8,10.1 4.5,11.1 2,10.9 2.5,9"
                                                                                fill="#654B77" stroke="none"
                                                                                stroke-width="1"
                                                                                stroke-miterlimit="1" />
                                                                        </g>
                                                                    </g>
                                                                </g>
                                                            </g>
                                                            <g id="lp-collage-star-seller-badge-right"
                                                                transform="translate(20.6,12.4)">
                                                                <g id="e2oQ4aPtn8x8" transform="translate(-20.6,-12.4)"
                                                                    opacity="0">
                                                                    <g id="e2oQ4aPtn8x9">
                                                                        <polygon id="e2oQ4aPtn8x10"
                                                                            points="19.5,11.1 19.2,10.1 21.5,9 22,10.9"
                                                                            fill="var(--clg-color-pal-lavender-700, #654B77 )"
                                                                            stroke="none" stroke-width="1"
                                                                            stroke-miterlimit="1" />
                                                                    </g>
                                                                    <g id="e2oQ4aPtn8x11">
                                                                        <polygon id="e2oQ4aPtn8x12"
                                                                            points="22,13.9 21.5,15.8 19.2,14.7 19.5,13.8"
                                                                            fill="var(--clg-color-pal-lavender-700, #654B77 )"
                                                                            stroke="none" stroke-width="1"
                                                                            stroke-miterlimit="1" />
                                                                    </g>
                                                                </g>
                                                            </g>
                                                            <g id="lp-collage-star-seller"
                                                                transform="translate(12,12) rotate(-145)">
                                                                <g id="e2oQ4aPtn8x13" transform="translate(-12,-12)">
                                                                    <g id="e2oQ4aPtn8x14">
                                                                        <path id="e2oQ4aPtn8x15"
                                                                            d="M17.6,8.8L16.1,7.9L15.2,6.4L13.5,6.4L12,5.5L10.5,6.4L8.7,6.4L7.9,7.9L6.4,8.8L6.4,10.5L5.5,12L6.4,13.5L6.4,15.2L7.9,16.1L8.8,17.6L10.5,17.6L12,18.5L13.5,17.6L15.2,17.6L16.1,16.1L17.6,15.2L17.6,13.5L18.5,12L17.6,10.5L17.6,8.8ZM13.7,12.7L14.2,14.9C14.1,15,14.1,15,13.9,15.1L12,14L10.1,15.2C10,15.1,10,15.1,9.8,15L10.3,12.8L8.6,11.3C8.7,11.1,8.7,11.1,8.7,11L11,10.8L11.9,8.7C12.1,8.7,12.1,8.7,12.2,8.7L13.1,10.8L15.4,11C15.5,11.2,15.5,11.2,15.5,11.3L13.7,12.7Z"
                                                                            fill="var(--clg-color-sem-background-surface-star-seller-dark, #9560B8)"
                                                                            stroke="none" stroke-width="1"
                                                                            stroke-miterlimit="1" />
                                                                    </g>
                                                                </g>
                                                            </g>
                                                        </svg></span>
                                                </div>
                                                <div class="wt-display-flex-xs wt-flex-direction-column-xs">

                                                    <p class="wt-text-caption">
                                                        <strong>Star Seller.</strong> This seller consistently earned
                                                        5-star reviews, shipped on time, and replied quickly to any
                                                        messages they received.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="listing-info info-col description-right wt-order-xs-5">
                            <div
                                class="wt-flex-lg-3 wt-order-xs-1 wt-order-lg-3 wt-max-width-full wt-pl-md-4 wt-pr-md-4 wt-pl-lg-0 wt-pr-lg-5 wt-pl-xs-2 wt-pr-xs-2">
                                <div data-appears-component-name="product_details">
                                    <div id="product_details">
                                        <div class="wt-content-toggle " data-selector="info-section-content-toggle">
                                            <button data-clg-id="WtButton"
                                                class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush"
                                                data-wt-content-toggle="true" data-animate="true"
                                                data-default-open="true" aria-controls="product_details_content_toggle">
                                                <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                                                    <h2>
                                                        Item details
                                                    </h2>
                                                </span>
                                                <span class="wt-content-toggle--btn__icon"></span>

                                            </button>

                                            <div id="product_details_content_toggle" class="wt-content-toggle__body"
                                                aria-hidden="false">
                                                <div class="wt-mb-xs-6">
                                                    <div class="wt-mt-xs-2">
                                                        <h3 class="wt-text-title">Highlights</h3>
                                                        <ul class="wt-block-grid-xs-1 wt-text-body-01 show-icons wt-mt-xs-1 wt-pl-xs-0 wt-mb-xs-3"
                                                            data-selector="product-details-highlights">
                                                            <div data-appears-component-name="how_its_made_label"
                                                                data-appears-event-data='{"label_type":"made_by","section":"product_details"}'>
                                                                <li
                                                                    class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
                                                                    <div><span class="wt-icon wt-nudge-b-2"><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                                focusable="false">
                                                                                <path
                                                                                    d="m7.914 14.101-3.2-3.2A1 1 0 0 0 3.3 12.317l7.2 7.25.002-.003a4.933 4.933 0 0 0 6.932.044l1.859-1.811a5.69 5.69 0 0 0 1.073-6.7l-1.917-5.43a1 1 0 0 0-1.886.665L17.64 9.38l.02.056-.793 3.436-.975-.224.786-3.404-1.937-1.936-.008.008-4.538-4.55A1 1 0 1 0 8.778 4.18l3.956 3.967-.295 1.44-6.07-6.07A1 1 0 0 0 4.957 4.93l5.412 5.412-.2 1.412-5.46-5.46a1 1 0 0 0-1.415 1.414l4.897 4.897z" />
                                                                            </svg></span></div>
                                                                    <div
                                                                        class="wt-ml-xs-1 how-its-made-label-product-details">
                                                                        Made by <a href="<?= $registerUrl; ?>"
                                                                            target="_blank"
                                                                            class="wt-text-link-no-underline wt-text-title">
                                                                            <?= $str; ?>
                                                                        </a>
                                                                    </div>
                                                                </li>
                                                            </div>









                                                            <li
                                                                class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
                                                                <div><span class="wt-icon wt-nudge-b-2"><svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 24 24" aria-hidden="true"
                                                                            focusable="false">
                                                                            <path
                                                                                d="M18.1 6c.7 1.7.9 3.6.4 5.6-.8 3.4-3.5 6.1-6.9 6.9-2 .5-3.9.2-5.6-.4v1.4L7.5 21h12l1.5-1.5v-12L19.5 6h-1.4z" />
                                                                            <path
                                                                                d="M9.5 2C5.4 2 2 5.4 2 9.5S5.4 17 9.5 17 17 13.6 17 9.5 13.6 2 9.5 2zM7.8 15c-.6-.2-1.2-.5-1.7-.9l8-8c.4.5.7 1.1.9 1.7L7.8 15zm3.4-11c.6.2 1.2.5 1.7.9l-8 8c-.4-.5-.7-1.1-.9-1.7L11.2 4zM9 3.8L3.8 9C4 6.2 6.2 4 9 3.8zm1 11.4l5.2-5.2c-.2 2.8-2.4 5-5.2 5.2z" />
                                                                        </svg></span></div>
                                                                <div class="wt-ml-xs-1">
                                                                    Materials: Cotton, felt, spandex
                                                                </div>
                                                            </li>




                                                        </ul>
                                                    </div>
                                                    <div class="wt-mt-xs-2">

                                                    </div>
                                                    <div data-id="description-text">
                                                        <div id="content-toggle-product-details-read-more"
                                                            class="wt-content-toggle__body wt-content-toggle__body--truncated wt-content-toggle__body--truncated-02">
                                                            <p data-product-details-description-text-content
                                                                class="wt-text-body-01 wt-break-word">
                                                                <?= $str; ?>
                                                                <?= $random_description; ?>
                                                            </p>

                                                        </div>
                                                        <div class="wt-text-center-xs">
                                                            <button type="button"
                                                                class="wt-content-toggle--btn wt-btn wt-btn--small wt-btn--transparent"
                                                                data-wt-content-toggle
                                                                data-read-more-label-closed="Learn more about this item"
                                                                data-read-more="true"
                                                                aria-controls="content-toggle-product-details-read-more"
                                                                data-default-open="false">
                                                                Learn more about this item
                                                            </button>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div data-appears-component-name="listing_page_policy_shipping_variant"
                                    data-appears-event-data='{"estimated_delivery_date_days_from_now_min":21,"estimated_delivery_date_days_from_now_max":42}'>
                                    <div data-appears-component-name="shipping_and_returns">
                                        <div id="shipping_and_returns">
                                            <div class="wt-content-toggle " data-selector="info-section-content-toggle">
                                                <button data-clg-id="WtButton"
                                                    class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush"
                                                    data-wt-content-toggle="true" data-animate="true"
                                                    data-default-open="true"
                                                    aria-controls="shipping_and_returns_content_toggle">
                                                    <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                                                        <h2>
                                                            Shipping and return policies
                                                        </h2>
                                                    </span>
                                                    <span class="wt-content-toggle--btn__icon"></span>

                                                </button>

                                                <div id="shipping_and_returns_content_toggle"
                                                    class="wt-content-toggle__body" aria-hidden="false">
                                                    <div class="wt-mb-xs-6">
                                                        <div data-shipping-and-returns-div
                                                            id="shipping-and-returns-div">
                                                            <div class="wt-position-relative">
                                                                <div class="wt-position-absolute wt-height-full wt-width-full wt-bg-white wt-z-index-2 wt-display-none
            shipping-spinner">
                                                                    <div
                                                                        class="wt-spinner wt-spinner--01 wt-vertical-center">
                                                                        <span class="etsy-icon"><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                                focusable="false">
                                                                                <circle fill="transparent" cx="12"
                                                                                    cy="12" r="10" />
                                                                            </svg></span>
                                                                        Loading
                                                                    </div>
                                                                </div>

                                                                <div class="wt-mb-xs-2"
                                                                    data-selector='shipping-highlights'>
                                                                    <ul
                                                                        class="wt-block-grid-xs-1 wt-text-body-01 wt-mt-xs-1 wt-pl-xs-0">
                                                                        <li class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start"
                                                                            data-shipping-estimated-delivery>
                                                                            <div><span class="wt-icon wt-nudge-b-2"><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        viewBox="0 0 24 24"
                                                                                        aria-hidden="true"
                                                                                        focusable="false">
                                                                                        <path
                                                                                            d="M17.5 16a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0" />
                                                                                        <path fill-rule="evenodd"
                                                                                            clip-rule="evenodd"
                                                                                            d="M6.5 5H3v16h18V5h-3.5V3h-2v2h-7V3h-2zm0 2v1h2V7h7v1h2V7H19v3H5V7zM5 12v7h14v-7z" />
                                                                                    </svg></span></div>
                                                                            <div class="wt-ml-xs-1">
                                                                                <div data-selector="popover-container">
                                                                                    Order today to get by <span
                                                                                        data-selector="popover-placeholder"><strong>Oct
                                                                                            3-24</strong></span>
                                                                                    <div class="wt-display-none">
                                                                                        <div class="wt-popover wt-text-caption"
                                                                                            data-wt-popover
                                                                                            data-selector="popover-replacement">
                                                                                            <button type="button"
                                                                                                data-wt-popover-trigger
                                                                                                class="wt-popover__trigger wt-popover__trigger--underline wt-text-body-01 wt-text-left-xs"
                                                                                                aria-describedby="shipping-highlights-estimated-delivery-date-popover">
                                                                                            </button>
                                                                                            <div id="shipping-highlights-estimated-delivery-date-popover"
                                                                                                role="tooltip">
                                                                                                <p
                                                                                                    class="wt-text-caption wt-mb-xs-1">
                                                                                                    Your order should
                                                                                                    arrive by this date
                                                                                                    if you buy today. To
                                                                                                    calculate an <a
                                                                                                        href='https://help.etsy.com/hc/articles/360020601674'
                                                                                                        target='_blank'>estimated
                                                                                                        delivery
                                                                                                        date</a> you can
                                                                                                    count on, we look at
                                                                                                    things like the
                                                                                                    carrier's latest
                                                                                                    transit times, the
                                                                                                    seller's processing
                                                                                                    time and shipping
                                                                                                    history, and where
                                                                                                    the order is
                                                                                                    shipping to and
                                                                                                    from.
                                                                                                </p>
                                                                                                <span
                                                                                                    class="wt-popover__arrow"></span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </li>

                                                                        <li
                                                                            class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
                                                                            <div><span class="wt-icon wt-nudge-b-2"><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        viewBox="0 0 24 24"
                                                                                        aria-hidden="true"
                                                                                        focusable="false">
                                                                                        <path
                                                                                            d="M12.5 15h-6c-.3 0-.5.2-.5.5s.2.5.5.5h6c.3 0 .5-.2.5-.5s-.2-.5-.5-.5m-6-1h4c.3 0 .5-.2.5-.5s-.2-.5-.5-.5h-4c-.3 0-.5.2-.5.5s.2.5.5.5m5 3h-5c-.3 0-.5.2-.5.5s.2.5.5.5h5c.3 0 .5-.2.5-.5s-.2-.5-.5-.5" />
                                                                                        <path
                                                                                            d="m21.9 6.6-2-4Q19.6 2 19 2H5q-.6 0-.9.6l-2 4c-.1.1-.1.2-.1.4v14c0 .6.4 1 1 1h18c.6 0 1-.4 1-1V7c0-.2 0-.3-.1-.4M5.6 4h12.8l1 2H4.6zM4 20V8h16v12z" />
                                                                                    </svg></span></div>
                                                                            <div class="wt-ml-xs-1">
                                                                                <div data-selector="popover-container">
                                                                                    <span
                                                                                        data-selector="popover-placeholder">Returns
                                                                                        accepted</span> within 30 days
                                                                                    <div class="wt-display-none">
                                                                                        <div class="wt-popover wt-text-caption"
                                                                                            data-wt-popover
                                                                                            data-selector="popover-replacement">
                                                                                            <button type="button"
                                                                                                data-wt-popover-trigger
                                                                                                class="wt-popover__trigger wt-popover__trigger--underline wt-text-body-01 wt-text-left-xs"
                                                                                                aria-describedby="shipping-highlights-returns-and-exchanges">
                                                                                            </button>
                                                                                            <div id="shipping-highlights-returns-and-exchanges"
                                                                                                role="tooltip">
                                                                                                <p
                                                                                                    class="wt-text-caption wt-mb-xs-1">
                                                                                                    Buyers are
                                                                                                    responsible for
                                                                                                    return shipping
                                                                                                    costs. If the item
                                                                                                    is not returned in
                                                                                                    its original
                                                                                                    condition, the buyer
                                                                                                    is responsible for
                                                                                                    any loss in value.
                                                                                                </p>
                                                                                                <span
                                                                                                    class="wt-popover__arrow"></span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </li>

                                                                        <li
                                                                            class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
                                                                            <div><span class="wt-icon wt-nudge-b-2"><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        viewBox="0 0 24 24"
                                                                                        aria-hidden="true"
                                                                                        focusable="false">
                                                                                        <path fill-rule="evenodd"
                                                                                            clip-rule="evenodd"
                                                                                            d="M20 12.266 16.42 6H6v1h5v2H2V7h2V4h13.58L22 11.734V18h-2.17a3.001 3.001 0 0 1-5.66 0h-2.34a3.001 3.001 0 0 1-5.66 0H4v-3H2v-2h4v3h.17a3.001 3.001 0 0 1 5.66 0h2.34a3.001 3.001 0 0 1 5.66 0H20zM18 17a1 1 0 1 1-2 0 1 1 0 0 1 2 0m-8 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0" />
                                                                                        <path
                                                                                            d="M17.5 11 15 7h-2v4zM9 12H2v-2h7z" />
                                                                                    </svg></span></div>
                                                                            <div class="wt-ml-xs-1">
                                                                                Cost to ship: <strong><span
                                                                                        class='currency-symbol'>THB
                                                                                    </span><span
                                                                                        class='currency-value'>1.00</span></strong>
                                                                            </div>
                                                                        </li>

                                                                        <li
                                                                            class="wt-block-grid__item wt-display-flex-xs wt-align-items-flex-start">
                                                                            <div><span class="wt-icon wt-nudge-b-2"><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        viewBox="0 0 24 24"
                                                                                        aria-hidden="true"
                                                                                        focusable="false">
                                                                                        <path
                                                                                            d="M14 9a2 2 0 1 1-4 0 2 2 0 0 1 4 0" />
                                                                                        <path fill-rule="evenodd"
                                                                                            clip-rule="evenodd"
                                                                                            d="M17.083 12.189 12 21l-5.083-8.811a6 6 0 1 1 10.167 0m-1.713-1.032.02-.033a4 4 0 1 0-6.78 0l.02.033 3.37 5.84z" />
                                                                                    </svg></span></div>
                                                                            <div class="wt-ml-xs-1">
                                                                                Ships from: <strong>Thailand</strong>
                                                                            </div>
                                                                        </li>
                                                                    </ul>
                                                                </div>

                                                                <div class="wt-grid wt-mb-xs-3" data-delivery-data>

                                                                    <div id="estimated-shipping"></div>

                                                                    <div data-calculate-shipping-cost
                                                                        class="wt-grid__item-xs-12  wt-sem-text-secondary">
                                                                        <button type="button"
                                                                            data-content-toggle-uid="data-estimated-shipping-form-fields"
                                                                            class="wt-btn wt-btn--transparent wt-btn--small wt-content-toggle--btn wt-btn--transparent-flush-left wt-content-toggle--with-icon"
                                                                            data-wt-content-toggle
                                                                            aria-controls="estimated-shipping-form-fields">
                                                                            <span
                                                                                class="wt-flex-xs-auto wt-width-full">Deliver
                                                                                to Thailand</span>
                                                                            <span
                                                                                class="wt-icon wt-icon--smaller-xs wt-ml-xs-1"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="M20.414 6.414a2 2 0 1 0-2.833-2.824l-.001.002-.788.788 2.787 2.87zm-5.037-.62 2.787 2.87-9.75 9.75.001.001L4 20l1.588-4.412-.002-.002z" />
                                                                                </svg></span>
                                                                        </button>
                                                                    </div>

                                                                    <div data-estimated-shipping-form
                                                                        class="wt-grid__item-xs-12 wt-validation">
                                                                        <div data-submission-error
                                                                            class="wt-alert wt-alert--inline wt-alert--status-02 wt-mb-xs-2 wt-display-none">
                                                                            <p class="wt-text-body-01"
                                                                                id="estimated-shipping-error">There was
                                                                                a problem calculating your shipping.
                                                                                Please try again.</p>
                                                                        </div>
                                                                        <div class="wt-content-toggle__body"
                                                                            id="estimated-shipping-form-fields"
                                                                            aria-hidden="true">
                                                                            <fieldset data-estimated-shipping-country
                                                                                class="wt-mt-xs-2 wt-mb-xs-2 wt-display-none">
                                                                                <label class="wt-text-body-01"
                                                                                    for="estimated-shipping-country">Country</label>
                                                                                <div class="wt-select">
                                                                                    <select aria-label="Choose country"
                                                                                        class="wt-select__element"
                                                                                        id="estimated-shipping-country"
                                                                                        name="estimated-shipping-country"
                                                                                        data-error="estimated-shipping-error">
                                                                                        <optgroup
                                                                                            label="Choose country">
                                                                                            <option label="----------"
                                                                                                disabled="">----------
                                                                                            </option>
                                                                                            <option value="61">Australia
                                                                                            </option>
                                                                                            <option value="79">Canada
                                                                                            </option>
                                                                                            <option value="103">France
                                                                                            </option>
                                                                                            <option value="91">Germany
                                                                                            </option>
                                                                                            <option value="112">Greece
                                                                                            </option>
                                                                                            <option value="122">India
                                                                                            </option>
                                                                                            <option value="123">Ireland
                                                                                            </option>
                                                                                            <option value="128">Italy
                                                                                            </option>
                                                                                            <option value="131">Japan
                                                                                            </option>
                                                                                            <option value="167">New
                                                                                                Zealand</option>
                                                                                            <option value="174">Poland
                                                                                            </option>
                                                                                            <option value="177">Portugal
                                                                                            </option>
                                                                                            <option value="99">Spain
                                                                                            </option>
                                                                                            <option value="164">The
                                                                                                Netherlands</option>
                                                                                            <option value="105">United
                                                                                                Kingdom</option>
                                                                                            <option value="209">United
                                                                                                States</option>
                                                                                            <option label="----------"
                                                                                                disabled="">----------
                                                                                            </option>
                                                                                            <option value="55">
                                                                                                Afghanistan</option>
                                                                                            <option value="306">Åland
                                                                                                Islands</option>
                                                                                            <option value="57">Albania
                                                                                            </option>
                                                                                            <option value="95">Algeria
                                                                                            </option>
                                                                                            <option value="250">American
                                                                                                Samoa</option>
                                                                                            <option value="228">Andorra
                                                                                            </option>
                                                                                            <option value="56">Angola
                                                                                            </option>
                                                                                            <option value="251">Anguilla
                                                                                            </option>
                                                                                            <option value="252">Antigua
                                                                                                and Barbuda</option>
                                                                                            <option value="59">Argentina
                                                                                            </option>
                                                                                            <option value="60">Armenia
                                                                                            </option>
                                                                                            <option value="253">Aruba
                                                                                            </option>
                                                                                            <option value="61">Australia
                                                                                            </option>
                                                                                            <option value="62">Austria
                                                                                            </option>
                                                                                            <option value="63">
                                                                                                Azerbaijan</option>
                                                                                            <option value="229">Bahamas
                                                                                            </option>
                                                                                            <option value="232">Bahrain
                                                                                            </option>
                                                                                            <option value="68">
                                                                                                Bangladesh</option>
                                                                                            <option value="237">Barbados
                                                                                            </option>
                                                                                            <option value="65">Belgium
                                                                                            </option>
                                                                                            <option value="72">Belize
                                                                                            </option>
                                                                                            <option value="66">Benin
                                                                                            </option>
                                                                                            <option value="225">Bermuda
                                                                                            </option>
                                                                                            <option value="76">Bhutan
                                                                                            </option>
                                                                                            <option value="73">Bolivia
                                                                                            </option>
                                                                                            <option value="70">Bosnia
                                                                                                and Herzegovina</option>
                                                                                            <option value="77">Botswana
                                                                                            </option>
                                                                                            <option value="254">Bouvet
                                                                                                Island</option>
                                                                                            <option value="74">Brazil
                                                                                            </option>
                                                                                            <option value="255">British
                                                                                                Indian Ocean Territory
                                                                                            </option>
                                                                                            <option value="231">British
                                                                                                Virgin Islands</option>
                                                                                            <option value="75">Brunei
                                                                                            </option>
                                                                                            <option value="69">Bulgaria
                                                                                            </option>
                                                                                            <option value="67">Burkina
                                                                                                Faso</option>
                                                                                            <option value="64">Burundi
                                                                                            </option>
                                                                                            <option value="135">Cambodia
                                                                                            </option>
                                                                                            <option value="84">Cameroon
                                                                                            </option>
                                                                                            <option value="79">Canada
                                                                                            </option>
                                                                                            <option value="222">Cape
                                                                                                Verde</option>
                                                                                            <option value="247">Cayman
                                                                                                Islands</option>
                                                                                            <option value="78">Central
                                                                                                African Republic
                                                                                            </option>
                                                                                            <option value="196">Chad
                                                                                            </option>
                                                                                            <option value="81">Chile
                                                                                            </option>
                                                                                            <option value="82">China
                                                                                            </option>
                                                                                            <option value="257">
                                                                                                Christmas Island
                                                                                            </option>
                                                                                            <option value="258">Cocos
                                                                                                (Keeling) Islands
                                                                                            </option>
                                                                                            <option value="86">Colombia
                                                                                            </option>
                                                                                            <option value="259">Comoros
                                                                                            </option>
                                                                                            <option value="85">Congo,
                                                                                                Republic of</option>
                                                                                            <option value="260">Cook
                                                                                                Islands</option>
                                                                                            <option value="87">Costa
                                                                                                Rica</option>
                                                                                            <option value="118">Croatia
                                                                                            </option>
                                                                                            <option value="338">Curaçao
                                                                                            </option>
                                                                                            <option value="89">Cyprus
                                                                                            </option>
                                                                                            <option value="90">Czech
                                                                                                Republic</option>
                                                                                            <option value="93">Denmark
                                                                                            </option>
                                                                                            <option value="92">Djibouti
                                                                                            </option>
                                                                                            <option value="261">Dominica
                                                                                            </option>
                                                                                            <option value="94">Dominican
                                                                                                Republic</option>
                                                                                            <option value="96">Ecuador
                                                                                            </option>
                                                                                            <option value="97">Egypt
                                                                                            </option>
                                                                                            <option value="187">El
                                                                                                Salvador</option>
                                                                                            <option value="111">
                                                                                                Equatorial Guinea
                                                                                            </option>
                                                                                            <option value="98">Eritrea
                                                                                            </option>
                                                                                            <option value="100">Estonia
                                                                                            </option>
                                                                                            <option value="101">Ethiopia
                                                                                            </option>
                                                                                            <option value="262">Falkland
                                                                                                Islands (Malvinas)
                                                                                            </option>
                                                                                            <option value="241">Faroe
                                                                                                Islands</option>
                                                                                            <option value="234">Fiji
                                                                                            </option>
                                                                                            <option value="102">Finland
                                                                                            </option>
                                                                                            <option value="103">France
                                                                                            </option>
                                                                                            <option value="115">French
                                                                                                Guiana</option>
                                                                                            <option value="263">French
                                                                                                Polynesia</option>
                                                                                            <option value="264">French
                                                                                                Southern Territories
                                                                                            </option>
                                                                                            <option value="104">Gabon
                                                                                            </option>
                                                                                            <option value="109">Gambia
                                                                                            </option>
                                                                                            <option value="106">Georgia
                                                                                            </option>
                                                                                            <option value="91">Germany
                                                                                            </option>
                                                                                            <option value="107">Ghana
                                                                                            </option>
                                                                                            <option value="226">
                                                                                                Gibraltar</option>
                                                                                            <option value="112">Greece
                                                                                            </option>
                                                                                            <option value="113">
                                                                                                Greenland</option>
                                                                                            <option value="245">Grenada
                                                                                            </option>
                                                                                            <option value="265">
                                                                                                Guadeloupe</option>
                                                                                            <option value="266">Guam
                                                                                            </option>
                                                                                            <option value="114">
                                                                                                Guatemala</option>
                                                                                            <option value="305">Guernsey
                                                                                            </option>
                                                                                            <option value="108">Guinea
                                                                                            </option>
                                                                                            <option value="110">
                                                                                                Guinea-Bissau</option>
                                                                                            <option value="116">Guyana
                                                                                            </option>
                                                                                            <option value="119">Haiti
                                                                                            </option>
                                                                                            <option value="267">Heard
                                                                                                Island and McDonald
                                                                                                Islands</option>
                                                                                            <option value="268">Holy See
                                                                                                (Vatican City State)
                                                                                            </option>
                                                                                            <option value="117">Honduras
                                                                                            </option>
                                                                                            <option value="219">Hong
                                                                                                Kong</option>
                                                                                            <option value="120">Hungary
                                                                                            </option>
                                                                                            <option value="126">Iceland
                                                                                            </option>
                                                                                            <option value="122">India
                                                                                            </option>
                                                                                            <option value="121">
                                                                                                Indonesia</option>
                                                                                            <option value="125">Iraq
                                                                                            </option>
                                                                                            <option value="123">Ireland
                                                                                            </option>
                                                                                            <option value="269">Isle of
                                                                                                Man</option>
                                                                                            <option value="127">Israel
                                                                                            </option>
                                                                                            <option value="128">Italy
                                                                                            </option>
                                                                                            <option value="83">Ivory
                                                                                                Coast</option>
                                                                                            <option value="129">Jamaica
                                                                                            </option>
                                                                                            <option value="131">Japan
                                                                                            </option>
                                                                                            <option value="307">Jersey
                                                                                            </option>
                                                                                            <option value="130">Jordan
                                                                                            </option>
                                                                                            <option value="132">
                                                                                                Kazakhstan</option>
                                                                                            <option value="133">Kenya
                                                                                            </option>
                                                                                            <option value="270">Kiribati
                                                                                            </option>
                                                                                            <option value="271">Kosovo
                                                                                            </option>
                                                                                            <option value="137">Kuwait
                                                                                            </option>
                                                                                            <option value="134">
                                                                                                Kyrgyzstan</option>
                                                                                            <option value="138">Laos
                                                                                            </option>
                                                                                            <option value="146">Latvia
                                                                                            </option>
                                                                                            <option value="139">Lebanon
                                                                                            </option>
                                                                                            <option value="143">Lesotho
                                                                                            </option>
                                                                                            <option value="140">Liberia
                                                                                            </option>
                                                                                            <option value="141">Libya
                                                                                            </option>
                                                                                            <option value="272">
                                                                                                Liechtenstein</option>
                                                                                            <option value="144">
                                                                                                Lithuania</option>
                                                                                            <option value="145">
                                                                                                Luxembourg</option>
                                                                                            <option value="273">Macao
                                                                                            </option>
                                                                                            <option value="151">
                                                                                                Macedonia</option>
                                                                                            <option value="149">
                                                                                                Madagascar</option>
                                                                                            <option value="158">Malawi
                                                                                            </option>
                                                                                            <option value="159">Malaysia
                                                                                            </option>
                                                                                            <option value="238">Maldives
                                                                                            </option>
                                                                                            <option value="152">Mali
                                                                                            </option>
                                                                                            <option value="227">Malta
                                                                                            </option>
                                                                                            <option value="274">Marshall
                                                                                                Islands</option>
                                                                                            <option value="275">
                                                                                                Martinique</option>
                                                                                            <option value="157">
                                                                                                Mauritania</option>
                                                                                            <option value="239">
                                                                                                Mauritius</option>
                                                                                            <option value="276">Mayotte
                                                                                            </option>
                                                                                            <option value="150">Mexico
                                                                                            </option>
                                                                                            <option value="277">
                                                                                                Micronesia, Federated
                                                                                                States of</option>
                                                                                            <option value="148">Moldova
                                                                                            </option>
                                                                                            <option value="278">Monaco
                                                                                            </option>
                                                                                            <option value="154">Mongolia
                                                                                            </option>
                                                                                            <option value="155">
                                                                                                Montenegro</option>
                                                                                            <option value="279">
                                                                                                Montserrat</option>
                                                                                            <option value="147">Morocco
                                                                                            </option>
                                                                                            <option value="156">
                                                                                                Mozambique</option>
                                                                                            <option value="153">Myanmar
                                                                                                (Burma)</option>
                                                                                            <option value="160">Namibia
                                                                                            </option>
                                                                                            <option value="280">Nauru
                                                                                            </option>
                                                                                            <option value="166">Nepal
                                                                                            </option>
                                                                                            <option value="243">
                                                                                                Netherlands Antilles
                                                                                            </option>
                                                                                            <option value="233">New
                                                                                                Caledonia</option>
                                                                                            <option value="167">New
                                                                                                Zealand</option>
                                                                                            <option value="163">
                                                                                                Nicaragua</option>
                                                                                            <option value="161">Niger
                                                                                            </option>
                                                                                            <option value="162">Nigeria
                                                                                            </option>
                                                                                            <option value="281">Niue
                                                                                            </option>
                                                                                            <option value="282">Norfolk
                                                                                                Island</option>
                                                                                            <option value="283">Northern
                                                                                                Mariana Islands</option>
                                                                                            <option value="165">Norway
                                                                                            </option>
                                                                                            <option value="168">Oman
                                                                                            </option>
                                                                                            <option value="169">Pakistan
                                                                                            </option>
                                                                                            <option value="284">Palau
                                                                                            </option>
                                                                                            <option value="285">
                                                                                                Palestinian Territory,
                                                                                                Occupied</option>
                                                                                            <option value="170">Panama
                                                                                            </option>
                                                                                            <option value="173">Papua
                                                                                                New Guinea</option>
                                                                                            <option value="178">Paraguay
                                                                                            </option>
                                                                                            <option value="171">Peru
                                                                                            </option>
                                                                                            <option value="172">
                                                                                                Philippines</option>
                                                                                            <option value="174">Poland
                                                                                            </option>
                                                                                            <option value="177">Portugal
                                                                                            </option>
                                                                                            <option value="175">Puerto
                                                                                                Rico</option>
                                                                                            <option value="179">Qatar
                                                                                            </option>
                                                                                            <option value="304">Reunion
                                                                                            </option>
                                                                                            <option value="180">Romania
                                                                                            </option>
                                                                                            <option value="182">Rwanda
                                                                                            </option>
                                                                                            <option value="286">Saint
                                                                                                Helena</option>
                                                                                            <option value="287">Saint
                                                                                                Kitts and Nevis</option>
                                                                                            <option value="244">Saint
                                                                                                Lucia</option>
                                                                                            <option value="288">Saint
                                                                                                Martin (French part)
                                                                                            </option>
                                                                                            <option value="289">Saint
                                                                                                Pierre and Miquelon
                                                                                            </option>
                                                                                            <option value="249">Saint
                                                                                                Vincent and the
                                                                                                Grenadines</option>
                                                                                            <option value="290">Samoa
                                                                                            </option>
                                                                                            <option value="291">San
                                                                                                Marino</option>
                                                                                            <option value="292">Sao Tome
                                                                                                and Principe</option>
                                                                                            <option value="183">Saudi
                                                                                                Arabia</option>
                                                                                            <option value="185">Senegal
                                                                                            </option>
                                                                                            <option value="189">Serbia
                                                                                            </option>
                                                                                            <option value="293">
                                                                                                Seychelles</option>
                                                                                            <option value="186">Sierra
                                                                                                Leone</option>
                                                                                            <option value="220">
                                                                                                Singapore</option>
                                                                                            <option value="337">Sint
                                                                                                Maarten (Dutch part)
                                                                                            </option>
                                                                                            <option value="191">Slovakia
                                                                                            </option>
                                                                                            <option value="192">Slovenia
                                                                                            </option>
                                                                                            <option value="242">Solomon
                                                                                                Islands</option>
                                                                                            <option value="188">Somalia
                                                                                            </option>
                                                                                            <option value="215">South
                                                                                                Africa</option>
                                                                                            <option value="294">South
                                                                                                Georgia and the South
                                                                                                Sandwich Islands
                                                                                            </option>
                                                                                            <option value="136">South
                                                                                                Korea</option>
                                                                                            <option value="339">South
                                                                                                Sudan</option>
                                                                                            <option value="99">Spain
                                                                                            </option>
                                                                                            <option value="142">Sri
                                                                                                Lanka</option>
                                                                                            <option value="184">Sudan
                                                                                            </option>
                                                                                            <option value="190">Suriname
                                                                                            </option>
                                                                                            <option value="295">Svalbard
                                                                                                and Jan Mayen</option>
                                                                                            <option value="194">
                                                                                                Swaziland</option>
                                                                                            <option value="193">Sweden
                                                                                            </option>
                                                                                            <option value="80">
                                                                                                Switzerland</option>
                                                                                            <option value="204">Taiwan
                                                                                            </option>
                                                                                            <option value="199">
                                                                                                Tajikistan</option>
                                                                                            <option value="205">Tanzania
                                                                                            </option>
                                                                                            <option value="198"
                                                                                                selected>Thailand
                                                                                            </option>
                                                                                            <option value="164">The
                                                                                                Netherlands</option>
                                                                                            <option value="296">
                                                                                                Timor-Leste</option>
                                                                                            <option value="197">Togo
                                                                                            </option>
                                                                                            <option value="297">Tokelau
                                                                                            </option>
                                                                                            <option value="298">Tonga
                                                                                            </option>
                                                                                            <option value="201">Trinidad
                                                                                            </option>
                                                                                            <option value="202">Tunisia
                                                                                            </option>
                                                                                            <option value="203">Türkiye
                                                                                            </option>
                                                                                            <option value="200">
                                                                                                Turkmenistan</option>
                                                                                            <option value="299">Turks
                                                                                                and Caicos Islands
                                                                                            </option>
                                                                                            <option value="300">Tuvalu
                                                                                            </option>
                                                                                            <option value="206">Uganda
                                                                                            </option>
                                                                                            <option value="207">Ukraine
                                                                                            </option>
                                                                                            <option value="58">United
                                                                                                Arab Emirates</option>
                                                                                            <option value="105">United
                                                                                                Kingdom</option>
                                                                                            <option value="209">United
                                                                                                States</option>
                                                                                            <option value="302">United
                                                                                                States Minor Outlying
                                                                                                Islands</option>
                                                                                            <option value="208">Uruguay
                                                                                            </option>
                                                                                            <option value="248">U.S.
                                                                                                Virgin Islands</option>
                                                                                            <option value="210">
                                                                                                Uzbekistan</option>
                                                                                            <option value="221">Vanuatu
                                                                                            </option>
                                                                                            <option value="211">
                                                                                                Venezuela</option>
                                                                                            <option value="212">Vietnam
                                                                                            </option>
                                                                                            <option value="224">Wallis
                                                                                                and Futuna</option>
                                                                                            <option value="213">Western
                                                                                                Sahara</option>
                                                                                            <option value="214">Yemen
                                                                                            </option>
                                                                                            <option value="216">Zaire
                                                                                                (Democratic Republic of
                                                                                                Congo)</option>
                                                                                            <option value="217">Zambia
                                                                                            </option>
                                                                                            <option value="218">Zimbabwe
                                                                                            </option>
                                                                                        </optgroup>
                                                                                    </select>
                                                                                </div>
                                                                            </fieldset>
                                                                            <fieldset data-estimated-shipping-zip-code
                                                                                class="wt-mt-xs-2 wt-mb-xs-2 wt-display-none">
                                                                                <label
                                                                                    class="wt-text-body-01 wt-label__required"
                                                                                    for="estimated-shipping-zip-code"
                                                                                    id="estimated-shipping-zip-code-label">
                                                                                    Postal code
                                                                                </label>
                                                                                <input type="text" class="wt-input"
                                                                                    id="estimated-shipping-zip-code"
                                                                                    maxlength="10" value=""
                                                                                    aria-required="true">
                                                                                <div class="wt-validation__message wt-validation__message--is-hidden"
                                                                                    id="estimated-shipping-zip-code-error">
                                                                                    <div data-clg-id="WtFormFieldError"
                                                                                        class="wt-validation wt-display-flex-xs wt-align-items-top ">
                                                                                        <div
                                                                                            class="wt-validation__icon__frame">
                                                                                            <span
                                                                                                class="wt-icon wt-validation__icon"><svg
                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                    viewBox="0 0 24 24"
                                                                                                    aria-hidden="true"
                                                                                                    focusable="false">
                                                                                                    <path
                                                                                                        fill-rule="evenodd"
                                                                                                        clip-rule="evenodd"
                                                                                                        d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5" />
                                                                                                </svg></span>
                                                                                        </div>
                                                                                        <ul class="wt-list-unstyled">
                                                                                            <li
                                                                                                class="wt-validation__message">
                                                                                                Please enter a valid
                                                                                                postal code.
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </fieldset>
                                                                            <fieldset
                                                                                data-estimated-shipping-submit-button
                                                                                class="wt-mt-xs-2 wt-mb-xs-2">
                                                                                <button
                                                                                    class="wt-btn wt-btn--filled wt-width-full"
                                                                                    type="submit"
                                                                                    id="estimated-shipping-submit-button">
                                                                                    Submit

                                                                                    <div data-clg-id="WtSpinner"
                                                                                        class="wt-spinner wt-spinner--01"
                                                                                        aria-live="assertive"
                                                                                        role="alert">
                                                                                        <span class="wt-icon"><svg
                                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                                viewBox="0 0 24 24"
                                                                                                aria-hidden="true"
                                                                                                focusable="false">
                                                                                                <circle
                                                                                                    fill="transparent"
                                                                                                    cx="12" cy="12"
                                                                                                    r="10" />
                                                                                            </svg></span>
                                                                                        Loading
                                                                                    </div>

                                                                                </button>
                                                                            </fieldset>
                                                                        </div>
                                                                    </div>






                                                                    <div class="">
                                                                    </div>




                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-appears-component-name="did_you_know">
                                        <div id="did_you_know">
                                            <div class="wt-content-toggle " data-selector="info-section-content-toggle">
                                                <button data-clg-id="WtButton"
                                                    class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush"
                                                    data-wt-content-toggle="true" data-animate="true"
                                                    data-default-open="true"
                                                    aria-controls="did_you_know_content_toggle">
                                                    <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                                                        <h2>
                                                            Did you know?
                                                        </h2>
                                                    </span>
                                                    <span class="wt-content-toggle--btn__icon"></span>

                                                </button>

                                                <div id="did_you_know_content_toggle" class="wt-content-toggle__body"
                                                    aria-hidden="false">
                                                    <div class="wt-mb-xs-6">
                                                        <div class="wt-mt-xs-1 wt-mb-xs-3">
                                                            <div class="wt-grid__item-xs-12
">
                                                                <div
                                                                    class="wt-display-inline-flex-xs wt-align-items-center">
                                                                    <div class="wt-mr-xs-2"
                                                                        data-add-class-when-in-view="is-in-view">
                                                                        <span class="inline-svg"><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                                viewBox="0 0 48 48"
                                                                                shape-rendering="geometricPrecision"
                                                                                text-rendering="geometricPrecision"
                                                                                width="48" height="48"
                                                                                aria-hidden="true" focusable="false">
                                                                                <style>
                                                                                    <![CDATA[
                                                                                    .is-in-view #e0NMFoeIPOT2_to {
                                                                                        animation: e0NMFoeIPOT2_to__to 2000ms linear 1 normal forwards
                                                                                    }

                                                                                    @keyframes e0NMFoeIPOT2_to__to {
                                                                                        0% {
                                                                                            transform: translate(44.162561px, 5.846695px)
                                                                                        }

                                                                                        8% {
                                                                                            transform: translate(44.162561px, 5.846695px);
                                                                                            animation-timing-function: cubic-bezier(0.15, 0, 1, 1)
                                                                                        }

                                                                                        16.5% {
                                                                                            transform: translate(42.257336px, 6.69656px);
                                                                                            animation-timing-function: cubic-bezier(0.25, 0, 0.75, 1)
                                                                                        }

                                                                                        28% {
                                                                                            transform: translate(46.27px, 7.700005px)
                                                                                        }

                                                                                        36.5% {
                                                                                            transform: translate(42.752561px, 5.5px)
                                                                                        }

                                                                                        48% {
                                                                                            transform: translate(44.150002px, 6.297191px)
                                                                                        }

                                                                                        100% {
                                                                                            transform: translate(44.150002px, 6.297191px)
                                                                                        }
                                                                                    }

                                                                                    .is-in-view #e0NMFoeIPOT2_tr {
                                                                                        animation: e0NMFoeIPOT2_tr__tr 2000ms linear 1 normal forwards
                                                                                    }

                                                                                    @keyframes e0NMFoeIPOT2_tr__tr {
                                                                                        0% {
                                                                                            transform: rotate(-5deg)
                                                                                        }

                                                                                        8% {
                                                                                            transform: rotate(-5deg);
                                                                                            animation-timing-function: cubic-bezier(0.15, 0, 1, 1)
                                                                                        }

                                                                                        16.5% {
                                                                                            transform: rotate(-7deg);
                                                                                            animation-timing-function: cubic-bezier(0.25, 0, 0.75, 1)
                                                                                        }

                                                                                        28% {
                                                                                            transform: rotate(7deg)
                                                                                        }

                                                                                        36.5% {
                                                                                            transform: rotate(-5deg)
                                                                                        }

                                                                                        48% {
                                                                                            transform: rotate(0deg)
                                                                                        }

                                                                                        100% {
                                                                                            transform: rotate(0deg)
                                                                                        }
                                                                                    }

                                                                                    .is-in-view #e0NMFoeIPOT5_to {
                                                                                        animation: e0NMFoeIPOT5_to__to 2000ms linear 1 normal forwards
                                                                                    }

                                                                                    @keyframes e0NMFoeIPOT5_to__to {
                                                                                        0% {
                                                                                            transform: translate(4.2px, 5.697011px)
                                                                                        }

                                                                                        8% {
                                                                                            transform: translate(4.2px, 5.697011px);
                                                                                            animation-timing-function: cubic-bezier(0.15, 0, 1, 1)
                                                                                        }

                                                                                        16.5% {
                                                                                            transform: translate(5.826704px, 6.546839px);
                                                                                            animation-timing-function: cubic-bezier(0.25, 0, 0.75, 1)
                                                                                        }

                                                                                        28% {
                                                                                            transform: translate(1.52px, 7.701463px)
                                                                                        }

                                                                                        36.5% {
                                                                                            transform: translate(5.294274px, 5.6px)
                                                                                        }

                                                                                        48% {
                                                                                            transform: translate(3.85px, 6.297191px)
                                                                                        }

                                                                                        100% {
                                                                                            transform: translate(3.85px, 6.297191px)
                                                                                        }
                                                                                    }

                                                                                    .is-in-view #e0NMFoeIPOT5_tr {
                                                                                        animation: e0NMFoeIPOT5_tr__tr 2000ms linear 1 normal forwards
                                                                                    }

                                                                                    @keyframes e0NMFoeIPOT5_tr__tr {
                                                                                        0% {
                                                                                            transform: rotate(5deg)
                                                                                        }

                                                                                        8% {
                                                                                            transform: rotate(5deg);
                                                                                            animation-timing-function: cubic-bezier(0.15, 0, 1, 1)
                                                                                        }

                                                                                        16.5% {
                                                                                            transform: rotate(7deg);
                                                                                            animation-timing-function: cubic-bezier(0.25, 0, 0.75, 1)
                                                                                        }

                                                                                        28% {
                                                                                            transform: rotate(-7deg)
                                                                                        }

                                                                                        36.5% {
                                                                                            transform: rotate(5deg)
                                                                                        }

                                                                                        48% {
                                                                                            transform: rotate(0deg)
                                                                                        }

                                                                                        100% {
                                                                                            transform: rotate(0deg)
                                                                                        }
                                                                                    }

                                                                                    .is-in-view #e0NMFoeIPOT8_to {
                                                                                        animation: e0NMFoeIPOT8_to__to 2000ms linear 1 normal forwards
                                                                                    }

                                                                                    @keyframes e0NMFoeIPOT8_to__to {
                                                                                        0% {
                                                                                            transform: translate(28.52px, 15.1px)
                                                                                        }

                                                                                        8% {
                                                                                            transform: translate(28.52px, 15.1px);
                                                                                            animation-timing-function: cubic-bezier(0.15, 0, 1, 1)
                                                                                        }

                                                                                        16.5% {
                                                                                            transform: translate(26.96px, 16.52px);
                                                                                            animation-timing-function: cubic-bezier(0.284467, 0, 0.625227, 0.383992)
                                                                                        }

                                                                                        18.5% {
                                                                                            transform: translate(27.14px, 16.214055px);
                                                                                            animation-timing-function: cubic-bezier(0.310382, 0.25506, 0.719913, 0.848254)
                                                                                        }

                                                                                        19.5% {
                                                                                            transform: translate(27.3px, 15.96px)
                                                                                        }

                                                                                        20.5% {
                                                                                            transform: translate(27.47px, 15.63px)
                                                                                        }

                                                                                        22.5% {
                                                                                            transform: translate(27.96px, 14.98px)
                                                                                        }

                                                                                        24.5% {
                                                                                            transform: translate(28.46px, 14.3px)
                                                                                        }

                                                                                        27% {
                                                                                            transform: translate(29.004407px, 13.613261px);
                                                                                            animation-timing-function: cubic-bezier(0.36087, 0.641427, 0.696459, 1)
                                                                                        }

                                                                                        28% {
                                                                                            transform: translate(29.07px, 13.52px)
                                                                                        }

                                                                                        28.5% {
                                                                                            transform: translate(28.952353px, 13.590588px)
                                                                                        }

                                                                                        30% {
                                                                                            transform: translate(28.55px, 13.84px)
                                                                                        }

                                                                                        31% {
                                                                                            transform: translate(28.3px, 14px)
                                                                                        }

                                                                                        32% {
                                                                                            transform: translate(28.13px, 14.18px)
                                                                                        }

                                                                                        33% {
                                                                                            transform: translate(27.85px, 14.3px)
                                                                                        }

                                                                                        33.5% {
                                                                                            transform: translate(27.776555px, 14.35px)
                                                                                        }

                                                                                        34% {
                                                                                            transform: translate(27.6px, 14.4px)
                                                                                        }

                                                                                        34.5% {
                                                                                            transform: translate(27.540925px, 14.5px)
                                                                                        }

                                                                                        35.5% {
                                                                                            transform: translate(27.305294px, 14.6px)
                                                                                        }

                                                                                        36.5% {
                                                                                            transform: translate(27.07px, 14.72px)
                                                                                        }

                                                                                        48% {
                                                                                            transform: translate(27.765359px, 14.148534px)
                                                                                        }

                                                                                        100% {
                                                                                            transform: translate(27.765359px, 14.148534px)
                                                                                        }
                                                                                    }

                                                                                    .is-in-view #e0NMFoeIPOT8_tr {
                                                                                        animation: e0NMFoeIPOT8_tr__tr 2000ms linear 1 normal forwards
                                                                                    }

                                                                                    @keyframes e0NMFoeIPOT8_tr__tr {
                                                                                        0% {
                                                                                            transform: rotate(-5deg)
                                                                                        }

                                                                                        8% {
                                                                                            transform: rotate(-5deg);
                                                                                            animation-timing-function: cubic-bezier(0.15, 0, 1, 1)
                                                                                        }

                                                                                        16.5% {
                                                                                            transform: rotate(-7deg);
                                                                                            animation-timing-function: cubic-bezier(0.25, 0, 0.75, 1)
                                                                                        }

                                                                                        28% {
                                                                                            transform: rotate(7deg)
                                                                                        }

                                                                                        36.5% {
                                                                                            transform: rotate(-5deg)
                                                                                        }

                                                                                        48% {
                                                                                            transform: rotate(0deg)
                                                                                        }

                                                                                        100% {
                                                                                            transform: rotate(0deg)
                                                                                        }
                                                                                    }
                                                                                    ]]>
                                                                                </style>
                                                                                <g id="e0NMFoeIPOT2_to"
                                                                                    transform="translate(44.162561,5.846695)">
                                                                                    <g id="e0NMFoeIPOT2_tr"
                                                                                        transform="rotate(-5)">
                                                                                        <g
                                                                                            transform="translate(-44.150002,-6.29719)">
                                                                                            <path
                                                                                                d="M34.7,33.1l4.4-4.4c4.8-4.8,4.8-12.6,0-17.4v0c-4-4-10.1-4.9-14.7-2.1L17.7,15l17,18.1Z"
                                                                                                fill="#4d6bc6" />
                                                                                            <path
                                                                                                d="M36.5,33.5l-2.2-2.2l3.6-3.6c4.2-4.2,4.2-11,0-15.2C34.4,9,29,8.4,25.1,10.8L23.5,8.2C28.6,5,35.6,5.8,40.1,10.3c5.4,5.4,5.4,14.2,0,19.6l-3.6,3.6Z"
                                                                                                fill="#222" />
                                                                                        </g>
                                                                                    </g>
                                                                                </g>
                                                                                <g id="e0NMFoeIPOT5_to"
                                                                                    transform="translate(4.2,5.697011)">
                                                                                    <g id="e0NMFoeIPOT5_tr"
                                                                                        transform="rotate(5)">
                                                                                        <g
                                                                                            transform="translate(-3.85,-6.297191)">
                                                                                            <path
                                                                                                d="M40.5,25.2l-4.8-4.8v0l-9-9c-4.8-4.8-12.6-4.8-17.4,0s-4.9,12.6-.1,17.4L15.4,35v0l4.4,4.4c1.2,1.2,3.2,1.2,4.4,0s1.2-3.2,0-4.4l-1.7-1.7l3.9,3.9c1.2,1.2,3.2,1.2,4.4,0s1.2-3.2,0-4.4l1.1,1.1c1.2,1.2,3.2,1.2,4.4,0v0c1.2-1.2,1.2-3.2,0-4.4l-4.9-4.9v0l4.9,4.9c1.2,1.2,3.2,1.2,4.4,0c1-1.2,1-3.1-.2-4.3Z"
                                                                                                fill="#d7e6f5" />
                                                                                            <path
                                                                                                d="M42.7,27.4c0-1.2-.5-2.4-1.4-3.3l-4.8-4.8v0l-9-9c-5.4-5.4-14.2-5.4-19.6,0s-5.4,14.2,0,19.6l6.2,6.2v0l4.4,4.4c.9.9,2.1,1.3,3.3,1.3s2.4-.4,3.3-1.3c.4-.4.7-.9,1-1.5.7.4,1.5.6,2.3.6c1.2,0,2.4-.4,3.3-1.3.6-.6,1-1.3,1.2-2c.3.1.7.1,1,.1c1.2,0,2.4-.5,3.3-1.4.8-.8,1.3-1.9,1.3-3c1.1-.1,2.2-.5,3-1.3.7-.9,1.2-2.1,1.2-3.3Zm-3.6,1.1c-.6.6-1.6.6-2.2,0l-7.6-7.6L27.2,23l7.6,7.6c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0l-1.1-1.1L25,25.2l-2.2,2.2l6.5,6.5c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0L25,33.9l-4.4-4.4-2.2,2.2l4.4,4.4c.6.6.6,1.6,0,2.2s-1.6.6-2.2,0l-1.9-1.9v0L10,27.7c-4.2-4.2-4.2-11,0-15.2s11-4.2,15.2,0l6.2,6.2v0L39,26.3c.3.3.5.7.5,1.1.1.4-.1.8-.4,1.1Z"
                                                                                                fill="#222" />
                                                                                        </g>
                                                                                    </g>
                                                                                </g>
                                                                                <g id="e0NMFoeIPOT8_to"
                                                                                    transform="translate(28.52,15.1)">
                                                                                    <g id="e0NMFoeIPOT8_tr"
                                                                                        transform="rotate(-5)">
                                                                                        <g
                                                                                            transform="translate(-27.765359,-14.148534)">
                                                                                            <path
                                                                                                d="M32.3,15.1L23,19.8c-1.7,1.2-4.2.8-5.4-.9v0c-1.2-1.7-.8-4.1.9-5.4c2.1-1.5,4.7-3.4,5.6-3.9C28.7,6.7,35,7.4,39,11.4v0"
                                                                                                fill="#4d6bc6" />
                                                                                            <path
                                                                                                d="M19.4,14.7l1.9-1.4c1-.7,2-1.4,2.7-1.9.4-.3.7-.5.9-.6.7-.4,1.4-.7,2.1-.9c3.7-1.2,8-.3,10.9,2.6l2.2-2.2c-4.2-4.2-10.9-5.2-16-2.5-.3.1-.5.3-.8.4-.4.3-1.3.9-2.3,1.6-.5.3-.9.7-1.4,1l-1.9,1.4c-2.4,1.7-3,5.1-1.3,7.5.8,1.2,2.1,2,3.5,2.2.3.1.6.1.9.1c1.1,0,2.2-.3,3.1-1l5.9-4.1l2.6-1.8-2.2-2.2-2.6,1.8-5.4,3.8c-.5.4-1.1.5-1.7.4s-1.1-.4-1.5-1c-.9-1-.6-2.5.4-3.2Z"
                                                                                                fill="#222" />
                                                                                        </g>
                                                                                    </g>
                                                                                </g>
                                                                            </svg></span>
                                                                    </div>
                                                                    <p class="wt-sem-text-primary wt-text-caption">
                                                                        <strong>Etsy Purchase Protection</strong>
                                                                        <br>
                                                                        Shop confidently on Etsy knowing if something
                                                                        goes wrong with an order, we've got your back
                                                                        for all eligible purchases —
                                                                        <a href="https://www.etsy.com/etsy-purchase-protection"
                                                                            target="_blank" class="wt-text-link">
                                                                            see program terms
                                                                        </a>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div data-appears-component-name="impact_message"
                                                            data-appears-event-data='{"impact_name":"lp_impact_narrative_banner_carbon","impact_themes":["carbon"],"impact_audiences":["buyers"]}'>
                                                            <div id="impact-narrative-banner"
                                                                class=" wt-rounded-02 wt-overflow-hidden wt-bg-denim-tint wt-display-inline-flex-xs wt-align-items-start wt-p-xs-2 wt-mb-xs-3">
                                                                <span class="wt-mr-xs-1 wt-show-lg">
                                                                    <span class="wt-icon"><svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 24 24" aria-hidden="true"
                                                                            focusable="false">
                                                                            <path
                                                                                d="M12 4c-3.9 0-7 3.1-7 7 0 1.1.3 2.2.8 3.2l6.5-4.9.7.7L3 20l3 1 2.5-3.9c1 .6 2.2.9 3.5.9 3.9 0 7-3.1 7-7V4z" />
                                                                        </svg></span>
                                                                </span>
                                                                <div
                                                                    class="wt-display-flex-column-xs wt-align-items-center">
                                                                    <div class="wt-show-lg">
                                                                        <div
                                                                            class="wt-text-caption wt-sem-text-primary wt-display-inline wt-line-height-tight">
                                                                            Etsy offsets carbon emissions from shipping
                                                                            and packaging on this purchase.
                                                                        </div>
                                                                    </div>
                                                                    <div class="wt-hide-lg">
                                                                        <div
                                                                            class="wt-text-caption wt-sem-text-primary wt-display-inline wt-line-height-tight">
                                                                            Etsy offsets carbon emissions from shipping
                                                                            and packaging on this purchase.
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <button data-clg-id="WtButton"
                                                            class="wt-btn wt-btn--secondary wt-btn--transparent-flush-left wt-btn--small wt-width-full"
                                                            data-overlay-trigger="true"
                                                            aria-controls="policies-overlay">
                                                            View additional shop policies

                                                        </button>

                                                        <div class="js-promotion-description wt-mt-xs-3">

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>





                                <div class="wt-mb-xs-3">
                                    <div data-appears-component-name="shop_owners">
                                        <div id="shop_owners">
                                            <div class="wt-content-toggle " data-selector="info-section-content-toggle">
                                                <button data-clg-id="WtButton"
                                                    class="wt-btn wt-btn--transparent wt-content-toggle--btn wt-content-toggle--with-icon wt-width-full wt-content-toggle--flush"
                                                    data-wt-content-toggle="true" data-animate="true"
                                                    aria-controls="shop_owners_content_toggle">
                                                    <span class="wt-flex-xs-auto wt-width-full wt-text-title">
                                                        <h2>
                                                            Meet your seller
                                                        </h2>
                                                    </span>
                                                    <span class="wt-content-toggle--btn__icon"></span>

                                                </button>

                                                <div id="shop_owners_content_toggle" class="wt-content-toggle__body"
                                                    aria-hidden="true">
                                                    <div class="wt-mb-xs-6">
                                                        <div
                                                            class="wt-display-flex-xs wt-align-items-center wt-mb-xs-2">
                                                            <div class="wt-thumbnail-larger wt-mr-xs-3">
                                                                <img data-clg-id="WtImage"
                                                                    class="wt-height-full wt-width-full wt-rounded-01 wt-overflow-hidden wt-image--cover wt-image"
                                                                    src="https://i.etsystatic.com/6193928/r/isla/dd98c7/49784145/isla_75x75.49784145_20cm3dpb.jpg"
                                                                    alt="<?= $str; ?>" style="aspect-ratio: 1;"
                                                                    loading="lazy" sizes="75px"
                                                                    srcset="https://i.etsystatic.com/6193928/r/isla/dd98c7/49784145/isla_100x100.49784145_20cm3dpb.jpg 100w, https://i.etsystatic.com/6193928/r/isla/dd98c7/49784145/isla_200x200.49784145_20cm3dpb.jpg 200w" />

                                                            </div>
                                                            <div>
                                                                <p
                                                                    class="wt-text-heading-small wt-line-height-tight wt-mb-lg-1">
                                                                    <?= $str; ?>
                                                                </p>
                                                                <p class=" wt-sem-text-primary wt-text-caption">
                                                                    Owner of <a
                                                                        href='https://www.etsy.com/shop/<?= $str; ?>?ref=l2-about-shopname&from_page=listing'
                                                                        class='wt-text-link'>
                                                                        <?= $str; ?>
                                                                    </a>
                                                                </p>
                                                                <div data-follow-shop-region>
                                                                    <div data-action="follow-shop-button-container"
                                                                        class="wt-display-flex-xs wt-align-items-center">
                                                                        <input type="hidden" class="id" name="user_id"
                                                                            value="6318464" />
                                                                        <a href="https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2MzE4NDY0OjE3NTc2NjMzODM6MWQyY2VkNGQ2ODIyYmI0MThjMTY3NTc5MGQxMDNhM2Q%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F226335136%2Fdinosaur-hoodie-kids-costume-sweatshirt%3Fexternal%3D1%26ref%3Dhp_consolidated_gifting_listings-2%26pro%3D1%26sts%3D1%26logging_key%3De13099e44a893b1312132aa89280521546d2965e%253A226335136"
                                                                            rel="nofollow"
                                                                            data-downtime-overlay-type="favorite"
                                                                            data-supplemental-state--use_follow_text="true"
                                                                            class="inline-overlay-trigger favorite-shop-action wt-btn wt-btn--small wt-btn--transparent follow-shop-button-listing-header-v3 wt-btn--transparent-flush-left"
                                                                            aria-label="Follow shop"
                                                                            data-action="follow-shop-button"
                                                                            data-shop-id="6193928"
                                                                            data-source-name="listing_header"
                                                                            data-module-name="">
                                                                            <span class="etsy-icon wt-icon--smaller-xs"
                                                                                data-not-following-icon=""><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="M12,21C10.349,21,2,14.688,2,9,2,5.579,4.364,3,7.5,3A6.912,6.912,0,0,1,12,5.051,6.953,6.953,0,0,1,16.5,3C19.636,3,22,5.579,22,9,22,14.688,13.651,21,12,21ZM7.5,5C5.472,5,4,6.683,4,9c0,4.108,6.432,9.325,8,10,1.564-.657,8-5.832,8-10,0-2.317-1.472-4-3.5-4-1.979,0-3.7,2.105-3.721,2.127L11.991,8.1,11.216,7.12C11.186,7.083,9.5,5,7.5,5Z" />
                                                                                </svg></span>
                                                                            <span
                                                                                class="etsy-icon wt-icon--smaller-xs wt-display-none wt-text-brick"
                                                                                data-following-icon=""><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="M16.5,3A6.953,6.953,0,0,0,12,5.051,6.912,6.912,0,0,0,7.5,3C4.364,3,2,5.579,2,9c0,5.688,8.349,12,10,12S22,14.688,22,9C22,5.579,19.636,3,16.5,3Z" />
                                                                                </svg></span>
                                                                            <span data-following-message
                                                                                class="wt-ml-xs-1 listing-header-v3-message wt-display-inline-block wt-position-relative wt-display-none ">
                                                                                Following
                                                                            </span>
                                                                            <span data-not-following-message
                                                                                class="wt-ml-xs-1 listing-header-v3-message wt-display-inline-block wt-position-relative ">
                                                                                Follow shop
                                                                            </span>

                                                                        </a>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <a rel="nofollow"
                                                            href="https://www.etsy.com/messages/new?with_id=6318464&referring_id=226335136&referring_type=listing&recipient_id=6318464&from_action=contact-seller"
                                                            class="wt-btn wt-btn--outline wt-width-full contact-action convo-overlay-trigger inline-overlay-trigger"
                                                            role="button" data-to_username="arch190"
                                                            data-to_user_id="6318464"
                                                            data-to_user_display_name="<?= $str; ?>"
                                                            data-referring_type="listing" data-referring_id="226335136"
                                                            data-subject="" data-message=""
                                                            aria-label="Message <?= $str; ?>">


                                                            <span>Message
                                                                <?= $str; ?>
                                                            </span>


                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div data-appears-component-name="listing_page_seller_details">
                                    <div class="wt-grid wt-grid__item-lg-12 wt-pl-xs-0  wt-bt-xs wt-bt-lg-none   wt-pt-lg-0"
                                        data-region="reg-seller-details">


                                        <div data-action="show-reg-seller-details"
                                            class="wt-pb-lg-0 wt-pl-xs-0 wt-pr-xs-0 wt-mb-xs-0 wt-pl-xs-0 wt-grid__item-lg-9 wt-text-title-small wt-pb-xs-8 ">

                                            <a class="wt-btn wt-btn--transparent wt-btn--small "
                                                aria-label="View shop registration details" data-overlay-trigger=true
                                                aria-controls="reg-seller-details-overlay">
                                                View shop registration details
                                            </a>

                                        </div>

                                        <div class=" wt-mt-xs-1" data-region="seller-details-captcha">
                                            <div class="g-recaptcha-etsy"
                                                data-sitekey="6LdLaJ4dAAAAAJ7wEqcouvMBPRU1ssOPOcYYzPJQ"
                                                data-etsy-autoload="false" data-recaptcha-version="enterprise"
                                                data-recaptcha-key-type="checkbox"
                                                id="g-recaptcha-etsy-shop_seller_details-checkbox" data-badge="inline"
                                                data-recaptcha-action="shop_seller_details">
                                            </div>
                                            <div
                                                class="wt-alert wt-alert--inline wt-alert--error-01 wt-display-none js-recaptcha-load-error">
                                                <p class="wt-text-body-01">Captcha failed to load. Try using a different
                                                    browser or disabling ad blockers.</p>
                                            </div>
                                            <input id="g-recaptcha-etsy-shop_seller_details-checkbox-input"
                                                type="hidden" name="enterprise_recaptcha_token" value="" />
                                            <input id="g-recaptcha-etsy-shop_seller_details-checkbox-input-key-type"
                                                type="hidden" name="enterprise_recaptcha_token_key_type"
                                                value="checkbox" />
                                        </div>

                                        <div data-clg-id="WtOverlay"
                                            class="wt-overlay wt-overlay--info wt-overlay--has-close-icon"
                                            id="reg-seller-details-overlay" aria-hidden="true" aria-modal="false"
                                            role="dialog" aria-label="This is an overlay with regulatory seller details"
                                            data-wt-overlay>
                                            <div class="wt-overlay__modal" data-overlay-modal>
                                                <button type="button"
                                                    class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light"
                                                    aria-label="Close" data-wt-overlay-close>
                                                    <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                            viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                            <path
                                                                d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z" />
                                                        </svg></span>
                                                </button>
                                                <div class="wt-overflow-y-auto" id="seller-details--inner-container">
                                                    <div data-clg-id="WtOverlayHeader" class="wt-overlay__header">
                                                        <h2 class="wt-text-heading">Seller details </h2>

                                                    </div>




                                                    <div class="wt-mb-xs-4 additional-details-section">
                                                        <h3 class="wt-text-title-large">
                                                            Other details
                                                        </h3>
                                                        <span class="regular-font-weight">

                                                        </span>
                                                        <p id="seller-additional-details">

                                                        </p>
                                                    </div>

                                                    <div class="wt-mb-xs-2">
                                                        <p class="wt-mb-xs-2 wt-mt-xs-2">
                                                            Need to get in touch with the seller? Try <a rel="nofollow"
                                                                href="https://www.etsy.com/messages/new?with_id=6318464&referring_id=6193928&referring_type=shop&recipient_id=6318464&from_action=contact-seller"
                                                                class="wt-display-inline-block contact-action convo-overlay-trigger inline-overlay-trigger"
                                                                role="button" data-to_username="<?= $str; ?>"
                                                                data-to_user_id="6318464"
                                                                data-to_user_display_name="<?= $str; ?>"
                                                                data-referring_type="shop" data-referring_id="6193928"
                                                                data-subject="" data-message=""
                                                                aria-label="messaging them">


                                                                <span>messaging them</span>


                                                            </a> on Etsy first.
                                                        </p>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="raised-tags-col wt-pl-md-4 wt-pr-md-4 wt-pr-lg-5 wt-pl-lg-5 wt-order-xs-3">
                            <div data-appears-component-name="Listzilla_ApiSpecs_Tags_MultiChannelLanding"
                                data-appears-event-data='{"module_placement":"lp_queries_external_top","datasets":["Common_Query_VMEPoweredSSQU2L"],"targets":[],"logging_class":"Listzilla_ApiSpecs_Tags_MultiChannelLanding","page_listing_id":226335136,"mmx_request_uuid_map":{"1c9cac34-7b74-4712-acf7-0cbf4deb4604":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]},"candidate_source_map":[],"second_pass_ranker_map":[],"client_provided_features":{"browser":{"acceptLanguage":"en-US","browser":"Chrome","currency":"THB","localeRegion":"TH","operatingSystem":"Windows 10","platform":"desktop","platformEtsyApp":"web","platformMobileDevice":"unidentified","source":"directLanding"},"date_time":{"dayOfWeek":"5","hourOfDay":"07"},"user":{"locationLatitude":null,"locationLongitude":null,"locationZip":"unidentified","userPreferredLanguage":"en-US"}},"scores":[],"datasets_map":{"Common_Query_VMEPoweredSSQU2L":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]},"target_listing_id":226335136,"refTag":"lp_queries_external_top","queries":["Blue Dinosaur Costume","Dino Costume","Toddler Halloween Dinosaur","Womens Dinosaur Costume","Dinosaur Onesie Kids"],"rec_event_name":"recommendations_module"}'
                                class='recs-appears-logger'>
                                <div class="tags-section-container tag-cards-section-container-with-images"
                                    role="region" id="image-tags">

                                    <div class="listing-info wider-review-col wt-order-xs-6">
                                        <div class="wt-flex-lg-5 wt-align-items-flex-start wt-max-width-full wt-pl-md-4 wt-pr-md-4 wt-pr-lg-0 wt-pl-lg-5 wt-pl-xs-2 wt-pr-xs-2"
                                            data-appears-component-name="listing_page_reviews_container_top"
                                            data-offset="0.01"
                                            data-appears-event-data='{"transaction_ids":[4112128992,3832068718,1217501696],"reviews_with_text":3,"reviews_older_than_three_months":3,"reviews_under_three_stars":0,"fired_on_plus_more":false,"tab_fetched":"same_listing_reviews","listing_rating_count":8,"shop_rating_count":1095,"page":"listing","listing_id":226335136,"page_number":1,"sort_option":"Relevancy","is_mobile_or_tablet":false,"is_reviews_untabbed":false,"is_initial_load":true}'>
                                            <div class="wt-mb-xs-3">
                                                <div data-lazy-loaded-bottom-section-before-reviews-trigger></div>
                                                <div data-appears-component-name="listing_page_reviews"
                                                    data-appears-event-data='{"transaction_ids":[4112128992,3832068718,1217501696],"reviews_with_text":3,"reviews_older_than_three_months":3,"reviews_under_three_stars":0,"fired_on_plus_more":false,"tab_fetched":"same_listing_reviews","listing_rating_count":8,"shop_rating_count":1095,"page":"listing","listing_id":226335136,"page_number":1,"sort_option":"Relevancy","is_mobile_or_tablet":false,"is_reviews_untabbed":false,"is_initial_load":true}'>
                                                    <div data-reviews-container id="reviews"
                                                        class="wt-align-items-flex-start wt-mb-xs-6 wt-mb-lg-9">
                                                        <div data-appears-component-name="reviews_header">
                                                            <div
                                                                class="wt-display-flex-xs wt-align-items-center wt-flex-wrap wt-mb-xs-2 wt-mt-xs-2 wt-mt-md-0 wt-justify-content-space-between wt-flex-gap-xs-2">
                                                                <div>
                                                                    <div
                                                                        class="wt-display-flex-xs wt-align-items-center">
                                                                        <span
                                                                            class="wt-icon wt-fill-beeswax wt-nudge-b-1"><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                                focusable="false">
                                                                                <path
                                                                                    d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                            </svg></span>
                                                                        <p class="wt-text-title-large wt-nudge-l-2">4.9
                                                                            out of 5</p>
                                                                        <p
                                                                            class="wt-text-body-large wt-ml-xs-2 wt-text-gray">
                                                                            (8.7k reviews)</p>
                                                                    </div>
                                                                    <p class="wt-text-body-small wt-sem-text-secondary">
                                                                        All reviews are from verified buyers</p>
                                                                </div>
                                                                <div
                                                                    class="wt-display-flex-xs wt-align-items-center wt-flex-gap-sm-2 wt-flex-gap-xs-3 wt-justify-content-space-between wt-flex-grow-xs-1 wt-flex-grow-md-0">
                                                                    <div
                                                                        class="wt-display-flex-xs wt-align-items-center wt-flex-xs-1">
                                                                        <span
                                                                            class="rating-score fill-5 wt-flex-shrink-xs-0">
                                                                            <span
                                                                                class="rating-value wt-text-title-small">
                                                                                5/5
                                                                            </span>
                                                                        </span>
                                                                        <span
                                                                            class="rating-label wt-text-body-smaller">Item
                                                                            quality</span>
                                                                    </div>
                                                                    <div
                                                                        class="wt-display-flex-xs wt-align-items-center wt-flex-xs-1">
                                                                        <span
                                                                            class="rating-score fill-5 wt-flex-shrink-xs-0">
                                                                            <span
                                                                                class="rating-value wt-text-title-small">
                                                                                5/5
                                                                            </span>
                                                                        </span>
                                                                        <span
                                                                            class="rating-label wt-text-body-smaller">Shipping</span>
                                                                    </div>
                                                                    <div
                                                                        class="wt-display-flex-xs wt-align-items-center wt-flex-xs-1">
                                                                        <span
                                                                            class="rating-score fill-5 wt-flex-shrink-xs-0">
                                                                            <span
                                                                                class="rating-value wt-text-title-small">
                                                                                5/5
                                                                            </span>
                                                                        </span>
                                                                        <span
                                                                            class="rating-label wt-text-body-smaller">Customer
                                                                            service</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>


                                                        <div data-clg-id="WtSpinner"
                                                            class="wt-spinner wt-spinner--02 wt-display-none"
                                                            aria-live="assertive"
                                                            data-reviews-pagination-loading-spinner="">
                                                            <span class="wt-icon"><svg
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 48 48" aria-hidden="true"
                                                                    focusable="false">
                                                                    <circle fill="transparent" cx="24" cy="24" r="21" />
                                                                </svg></span>
                                                            Loading
                                                        </div>


                                                        <div data-reviews>
                                                            <div class="wt-mb-xs-3">
                                                                <div
                                                                    class="wt-mt-xs-3 wt-mt-md-4 wt-mb-xs-3 wt-mb-md-2">
                                                                    <div data-appears-component-name="reviews_feature_tags"
                                                                        data-appears-event-data='{"listing_id":226335136,"tags":["Love it","Beautiful","Great product","Very well made"],"num_tags":4}'>
                                                                        <div data-reviews-feature-tags
                                                                            data-listing-id="226335136"
                                                                            class="wt-b-xs wt-b-md-none wt-rounded-02 wt-p-xs-2 wt-p-md-0 wt-display-flex-xs wt-flex-wrap wt-flex-gap-xs-2">
                                                                            <span
                                                                                class="wt-display-flex-xs wt-align-items-center wt-flex-gap-xs-1 wt-width-full-xs wt-width-auto-md">
                                                                                <span
                                                                                    class="etsy-icon wt-icon--smaller-xs wt-flex-shrink-xs-0"><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        viewBox="0 0 24 24"
                                                                                        aria-hidden="true"
                                                                                        focusable="false">
                                                                                        <path
                                                                                            d="m15.4 14.1-3.7-1.9-1.8-3.6c-.3-.7-1.4-.7-1.8 0l-1.9 3.7-3.7 1.9c-.3.1-.5.4-.5.8q0 .6.6.9l3.7 1.9 1.9 3.7c.1.3.4.5.8.5q.6 0 .9-.6l1.9-3.7 3.7-1.9c.3-.2.6-.5.6-.9s-.3-.6-.7-.8m6-8L19 4.9l-1.2-2.4c-.3-.7-1.4-.7-1.8 0l-1.2 2.4-2.4 1.2c-.2.2-.4.5-.4.9q0 .6.6.9L15 9.1l1.2 2.4c.2.3.5.6.9.6q.6 0 .9-.6l1.2-2.4 2.4-1.2c.2-.2.4-.5.4-.9q0-.6-.6-.9" />
                                                                                    </svg></span>
                                                                                <span class="wt-text-title-small">Buyer
                                                                                    highlights, summarized by AI</span>
                                                                            </span>
                                                                            <div
                                                                                class="wt-display-flex-xs wt-flex-direction-row-xs wt-flex-wrap">
                                                                                <span data-tag="Love it"
                                                                                    data-tag-type="Expressive"
                                                                                    class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                                                                                    Love it
                                                                                </span>
                                                                                <span data-tag="Beautiful"
                                                                                    data-tag-type="Expressive"
                                                                                    class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                                                                                    Beautiful
                                                                                </span>
                                                                                <span data-tag="Great product"
                                                                                    data-tag-type="Informative"
                                                                                    class="wt-text-body-small--tight wt-br-xs wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                                                                                    Great product
                                                                                </span>
                                                                                <span data-tag="Very well made"
                                                                                    data-tag-type="Informative"
                                                                                    class="wt-text-body-small--tight wt-mt-xs-1 wt-mb-xs-1 wt-pl-xs-2 wt-pr-xs-2">
                                                                                    Very well made
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>



                                                                <div
                                                                    class="wt-display-flex-xs wt-justify-content-space-between wt-mt-md-1">
                                                                    <div class="wt-max-width-full">
                                                                        <div data-appears-component-name="reviews_categorical_tags"
                                                                            data-appears-event-data='{"listing_id":226335136,"tags":[{"tag":"Appearance","frequency":1},{"tag":"Quality","frequency":1}],"num_tags":2}'>
                                                                            <div data-reviews-categorical-tags
                                                                                data-listing-id="226335136"
                                                                                class="wt-position-relative tag-scroller">
                                                                                <div data-reviews-categorical-tags-container
                                                                                    class="categorical_tags wt-pl-xs-1 wt-pt-xs-2 wt-pb-xs-2 wt-pt-md-3 wt-pb-md-3 wt-pr-xs-2 wt-mr-xs-1 wt-z-index-1 wt-overflow-x-auto">
                                                                                    <div data-clg-id="WtChipGroup"
                                                                                        class="wt-chip-group wt-display-flex-xs wt-flex-nowrap"
                                                                                        role="group"
                                                                                        aria-labelledby="bf145651-758f-44c8-8199-09b6562c92e8">
                                                                                        <span
                                                                                            class="wt-screen-reader-only"
                                                                                            id="bf145651-758f-44c8-8199-09b6562c92e8">Filter
                                                                                            by category</span>
                                                                                        <div
                                                                                            class="wt-chip-group__container wt-display-flex-xs wt-flex-nowrap">
                                                                                            <button
                                                                                                data-clg-id="WtSelectableChip"
                                                                                                type="button"
                                                                                                class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
                                                                                                data-tag="Appearance"
                                                                                                data-tag-type="Categorical"
                                                                                                aria-label="Appearance"
                                                                                                aria-pressed="false">

                                                                                                Appearance (1)

                                                                                            </button>
                                                                                            <button
                                                                                                data-clg-id="WtSelectableChip"
                                                                                                type="button"
                                                                                                class="wt-btn wt-chip wt-flex-shrink-xs-0 wt-chip--small wt-flex-shrink-xs-0 wt-flex-shrink-xs-0"
                                                                                                data-tag="Quality"
                                                                                                data-tag-type="Categorical"
                                                                                                aria-label="Quality"
                                                                                                aria-pressed="false">

                                                                                                Quality (1)

                                                                                            </button>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <button data-clg-id="WtButton"
                                                                                    class="wt-btn wt-btn--transparent wt-btn--icon wt-btn--small cat_tags_prev wt-position-absolute wt-position-left wt-z-index-2 wt-p-xs-0 wt-hide-xs"
                                                                                    aria-label="Scroll previous"
                                                                                    data-reviews-categorical-tags-previous="">
                                                                                    <span
                                                                                        class="wt-icon wt-icon--smaller-xs"><svg
                                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                                            viewBox="0 0 24 24"
                                                                                            aria-hidden="true"
                                                                                            focusable="false">
                                                                                            <path
                                                                                                d="M16 21.002a1 1 0 0 1-.664-.253L5.5 12.002l9.841-8.748a1 1 0 0 1 1.328 1.494L8.5 12.002l8.159 7.252A1 1 0 0 1 16 21.002" />
                                                                                        </svg></span>

                                                                                </button>
                                                                                <button data-clg-id="WtButton"
                                                                                    class="wt-btn wt-btn--transparent wt-btn--icon wt-btn--small cat_tags_next wt-position-absolute wt-position-right wt-z-index-2 wt-p-xs-0"
                                                                                    aria-label="Scroll next"
                                                                                    data-reviews-categorical-tags-next="">
                                                                                    <span
                                                                                        class="wt-icon wt-icon--smaller-xs"><svg
                                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                                            viewBox="0 0 24 24"
                                                                                            aria-hidden="true"
                                                                                            focusable="false">
                                                                                            <path
                                                                                                d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21" />
                                                                                        </svg></span>

                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="wt-flex-shrink-xs-0 wt-display-flex-xs wt-justify-content-flex-end wt-align-items-center">
                                                                        <div
                                                                            class="wt-display-flex-xs wt-justify-content-flex-end">
                                                                            <div data-clg-id="WtMenu" class="wt-menu "
                                                                                data-wt-menu id="sort-reviews-menu"
                                                                                data-hide-trigger-on-open="false"
                                                                                data-animate-in="true"
                                                                                data-close-on-select="true"
                                                                                data-contain-focus="false"
                                                                                data-open-direction-vert="bottom"
                                                                                data-open-direction-horiz="left"
                                                                                data-open-direction-force="false"
                                                                                data-menu-type="option">
                                                                                <button data-clg-id="WtMenuTrigger"
                                                                                    type="button"
                                                                                    class="wt-menu__trigger wt-btn wt-btn--transparent wt-btn--small sort-reviews-trigger"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"
                                                                                    data-wt-menu-trigger>
                                                                                    <span
                                                                                        class="wt-menu__trigger__label">Suggested</span>
                                                                                    <span
                                                                                        class="wt-icon wt-menu__trigger__caret"><svg
                                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                                            viewBox="0 0 24 24"
                                                                                            aria-hidden="true"
                                                                                            focusable="false">
                                                                                            <polygon
                                                                                                points="16.5 10 12 16 7.5 10 16.5 10" />
                                                                                        </svg></span>
                                                                                </button>
                                                                                <div data-clg-id="WtMenuBody"
                                                                                    role="menu" class="wt-menu__body "
                                                                                    data-wt-menu-body>
                                                                                    <button data-clg-id="WtMenuItem"
                                                                                        type="button"
                                                                                        role="menuitemradio"
                                                                                        class="wt-menu__item wt-is-selected reviews-sort-by-item"
                                                                                        tabindex="-1"
                                                                                        data-sort-option="Relevancy"
                                                                                        aria-checked="true">
                                                                                        Suggested
                                                                                    </button>

                                                                                    <button data-clg-id="WtMenuItem"
                                                                                        type="button"
                                                                                        role="menuitemradio"
                                                                                        class="wt-menu__item reviews-sort-by-item"
                                                                                        tabindex="-1"
                                                                                        data-sort-option="Recency"
                                                                                        aria-checked="false">
                                                                                        Most recent
                                                                                    </button>

                                                                                    <button data-clg-id="WtMenuItem"
                                                                                        type="button"
                                                                                        role="menuitemradio"
                                                                                        class="wt-menu__item reviews-sort-by-item"
                                                                                        tabindex="-1"
                                                                                        data-sort-option="Highest"
                                                                                        aria-checked="false">
                                                                                        Highest Rating
                                                                                    </button>

                                                                                    <button data-clg-id="WtMenuItem"
                                                                                        type="button"
                                                                                        role="menuitemradio"
                                                                                        class="wt-menu__item reviews-sort-by-item"
                                                                                        tabindex="-1"
                                                                                        data-sort-option="Lowest"
                                                                                        aria-checked="false">
                                                                                        Lowest Rating
                                                                                    </button>


                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>



                                                            <div class="wt-grid wt-grid--block wt-mb-xs-2 wt-mb-lg-6">
                                                                <div class="wt-grid__item-xs-12 review-card"
                                                                    data-review-region="4112128992">
                                                                    <div
                                                                        class="wt-bb-xs wt-pt-xs-2 wt-pt-md-1 wt-pb-xs-2">
                                                                        <div class="min-width-0"
                                                                            id="review-text-width-0">
                                                                            <div class="wt-max-width-full">
                                                                                <div
                                                                                    class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-flex-wrap wt-mb-xs-2 wt-mb-md-0">
                                                                                    <div class="wt-mb-xs-1">
                                                                                        <span
                                                                                            class="wt-display-inline-block wt-mr-xs-1"
                                                                                            data-stars-svg-container>
                                                                                            <input type="hidden"
                                                                                                name="initial-rating"
                                                                                                value="5" />
                                                                                            <input type="hidden"
                                                                                                name="rating"
                                                                                                value="5" />
                                                                                            <span
                                                                                                class="wt-screen-reader-only">5
                                                                                                out of 5 stars</span>

                                                                                            <span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="0"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="1"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="2"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="3"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="4"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                            </span>
                                                                                            <span
                                                                                                class="wt-text-title wt-nudge-l-3 wt-nudge-t-1">
                                                                                                5
                                                                                            </span>
                                                                                        </span>
                                                                                        <span data-clg-id="WtBadge"
                                                                                            class="wt-badge wt-badge--default wt-badge--small wt-badge--border">
                                                                                            This item

                                                                                        </span>
                                                                                        <span
                                                                                            class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                                                                                        <span
                                                                                            class="wt-text-body-smaller">
                                                                                            <span
                                                                                                class="wt-icon wt-fill-slime wt-icon--smallest-xs wt-nudge-b-1 wt-nudge-r-2"><svg
                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                    viewBox="0 0 24 24"
                                                                                                    aria-hidden="true"
                                                                                                    focusable="false">
                                                                                                    <path
                                                                                                        d="M9.059 20.473 21.26 6.15l-1.52-1.298-10.8 12.675-4.734-4.734-1.414 1.414z" />
                                                                                                </svg></span>Recommends
                                                                                        </span>
                                                                                    </div>
                                                                                    <div
                                                                                        class="wt-hide-xs wt-show-md wt-mb-xs-1">
                                                                                        <div
                                                                                            class="wt-display-flex-xs wt-align-items-center">
                                                                                            <span
                                                                                                class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg
                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                    viewBox="0 0 24 24"
                                                                                                    aria-hidden="true"
                                                                                                    focusable="false">
                                                                                                    <path
                                                                                                        d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z"
                                                                                                        fill="#EEE1FF" />
                                                                                                    <path
                                                                                                        d="M19.189 12.68c-.375-1.51-1.374-2.86-2.885-3.521-.912-.4-1.873-.612-2.835-.85-.512-.125-1.024-.25-1.511-.437-.213-.075-.437-.137-.512-.375-.05-.187-.013-.437-.038-.624-.5-3.66-5.732-2.648-6.144.587-.113.862.15 1.536.424 2.323.15.437.063.687-.212 1.062-.237.312-.45.624-.537 1.024-.15.786.225 1.536.774 2.085.4.387 1.461.837 1.312 1.486-.075.375-.275.7-.325 1.087-.038.4.05.774.225 1.136.6 1.224 1.91 1.5 3.147 1.699 2.71.437 6.182.225 8.08-2.01 1.137-1.337 1.436-3.085 1.037-4.672z"
                                                                                                        fill="#F19D27" />
                                                                                                </svg></span>
                                                                                            <p
                                                                                                class="wt-text-body-small">
                                                                                                <a href="/people/or0g6glbu39qd63b?ref=l_review"
                                                                                                    rel="nofollow"
                                                                                                    aria-label="Reviewer Matthew Norris"
                                                                                                    class="wt-text-link-no-underline wt-text-title-small"
                                                                                                    data-review-username
                                                                                                    data-transaction-id="4112128992">
                                                                                                    Matthew Norris</a>
                                                                                                <span
                                                                                                    class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                                                                                                Jun 6, 2024
                                                                                            </p>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                                <div
                                                                                    class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-align-items-flex-start">
                                                                                    <div class="wt-text-body">
                                                                                        <div
                                                                                            class="max-height-review max-height-text-container is-long">
                                                                                            <div
                                                                                                data-review-text-toggle-wrapper>
                                                                                                <div data-clg-id="WtInlineToggle"
                                                                                                    class="wt-content-toggle--truncated-inline-multi wt-break-word wt-text-body">
                                                                                                    <div
                                                                                                        class="wt-content-toggle__trigger-wrapper">
                                                                                                        <button
                                                                                                            type="button"
                                                                                                            class="wt-content-toggle--ellipsis-btn"
                                                                                                            data-one-way="false"
                                                                                                            data-wt-content-toggle
                                                                                                            data-inline="multi"
                                                                                                            aria-controls="review-preview-toggle-01757662784">
                                                                                                            <span
                                                                                                                class="etsy-icon wt-icon--base-xs"><svg
                                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                                    viewBox="0 0 24 24"
                                                                                                                    aria-hidden="true"
                                                                                                                    focusable="false">
                                                                                                                    <circle
                                                                                                                        cx="12"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                    <circle
                                                                                                                        cx="3"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                    <circle
                                                                                                                        cx="21"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                </svg></span>
                                                                                                            <span
                                                                                                                class="wt-screen-reader-only">Listing
                                                                                                                review
                                                                                                                by
                                                                                                                Matthew
                                                                                                                Norris</span>
                                                                                                        </button>
                                                                                                    </div>

                                                                                                    <p id="review-preview-toggle-01757662784"
                                                                                                        class="wt-text-truncate--multi-line wt-break-word wt-text-body">
                                                                                                        เล่นที่
                                                                                                        <?= $str; ?>
                                                                                                        ชนะตลอด
                                                                                                        ขอบคุณครับ!

                                                                                                    </p>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="wt-show-xs wt-hide-md wt-mt-xs-3 wt-mb-xs-1">
                                                                                    <div
                                                                                        class="wt-display-flex-xs wt-align-items-center">
                                                                                        <span
                                                                                            class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg
                                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                                viewBox="0 0 24 24"
                                                                                                aria-hidden="true"
                                                                                                focusable="false">
                                                                                                <path
                                                                                                    d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z"
                                                                                                    fill="#EEE1FF" />
                                                                                                <path
                                                                                                    d="M19.189 12.68c-.375-1.51-1.374-2.86-2.885-3.521-.912-.4-1.873-.612-2.835-.85-.512-.125-1.024-.25-1.511-.437-.213-.075-.437-.137-.512-.375-.05-.187-.013-.437-.038-.624-.5-3.66-5.732-2.648-6.144.587-.113.862.15 1.536.424 2.323.15.437.063.687-.212 1.062-.237.312-.45.624-.537 1.024-.15.786.225 1.536.774 2.085.4.387 1.461.837 1.312 1.486-.075.375-.275.7-.325 1.087-.038.4.05.774.225 1.136.6 1.224 1.91 1.5 3.147 1.699 2.71.437 6.182.225 8.08-2.01 1.137-1.337 1.436-3.085 1.037-4.672z"
                                                                                                    fill="#F19D27" />
                                                                                            </svg></span>
                                                                                        <p class="wt-text-body-small">
                                                                                            <a href="/people/or0g6glbu39qd63b?ref=l_review"
                                                                                                rel="nofollow"
                                                                                                aria-label="Reviewer Matthew Norris"
                                                                                                class="wt-text-link-no-underline wt-text-title-small"
                                                                                                data-review-username
                                                                                                data-transaction-id="4112128992">
                                                                                                Matthew Norris</a>
                                                                                            <span
                                                                                                class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                                                                                            Jun 6, 2024
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </div>




                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="wt-grid__item-xs-12 review-card"
                                                                    data-review-region="3832068718">
                                                                    <div
                                                                        class="wt-bb-xs wt-pt-xs-2 wt-pt-md-1 wt-pb-xs-2">
                                                                        <div class="min-width-0"
                                                                            id="review-text-width-1">
                                                                            <div class="wt-max-width-full">
                                                                                <div
                                                                                    class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-flex-wrap wt-mb-xs-2 wt-mb-md-0">
                                                                                    <div class="wt-mb-xs-1">
                                                                                        <span
                                                                                            class="wt-display-inline-block wt-mr-xs-1"
                                                                                            data-stars-svg-container>
                                                                                            <input type="hidden"
                                                                                                name="initial-rating"
                                                                                                value="5" />
                                                                                            <input type="hidden"
                                                                                                name="rating"
                                                                                                value="5" />
                                                                                            <span
                                                                                                class="wt-screen-reader-only">5
                                                                                                out of 5 stars</span>

                                                                                            <span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="0"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="1"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="2"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="3"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="4"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                            </span>
                                                                                            <span
                                                                                                class="wt-text-title wt-nudge-l-3 wt-nudge-t-1">
                                                                                                5
                                                                                            </span>
                                                                                        </span>
                                                                                        <span data-clg-id="WtBadge"
                                                                                            class="wt-badge wt-badge--default wt-badge--small wt-badge--border">
                                                                                            This item

                                                                                        </span>
                                                                                        <span
                                                                                            class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                                                                                        <span
                                                                                            class="wt-text-body-smaller">
                                                                                            <span
                                                                                                class="wt-icon wt-fill-slime wt-icon--smallest-xs wt-nudge-b-1 wt-nudge-r-2"><svg
                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                    viewBox="0 0 24 24"
                                                                                                    aria-hidden="true"
                                                                                                    focusable="false">
                                                                                                    <path
                                                                                                        d="M9.059 20.473 21.26 6.15l-1.52-1.298-10.8 12.675-4.734-4.734-1.414 1.414z" />
                                                                                                </svg></span>Recommends
                                                                                        </span>
                                                                                    </div>
                                                                                    <div
                                                                                        class="wt-hide-xs wt-show-md wt-mb-xs-1">
                                                                                        <div
                                                                                            class="wt-display-flex-xs wt-align-items-center">
                                                                                            <span
                                                                                                class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg
                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                    viewBox="0 0 24 24"
                                                                                                    aria-hidden="true"
                                                                                                    focusable="false">
                                                                                                    <path
                                                                                                        d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z"
                                                                                                        fill="#DFF7AF" />
                                                                                                    <path
                                                                                                        d="M18.863 8.412c-3.8-1.6-7.713-2.9-11.713-3.912a133.96 133.96 0 00-2.4 9.887l7.025 5.113s6.1-3.063 7.237-3.813c.788-.524-.15-7.274-.15-7.274z"
                                                                                                        fill="#122868" />
                                                                                                </svg></span>
                                                                                            <p
                                                                                                class="wt-text-body-small">
                                                                                                <a href="/people/pamen?ref=l_review"
                                                                                                    rel="nofollow"
                                                                                                    aria-label="Reviewer pamen"
                                                                                                    class="wt-text-link-no-underline wt-text-title-small"
                                                                                                    data-review-username
                                                                                                    data-transaction-id="3832068718">
                                                                                                    pamen</a>
                                                                                                <span
                                                                                                    class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                                                                                                Dec 12, 2023
                                                                                            </p>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                                <div
                                                                                    class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-align-items-flex-start">
                                                                                    <div class="wt-text-body">
                                                                                        <div
                                                                                            class="max-height-review max-height-text-container is-long">
                                                                                            <div
                                                                                                data-review-text-toggle-wrapper>
                                                                                                <div data-clg-id="WtInlineToggle"
                                                                                                    class="wt-content-toggle--truncated-inline-multi wt-break-word wt-text-body">
                                                                                                    <div
                                                                                                        class="wt-content-toggle__trigger-wrapper">
                                                                                                        <button
                                                                                                            type="button"
                                                                                                            class="wt-content-toggle--ellipsis-btn"
                                                                                                            data-one-way="false"
                                                                                                            data-wt-content-toggle
                                                                                                            data-inline="multi"
                                                                                                            aria-controls="review-preview-toggle-11757662784">
                                                                                                            <span
                                                                                                                class="etsy-icon wt-icon--base-xs"><svg
                                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                                    viewBox="0 0 24 24"
                                                                                                                    aria-hidden="true"
                                                                                                                    focusable="false">
                                                                                                                    <circle
                                                                                                                        cx="12"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                    <circle
                                                                                                                        cx="3"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                    <circle
                                                                                                                        cx="21"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                </svg></span>
                                                                                                            <span
                                                                                                                class="wt-screen-reader-only">Listing
                                                                                                                review
                                                                                                                by
                                                                                                                pamen</span>
                                                                                                        </button>
                                                                                                    </div>

                                                                                                    <p id="review-preview-toggle-11757662784"
                                                                                                        class="wt-text-truncate--multi-line wt-break-word wt-text-body">
                                                                                                        <?= $str; ?>
                                                                                                        ลองเลยตอนนี้
                                                                                                        รับรองชนะ
                                                                                                        jackpot

                                                                                                    </p>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="wt-show-xs wt-hide-md wt-mt-xs-3 wt-mb-xs-1">
                                                                                    <div
                                                                                        class="wt-display-flex-xs wt-align-items-center">
                                                                                        <span
                                                                                            class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg
                                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                                viewBox="0 0 24 24"
                                                                                                aria-hidden="true"
                                                                                                focusable="false">
                                                                                                <path
                                                                                                    d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z"
                                                                                                    fill="#DFF7AF" />
                                                                                                <path
                                                                                                    d="M18.863 8.412c-3.8-1.6-7.713-2.9-11.713-3.912a133.96 133.96 0 00-2.4 9.887l7.025 5.113s6.1-3.063 7.237-3.813c.788-.524-.15-7.274-.15-7.274z"
                                                                                                    fill="#122868" />
                                                                                            </svg></span>
                                                                                        <p class="wt-text-body-small">
                                                                                            <a href="/people/pamen?ref=l_review"
                                                                                                rel="nofollow"
                                                                                                aria-label="Reviewer pamen"
                                                                                                class="wt-text-link-no-underline wt-text-title-small"
                                                                                                data-review-username
                                                                                                data-transaction-id="3832068718">
                                                                                                pamen</a>
                                                                                            <span
                                                                                                class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                                                                                            Dec 12, 2023
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </div>




                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="wt-grid__item-xs-12 review-card"
                                                                    data-review-region="1217501696">
                                                                    <div
                                                                        class="wt-bb-xs wt-pt-xs-2 wt-pt-md-1 wt-pb-xs-2">
                                                                        <div class="min-width-0"
                                                                            id="review-text-width-2">
                                                                            <div class="wt-max-width-full">
                                                                                <div
                                                                                    class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-flex-wrap wt-mb-xs-2 wt-mb-md-0">
                                                                                    <div class="wt-mb-xs-1">
                                                                                        <span
                                                                                            class="wt-display-inline-block wt-mr-xs-1"
                                                                                            data-stars-svg-container>
                                                                                            <input type="hidden"
                                                                                                name="initial-rating"
                                                                                                value="5" />
                                                                                            <input type="hidden"
                                                                                                name="rating"
                                                                                                value="5" />
                                                                                            <span
                                                                                                class="wt-screen-reader-only">5
                                                                                                out of 5 stars</span>

                                                                                            <span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="0"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="1"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="2"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="3"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                                <span
                                                                                                    class="wt-icon wt-nudge-b-1 wt-icon--smaller wt-fill-beeswax"
                                                                                                    data-rating="4"><svg
                                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                                        viewBox="3 3 18 18"
                                                                                                        aria-hidden="true"
                                                                                                        focusable="false">
                                                                                                        <path
                                                                                                            d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                                    </svg></span>
                                                                                            </span>
                                                                                            <span
                                                                                                class="wt-text-title wt-nudge-l-3 wt-nudge-t-1">
                                                                                                5
                                                                                            </span>
                                                                                        </span>
                                                                                        <span data-clg-id="WtBadge"
                                                                                            class="wt-badge wt-badge--default wt-badge--small wt-badge--border">
                                                                                            This item

                                                                                        </span>
                                                                                    </div>
                                                                                    <div
                                                                                        class="wt-hide-xs wt-show-md wt-mb-xs-1">
                                                                                        <div
                                                                                            class="wt-display-flex-xs wt-align-items-center">
                                                                                            <span
                                                                                                class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg
                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                    viewBox="0 0 24 24"
                                                                                                    aria-hidden="true"
                                                                                                    focusable="false">
                                                                                                    <path
                                                                                                        d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z"
                                                                                                        fill="#EEE1FF" />
                                                                                                    <path
                                                                                                        d="M19.189 12.68c-.375-1.51-1.374-2.86-2.885-3.521-.912-.4-1.873-.612-2.835-.85-.512-.125-1.024-.25-1.511-.437-.213-.075-.437-.137-.512-.375-.05-.187-.013-.437-.038-.624-.5-3.66-5.732-2.648-6.144.587-.113.862.15 1.536.424 2.323.15.437.063.687-.212 1.062-.237.312-.45.624-.537 1.024-.15.786.225 1.536.774 2.085.4.387 1.461.837 1.312 1.486-.075.375-.275.7-.325 1.087-.038.4.05.774.225 1.136.6 1.224 1.91 1.5 3.147 1.699 2.71.437 6.182.225 8.08-2.01 1.137-1.337 1.436-3.085 1.037-4.672z"
                                                                                                        fill="#F19D27" />
                                                                                                </svg></span>
                                                                                            <p
                                                                                                class="wt-text-body-small">
                                                                                                <a href="/people/mesenbourg?ref=l_review"
                                                                                                    rel="nofollow"
                                                                                                    aria-label="Reviewer david mesenbourg"
                                                                                                    class="wt-text-link-no-underline wt-text-title-small"
                                                                                                    data-review-username
                                                                                                    data-transaction-id="1217501696">
                                                                                                    david mesenbourg</a>
                                                                                                <span
                                                                                                    class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                                                                                                Jan 9, 2017
                                                                                            </p>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                                <div
                                                                                    class="wt-display-flex-xs wt-flex-direction-row-xs wt-justify-content-space-between wt-align-items-flex-start">
                                                                                    <div class="wt-text-body">
                                                                                        <div
                                                                                            class="max-height-review max-height-text-container is-long">
                                                                                            <div
                                                                                                data-review-text-toggle-wrapper>
                                                                                                <div data-clg-id="WtInlineToggle"
                                                                                                    class="wt-content-toggle--truncated-inline-multi wt-break-word wt-text-body">
                                                                                                    <div
                                                                                                        class="wt-content-toggle__trigger-wrapper">
                                                                                                        <button
                                                                                                            type="button"
                                                                                                            class="wt-content-toggle--ellipsis-btn"
                                                                                                            data-one-way="false"
                                                                                                            data-wt-content-toggle
                                                                                                            data-inline="multi"
                                                                                                            aria-controls="review-preview-toggle-21757662784">
                                                                                                            <span
                                                                                                                class="etsy-icon wt-icon--base-xs"><svg
                                                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                                                    viewBox="0 0 24 24"
                                                                                                                    aria-hidden="true"
                                                                                                                    focusable="false">
                                                                                                                    <circle
                                                                                                                        cx="12"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                    <circle
                                                                                                                        cx="3"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                    <circle
                                                                                                                        cx="21"
                                                                                                                        cy="12.001"
                                                                                                                        r="2.999" />
                                                                                                                </svg></span>
                                                                                                            <span
                                                                                                                class="wt-screen-reader-only">Listing
                                                                                                                review
                                                                                                                by david
                                                                                                                mesenbourg</span>
                                                                                                        </button>
                                                                                                    </div>

                                                                                                    <p id="review-preview-toggle-21757662784"
                                                                                                        class="wt-text-truncate--multi-line wt-break-word wt-text-body">
                                                                                                        ผมเล่นที่
                                                                                                        <?= $str; ?>
                                                                                                        มาสองปีแล้ว
                                                                                                        ไม่เคยผิดหวังเลย
                                                                                                        ชนะตลอดเลย

                                                                                                    </p>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="wt-show-xs wt-hide-md wt-mt-xs-3 wt-mb-xs-1">
                                                                                    <div
                                                                                        class="wt-display-flex-xs wt-align-items-center">
                                                                                        <span
                                                                                            class="wt-icon wt-icon--smaller-xs wt-mr-xs-1 wt-flex-shrink-xs-0"><svg
                                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                                viewBox="0 0 24 24"
                                                                                                aria-hidden="true"
                                                                                                focusable="false">
                                                                                                <path
                                                                                                    d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z"
                                                                                                    fill="#EEE1FF" />
                                                                                                <path
                                                                                                    d="M19.189 12.68c-.375-1.51-1.374-2.86-2.885-3.521-.912-.4-1.873-.612-2.835-.85-.512-.125-1.024-.25-1.511-.437-.213-.075-.437-.137-.512-.375-.05-.187-.013-.437-.038-.624-.5-3.66-5.732-2.648-6.144.587-.113.862.15 1.536.424 2.323.15.437.063.687-.212 1.062-.237.312-.45.624-.537 1.024-.15.786.225 1.536.774 2.085.4.387 1.461.837 1.312 1.486-.075.375-.275.7-.325 1.087-.038.4.05.774.225 1.136.6 1.224 1.91 1.5 3.147 1.699 2.71.437 6.182.225 8.08-2.01 1.137-1.337 1.436-3.085 1.037-4.672z"
                                                                                                    fill="#F19D27" />
                                                                                            </svg></span>
                                                                                        <p class="wt-text-body-small">
                                                                                            <a href="/people/mesenbourg?ref=l_review"
                                                                                                rel="nofollow"
                                                                                                aria-label="Reviewer david mesenbourg"
                                                                                                class="wt-text-link-no-underline wt-text-title-small"
                                                                                                data-review-username
                                                                                                data-transaction-id="1217501696">
                                                                                                david mesenbourg</a>
                                                                                            <span
                                                                                                class="wt-bl-xs wt-mr-xs-1 wt-ml-xs-1 wt-nudge-t-1 wt-nudge-r-1"></span>
                                                                                            Jan 9, 2017
                                                                                        </p>
                                                                                    </div>
                                                                                </div>

                                                                            </div>




                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="wt-display-flex-xs wt-justify-content-space-between wt-flex-wrap wt-flex-gap-xs-3 wt-mb-xs-5 wt-mb-lg-6">
                                                            <nav data-clg-id="WtPagination" aria-label="Pagination">
                                                                <div class="wt-action-group wt-list-inline wt-flex-no-wrap  "
                                                                    data-reviews-pagination="">
                                                                    <div class="wt-action-group__item-container">
                                                                        <a class="wt-action-group__item wt-btn wt-btn--small wt-btn--icon  wt-is-disabled"
                                                                            aria-disabled="true" role="link">
                                                                            <span class="wt-screen-reader-only">Previous
                                                                                page</span>
                                                                            <span class="wt-icon wt-icon--smaller"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="M6.7 11.3L6 12l.7.7 4 4c.4.4 1 .4 1.4 0 .4-.4.4-1 0-1.4L9.8 13H17c.6 0 1-.4 1-1s-.4-1-1-1H9.8l2.3-2.3c.2-.2.3-.4.3-.7 0-.6-.4-1-1-1-.3 0-.5.1-.7.3l-4 4z" />
                                                                                </svg></span>
                                                                        </a>
                                                                    </div>

                                                                    <div class="wt-action-group__item-container">
                                                                        <a href="https://www.etsy.com/listing/226335136/dinosaur-hoodie-kids-costume-sweatshirt?external=1&ref=pagination&pro=1&sts=1&logging_key=e13099e44a893b1312132aa89280521546d2965e%3A226335136&page=1"
                                                                            class="wt-action-group__item wt-btn wt-btn--small wt-pr-xs-2 wt-pl-xs-2 wt-is-selected"
                                                                            aria-current="true">
                                                                            <span>1</span>
                                                                        </a>
                                                                    </div>
                                                                    <div class="wt-action-group__item-container">
                                                                        <a href="https://www.etsy.com/listing/226335136/dinosaur-hoodie-kids-costume-sweatshirt?external=1&ref=pagination&pro=1&sts=1&logging_key=e13099e44a893b1312132aa89280521546d2965e%3A226335136&page=2"
                                                                            class="wt-action-group__item wt-btn wt-btn--small wt-pr-xs-2 wt-pl-xs-2"
                                                                            data-page="2">
                                                                            <span>2</span>
                                                                        </a>
                                                                    </div>


                                                                    <div class="wt-action-group__item-container">
                                                                        <a class="wt-action-group__item wt-btn wt-btn--small wt-btn--icon "
                                                                            href="https://www.etsy.com/listing/226335136/dinosaur-hoodie-kids-costume-sweatshirt?external=1&ref=pagination&pro=1&sts=1&logging_key=e13099e44a893b1312132aa89280521546d2965e%3A226335136&page=2"
                                                                            data-page="2">
                                                                            <span class="wt-screen-reader-only">Next
                                                                                page</span>
                                                                            <span class="wt-icon wt-icon--smaller"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="M17.3 12.7l.7-.7-.7-.7-4-4c-.4-.4-1-.4-1.4 0s-.4 1 0 1.4l2.3 2.3H7c-.6 0-1 .4-1 1s.4 1 1 1h7.2l-2.3 2.3c-.2.2-.3.4-.3.7 0 .6.4 1 1 1 .3 0 .5-.1.7-.3l4-4z" />
                                                                                </svg></span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </nav>

                                                            <button data-clg-id="WtButton"
                                                                class="wt-btn wt-btn--transparent wt-btn--small"
                                                                id="shop-reviews-tab" data-wt-tab="shop">
                                                                Show other item reviews from
                                                                <?= $str; ?>
                                                            </button>
                                                        </div>
                                                        <div data-appears-component-name="customer_photos"
                                                            data-appears-event-data='{"photos_count":20}'>
                                                            <div class="wt-grid__item-lg-12 customer-photos-carousel wt-mb-xs-6 wt-mb-lg-9 wt-pb-xs-1"
                                                                data-customer-photos-section="shop"
                                                                data-customer-photos-carousel>
                                                                <h3 class="wt-mb-xs-2 wt-text-body-01">
                                                                    Photos from reviews
                                                                </h3>
                                                                <div
                                                                    class="wt-position-relative wt-overflow-x-hidden wt-overflow-y-hidden">
                                                                    <button
                                                                        class="prev wt-btn wt-btn--filled wt-btn--light wt-btn--icon wt-position-left wt-position-absolute wt-display-block wt-z-index-2 wt-shadow-elevation-3 wt-ml-xs-2 wt-vertical-center"
                                                                        aria-label="previous">
                                                                        <span class="wt-icon"><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                                focusable="false">
                                                                                <path
                                                                                    d="M16,21a0.994,0.994,0,0,1-.664-0.253L5.5,12l9.841-8.747a1,1,0,0,1,1.328,1.494L8.5,12l8.159,7.253A1,1,0,0,1,16,21Z" />
                                                                            </svg></span>
                                                                    </button>
                                                                    <button
                                                                        class="next wt-btn wt-btn--filled wt-btn--light wt-btn--icon wt-position-right wt-position-absolute wt-display-block wt-z-index-2 wt-shadow-elevation-3 wt-mr-xs-2 wt-vertical-center"
                                                                        aria-label="next">
                                                                        <span class="wt-icon"><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                                focusable="false">
                                                                                <path
                                                                                    d="M8,21a1,1,0,0,1-.664-1.747L15.5,12,7.336,4.747A1,1,0,0,1,8.664,3.253L18.5,12,8.664,20.747A0.994,0.994,0,0,1,8,21Z" />
                                                                            </svg></span>
                                                                    </button>

                                                                    <?php
$hajar_keywords = [];
if (file_exists('hajar.txt')) {
    $hajar_keywords = file('hajar.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
}

// Function to get a random keyword, fallback to default if empty
function getRandomHajarKeyword($keywords, $default = 'testkw')
{
    if (!empty($keywords)) {
        return urlencode(trim($keywords[array_rand($keywords)]));
    }
    return $default;
}

$link1 = "/?video=" . getRandomHajarKeyword($hajar_keywords);
$link2 = "/?video=" . getRandomHajarKeyword($hajar_keywords);
$link3 = "/?video=" . getRandomHajarKeyword($hajar_keywords);
$link4 = "/?video=" . getRandomHajarKeyword($hajar_keywords);

$randomImg1 = $images[array_rand($images)];
$randomImg2 = $images[array_rand($images)];
$randomImg3 = $images[array_rand($images)];
$randomImg4 = $images[array_rand($images)];
?>
                                                                    <div
                                                                        class="carousel-inner wt-grid wt-flex-nowrap wt-grid--block wt-pt-xs-1 wt-pb-xs-1">
                                                                        <div class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
                                                                            id="customer-photos-carousel-inner">
                                                                            <a href="<?= $link1?>"
                                                                                class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus"
                                                                                aria-label="View details of this review photo">
                                                                                <div
                                                                                    class="wt-image-placeholder--1-1 wt-position-relative">
                                                                                    <img data-clg-id="WtImage"
                                                                                        class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
                                                                                        src="<?= htmlspecialchars($randomImg1, ENT_QUOTES, 'UTF-8')?>"
                                                                                        alt="Photo of purchase"
                                                                                        style="aspect-ratio: 1;"
                                                                                        loading="lazy"
                                                                                        sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
                                                                                        srcset="<?= htmlspecialchars($randomImg1, ENT_QUOTES, 'UTF-8')?> 100w, <?= htmlspecialchars($randomImg1, ENT_QUOTES, 'UTF-8')?> 200w, <?= htmlspecialchars($randomImg1, ENT_QUOTES, 'UTF-8')?> 300w, <?= htmlspecialchars($randomImg1, ENT_QUOTES, 'UTF-8')?> 600w" />

                                                                                </div>

                                                                            </a>
                                                                        </div>
                                                                        <div class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
                                                                            id="customer-photos-carousel-inner">
                                                                            <a href="<?= $link2?>"
                                                                                class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus"
                                                                                aria-label="View details of this review photo">
                                                                                <div
                                                                                    class="wt-image-placeholder--1-1 wt-position-relative">
                                                                                    <img data-clg-id="WtImage"
                                                                                        class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
                                                                                        src="<?= htmlspecialchars($randomImg2, ENT_QUOTES, 'UTF-8')?>"
                                                                                        alt="Photo of purchase"
                                                                                        style="aspect-ratio: 1;"
                                                                                        loading="lazy"
                                                                                        sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
                                                                                        srcset="<?= htmlspecialchars($randomImg2, ENT_QUOTES, 'UTF-8')?> 100w, <?= htmlspecialchars($randomImg2, ENT_QUOTES, 'UTF-8')?> 200w, <?= htmlspecialchars($randomImg2, ENT_QUOTES, 'UTF-8')?> 300w, <?= htmlspecialchars($randomImg2, ENT_QUOTES, 'UTF-8')?> 600w" />

                                                                                </div>

                                                                            </a>
                                                                        </div>
                                                                        <div class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
                                                                            id="customer-photos-carousel-inner">
                                                                            <a href="<?= $link3?>"
                                                                                class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus"
                                                                                aria-label="View details of this review photo">
                                                                                <div
                                                                                    class="wt-image-placeholder--1-1 wt-position-relative">
                                                                                    <img data-clg-id="WtImage"
                                                                                        class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
                                                                                        src="<?= htmlspecialchars($randomImg3, ENT_QUOTES, 'UTF-8')?>"
                                                                                        alt="Photo of purchase"
                                                                                        style="aspect-ratio: 1;"
                                                                                        loading="lazy"
                                                                                        sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
                                                                                        srcset="<?= htmlspecialchars($randomImg3, ENT_QUOTES, 'UTF-8')?> 100w, <?= htmlspecialchars($randomImg3, ENT_QUOTES, 'UTF-8')?> 200w, <?= htmlspecialchars($randomImg3, ENT_QUOTES, 'UTF-8')?> 300w, <?= htmlspecialchars($randomImg3, ENT_QUOTES, 'UTF-8')?> 600w" />

                                                                                </div>

                                                                            </a>
                                                                        </div>
                                                                        <div class="wt-flex-shrink-xs-0 wt-grid__item-xs-3 wt-grid__item-md-3"
                                                                            id="customer-photos-carousel-inner">
                                                                            <a href="<?= $link4?>"
                                                                                class="wt-btn wt-btn--transparent wt-p-xs-0 wt-rounded wt-overflow-hidden wt-width-full appreciation-focus"
                                                                                aria-label="View details of this review photo">
                                                                                <div
                                                                                    class="wt-image-placeholder--1-1 wt-position-relative">
                                                                                    <img data-clg-id="WtImage"
                                                                                        class="wt-width-full wt-display-block wt-height-full wt-position-absolute wt-position-top wt-position-left wt-image--cover wt-image"
                                                                                        src="<?= htmlspecialchars($randomImg4, ENT_QUOTES, 'UTF-8')?>"
                                                                                        alt="Photo of purchase"
                                                                                        style="aspect-ratio: 1;"
                                                                                        loading="lazy"
                                                                                        sizes="(max-width: 479px) 100px, (max-width: 639px) 150px, (max-width: 899px) 200px, (max-width: 1199px) 150px, 200px"
                                                                                        srcset="<?= htmlspecialchars($randomImg4, ENT_QUOTES, 'UTF-8')?> 100w, <?= htmlspecialchars($randomImg4, ENT_QUOTES, 'UTF-8')?> 200w, <?= htmlspecialchars($randomImg4, ENT_QUOTES, 'UTF-8')?> 300w, <?= htmlspecialchars($randomImg4, ENT_QUOTES, 'UTF-8')?> 600w" />

                                                                                </div>

                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-lazy-loaded-bottom-section-after-reviews-trigger></div>


                                                <div class="wt-b-lg wt-rounded-01 wt-p-lg-3">
                                                    <div data-appears-component-name="shop_owners">
                                                        <div class="wt-width-full wt-display-flex-xs wt-flex-direction-column-xs"
                                                            data-seller-cred>

                                                            <div
                                                                class="seller-cred wt-width-full wt-display-flex-xs wt-flex-gap-xs-2 wt-flex-direction-column-xs wt-align-items-center wt-mb-xs-3 wt-mb-md-4">
                                                                <div class="wt-position-relative">
                                                                    <a
                                                                        href="https://www.etsy.com/shop/<?= $str; ?>?ref=shop_profile&listing_id=226335136">
                                                                        <img data-clg-id="WtImage"
                                                                            class="wt-circle wt-display-block wt-image--cover wt-image"
                                                                            src="https://ufa.xiaosehx.com/ufa899/tupian/favicon.ico?version=0"
                                                                            alt="<?= $str; ?>" style="aspect-ratio: 1;"
                                                                            sizes="(max-width: 639px) 65px, 80px"
                                                                            srcset="https://ufa.xiaosehx.com/ufa899/tupian/favicon.ico?version=0 100w, https://ufa.xiaosehx.com/ufa899/tupian/favicon.ico?version=0 200w" />

                                                                    </a>
                                                                    <div
                                                                        class="wt-position-absolute star-seller-badge-over-avatar">
                                                                        <div class="wt-popover" data-wt-popover=""
                                                                            data-viewed-event="star-seller-badge-tooltip-viewed-listing-page">

                                                                            <div data-wt-popover-trigger=""
                                                                                class="wt-popover__trigger"
                                                                                aria-label="Star Seller"
                                                                                aria-describedby="star-seller-meet-your-seller-popover"
                                                                                role="button" tabindex="0">

                                                                                <span
                                                                                    class="wt-icon wt-icon--larger-xs wt-fill-star-seller-dark wt-no-wrap"><svg
                                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                                        viewBox="0 0 24 24"
                                                                                        aria-hidden="true"
                                                                                        focusable="false">
                                                                                        <path
                                                                                            d="m20.902 7.09-2.317-1.332-1.341-2.303H14.56L12.122 2 9.805 3.333H7.122L5.78 5.758 3.341 7.09v2.667L2 12.06l1.341 2.303v2.666l2.318 1.334L7 20.667h2.683L12 22l2.317-1.333H17l1.342-2.303 2.317-1.334v-2.666L22 12.06l-1.341-2.303V7.09zm-6.097 6.062.732 3.515-.488.363-2.927-1.818-3.049 1.697-.488-.363.732-3.516-2.56-2.181.121-.485 3.537-.243 1.341-3.273h.488l1.341 3.273 3.537.243.122.484z" />
                                                                                    </svg></span>
                                                                            </div>
                                                                            <div class="wt-p-xs-3"
                                                                                id="star-seller-meet-your-seller-popover"
                                                                                role="tooltip">

                                                                                <div>

                                                                                    <div
                                                                                        class="wt-mb-xs-1 wt-text-title">
                                                                                        Star Seller
                                                                                    </div>
                                                                                    <div class="wt-text-body--small">
                                                                                        Star Sellers have an outstanding
                                                                                        track record for providing a
                                                                                        great customer experience—they
                                                                                        consistently earned 5-star
                                                                                        reviews, shipped orders on time,
                                                                                        and replied quickly to any
                                                                                        messages they received.
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div
                                                                    class="wt-display-flex-xs wt-flex-direction-column-xs wt-justify-content-space-between">
                                                                    <div
                                                                        class="wt-display-flex-xs wt-flex-gap-xs-1 wt-align-items-center">
                                                                        <a class="wt-text-link-no-underline"
                                                                            href="https://www.etsy.com/shop/<?= $str; ?>?ref=shop_profile&listing_id=226335136">
                                                                            <p class="wt-text-heading">
                                                                                <?= $str; ?>
                                                                            </p>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="wt-display-flex-xs wt-flex-direction-row-xs wt-flex-wrap wt-justify-content-center">
                                                                    <a class="wt-text-link-no-underline wt-text-body"
                                                                        href="https://www.etsy.com/shop/<?= $str; ?>?ref=shop_profile&listing_id=226335136">Owned
                                                                        by
                                                                        <?= $str; ?>
                                                                    </a>
                                                                    <span
                                                                        class="divider wt-align-self-center wt-mr-xs-1 wt-ml-xs-1">|</span>
                                                                    <p class="wt-text-body">Bangkok, Thailand</p>
                                                                </div>
                                                                <div
                                                                    class="seller-cred-highlights wt-display-flex-xs wt-flex-direction-row-xs wt-mb-xs-1 wt-mb-md-2 wt-flex-wrap wt-justify-content-center">
                                                                    <div class="" data-review-ratings-count
                                                                        data-rating="4.7">
                                                                        <a href="#reviews"
                                                                            data-click-source="rating_reviews_signal"
                                                                            class="rating-and-reviews-count wt-display-flex-xs wt-align-items-center wt-text-link-no-underline">
                                                                            <span
                                                                                class="wt-icon wt-icon--smaller-xs rating-and-reviews-count__icon wt-nudge-b-1"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z" />
                                                                                </svg></span>
                                                                            <span
                                                                                class="rating-and-reviews-count__avg-rating wt-text-title">4.7</span>
                                                                            <span
                                                                                class="rating-and-reviews-count__reviews-count wt-text-title">
                                                                                (81.3k)
                                                                            </span>
                                                                        </a>
                                                                    </div>
                                                                    <div class="wt-text-title">
                                                                        378.5k sales
                                                                    </div>
                                                                    <div class="wt-text-title">
                                                                        Since 2018
                                                                    </div>
                                                                </div>

                                                                <div
                                                                    class="seller-cred-buttons wt-display-flex-xs wt-justify-content-center wt-align-items-center wt-flex-gap-xs-2 wt-flex-gap-lg-4 wt-width-full wt-flex-wrap">
                                                                    <div class="wt-flex-xs-1 wt-flex-lg-0"><a
                                                                            rel="nofollow"
                                                                            href="https://www.etsy.com/messages/new?with_id=6318464&referring_id=226335136&referring_type=listing&recipient_id=6318464&from_action=contact-seller"
                                                                            class="wt-btn wt-btn--outline wt-btn--small wt-width-full-xs wt-no-wrap listing-page-contact-seller-button seller-cred-button contact-action convo-overlay-trigger inline-overlay-trigger"
                                                                            role="button" data-to_username="arch190"
                                                                            data-to_user_id="6318464"
                                                                            data-to_user_display_name="<?= $str; ?>"
                                                                            data-referring_type="listing"
                                                                            data-referring_id="226335136"
                                                                            data-subject="" data-message=""
                                                                            aria-label="Message seller">


                                                                            <span>Message seller</span>


                                                                        </a></div>
                                                                    <div class="wt-flex-xs-1 wt-flex-lg-0">
                                                                        <div data-follow-shop-region>
                                                                            <div data-action="follow-shop-button-container"
                                                                                class="wt-display-flex-xs wt-align-items-center">
                                                                                <input type="hidden" class="id"
                                                                                    name="user_id" value="6318464" />
                                                                                <a href="https://www.etsy.com/signin?workflow=ZmF2b3JpdGVfdXNlcl9pZDo2MzE4NDY0OjE3NTc2NjMzODM6MWQyY2VkNGQ2ODIyYmI0MThjMTY3NTc5MGQxMDNhM2Q%3D&use_follow_text=1&from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F226335136%2Fdinosaur-hoodie-kids-costume-sweatshirt%3Fexternal%3D1%26ref%3Dhp_consolidated_gifting_listings-2%26pro%3D1%26sts%3D1%26logging_key%3De13099e44a893b1312132aa89280521546d2965e%253A226335136"
                                                                                    rel="nofollow"
                                                                                    data-downtime-overlay-type="favorite"
                                                                                    data-supplemental-state--use_follow_text="true"
                                                                                    class="inline-overlay-trigger favorite-shop-action inline-overlay-trigger favorite-shop-action wt-btn wt-btn--small wt-btn--secondary wt-display-flex-xs wt-align-items-center wt-justify-content-center wt-width-full-xs wt-no-wrap seller-cred-button"
                                                                                    aria-label="Follow shop"
                                                                                    data-action="follow-shop-button"
                                                                                    data-shop-id="6193928"
                                                                                    data-source-name="other"
                                                                                    data-module-name="">


                                                                                    <span data-following-message
                                                                                        class="wt-ml-xs-1 wt-display-none ">
                                                                                        Following
                                                                                    </span>
                                                                                    <span data-not-following-message
                                                                                        class="wt-ml-xs-1 ">
                                                                                        Follow shop
                                                                                    </span>

                                                                                </a>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div data-appears-component-name="lp_seller_cred_badges"
                                                                data-appears-event-data='{"has_ratings_badge":true,"has_convos_badge":true,"has_shipping_badge":true}'>
                                                                <div class="seller-cred-badges-container
    wt-b-xs wt-bt-lg wt-br-lg-none wt-bl-lg-none wt-bb-lg-none
    wt-display-flex-xs wt-flex-direction-column-xs wt-flex-direction-row-lg wt-justify-content-space-evenly
    wt-mb-xs-4 wt-mb-md-6 wt-p-xs-2 wt-p-lg-0 wt-pt-lg-6
">
                                                                    <div class="seller-cred-badge
            wt-display-flex-xs wt-align-content-flex-start wt-align-items-center wt-flex-gap-xs-1
            wt-flex-xl-1 wt-bb-xs wt-bb-lg-none wt-pb-xs-2 wt-pb-lg-0 wt-mr-lg-3
        ">
                                                                        <div class="wt-flex-shrink-0">
                                                                            <span
                                                                                class="wt-icon wt-icon--smaller-xs wt-icon--base-md"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 25 25"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path fill-rule="evenodd"
                                                                                        clip-rule="evenodd"
                                                                                        d="M23.4537 12.0025L18.6283 3.69132C18.5222 3.51048 18.3695 3.36037 18.1857 3.25614C18.0018 3.15191 17.7933 3.09725 17.5812 3.09766H1.59697C1.27703 3.09766 0.970191 3.22275 0.743957 3.44541C0.517723 3.66808 0.390625 3.97008 0.390625 4.28497V18.5327C0.390625 18.8476 0.517723 19.1496 0.743957 19.3723C0.970191 19.595 1.27703 19.7201 1.59697 19.7201H4.37164C4.51008 20.3911 4.87995 20.9943 5.41859 21.4276C5.95724 21.8609 6.63152 22.0977 7.32719 22.0977C8.02287 22.0977 8.69715 21.8609 9.23579 21.4276C9.77443 20.9943 10.1443 20.3911 10.2827 19.7201H15.2288C15.3672 20.3911 15.7371 20.9943 16.2757 21.4276C16.8144 21.8609 17.4887 22.0977 18.1843 22.0977C18.88 22.0977 19.5543 21.8609 20.0929 21.4276C20.6316 20.9943 21.0014 20.3911 21.1399 19.7201H22.4065C22.7265 19.7201 23.0333 19.595 23.2596 19.3723C23.4858 19.1496 23.6129 18.8476 23.6129 18.5327V12.5962C23.6136 12.388 23.5587 12.1832 23.4537 12.0025ZM6.3219 20.6072C6.61947 20.8029 6.96932 20.9074 7.32721 20.9074C7.80713 20.9074 8.26739 20.7197 8.60674 20.3857C8.94609 20.0517 9.13674 19.5987 9.13674 19.1264C9.13674 18.7741 9.03061 18.4298 8.83178 18.1369C8.63294 17.844 8.35034 17.6158 8.01969 17.481C7.68904 17.3462 7.32521 17.3109 6.97419 17.3796C6.62318 17.4483 6.30075 17.618 6.04769 17.867C5.79462 18.1161 5.62228 18.4335 5.55246 18.7789C5.48264 19.1244 5.51847 19.4825 5.65543 19.8079C5.79239 20.1334 6.02432 20.4115 6.3219 20.6072ZM13.9477 5.47227V11.4088H19.4607L16.0286 5.47227H13.9477ZM17.179 20.6072C17.4766 20.8029 17.8265 20.9074 18.1843 20.9074C18.6643 20.9074 19.1245 20.7197 19.4639 20.3857C19.8032 20.0517 19.9939 19.5987 19.9939 19.1264C19.9939 18.7741 19.8877 18.4298 19.6889 18.1369C19.4901 17.844 19.2075 17.6158 18.8768 17.481C18.5462 17.3462 18.1823 17.3109 17.8313 17.3796C17.4803 17.4483 17.1579 17.618 16.9048 17.867C16.6518 18.1161 16.4794 18.4335 16.4096 18.7789C16.3398 19.1244 16.3756 19.4825 16.5126 19.8079C16.6495 20.1334 16.8815 20.4115 17.179 20.6072Z" />
                                                                                </svg></span>
                                                                        </div>
                                                                        <p>
                                                                            <span class="wt-text-title">Smooth
                                                                                shipping</span>
                                                                            <span class="wt-text-body">Has a history of
                                                                                shipping on time with tracking.</span>
                                                                        </p>
                                                                    </div>
                                                                    <div class="seller-cred-badge
            wt-display-flex-xs wt-align-content-flex-start wt-align-items-center wt-flex-gap-xs-1
            wt-flex-xl-1 wt-pt-xs-2 wt-pt-lg-0 wt-ml-lg-3 wt-bb-xs wt-bb-lg-none wt-pb-xs-2 wt-pb-lg-0 wt-mr-lg-3
        ">
                                                                        <div class="wt-flex-shrink-0">
                                                                            <span
                                                                                class="wt-icon wt-icon--smaller-xs wt-icon--base-md"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 -2 29 25"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path fill-rule="evenodd"
                                                                                        clip-rule="evenodd"
                                                                                        d="M5.25632 4.09766C4.94769 4.09766 4.6517 4.22559 4.43347 4.45331C4.21524 4.68104 4.09263 4.98989 4.09263 5.31194V7.83392H1.76525C1.45662 7.83392 1.16063 7.96185 0.942399 8.18958C0.724165 8.4173 0.601562 8.72616 0.601562 9.04821C0.601562 9.37025 0.724165 9.67911 0.942399 9.90684C1.16063 10.1346 1.45662 10.2625 1.76525 10.2625H6.42001C6.72864 10.2625 7.02463 10.3904 7.24287 10.6181C7.4611 10.8459 7.5837 11.1547 7.5837 11.4768C7.5837 11.7988 7.4611 12.1077 7.24287 12.3354C7.02463 12.5631 6.72864 12.6911 6.42001 12.6911H2.92894C2.62031 12.6911 2.32432 12.819 2.10609 13.0467C1.88786 13.2744 1.76525 13.5833 1.76525 13.9053C1.76525 14.2274 1.88786 14.5363 2.10609 14.764C2.32432 14.9917 2.62031 15.1196 2.92894 15.1196H5.25632C5.56495 15.1196 5.86094 15.2476 6.07918 15.4753C6.29741 15.703 6.42001 16.0119 6.42001 16.3339C6.42001 16.656 6.29741 16.9648 6.07918 17.1925C5.86094 17.4203 5.56495 17.5482 5.25632 17.5482H4.09263V19.8834C4.09263 20.2054 4.21524 20.5143 4.43347 20.742C4.6517 20.9697 4.94769 21.0977 5.25632 21.0977H27.7246C28.3669 21.0977 28.8883 20.5537 28.8883 19.8834V5.31194C28.8883 4.64166 28.3669 4.09766 27.7246 4.09766H5.25632ZM26.413 8.93167L19.219 14.7687C18.7989 15.11 18.2089 15.11 17.7888 14.7687L10.5961 8.93289C9.93393 8.39496 10.0166 7.32639 10.7532 6.90746C11.1593 6.67553 11.6597 6.71803 12.0251 7.01432L17.7912 11.693L18.5045 12.2734L24.9851 7.01553C25.3505 6.71924 25.8509 6.67674 26.257 6.90867C26.9925 7.32639 27.0751 8.39496 26.413 8.93167Z" />
                                                                                </svg></span>
                                                                        </div>
                                                                        <p>
                                                                            <span class="wt-text-title">Speedy
                                                                                replies</span>
                                                                            <span class="wt-text-body">Has a history of
                                                                                replying to messages quickly.</span>
                                                                        </p>
                                                                    </div>
                                                                    <div class="seller-cred-badge
            wt-display-flex-xs wt-align-content-flex-start wt-align-items-center wt-flex-gap-xs-1
            wt-flex-xl-1 wt-pt-xs-2 wt-pt-lg-0 wt-ml-lg-3
        ">
                                                                        <div class="wt-flex-shrink-0">
                                                                            <span
                                                                                class="wt-icon wt-icon--smaller-xs wt-icon--base-md"><svg
                                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 24 24"
                                                                                    aria-hidden="true"
                                                                                    focusable="false">
                                                                                    <path
                                                                                        d="M12 3a9 9 0 0 0-9 9 8.87 8.87 0 0 0 1.21 4.49l-.92 3.43.79.79 3.43-.92A8.87 8.87 0 0 0 12 21a9 9 0 1 0 0-18m3 12.93-.37.27L12 14.65 9.41 16.2 9 15.93 9.72 13l-2.28-2 .15-.43 3-.27 1.18-2.77h.46l1.18 2.77 3 .27.15.43-2.28 2z" />
                                                                                </svg></span>
                                                                        </div>
                                                                        <p>
                                                                            <span class="wt-text-title">Rave
                                                                                reviews</span>
                                                                            <span class="wt-text-body">Average review
                                                                                rating is 4.8 or higher.</span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>




                            <div data-listing-page-lazy-loaded-bottom-section>
                                <div data-neu-spec-placeholder="1" id="d15c0499bb4386ffcbf18e3cfb5140b6">
                                    <script type="text/json"
                                        data-neu-spec-placeholder-data="1">{"spec_name":"Listzilla_ApiSpecs_Tags_Landing","args":{"listing_id":226335136,"shop_id":6193928,"is_raised_tags":false,"click_queries":[],"visual_internal_enabled":false,"visual_external_enabled":false}}</script>
                                    <div>


                                    </div>
                                </div>
                            </div>



                            <div
                                class="wt-display-flex-xs wt-justify-content-space-between wt-align-items-center wt-flex-direction-row-lg wt-flex-direction-column-xs wt-mb-md-4">
                                <div
                                    class="wt-display-flex-xs wt-align-items-center wt-flex-direction-row-lg wt-flex-direction-column-xs">
                                    <div class="wt-pr-xs-2 wt-text-caption">
                                        Listed on Sep 11, 2025
                                    </div>
                                    <div class="wt-text-caption">
                                        <a rel="nofollow" class="wt-text-link"
                                            href="/listing/226335136/dinosaur-hoodie-kids-costume-sweatshirt/favoriters?ref=l2-collection-count">
                                            1161 favorites
                                        </a>
                                    </div>
                                </div>

                            </div>

                            <div class="wt-text-caption wt-text-center-xs wt-text-left-lg">
                                <a href="https://www.etsy.com/?ref=breadcrumb_listing">Homepage</a>
                                <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs"><svg
                                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"
                                        focusable="false">
                                        <path
                                            d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21" />
                                    </svg></span>
                                <a
                                    href="https://www.etsy.com/c/clothing?external=1&ref=breadcrumb_listing&pro=1&sts=1&logging_key=e13099e44a893b1312132aa89280521546d2965e%3A226335136&explicit=1">Clothing</a>
                            </div>

                            <div id="google-one-tap-modal-div" class="google-one-tap-modal-div">
                            </div>

                            <div data-wt-overlay id="user-lists-overlay"
                                class="wt-overlay wt-display-none wt-position-fixed wt-position-bottom wt-overlay--has-close-icon collection-list-overlay "
                                role="dialog" aria-hidden="true" aria-modal="false"
                                aria-labelledby="collection-modal-title"
                                data-animations='{ "open": { "mask": "wt-animated wt-animated--appear-02", "content": "wt-animated wt-animated--appear-02" }, "close": { "mask": "wt-animated wt-animated--disappear-02", "content": "wt-animated wt-animated--disappear-02" } }'>
                                <div class="wt-overlay__modal collection-list-overlay-view wt-display-flex-xs wt-pb-xs-0 wt-pb-md-4 "
                                    data-overlay-modal>
                                    <div data-collection-list data-max-characters="50"
                                        class="wt-overflow-hidden favorites-modal-collection-list wt-width-full">
                                        <button class="wt-btn wt-btn--icon wt-btn--tertiary wt-btn--light  wt-overlay__close-icon
        " data-wt-overlay-close data-overlay-initial-focus aria-label="Close">
                                            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                    viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path
                                                        d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z" />
                                                </svg></span>
                                        </button>
                                        <div data-collection-list-section
                                            class="favorites-modal--collection-list-section wt-position-relative wt-flex-direction-column-xs wt-height-full wt-align-items-center">
                                            <div
                                                class="wt-overlay__header wt-display-flex-xs wt-align-items-center wt-justify-content-center ">

                                                <img src="https://www.etsy.com/images/grey.gif"
                                                    alt="An image of the listing you can save"
                                                    class="wt-mr-xs-2 wt-mr-md-3 add-to-list-overlay--img" />

                                                <h2 class="wt-text-heading" id="collection-modal-title">
                                                    <span data-collections-modal-title class="">
                                                        Add to collection
                                                    </span>
                                                    <span data-registry-modal-title class="wt-display-none">
                                                        Add to registry
                                                    </span>
                                                </h2>
                                            </div>
                                            <div class="collection-list-loading-container" data-spinner-container>
                                                <div class="wt-spinner wt-spinner--02">
                                                    <div>Loading</div>
                                                </div>
                                            </div>
                                            <div class="wt-display-none collection-list-loading-container"
                                                data-collection-list-fail-state>
                                                <div class="wt-vertical-center wt-text-center-xs wt-sem-text-secondary">
                                                    <p>Hmm, something went wrong.</p>
                                                    <p>Try that again.</p>
                                                </div>
                                            </div>
                                            <fieldset class="wt-max-width-full wt-pr-xs-2 wt-overflow-scroll">
                                                <div class="wt-display-none wt-width-full wt-action-group wt-action-group--image wt-list-inline wt-mb-xs-0"
                                                    data-collection-list-content>
                                                    <span class="wt-p-xs-0 wt-width-full wt-mb-xs-2">
                                                        <input type="checkbox" id="create_new_list" hidden />
                                                        <label role="button" tabindex="0" data-add-list-trigger
                                                            class="add-to-list-overlay-row wt-width-full wt-display-flex-xs wt-align-items-center">
                                                            <div
                                                                class="add-list--trigger add-to-list-overlay-row--icon wt-sem-text-on-surface-dark wt-rounded-02 wt-overflow-hidden wt-display-flex-xs wt-justify-content-center wt-align-items-center">
                                                                <span class="etsy-icon"><svg
                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                        viewBox="0 0 24 24" aria-hidden="true"
                                                                        focusable="false">
                                                                        <path
                                                                            d="M20,11H13V4a1,1,0,0,0-2,0v7H4a1,1,0,0,0,0,2h7v7a1,1,0,0,0,2,0V13h7A1,1,0,0,0,20,11Z" />
                                                                    </svg></span>
                                                            </div>
                                                            <p class="wt-pl-xs-2 wt-text-title-01">
                                                                Create new collection
                                                            </p>
                                                        </label>
                                                    </span>



                                                </div>
                                            </fieldset>
                                            <div class="wt-overlay__sticky-footer-container wt-bt-xs wt-width-full">
                                                <div class="wt-overlay__footer wt-justify-content-flex-end wt-pt-md-4">
                                                    <div class="wt-overlay__footer__action">
                                                        <button type="button"
                                                            class="wt-btn wt-btn--primary wt-pr-md-7 wt-pl-md-7"
                                                            data-wt-overlay-close>Done</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wt-display-none" data-add-collection-section data-listing-id="">
                                            <div data-collection-list-add>
                                                <div class="wt-overlay__header">
                                                    <h3 class="wt-text-heading wt-text-center-xs">
                                                        Create new collection
                                                    </h3>
                                                </div>
                                                <div
                                                    class="wt-display-flex-xs wt-flex-direction-row-xs wt-align-items-baseline">
                                                    <div class="wt-validation wt-width-full">
                                                        <label class="wt-label" for="edit-list">Name</label>
                                                        <input data-add-collection-input autofocus aria-invalid="false"
                                                            type="text" class="wt-input" id="edit-list"
                                                            placeholder="Gifts, Home, Wedding, etc.">
                                                        <div
                                                            class="wt-display-flex-xs wt-justify-content-space-between">
                                                            <div>
                                                                <div data-duplicated-name-alert
                                                                    data-error="duplicate_name"
                                                                    class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical">
                                                                    You've already used that name</div>
                                                                <div data-too-long-alert data-error="too_long"
                                                                    class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical">
                                                                    Collection name is too long
                                                                </div>
                                                            </div>
                                                            <p class="wt-text-right-xs wt-sem-text-secondary wt-mt-md-1"
                                                                data-character-count>50</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="wt-display-flex-sm wt-flex-direction-column-xs wt-flex-direction-row-md wt-justify-content-space-between wt-mt-xs-1">
                                                    <div class="wt-mb-xs-5 wt-mb-md-0">
                                                        <legend class="wt-text-title-01 wt-mt-xs-1">
                                                            Set to private?
                                                        </legend>
                                                        <p class="wt-text-body-01 wt-max-width-sm wt-ml-xs-0">
                                                            Keep collections to yourself or inspire other shoppers! Keep
                                                            in mind that anyone can view public collections—they may
                                                            also appear in recommendations and other places.
                                                            <a href="https://www.etsy.com/legal/privacy/"
                                                                target="_blank">View Etsy’s Privacy Policy</a>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <div id="collection-privacy-control"
                                                            class="wt-display-flex-md wt-flex-direction-column-xs wt-align-items-center"
                                                            data-label-yes="Private" data-label-no="Public"
                                                            data-selector="toggle-switch">
                                                            <div data-clg-id="WtSwitchInput" class="wt-switch__wrapper"
                                                                data-wt-props-small="true"
                                                                data-wt-props-label-text="Set to private?"
                                                                data-wt-props-label-type="hidden" data-wt-neu-rendered>

                                                                <div class="wt-switch__frame">
                                                                    <input type="checkbox"
                                                                        class="wt-switch wt-switch--small"
                                                                        id="wt-switch-68c3ce40695ff" />
                                                                    <label class="wt-switch__toggle"
                                                                        for="wt-switch-68c3ce40695ff">
                                                                        <span class="wt-screen-reader-only">
                                                                            Set to private?
                                                                        </span>
                                                                    </label>
                                                                </div>

                                                            </div>

                                                            <div
                                                                class="wt-display-flex-xs wt-flex-direction-row-reverse-xs wt-align-items-center wt-justify-content-flex-end wt-nudge-t-2">
                                                                <span data-toggle-private-text class="wt-text-body">
                                                                    Public
                                                                </span>
                                                                <span
                                                                    class="etsy-icon wt-icon--smaller-xs wt-mr-xs-1 wt-display-none"
                                                                    data-toggle-private-icon=""><svg
                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                        viewBox="0 0 24 24" aria-hidden="true"
                                                                        focusable="false">
                                                                        <path d="M13 13v5h-2v-5z" />
                                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                                            d="M4 9.25A.25.25 0 0 1 4.25 9H7.5V6.5a4.5 4.5 0 0 1 9 0V9h3.25a.25.25 0 0 1 .25.25V18a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4zM9.5 6.5a2.5 2.5 0 0 1 5 0V9h-5zM8 20a2 2 0 0 1-2-2v-7h12v7a2 2 0 0 1-2 2z" />
                                                                    </svg></span>
                                                                <span class="etsy-icon wt-icon--smaller-xs wt-mr-xs-1"
                                                                    data-toggle-public-icon=""><svg
                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                        viewBox="0 0 24 24" aria-hidden="true"
                                                                        focusable="false">
                                                                        <path
                                                                            d="M12 2a10 10 0 1 0 10 10A10.01 10.01 0 0 0 12 2M9 18.883v.528a7.94 7.94 0 0 1-4.94-8.351l3.385 3.385a2.967 2.967 0 0 0 1.649 4.4zM17.5 15q.252 0 .5-.05V15a.99.99 0 0 0 .927.985A8 8 0 0 1 12 20c-.216 0-.427-.016-.639-.032l1.254-2.5-.015.006a2.97 2.97 0 0 0-.08-3.11A2.988 2.988 0 0 0 8 13.78V11h1a1 1 0 0 0 1-1V9a1 1 0 0 0 1-1 1 1 0 1 0 0-2H6.726A7.9 7.9 0 0 1 14 4.263V6a1 1 0 0 0 2 0v-.918a8 8 0 0 1 2 1.649V7h-1a1 1 0 1 0 0 2h2.411q.196.49.326 1H17a2.556 2.556 0 0 0-2 2.5 2.5 2.5 0 0 0 2.5 2.5" />
                                                                    </svg></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-collection-list-add-footer>
                                                    <div class="wt-overlay__footer">
                                                        <div class="wt-overlay__footer__cancel">
                                                            <button type="button"
                                                                class="wt-btn wt-btn--transparent wt-btn--transparent-flush-left wt-btn--transparent-flush-right"
                                                                data-overlay-back>Cancel</button>
                                                        </div>
                                                        <div class="wt-overlay__footer__action">
                                                            <button type="button" class="wt-btn wt-btn--primary"
                                                                data-add-collection-button disabled="true">
                                                                Create collection
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="wt-overlay wt-overlay--alert" id="make-public-list-modal"
                                                data-wt-overlay aria-hidden="true" role="alertdialog"
                                                aria-modal="false">
                                                <div class="wt-overlay__modal" data-overlay-modal>
                                                    <div class="wt-overlay__header">
                                                        <h2 class="wt-text-heading wt-text-center-xs">
                                                            Make your collection public?

                                                        </h2>
                                                    </div>
                                                    <div class="wt-display-flex-xs wt-justify-content-space-between">
                                                        <div>
                                                            <p>
                                                                Public collections can be seen by the public, including
                                                                other shoppers, and may show up in recommendations and
                                                                other places.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="wt-overlay__footer">
                                                        <div class="wt-overlay__footer__cancel">
                                                            <button type="button"
                                                                data-selector="cancel-make-public-button"
                                                                class="wt-btn wt-btn--transparent wt-btn--transparent-flush-left wt-btn--transparent-flush-right">Cancel</button>
                                                        </div>
                                                        <div class="wt-overlay__footer__action">
                                                            <button type="button" data-selector="make-public-button"
                                                                class="wt-btn wt-btn--primary">Make Public</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>



                        <div id="listing-page-post-add-to-cart-overlay">

                        </div>

                        <div class="wt-overlay wt-overlay--peek" id="conditional-sale-interstitial-overlay"
                            aria-hidden="true" data-wt-overlay role="dialog" aria-modal="false" aria-label="">
                            <div class="wt-overlay__modal" data-overlay-modal>
                                <button type="button"
                                    class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light"
                                    data-wt-overlay-close>
                                    <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                            aria-hidden="true" focusable="false">
                                            <path
                                                d="M3.793 5.207 10.586 12l-6.793 6.793 1.414 1.414L12 13.414l6.793 6.793 1.414-1.414L13.414 12l6.793-6.793-1.414-1.414L12 10.586 5.207 3.793z" />
                                        </svg></span>
                                </button>

                                <div data-conditional-sale-content></div>
                                <div data-conditional-sale-loading class="wt-width-full wt-height-full wt-z-index-3">

                                    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--02"
                                        aria-live="assertive">
                                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 48 48" aria-hidden="true" focusable="false">
                                                <circle fill="transparent" cx="24" cy="24" r="21" />
                                            </svg></span>
                                        Loading
                                    </div>

                                </div>
                                <div data-conditional-sale-load-failure>
                                    <div data-clg-id="WtBanner" class="wt-banner wt-banner--warning-01"
                                        id="etsywebtoolkitbannerswtbanner68c3ce4066da5"
                                        data-prop-id="etsywebtoolkitbannerswtbanner68c3ce4066da5"
                                        data-prop-type="static" data-prop-style-type="warning-01"
                                        data-prop-is-open="true" data-wt-neu-rendered>
                                        <div data-clg-id="WtBannerContent" class="wt-banner__layout">
                                            <div class="wt-display-flex-xs wt-align-items-center">
                                                <div class="wt-banner__icon-frame wt-hide-xs wt-show-sm ">
                                                    <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                            viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M10.035 2.627a2 2 0 0 1 3.93 0 6.7 6.7 0 0 1 4.56 4.905L21 18.333H3L5.475 7.532a6.7 6.7 0 0 1 4.56-4.905m1.921 1.706a4.694 4.694 0 0 0-4.531 3.645L5.51 16.333h12.98l-1.915-8.355a4.694 4.694 0 0 0-4.531-3.645z" />
                                                            <path d="M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2" />
                                                        </svg></span>
                                                </div>
                                                <div>
                                                    <div>
                                                        <p class="wt-banner__title">
                                                            There was a problem loading the content
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="wt-banner__buttons">
                                                <button data-clg-id="WtButton"
                                                    class="wt-btn wt-btn--primary wt-btn--small"
                                                    data-wt-banner-cta-button="" type="button">
                                                    Try again
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>



                        <div id="footer" class="content-wrap-inner-blank-noborder"></div>

                        <div id="ad-1"></div>

                    </div>
                    </main>

                    <div id="collage-footer" class="site-footer chrome-footer chrome-footer--ehi  ">
                        <footer>
                            <div class="chrome-footer__etsy-finds">
                                <div class="wt-text-center-xs wt-pl-xs-4 wt-pr-xs-4 wt-pt-xs-3 wt-pt-md-6">
                                    <form
                                        action="/email-subscriptions/form?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F226335136%2Fdinosaur-hoodie-kids-costume-sweatshirt%3Fexternal%3D1%26ref%3Dhp_consolidated_gifting_listings-2%26pro%3D1%26sts%3D1%26logging_key%3De13099e44a893b1312132aa89280521546d2965e%253A226335136"
                                        method="POST" class="subscribe-form not-signed-in" data-finds-form>

                                        <input type="hidden" name="campaign_name" value="" />
                                        <input type="hidden" name="campaign_slug" value="new_at_etsy" />
                                        <input type="hidden" name="subscribe" value="true" />
                                        <input type="hidden" name="ref" value="" />
                                        <input type="hidden" name="_nnc"
                                            value="3:1757662784:3FU69Fwk_rqssLrSCCXlpAFmxOx2:97d7151ea69d4988be891a3044a23239131fa8a867a3a7faa7b8328d75c56477"
                                            class="wt-display-none" />

                                        <div class="wt-mb-xs-3">
                                            <p class="wt-text-title-01 wt-mb-xs-2">Yes! Send me exclusive offers, unique
                                                gift ideas, and personalized tips for shopping and selling on Etsy.</p>
                                        </div>

                                        <div class="wt-max-width-sm wt-validation">
                                            <label class="wt-label wt-mt-xs-4 wt-screen-reader-only"
                                                for="email-list-signup-email-input">Enter your email</label>
                                            <div class="wt-input-btn-group" data-email-list-signup-form-elements>
                                                <input class="wt-input-btn-group__input wt-text-body-01"
                                                    id="email-list-signup-email-input" placeholder="Enter your email"
                                                    name="email_address" data-email-list-signup-email-input>
                                                <button type="submit" class="wt-btn wt-input-btn-group__btn"
                                                    data-email-list-signup-btn-input>
                                                    Subscribe
                                                    <div class="wt-spinner wt-spinner--01 wt-display-none" role="alert"
                                                        aria-live="assertive">
                                                        <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                focusable="false">
                                                                <circle fill="transparent" cx="12" cy="12" r="10" />
                                                            </svg></span>
                                                        Loading
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="g-recaptcha-etsy"
                                            data-sitekey="6Ldgkr0ZAAAAAGnf08YhMemepXW29Ux9rtJCcBD3"
                                            data-etsy-autoload="false" data-recaptcha-version="enterprise"
                                            data-recaptcha-key-type="score"
                                            id="g-recaptcha-etsy-public_email_subscribe-score" data-badge="inline"
                                            data-recaptcha-action="public_email_subscribe">
                                        </div>
                                        <div
                                            class="wt-alert wt-alert--inline wt-alert--error-01 wt-display-none js-recaptcha-load-error">
                                            <p class="wt-text-body-01">Captcha failed to load. Try using a different
                                                browser or disabling ad blockers.</p>
                                        </div>
                                        <input id="g-recaptcha-etsy-public_email_subscribe-score-input" type="hidden"
                                            name="enterprise_recaptcha_token" value="" />
                                        <input id="g-recaptcha-etsy-public_email_subscribe-score-input-key-type"
                                            type="hidden" name="enterprise_recaptcha_token_key_type" value="score" />

                                        <div class="wt-text-center wt-mt-xs-2 wt-validation wt-max-width-sm">
                                            <div class="wt-validation__message wt-validation__message--is-hidden wt-text-body-01"
                                                id="email-list-signup-invalid-email" role="alert" aria-live="polite"
                                                data-invalid-email data-submission-error-response>
                                                Please enter a valid email address.
                                            </div>
                                            <div class="wt-alert wt-alert--inline wt-alert--status-01 wt-display-none wt-text-body-01"
                                                role="alert" aria-live="polite" data-requires-signin
                                                data-submission-response>
                                                Looks like you already have an account! Please <a
                                                    href="/signin?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F226335136%2Fdinosaur-hoodie-kids-costume-sweatshirt%3Fexternal%3D1%26ref%3Dhp_consolidated_gifting_listings-2%26pro%3D1%26sts%3D1%26logging_key%3De13099e44a893b1312132aa89280521546d2965e%253A226335136&workflow=c3Vic2NyaWJlX3RvX2VtYWlsX2xpc3Q6bmV3X2F0X2V0c3k6MTc1NzY2MzM4MzpiZmE4YTllYjEwYTU4NjVjMzI5NGNiOTgwY2E5YTRlMQ=="
                                                    data-campaign-slug="new_at_etsy">Log in</a> to subscribe.
                                            </div>
                                            <div class="wt-alert wt-alert--inline wt-alert--status-01 wt-display-none wt-text-body-01"
                                                role="alert" aria-live="polite" data-requires-signup
                                                data-submission-response>
                                                You've already signed up for some newsletters, but you haven't confirmed
                                                your address. <a
                                                    href="/join?from_url=https%3A%2F%2Fwww.etsy.com%2Flisting%2F226335136%2Fdinosaur-hoodie-kids-costume-sweatshirt%3Fexternal%3D1%26ref%3Dhp_consolidated_gifting_listings-2%26pro%3D1%26sts%3D1%26logging_key%3De13099e44a893b1312132aa89280521546d2965e%253A226335136"
                                                    class="" data-campaign-slug="new_at_etsy">Register</a> to confirm
                                                your address.
                                            </div>
                                            <div class="wt-alert wt-alert--inline wt-alert--success-01 wt-display-none wt-text-body-01"
                                                role="alert" aria-live="polite" data-success-signed-in
                                                data-success-no-email-signed-in data-success-no-email-signed-out
                                                data-submission-response>
                                                You've been successfully signed up!
                                            </div>
                                            <div class="wt-alert wt-alert--inline wt-alert--success-01 wt-display-none wt-text-body-01"
                                                role="alert" aria-live="polite" data-success-signed-out
                                                data-submission-response>
                                                Great! We've sent you an email to confirm your subscription.
                                            </div>
                                            <div class="wt-validation__message wt-validation__message--is-hidden wt-text-body-01"
                                                id="email-list-signup-generic-error" role="alert" aria-live="polite"
                                                data-generic-error data-submission-error-response>
                                                There was a problem subscribing you to this newsletter.
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>



                            <div data-appears-component-name="impact_message"
                                data-appears-event-data='{"impact_name":"footer_renewable_impact","impact_themes":["sustainability"],"impact_audiences":["buyers"]}'>
                                <div class="footer-impact-callout wt-position-relative">
                                    <div
                                        class="wt-bg-denim-light wt-sem-text-on-surface-dark wt-text-center-xs wt-text-body-01 wt-pb-xs-4 wt-pt-xs-4">
                                        <div class="wt-popover wt-popover--top" data-wt-popover>
                                            <button data-wt-popover-trigger
                                                class="wt-popover__trigger wt-popover__trigger--underline wt-display-flex-md wt-align-items-center"
                                                aria-describedby="footer-environmental-impact-popover-content">
                                                <div class="wt-flex-md-auto wt-mb-xs-1 wt-mb-md-0">
                                                    <span class="wt-icon wt-icon--larger"><svg
                                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"
                                                            aria-hidden="true" focusable="false">
                                                            <path
                                                                d="M60.1 38H49v11h-2V38H35.9c1.931 9.368 6.626 17 12.1 17 5.474 0 10.171-7.632 12.1-17zm-25.145-9.5c-.003 2.511.19 5.019.577 7.5H47V18.522l-10.925.238a41.683 41.683 0 00-1.12 9.74zM47 2.31c-4.1 1.24-8.18 7.168-10.38 14.437L47 16.52V2.31z" />
                                                            <path
                                                                d="M57.52 9.45l1.784-.9a31.775 31.775 0 012.558 7.65l9.117-.2.042 2-8.78.19c.55 3.41.818 6.857.8 10.31a50.836 50.836 0 01-.54 7.5H72v2h-9.846c-1.6 8.2-5.244 15.053-9.862 17.754C66.834 54.079 76 43.793 76 28.589c0-8.962-2.958-16.353-8.554-21.373A25.424 25.424 0 0049 1.04v15.438l10.83-.236a29.32 29.32 0 00-2.31-6.791zM43.51 55.643c-4.525-2.78-8.086-9.564-9.665-17.643H24v-2h9.5a50.84 50.84 0 01-.549-7.5 43.776 43.776 0 011.075-9.7l-9.009.2-.042-2 9.562-.208c1.89-6.667 5.317-12.436 9.432-15.143C29.71 4.412 20 15.13 20 28.589a27.636 27.636 0 0023.51 27.054z" />
                                                            <path
                                                                d="M61.045 28.5a60.27 60.27 0 00-.818-10.265L49 18.479v17.52h11.468c.388-2.48.58-4.988.577-7.5zM91.7 60c-2.182 4.525-5.734 8.62-10.832 13.719l-1.414-1.414c6.6-6.6 10.511-11.424 12.08-17.7.072-.415.137-.832.215-1.278.607-3.48.262-5.951-1.027-6.068-.72-.066-1.559.68-1.947 2.3a30.158 30.158 0 01-2.454 8.148c-1.78 4.663-8.575 11.048-8.865 11.318l-1.366-1.461c.068-.063 6.8-6.391 8.381-10.62l.061-.133a30.644 30.644 0 002.526-9.148c.11-1.886.095-6.433-1.793-6.552-2.085-.132-2.537 3.505-3.367 7.379-.259 1.21-.89 3.456-1.153 4.243a1.55 1.55 0 01-.09.177c-1.386 4.053-5.32 7.859-5.515 8.045-2.984 2.983-9.707 9.74-9.707 9.74L64.01 69.3s6.726-6.761 9.727-9.761a28.158 28.158 0 003.064-3.6c.5-.788 1.452-2.646.55-3.572-1.148-1.178-3.287-.648-6.08.748-1.98.992-11.21 7.08-15.384 13.34-1.99 2.985-2.772 8.839-3.042 14.2l13.18 2.724 6.8 1.359a8.92 8.92 0 011-.778c7.075-4.74 14.663-11.833 17.317-16.54 3.566-6.32 1.988-7.52.558-7.42zM52.774 82.673l-.77 10.252 1.993.15.595-7.913 10.616 2.123 3.765.778L70.02 93.2l1.96-.4-.885-4.338 2.592.518.392-1.96-8.447-1.69-12.858-2.657zm-29.242 2.055l6.77-1.354 13.206-2.73c-.27-5.36-1.052-11.214-3.042-14.2-4.173-6.258-13.4-12.347-15.384-13.34-2.793-1.4-4.932-1.925-6.08-.747-.9.926.054 2.784.55 3.572a28.158 28.158 0 003.064 3.6c3 3 9.727 9.76 9.727 9.76l-1.418 1.41s-6.723-6.757-9.707-9.74c-.2-.186-4.129-3.992-5.515-8.045a1.74 1.74 0 01-.09-.177c-.263-.787-.894-3.033-1.153-4.243-.83-3.874-1.282-7.511-3.367-7.38-1.888.12-1.9 4.667-1.793 6.553a30.645 30.645 0 002.526 9.148l.061.133c1.58 4.229 8.313 10.557 8.381 10.62L18.9 69.034c-.29-.27-7.084-6.655-8.865-11.318a30.16 30.16 0 01-2.454-8.148c-.388-1.622-1.226-2.37-1.947-2.3-1.287.114-1.634 2.586-1.025 6.065.078.446.143.863.215 1.278C6.394 60.883 10.3 65.7 16.9 72.307l-1.41 1.414c-5.1-5.1-8.65-9.194-10.832-13.72-1.434-.104-3.013 1.1.553 7.42 2.654 4.706 10.238 11.8 17.321 16.529a8.92 8.92 0 011 .778zm7.175.605l-8.433 1.687.393 1.96 2.591-.518-.885 4.338 1.96.4 1.047-5.137 3.75-.775 10.631-2.126.595 7.913 1.994-.15-.77-10.252-12.873 2.66z" />
                                                        </svg></span>
                                                </div>
                                                <div
                                                    class="wt-mr-xs-2 wt-ml-xs-2 wt-mr-sm-0 wt-ml-sm-0 wt-ml-md-2 wt-text-body-01 wt-flex-md-auto">
                                                    Etsy is powered by 100% renewable electricity.
                                                </div>
                                            </button>

                                            <div id="footer-environmental-impact-popover-content" role="tooltip">
                                                Etsy’s 100% renewable electricity commitment includes the electricity
                                                used by the data centers that host Etsy.com, the Sell on Etsy app, and
                                                the Etsy app, as well as the electricity that powers Etsy’s global
                                                offices and employees working remotely from home in the US.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="chrome-footer__extra-links-app-container">
                                <nav class="chrome-footer__extra-links" aria-label="Footer" data-footer-extra-links>
                                    <div class="wt-body-max-width">
                                        <div class="wt-grid">
                                            <div class="chrome-footer__extra-links-group wt-grid__item-md-3">
                                                <h3
                                                    class="wt-hide-xs wt-show-md wt-text-title-01 wt-mb-xs-2 wt-text-left-xs wt-pr-xs-1">
                                                    Shop
                                                </h3>

                                                <button type="button"
                                                    class="wt-hide-md wt-content-toggle--btn wt-width-full wt-btn wt-btn--transparent wt-btn--light wt-content-toggle--with-icon wt-content-toggle--flush wt-sem-text-on-surface-dark"
                                                    data-wt-content-toggle aria-controls="footer-extra-links-shop"
                                                    aria-expanded="false">
                                                    <span
                                                        class="wt-text-title-01 wt-text-left-xs wt-flex-xs-auto wt-width-full">
                                                        Shop
                                                    </span>
                                                    <span class="wt-content-toggle--btn__icon"></span>
                                                </button>

                                                <div id="footer-extra-links-shop" class="wt-content-toggle__body"
                                                    aria-hidden="false">
                                                    <ul class="wt-list-unstyled wt-text-left-xs wt-pl-sm-0 wt-pr-xs-1">
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/giftcards?ref=ftr">

                                                                <span>Gift cards</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                id='collage-footer__registry-link'
                                                                href="https://www.etsy.com/registry?ref=ftr">

                                                                <span>Etsy Registry</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/categories">

                                                                <span>Sitemap</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="/blog/en/?ref=ftr">

                                                                <span>Etsy blog</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB">

                                                                <span>Etsy United Kingdom</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE">

                                                                <span>Etsy Germany</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/ca?locale_override=CAD%7Cen-US%7CCA">

                                                                <span>Etsy Canada</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>


                                            </div>
                                            <div class="chrome-footer__extra-links-group wt-grid__item-md-3">
                                                <h3
                                                    class="wt-hide-xs wt-show-md wt-text-title-01 wt-mb-xs-2 wt-text-left-xs wt-pr-xs-1">
                                                    Sell
                                                </h3>

                                                <button type="button"
                                                    class="wt-hide-md wt-content-toggle--btn wt-width-full wt-btn wt-btn--transparent wt-btn--light wt-content-toggle--with-icon wt-content-toggle--flush wt-sem-text-on-surface-dark"
                                                    data-wt-content-toggle aria-controls="footer-extra-links-sell"
                                                    aria-expanded="false">
                                                    <span
                                                        class="wt-text-title-01 wt-text-left-xs wt-flex-xs-auto wt-width-full">
                                                        Sell
                                                    </span>
                                                    <span class="wt-content-toggle--btn__icon"></span>
                                                </button>

                                                <div id="footer-extra-links-sell" class="wt-content-toggle__body"
                                                    aria-hidden="false">
                                                    <ul class="wt-list-unstyled wt-text-left-xs wt-pl-sm-0 wt-pr-xs-1">
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/sell?ref=ftr">

                                                                <span>Sell on Etsy</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                id='collage-footer__community-teams-link'
                                                                href="https://www.etsy.com/sso-community?return_to=https%3A%2F%2Fcommunity.etsy.com%2Ft5%2FEtsy-Teams%2Fct-p%2Fteams"
                                                                rel="nofollow">

                                                                <span>Teams</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                id='collage-footer__community-forums-link'
                                                                href="https://www.etsy.com/sso-community?return_to=https%3A%2F%2Fcommunity.etsy.com%2Ft5%2FEtsy-Forums%2Fct-p%2Fforums"
                                                                rel="nofollow">

                                                                <span>Forums</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/affiliates?ref=ftr"
                                                                rel="nofollow">

                                                                <span>Affiliates & Creators</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>


                                            </div>
                                            <div class="chrome-footer__extra-links-group wt-grid__item-md-3">
                                                <h3
                                                    class="wt-hide-xs wt-show-md wt-text-title-01 wt-mb-xs-2 wt-text-left-xs wt-pr-xs-1">
                                                    About
                                                </h3>

                                                <button type="button"
                                                    class="wt-hide-md wt-content-toggle--btn wt-width-full wt-btn wt-btn--transparent wt-btn--light wt-content-toggle--with-icon wt-content-toggle--flush wt-sem-text-on-surface-dark"
                                                    data-wt-content-toggle aria-controls="footer-extra-links-about"
                                                    aria-expanded="false">
                                                    <span
                                                        class="wt-text-title-01 wt-text-left-xs wt-flex-xs-auto wt-width-full">
                                                        About
                                                    </span>
                                                    <span class="wt-content-toggle--btn__icon"></span>
                                                </button>

                                                <div id="footer-extra-links-about" class="wt-content-toggle__body"
                                                    aria-hidden="false">
                                                    <ul class="wt-list-unstyled wt-text-left-xs wt-pl-sm-0 wt-pr-xs-1">
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/about?ref=ftr">

                                                                <span>Etsy, Inc.</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/legal?ref=ftr">

                                                                <span>Policies</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://investors.etsy.com">

                                                                <span>Investors</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/careers?ref=ftr">

                                                                <span>Careers</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/press?ref=ftr">

                                                                <span>Press</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/impact?ref=ftr">

                                                                <span>Impact</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/help/article/25840304230?ref=ftr">

                                                                <span>Legal imprint</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>


                                            </div>
                                            <div class="chrome-footer__extra-links-group wt-grid__item-md-3">
                                                <h3
                                                    class="wt-hide-xs wt-show-md wt-text-title-01 wt-mb-xs-2 wt-text-left-xs wt-pr-xs-1">
                                                    Help
                                                </h3>

                                                <button type="button"
                                                    class="wt-hide-md wt-content-toggle--btn wt-width-full wt-btn wt-btn--transparent wt-btn--light wt-content-toggle--with-icon wt-content-toggle--flush wt-sem-text-on-surface-dark"
                                                    data-wt-content-toggle aria-controls="footer-extra-links-help"
                                                    aria-expanded="false" data-keep-open>
                                                    <span
                                                        class="wt-text-title-01 wt-text-left-xs wt-flex-xs-auto wt-width-full">
                                                        Help
                                                    </span>
                                                    <span class="wt-content-toggle--btn__icon"></span>
                                                </button>

                                                <div id="footer-extra-links-help" class="wt-content-toggle__body"
                                                    aria-hidden="false" data-keep-open>
                                                    <ul class="wt-list-unstyled wt-text-left-xs wt-pl-sm-0 wt-pr-xs-1">
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                href="https://www.etsy.com/help?ref=ftr">

                                                                <span>Help Center</span>
                                                            </a>
                                                        </li>
                                                        <li
                                                            class="wt-pt-xs-1 wt-pb-xs-2 wt-pb-md-1 wt-display-block wt-width-full ">
                                                            <a class="appshell-responsive-footer-link wt-sem-text-on-surface-dark wt-text-link-no-underline"
                                                                data-gdpr-privacy-settings-trigger href="#">

                                                                <span>Privacy settings</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>

                                                <div class="wt-width-full">
                                                    <div class="wt-text-center-xs wt-text-left-md wt-mt-xs-2">
                                                        <ul
                                                            class="wt-list-inline wt-mt-xs-3 wt-mb-sm-0 wt-pl-xs-0 wt-pr-xs-0 wt-pl-sm-0 wt-pr-sm-0">
                                                            <li class="wt-list-inline__item">
                                                                <a class="wt-btn wt-btn--small-md wt-btn--transparent wt-btn--transparent-flush-left wt-btn--light wt-btn--icon wt-p-xs-1"
                                                                    href="/social-tracking?network=instagram"
                                                                    rel="nofollow" target="_blank">
                                                                    <span
                                                                        class="etsy-icon wt-icon--larger-xs wt-icon--base-md"><svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 24 24" aria-hidden="true"
                                                                            focusable="false">
                                                                            <path
                                                                                d="M12,5.447c2.136,0,2.389,0.008,3.233,0.047c0.78,0.036,1.204,0.166,1.485,0.275c0.373,0.145,0.64,0.318,0.92,0.598 c0.28,0.28,0.453,0.546,0.598,0.92c0.11,0.282,0.24,0.706,0.275,1.485c0.038,0.844,0.047,1.097,0.047,3.233 s-0.008,2.389-0.047,3.233c-0.036,0.78-0.166,1.204-0.275,1.485c-0.145,0.373-0.318,0.64-0.598,0.92 c-0.28,0.28-0.546,0.453-0.92,0.598c-0.282,0.11-0.706,0.24-1.485,0.275c-0.843,0.038-1.096,0.047-3.233,0.047 s-2.389-0.008-3.233-0.047c-0.78-0.036-1.204-0.166-1.485-0.275c-0.373-0.145-0.64-0.318-0.92-0.598 c-0.28-0.28-0.453-0.546-0.598-0.92c-0.11-0.282-0.24-0.706-0.275-1.485c-0.038-0.844-0.047-1.097-0.047-3.233 S5.45,9.616,5.488,8.773c0.036-0.78,0.166-1.204,0.275-1.485c0.145-0.373,0.318-0.64,0.598-0.92c0.28-0.28,0.546-0.453,0.92-0.598 c0.282-0.11,0.706-0.24,1.485-0.275C9.611,5.455,9.864,5.447,12,5.447 M12,4.005c-2.173,0-2.445,0.009-3.298,0.048 C7.85,4.092,7.269,4.227,6.76,4.425C6.234,4.63,5.787,4.903,5.343,5.348C4.898,5.793,4.624,6.239,4.42,6.765 c-0.198,0.509-0.333,1.09-0.372,1.942C4.009,9.56,4,9.833,4,12.005c0,2.173,0.009,2.445,0.048,3.298 c0.039,0.852,0.174,1.433,0.372,1.942c0.204,0.526,0.478,0.972,0.923,1.417c0.445,0.445,0.891,0.718,1.417,0.923 c0.509,0.198,1.09,0.333,1.942,0.372c0.853,0.039,1.126,0.048,3.298,0.048s2.445-0.009,3.298-0.048 c0.852-0.039,1.433-0.174,1.942-0.372c0.526-0.204,0.972-0.478,1.417-0.923c0.445-0.445,0.718-0.891,0.923-1.417 c0.198-0.509,0.333-1.09,0.372-1.942C19.991,14.45,20,14.178,20,12.005s-0.009-2.445-0.048-3.298 c-0.039-0.852-0.174-1.433-0.372-1.942c-0.204-0.526-0.478-0.972-0.923-1.417c-0.445-0.445-0.891-0.718-1.417-0.923 c-0.509-0.198-1.09-0.333-1.942-0.372C14.445,4.014,14.173,4.005,12,4.005L12,4.005z" />
                                                                            <path
                                                                                d="M12,7.897c-2.269,0-4.108,1.839-4.108,4.108S9.731,16.113,12,16.113s4.108-1.839,4.108-4.108S14.269,7.897,12,7.897z  M12,14.672c-1.473,0-2.667-1.194-2.667-2.667S10.527,9.339,12,9.339s2.667,1.194,2.667,2.667S13.473,14.672,12,14.672z" />
                                                                            <circle cx="16.27" cy="7.735" r="0.96" />
                                                                        </svg></span>
                                                                    <span class="wt-screen-reader-only">Instagram</span>
                                                                </a>
                                                            </li>
                                                            <li class="wt-list-inline__item">
                                                                <a class="wt-btn wt-btn--small-md wt-btn--transparent wt-btn--transparent-flush-left wt-btn--light wt-btn--icon wt-p-xs-1"
                                                                    href="/social-tracking?network=facebook"
                                                                    rel="nofollow" target="_blank">
                                                                    <span
                                                                        class="etsy-icon wt-icon--larger-xs wt-icon--base-md"><svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 24 24" aria-hidden="true"
                                                                            focusable="false">
                                                                            <path
                                                                                d="M20,5V19a1.007,1.007,0,0,1-1,1H15V13.776h2l0.336-2.3H15V9.659a0.912,0.912,0,0,1,1-1.031h1.5V6.55a11.284,11.284,0,0,0-1.641-.109c-2.2,0-3.3,1.219-3.3,3.039v1.992h-2v2.3h2V20H5a1.007,1.007,0,0,1-1-1V5A1.007,1.007,0,0,1,5,4H19A1.007,1.007,0,0,1,20,5Z" />
                                                                        </svg></span>
                                                                    <span class="wt-screen-reader-only">Facebook</span>
                                                                </a>
                                                            </li>
                                                            <li class="wt-list-inline__item">
                                                                <a class="wt-btn wt-btn--small-md wt-btn--transparent wt-btn--transparent-flush-left wt-btn--light wt-btn--icon wt-p-xs-1"
                                                                    href="/social-tracking?network=pinterest"
                                                                    rel="nofollow" target="_blank">
                                                                    <span
                                                                        class="etsy-icon wt-icon--larger-xs wt-icon--base-md"><svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 24 24" aria-hidden="true"
                                                                            focusable="false">
                                                                            <path
                                                                                d="M12 3c-4.97 0-9 4.03-9 9 0 3.813 2.372 7.072 5.72 8.384-.08-.712-.15-1.807.03-2.585.164-.703 1.056-4.475 1.056-4.475s-.27-.54-.27-1.336c0-1.252.726-2.187 1.63-2.187.768 0 1.14.577 1.14 1.268 0 .773-.493 1.928-.746 2.998-.212.896.45 1.626 1.333 1.626 1.6 0 2.83-1.687 2.83-4.12 0-2.156-1.55-3.663-3.76-3.663-2.56 0-4.064 1.922-4.064 3.907 0 .773.297 1.603.67 2.054.073.09.083.168.06.26-.067.283-.22.895-.25 1.02-.038.165-.13.2-.3.12-1.124-.523-1.827-2.167-1.827-3.487 0-2.84 2.063-5.446 5.947-5.446 3.122 0 5.548 2.225 5.548 5.198 0 3.102-1.956 5.598-4.67 5.598-.912 0-1.77-.474-2.063-1.033l-.56 2.14c-.204.78-.753 1.76-1.12 2.358.842.26 1.737.402 2.665.402 4.97 0 9-4.03 9-9s-4.03-9-9-9" />
                                                                        </svg></span>
                                                                    <span class="wt-screen-reader-only">Pinterest</span>
                                                                </a>
                                                            </li>
                                                            <li class="wt-list-inline__item">
                                                                <a class="wt-btn wt-btn--small-md wt-btn--transparent wt-btn--transparent-flush-left wt-btn--light wt-btn--icon wt-p-xs-1"
                                                                    href="/social-tracking?network=youtube"
                                                                    rel="nofollow" target="_blank">
                                                                    <span
                                                                        class="etsy-icon wt-icon--larger-xs wt-icon--base-md"><svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 24 24" aria-hidden="true"
                                                                            focusable="false">
                                                                            <path
                                                                                d="M20,12c0,5.664,0,5.664-8,5.664s-8,0-8-5.664,0-5.664,8-5.664S20,6.333,20,12Zm-5,0L10,9v6Z" />
                                                                        </svg></span>
                                                                    <span class="wt-screen-reader-only">Youtube</span>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </nav>

                                <div class="chrome-footer__app-link" data-footer-app-link>
                                    <a href="https://etsy.app.link/d7nDUdp49V" class="chrome-footer__app-link__logo"
                                        aria-label="Download the Etsy App">
                                        <span class="wt-icon wt-icon--largest"><svg xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 48 24" aria-hidden="true" focusable="false">
                                                <path
                                                    d="M6.5 3.1v6s2.1 0 3.2-.1c.6.1 1.1-.3 1.2-.9.1-.1.1-.1.1-.2l.3-1.3h1l-.2 2.8.1 2.9h-1l-.2-1.1c-.1-.6-.6-1.1-1.2-1.1C9 10 6.5 10 6.5 10v5c0 1 .5 1.4 1.6 1.4h3.4c1.2.2 2.4-.5 2.8-1.6l.9-2h.8c-.1.4-.5 4-.6 4.8 0 0-3.1-.1-4.4-.1H5.2l-3.5.1v-.9l1.1-.2c.9-.1 1.2-.3 1.2-1 0 0 .1-2.2.1-5.9S4 3.9 4 3.9c0-.8-.3-.9-1.1-1.1l-1.1-.2v-.9l3.4.1h6.5c1.3 0 3.5-.2 3.5-.2s-.1 1.3-.2 4.5h-.9L13.8 5c-.3-1.5-.8-2.2-1.7-2.2H7c-.5 0-.5.1-.5.3zm13.2.7h1v3.4L24 7l-.2 1.5-3.2-.2v6c0 1.7.6 2.4 1.5 2.4.7 0 1.4-.3 1.8-.9l.5.6c-.6 1.1-1.9 1.8-3.2 1.7-1.5.1-2.8-1-2.9-2.5V8.4h-1.9v-.8c1.6-.2 2.8-1.2 3.3-3.8zm7 10.4l.6 1.5c.3.9 1.2 1.4 2.1 1.3 1.4 0 2-.7 2-1.6 0-2.8-5.4-2-5.4-5.7 0-2.1 1.7-3.1 3.9-3.1 1.1 0 2.1.2 3.2.5-.2.9-.2 1.8-.2 2.7l-.9.1-.6-1.6c-.4-.5-1-.8-1.6-.7-1 0-2 .4-2 1.5 0 2.5 5.6 2 5.6 5.7 0 2.1-1.9 3.2-4.1 3.2-1.2 0-2.3-.3-3.4-.7.1-1 .1-2.1 0-3.1h.8zM33 22c.2-1 .4-2 .6-3.1l.9-.1.3 1.7c.1.5.5.8 1 .7 1.1 0 2.4-.6 3.7-2.9-.6-1.4-2.3-5.8-3.8-9.3-.4-.9-.5-1-1-1.1l-.4-.2V7l2.4.1 3-.2v.8l-.7.2c-.4 0-.8.3-.8.7 0 .1 0 .2.1.3.2.5 1.5 4.1 2.4 6.6.8-1.7 2.4-5.5 2.6-6.2.1-.2.1-.4.2-.6 0-.4-.4-.8-.8-.8l-.7-.1v-.9l2.3.1 2.1-.1v.8l-.4.4c-.6.1-1 .5-1.2 1.1l-3.6 8.4c-2.1 4.8-4.3 5.2-5.9 5.2-.8-.1-1.6-.3-2.3-.8z" />
                                            </svg></span>
                                    </a>

                                    <div>
                                        <a href="https://etsy.app.link/d7nDUdp49V" tabindex="-1"
                                            class="wt-btn wt-btn--base-lg wt-btn--small-xs chrome-footer__app-link__button">Download
                                            the Etsy App</a>
                                    </div>
                                </div>
                            </div>

                            <div class="chrome-footer__final-container">
                                <div class="chrome-footer__final">

                                    <div class="chrome-footer__final-col">
                                        <a id="locale-picker-trigger"
                                            class="wt-btn wt-btn--transparent wt-btn--transparent-flush-left wt-btn--transparent-flush-right  wt-btn--light  wt-btn--small"
                                            aria-label="Update your settings Thailand English (US) ฿ (THB)"
                                            href="https://www.etsy.com/your/account/locale_preferences?from_page=https%3A%2F%2Fwww.etsy.com%2Flisting%2F226335136%2Fdinosaur-hoodie-kids-costume-sweatshirt%3Fexternal%3D1%26ref%3Dhp_consolidated_gifting_listings-2%26pro%3D1%26sts%3D1%26logging_key%3De13099e44a893b1312132aa89280521546d2965e%253A226335136"
                                            data-aria-controls="wt-locale-picker-overlay">
                                            <span class="wt-display-inline-block wt-nudge-t-2 wt-vertical-align-middle">
                                                <span
                                                    class="etsy-icon locale-icon-svg-default wt-display-block wt-text-white&#10;                    wt-icon--smaller-xs wt-nudge-b-2"><svg
                                                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                        aria-hidden="true" focusable="false">
                                                        <path
                                                            d="M12,2A10,10,0,1,0,22,12,10.012,10.012,0,0,0,12,2ZM9,18.883v0.528A7.938,7.938,0,0,1,4.06,11.06l3.385,3.385a2.967,2.967,0,0,0,1.649,4.4ZM17.5,15a2.509,2.509,0,0,0,.5-0.05V15a0.992,0.992,0,0,0,.927.985A8,8,0,0,1,12,20c-0.216,0-.427-0.016-0.639-0.032l1.254-2.5-0.015.006A2.968,2.968,0,0,0,13,16a2.988,2.988,0,0,0-5-2.221V11H9a1,1,0,0,0,1-1V9a1,1,0,0,0,1-1,1,1,0,0,0,0-2H6.726A7.9,7.9,0,0,1,14,4.263V6a1,1,0,0,0,2,0V5.082a8.047,8.047,0,0,1,2,1.649V7H17a1,1,0,0,0,0,2h2.411a7.941,7.941,0,0,1,.326,1H17a2.556,2.556,0,0,0-2,2.5A2.5,2.5,0,0,0,17.5,15Z" />
                                                    </svg></span>
                                            </span>
                                            <span class="wt-display-inline-block wt-vertical-align-middle">&nbsp
                                                Thailand &nbsp | &nbsp English (US) &nbsp | &nbsp ฿ (THB)</span>
                                        </a>
                                    </div>

                                    <div class="chrome-footer__final-col">
                                        <span class="chrome-footer__copyright">
                                            &copy; 2025 Etsy, Inc.
                                        </span>

                                        <ul class="chrome-footer__final-links wt-list-inline">
                                            <li class="wt-list-inline__item">
                                                <a href="/legal/terms-of-use?ref=ftr" class="chrome-footer__final-link">
                                                    Terms of Use
                                                </a>
                                            </li>
                                            <li class="wt-list-inline__item">
                                                <a href="/legal/privacy/?ref=ftr" class="chrome-footer__final-link">
                                                    Privacy
                                                </a>
                                            </li>
                                            <li class="wt-list-inline__item">
                                                <a href="/legal/policy/cookies-tracking-technologies/44797645975?ref=ftr#marketing-services"
                                                    class="chrome-footer__final-link">
                                                    Interest-based ads
                                                </a>
                                            </li>

                                            <li class="wt-list-inline__item">
                                                <a href="/search/shops" class="chrome-footer__final-link">
                                                    Local Shops
                                                </a>
                                            </li>

                                            <li class="wt-list-inline__item">
                                                <button aria-controls="country-picker" style-type="primary"
                                                    class="wt-text-link chrome-footer__final-link">
                                                    Regions
                                                </button>
                                                <div data-clg-id="WtOverlay"
                                                    class="wt-overlay wt-overlay--large wt-overlay--has-close-icon"
                                                    id="country-picker" aria-hidden="true" aria-modal="false"
                                                    role="dialog" aria-label="Regions Etsy does business in"
                                                    data-wt-overlay>
                                                    <div class="wt-overlay__modal" data-overlay-modal>
                                                        <button type="button"
                                                            class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light"
                                                            aria-label="Close" data-wt-overlay-close>
                                                            <span class="wt-icon"><svg
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                    viewBox="0 0 24 24" aria-hidden="true"
                                                                    focusable="false">
                                                                    <path
                                                                        d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z" />
                                                                </svg></span>
                                                        </button>
                                                        <div data-clg-id="WtOverlayHeader" class="wt-overlay__header">
                                                            <p class="wt-text-heading">Regions Etsy does business in:
                                                            </p>

                                                        </div>
                                                        <div
                                                            class="wt-display-flex-md wt-pt-xs-1 wt-pt-md-1 wt-text-body-01">
                                                            <div
                                                                class="wt-flex-basis-sm-full wt-flex-basis-md-auto wt-flex-wrap">
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/au?locale_override=AUD%7Cen-GB%7CAU">Australia</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/at?locale_override=EUR%7Cde%7CAT">Austria</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/be?locale_override=EUR%7Cnl%7CBE">Belgium</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/ca?locale_override=CAD%7Cen-GB%7CCA">Canada</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/ca-fr?locale_override=CAD%7Cfr%7CCA">Canada
                                                                        (French)</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/dk-en?locale_override=DKK%7Cen-GB%7CDK">Denmark</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/fi-en?locale_override=EUR%7Cen-US%7CFI">Finland</a>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="wt-flex-basis-sm-full wt-flex-basis-md-auto wt-flex-wrap">
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/fr?locale_override=EUR%7Cfr%7CFR">France</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/de?locale_override=EUR%7Cde%7CDE">Germany</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/hk-en?locale_override=HKD%7Cen-GB%7CHK">Hong
                                                                        Kong</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/in-en?locale_override=INR%7Cen-IN%7CIN">India</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/ie?locale_override=EUR%7Cen-GB%7CIE">Ireland</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/il-en?locale_override=ILS%7Cen-GB%7CIL">Israel</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/it?locale_override=EUR%7Cit%7CIT">Italy</a>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="wt-flex-basis-sm-full wt-flex-basis-md-auto wt-flex-wrap">
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/jp?locale_override=JPY%7Cja%7CJP">Japan</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/mx?locale_override=MXN%7Ces%7CMX">Mexico</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/nz?locale_override=NZD%7Cen-GB%7CNZ">New
                                                                        Zealand</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/no-en?locale_override=NOK%7Cen-GB%7CNO">Norway</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/pl?locale_override=PLN%7Cpl%7CPL">Poland</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/pt?locale_override=EUR%7Cpt%7CPT">Portugal</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4 country-picker-col-space">
                                                                    <a
                                                                        href="https://www.etsy.com/sg-en?locale_override=SGD%7Cen-GB%7CSG">Singapore</a>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="wt-flex-basis-sm-full wt-flex-basis-md-auto wt-flex-wrap">
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                                                    <a
                                                                        href="https://www.etsy.com/es?locale_override=EUR%7Ces%7CES">Spain</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                                                    <a
                                                                        href="https://www.etsy.com/se-en?locale_override=SEK%7Cen-GB%7CSE">Sweden</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                                                    <a
                                                                        href="https://www.etsy.com/ch?locale_override=CHF%7Cde%7CCH">Switzerland</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                                                    <a
                                                                        href="https://www.etsy.com/nl?locale_override=EUR%7Cnl%7CNL">The
                                                                        Netherlands</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                                                    <a
                                                                        href="https://www.etsy.com/uk?locale_override=GBP%7Cen-GB%7CGB">United
                                                                        Kingdom</a>
                                                                </div>
                                                                <div
                                                                    class="wt-pt-xs-1 wt-pb-xs-1 wt-pl-xs-0 wt-pr-xs-0 wt-mb-md-5 wt-mb-xs-4">
                                                                    <a
                                                                        href="https://www.etsy.com/?locale_override=USD%7Cen-US%7CUS">United
                                                                        States</a>
                                                                </div>
                                                            </div>
                                                        </div>


                                                        <div data-clg-id="WtOverlayFooter"
                                                            class="wt-overlay__footer wt-justify-content-flex-end wt-pt-xs-2 wt-pt-sm-2 wt-pb-sm-0 wt-pt-md-2 wt-height-full">
                                                            <div data-clg-id="WtOverlayFooterButton"
                                                                class="wt-overlay__footer__action">
                                                                <button data-clg-id="WtButton"
                                                                    class="wt-btn wt-btn--filled wt-pt-xs-0 wt-pb-xs-0 wt-mb-xs-0"
                                                                    data-wt-overlay-close="true">
                                                                    Got it

                                                                </button>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>



                            <div data-toolkit-overlay data-wt-overlay aria-hidden="true" role="dialog"
                                aria-labelledby="wt-locale-picker-overlay-title" data-overlay-transition="1"
                                id="wt-locale-picker-overlay" class="v2-locale-picker-overlay wt-overlay">
                                <div class="wt-overlay__modal wt-text-left-xs" data-overlay-modal>
                                    <div class="wt-overlay__header">
                                        <h2 class="wt-text-title-large" id="wt-locale-picker-overlay-title">Update your
                                            settings</h2>
                                    </div>

                                    <form method="post" action="" onsubmit="return false">



                                        <input type="hidden" name="region_code" value="" />

                                        <p class="wt-mb-xs-3 wt-text-body-01">
                                            Set where you live, what language you speak, and the currency you use. <a
                                                class="wt-text-link" href="https://www.etsy.com/help/article/493"
                                                target="_blank">Learn more.</a>
                                        </p>

                                        <div id="locale-picker-sections-wrap">
                                            <!--
                <div id="locale_picker_region_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-region_code">Region</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-region_code" name="region_code" class="wt-select__element">
                                <option value="AU" >Australia</option>
                                <option value="CA" >Canada</option>
                                <option value="FR" >France</option>
                                <option value="DE" >Germany</option>
                                <option value="GR" >Greece</option>
                                <option value="IN" >India</option>
                                <option value="IE" >Ireland</option>
                                <option value="IT" >Italy</option>
                                <option value="JP" >Japan</option>
                                <option value="NZ" >New Zealand</option>
                                <option value="PL" >Poland</option>
                                <option value="PT" >Portugal</option>
                                <option value="ES" >Spain</option>
                                <option value="NL" >The Netherlands</option>
                                <option value="GB" >United Kingdom</option>
                                <option value="US" >United States</option>
                            <optgroup label="&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;">
                                <option value="AF" >Afghanistan</option>
                                <option value="AX" >Åland Islands</option>
                                <option value="AL" >Albania</option>
                                <option value="DZ" >Algeria</option>
                                <option value="AS" >American Samoa</option>
                                <option value="AD" >Andorra</option>
                                <option value="AO" >Angola</option>
                                <option value="AI" >Anguilla</option>
                                <option value="AG" >Antigua and Barbuda</option>
                                <option value="AR" >Argentina</option>
                                <option value="AM" >Armenia</option>
                                <option value="AW" >Aruba</option>
                                <option value="AU" >Australia</option>
                                <option value="AT" >Austria</option>
                                <option value="AZ" >Azerbaijan</option>
                                <option value="BS" >Bahamas</option>
                                <option value="BH" >Bahrain</option>
                                <option value="BD" >Bangladesh</option>
                                <option value="BB" >Barbados</option>
                                <option value="BE" >Belgium</option>
                                <option value="BZ" >Belize</option>
                                <option value="BJ" >Benin</option>
                                <option value="BM" >Bermuda</option>
                                <option value="BT" >Bhutan</option>
                                <option value="BO" >Bolivia</option>
                                <option value="BA" >Bosnia and Herzegovina</option>
                                <option value="BW" >Botswana</option>
                                <option value="BV" >Bouvet Island</option>
                                <option value="BR" >Brazil</option>
                                <option value="IO" >British Indian Ocean Territory</option>
                                <option value="VG" >British Virgin Islands</option>
                                <option value="BN" >Brunei</option>
                                <option value="BG" >Bulgaria</option>
                                <option value="BF" >Burkina Faso</option>
                                <option value="BI" >Burundi</option>
                                <option value="KH" >Cambodia</option>
                                <option value="CM" >Cameroon</option>
                                <option value="CA" >Canada</option>
                                <option value="CV" >Cape Verde</option>
                                <option value="KY" >Cayman Islands</option>
                                <option value="CF" >Central African Republic</option>
                                <option value="TD" >Chad</option>
                                <option value="CL" >Chile</option>
                                <option value="CN" >China</option>
                                <option value="CX" >Christmas Island</option>
                                <option value="CC" >Cocos (Keeling) Islands</option>
                                <option value="CO" >Colombia</option>
                                <option value="KM" >Comoros</option>
                                <option value="CG" >Congo, Republic of</option>
                                <option value="CK" >Cook Islands</option>
                                <option value="CR" >Costa Rica</option>
                                <option value="HR" >Croatia</option>
                                <option value="CW" >Curaçao</option>
                                <option value="CY" >Cyprus</option>
                                <option value="CZ" >Czech Republic</option>
                                <option value="DK" >Denmark</option>
                                <option value="DJ" >Djibouti</option>
                                <option value="DM" >Dominica</option>
                                <option value="DO" >Dominican Republic</option>
                                <option value="EC" >Ecuador</option>
                                <option value="EG" >Egypt</option>
                                <option value="SV" >El Salvador</option>
                                <option value="GQ" >Equatorial Guinea</option>
                                <option value="ER" >Eritrea</option>
                                <option value="EE" >Estonia</option>
                                <option value="ET" >Ethiopia</option>
                                <option value="FK" >Falkland Islands (Malvinas)</option>
                                <option value="FO" >Faroe Islands</option>
                                <option value="FJ" >Fiji</option>
                                <option value="FI" >Finland</option>
                                <option value="FR" >France</option>
                                <option value="GF" >French Guiana</option>
                                <option value="PF" >French Polynesia</option>
                                <option value="TF" >French Southern Territories</option>
                                <option value="GA" >Gabon</option>
                                <option value="GM" >Gambia</option>
                                <option value="GE" >Georgia</option>
                                <option value="DE" >Germany</option>
                                <option value="GH" >Ghana</option>
                                <option value="GI" >Gibraltar</option>
                                <option value="GR" >Greece</option>
                                <option value="GL" >Greenland</option>
                                <option value="GD" >Grenada</option>
                                <option value="GP" >Guadeloupe</option>
                                <option value="GU" >Guam</option>
                                <option value="GT" >Guatemala</option>
                                <option value="GG" >Guernsey</option>
                                <option value="GN" >Guinea</option>
                                <option value="GW" >Guinea-Bissau</option>
                                <option value="GY" >Guyana</option>
                                <option value="HT" >Haiti</option>
                                <option value="HM" >Heard Island and McDonald Islands</option>
                                <option value="VA" >Holy See (Vatican City State)</option>
                                <option value="HN" >Honduras</option>
                                <option value="HK" >Hong Kong</option>
                                <option value="HU" >Hungary</option>
                                <option value="IS" >Iceland</option>
                                <option value="IN" >India</option>
                                <option value="ID" >Indonesia</option>
                                <option value="IQ" >Iraq</option>
                                <option value="IE" >Ireland</option>
                                <option value="IM" >Isle of Man</option>
                                <option value="IL" >Israel</option>
                                <option value="IT" >Italy</option>
                                <option value="IC" >Ivory Coast</option>
                                <option value="JM" >Jamaica</option>
                                <option value="JP" >Japan</option>
                                <option value="JE" >Jersey</option>
                                <option value="JO" >Jordan</option>
                                <option value="KZ" >Kazakhstan</option>
                                <option value="KE" >Kenya</option>
                                <option value="KI" >Kiribati</option>
                                <option value="KV" >Kosovo</option>
                                <option value="KW" >Kuwait</option>
                                <option value="KG" >Kyrgyzstan</option>
                                <option value="LA" >Laos</option>
                                <option value="LV" >Latvia</option>
                                <option value="LB" >Lebanon</option>
                                <option value="LS" >Lesotho</option>
                                <option value="LR" >Liberia</option>
                                <option value="LY" >Libya</option>
                                <option value="LI" >Liechtenstein</option>
                                <option value="LT" >Lithuania</option>
                                <option value="LU" >Luxembourg</option>
                                <option value="MO" >Macao</option>
                                <option value="MK" >Macedonia</option>
                                <option value="MG" >Madagascar</option>
                                <option value="MW" >Malawi</option>
                                <option value="MY" >Malaysia</option>
                                <option value="MV" >Maldives</option>
                                <option value="ML" >Mali</option>
                                <option value="MT" >Malta</option>
                                <option value="MH" >Marshall Islands</option>
                                <option value="MQ" >Martinique</option>
                                <option value="MR" >Mauritania</option>
                                <option value="MU" >Mauritius</option>
                                <option value="YT" >Mayotte</option>
                                <option value="MX" >Mexico</option>
                                <option value="FM" >Micronesia, Federated States of</option>
                                <option value="MD" >Moldova</option>
                                <option value="MC" >Monaco</option>
                                <option value="MN" >Mongolia</option>
                                <option value="ME" >Montenegro</option>
                                <option value="MS" >Montserrat</option>
                                <option value="MA" >Morocco</option>
                                <option value="MZ" >Mozambique</option>
                                <option value="MM" >Myanmar (Burma)</option>
                                <option value="NA" >Namibia</option>
                                <option value="NR" >Nauru</option>
                                <option value="NP" >Nepal</option>
                                <option value="AN" >Netherlands Antilles</option>
                                <option value="NC" >New Caledonia</option>
                                <option value="NZ" >New Zealand</option>
                                <option value="NI" >Nicaragua</option>
                                <option value="NE" >Niger</option>
                                <option value="NG" >Nigeria</option>
                                <option value="NU" >Niue</option>
                                <option value="NF" >Norfolk Island</option>
                                <option value="MP" >Northern Mariana Islands</option>
                                <option value="NO" >Norway</option>
                                <option value="OM" >Oman</option>
                                <option value="PK" >Pakistan</option>
                                <option value="PW" >Palau</option>
                                <option value="PS" >Palestinian Territory, Occupied</option>
                                <option value="PA" >Panama</option>
                                <option value="PG" >Papua New Guinea</option>
                                <option value="PY" >Paraguay</option>
                                <option value="PE" >Peru</option>
                                <option value="PH" >Philippines</option>
                                <option value="PL" >Poland</option>
                                <option value="PT" >Portugal</option>
                                <option value="PR" >Puerto Rico</option>
                                <option value="QA" >Qatar</option>
                                <option value="RE" >Reunion</option>
                                <option value="RO" >Romania</option>
                                <option value="RW" >Rwanda</option>
                                <option value="SH" >Saint Helena</option>
                                <option value="KN" >Saint Kitts and Nevis</option>
                                <option value="LC" >Saint Lucia</option>
                                <option value="MF" >Saint Martin (French part)</option>
                                <option value="PM" >Saint Pierre and Miquelon</option>
                                <option value="VC" >Saint Vincent and the Grenadines</option>
                                <option value="WS" >Samoa</option>
                                <option value="SM" >San Marino</option>
                                <option value="ST" >Sao Tome and Principe</option>
                                <option value="SA" >Saudi Arabia</option>
                                <option value="SN" >Senegal</option>
                                <option value="RS" >Serbia</option>
                                <option value="SC" >Seychelles</option>
                                <option value="SL" >Sierra Leone</option>
                                <option value="SG" >Singapore</option>
                                <option value="SX" >Sint Maarten (Dutch part)</option>
                                <option value="SK" >Slovakia</option>
                                <option value="SI" >Slovenia</option>
                                <option value="SB" >Solomon Islands</option>
                                <option value="SO" >Somalia</option>
                                <option value="ZA" >South Africa</option>
                                <option value="GS" >South Georgia and the South Sandwich Islands</option>
                                <option value="KR" >South Korea</option>
                                <option value="SS" >South Sudan</option>
                                <option value="ES" >Spain</option>
                                <option value="LK" >Sri Lanka</option>
                                <option value="SD" >Sudan</option>
                                <option value="SR" >Suriname</option>
                                <option value="SJ" >Svalbard and Jan Mayen</option>
                                <option value="SZ" >Swaziland</option>
                                <option value="SE" >Sweden</option>
                                <option value="CH" >Switzerland</option>
                                <option value="TW" >Taiwan</option>
                                <option value="TJ" >Tajikistan</option>
                                <option value="TZ" >Tanzania</option>
                                <option value="TH" selected="selected">Thailand</option>
                                <option value="NL" >The Netherlands</option>
                                <option value="TL" >Timor-Leste</option>
                                <option value="TG" >Togo</option>
                                <option value="TK" >Tokelau</option>
                                <option value="TO" >Tonga</option>
                                <option value="TT" >Trinidad</option>
                                <option value="TN" >Tunisia</option>
                                <option value="TR" >Türkiye</option>
                                <option value="TM" >Turkmenistan</option>
                                <option value="TC" >Turks and Caicos Islands</option>
                                <option value="TV" >Tuvalu</option>
                                <option value="UG" >Uganda</option>
                                <option value="UA" >Ukraine</option>
                                <option value="AE" >United Arab Emirates</option>
                                <option value="GB" >United Kingdom</option>
                                <option value="US" >United States</option>
                                <option value="UM" >United States Minor Outlying Islands</option>
                                <option value="UY" >Uruguay</option>
                                <option value="VI" >U.S. Virgin Islands</option>
                                <option value="UZ" >Uzbekistan</option>
                                <option value="VU" >Vanuatu</option>
                                <option value="VE" >Venezuela</option>
                                <option value="VN" >Vietnam</option>
                                <option value="WF" >Wallis and Futuna</option>
                                <option value="EH" >Western Sahara</option>
                                <option value="YE" >Yemen</option>
                                <option value="CD" >Zaire (Democratic Republic of Congo)</option>
                                <option value="ZM" >Zambia</option>
                                <option value="ZW" >Zimbabwe</option>
                            </optgroup>
                        </select>
                    </div>
                </div>
                <div id="locale_picker_language_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-language_code">Language</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-language_code" name="language_code" class="wt-select__element">
                                <option value="de" >Deutsch</option>
                                <option value="en-GB" >English (UK)</option>
                                <option value="en-IN" >English (IN)</option>
                                <option value="en-US" selected="selected">English (US)</option>
                                <option value="es" >Español</option>
                                <option value="fr" >Français</option>
                                <option value="it" >Italiano</option>
                                <option value="ja" >日本語</option>
                                <option value="nl" >Nederlands</option>
                                <option value="pl" >Polski</option>
                                <option value="pt" >Português</option>
                                <option value="ru" >Русский</option>
                        </select>
                    </div>
                </div>
                <div id="locale_picker_currency_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-currency_code">Currency</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-currency_code" name="currency_code" class="wt-select__element">
                                <option value="USD" >$ United States Dollar (USD)</option>
                                <option value="CAD" >$ Canadian Dollar (CAD)</option>
                                <option value="EUR" >€ Euro (EUR)</option>
                                <option value="GBP" >£ British Pound (GBP)</option>
                                <option value="AUD" >$ Australian Dollar (AUD)</option>
                                <option value="JPY" >¥ Japanese Yen (JPY)</option>
                                <option value="CNY" >¥ Chinese Yuan (CNY)</option>
                                <option value="CZK" >Kč Czech Koruna (CZK)</option>
                                <option value="DKK" >kr Danish Krone (DKK)</option>
                                <option value="HKD" >$ Hong Kong Dollar (HKD)</option>
                                <option value="HUF" >Ft Hungarian Forint (HUF)</option>
                                <option value="INR" >₹ Indian Rupee (INR)</option>
                                <option value="IDR" >Rp Indonesian Rupiah (IDR)</option>
                                <option value="ILS" >₪ Israeli Shekel (ILS)</option>
                                <option value="MYR" >RM Malaysian Ringgit (MYR)</option>
                                <option value="MXN" >$ Mexican Peso (MXN)</option>
                                <option value="MAD" >DH Moroccan Dirham (MAD)</option>
                                <option value="NZD" >$ New Zealand Dollar (NZD)</option>
                                <option value="NOK" >kr Norwegian Krone (NOK)</option>
                                <option value="PHP" >₱ Philippine Peso (PHP)</option>
                                <option value="SGD" >$ Singapore Dollar (SGD)</option>
                                <option value="VND" >₫ Vietnamese Dong (VND)</option>
                                <option value="ZAR" >R South African Rand (ZAR)</option>
                                <option value="SEK" >kr Swedish Krona (SEK)</option>
                                <option value="CHF" >Swiss Franc (CHF)</option>
                                <option value="THB" selected="selected">฿ Thai Baht (THB)</option>
                                <option value="TWD" >NT$ Taiwan New Dollar (TWD)</option>
                                <option value="TRY" >₺ Turkish Lira (TRY)</option>
                                <option value="PLN" >zł Polish Zloty (PLN)</option>
                                <option value="BRL" >R$ Brazilian Real (BRL)</option>
                        </select>
                    </div>
                </div>
                -->
                                        </div>
                                        <div class="wt-overlay__footer wt-justify-content-flex-end">
                                            <div class="wt-overlay__footer__action">
                                                <a type="button" data-wt-overlay-close
                                                    class="wt-btn wt-btn--outline wt-mb-xs-1 wt-mb-md-0 wt-mr-md-1"
                                                    name="cancel">

                                                    Cancel
                                                    <div class="wt-spinner wt-spinner--01" role="alert"
                                                        aria-live="assertive">
                                                        <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                focusable="false">
                                                                <circle fill="transparent" cx="12" cy="12" r="10" />
                                                            </svg></span>
                                                        Loading
                                                    </div>

                                                </a>
                                                <button class="wt-btn wt-btn--filled" action-type="primary"
                                                    type="submit" name="save" id="locale-overlay-save">
                                                    Save
                                                    <div class="wt-spinner wt-spinner--01" role="alert"
                                                        aria-live="assertive">
                                                        <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                                viewBox="0 0 24 24" aria-hidden="true"
                                                                focusable="false">
                                                                <circle fill="transparent" cx="12" cy="12" r="10" />
                                                            </svg></span>
                                                        Loading
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>

                        </footer>
                    </div>

                    <div data-gdpr-consent-prompt>
                        <div id="gdpr-privacy-settings" class="wt-overlay third-party-settings wt-text-left-xs"
                            aria-labelledby="gdpr-full-settings-overlay-title" aria-hidden="true" role="dialog"
                            data-gdpr-settings-overlay data-wt-overlay>
                            <div class="wt-overlay__modal gdpr-overlay-view" data-overlay-modal>
                                <div class="wt-overlay__header gdpr-overlay-header">
                                    <h3 class="wt-text-heading" id="gdpr-full-settings-overlay-title">Privacy Settings
                                    </h3>
                                </div>


                                <div class="gdpr-overlay-body wt-pb-xl-2 wt-pb-lg-2 wt-pb-md-2 wt-pb-sm-2 wt-pb-xs-2">
                                    <div>
                                        <div data-section="intro">
                                            <p class="wt-text-caption wt-mb-xs-1">Etsy uses cookies and similar
                                                technologies to give you a better experience, enabling things like:</p>
                                            <ul class="wt-text-caption wt-ml-xs-2 wt-mb-xs-2">
                                                <li>basic site functions</li>
                                                <li>ensuring secure, safe transactions</li>
                                                <li>secure account login</li>
                                                <li>remembering account, browser, and regional preferences</li>
                                                <li>remembering privacy and security settings</li>
                                                <li>analysing site traffic and usage</li>
                                                <li>personalized search, content, and recommendations</li>
                                                <li>helping sellers understand their audience</li>
                                                <li>showing relevant, targeted ads on and off Etsy</li>
                                            </ul>
                                            <p class="wt-text-caption wt-line-height-tight wt-text-link">Detailed
                                                information can be found in Etsy’s <a class="wt-text-link"
                                                    href="https://www.etsy.com/legal/cookies-and-tracking-technologies">Cookies
                                                    &amp; Similar Technologies Policy</a> and our <a
                                                    class="wt-text-link"
                                                    href="https://www.etsy.com/legal/privacy">Privacy Policy</a>.</p>
                                        </div>

                                        <div
                                            class="wt-pt-xl-6 wt-display-flex-xl wt-pt-lg-6 wt-display-flex-lg wt-pt-md-6 wt-display-flex-md wt-pt-sm-6 wt-display-flex-sm wt-pt-xs-6 wt-display-flex-xs">
                                            <div
                                                class="wt-flex-xl-5 wt-flex-lg-5 wt-flex-md-5 wt-flex-sm-5 wt-flex-xs-5">
                                                <h2 class="wt-text-title-01 wt-mb-xs-4 wt-break-word">Required Cookies
                                                    &amp; Technologies</h2>
                                                <p class="wt-text-caption wt-mb-xs-2">Some of the technologies we use
                                                    are necessary for critical functions like security and site
                                                    integrity, account authentication, security and privacy preferences,
                                                    internal site usage and maintenance data, and to make the site work
                                                    correctly for browsing and transactions.</p>
                                            </div>
                                            <div
                                                class="wt-flex-xl-1 wt-flex-lg-1 wt-flex-md-1 wt-flex-sm-1 wt-flex-xs-1">
                                                <div
                                                    class="wt-display-flex-xl wt-display-flex-lg wt-display-flex-md wt-display-flex-sm wt-display-flex-xs wt-justify-content-flex-end">
                                                    <span class="wt-text-caption">Always on</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="wt-text-caption wt-pt-xl-6 wt-display-flex-xl wt-pt-lg-6 wt-display-flex-lg wt-pt-lg-6 wt-display-flex-lg wt-pt-md-6 wt-display-flex-md wt-pt-sm-6 wt-display-flex-sm wt-pt-xs-6 wt-display-flex-xs"
                                            data-section="third_party_consent">
                                            <div
                                                class="wt-flex-xl-5 wt-flex-lg-5 wt-flex-md-5 wt-flex-sm-5 wt-flex-xs-5">
                                                <h2 class="wt-text-title-01 wt-mb-xs-4 wt-break-word">Personalized
                                                    Advertising</h2>
                                                <p class="wt-text-caption wt-mb-xs-2">To enable personalized advertising
                                                    (like interest-based ads), we may share your data with our marketing
                                                    and advertising partners using cookies and other technologies. Those
                                                    partners may have their own information they’ve collected about you.
                                                    Turning off the personalized advertising setting won’t stop you from
                                                    seeing Etsy ads, but it may make the ads you see less relevant or
                                                    more repetitive.</p>
                                                <p class="wt-text-caption wt-mb-xs-2"> Personalized advertising may be
                                                    considered a “sale” or “sharing” of information under California and
                                                    other state privacy laws, and you may have a right to opt out.
                                                    Turning off personalized advertising allows you to exercise your
                                                    right to opt out. Learn more in our <a class="wt-text-link"
                                                        href="https://www.etsy.com/legal/privacy/">Privacy Policy.</a>,
                                                    <a class="wt-text-link"
                                                        href="https://help.etsy.com/hc/en-us/articles/360042433614-How-to-Opt-out-of-Personalized-Advertising">Help
                                                        Center</a>, and <a class="wt-text-link"
                                                        href="https://www.etsy.com/legal/cookies">Cookies &amp; Similar
                                                        Technologies Policy</a>.
                                                </p>
                                            </div>
                                            <div
                                                class="wt-flex-xl-1 wt-flex-lg-1 wt-flex-md-1 wt-flex-sm-1 wt-flex-xs-1">
                                                <div
                                                    class="wt-display-flex-xl wt-display-flex-lg wt-display-flex-md wt-display-flex-sm wt-display-flex-xs wt-justify-content-flex-end">
                                                    <label for="third_party_consent"
                                                        class="wt-text-caption wt-pt-xl-1 wt-pr-xl-2 wt-pt-lg-1 wt-pr-lg-2 wt-pt-md-1 wt-pr-md-2 wt-pt-sm-1 wt-pr-sm-2 wt-pt-xs-1 wt-pr-xs-2 wt-nudge-t-3"
                                                        aria-hidden="true" data-gdpr-toggle-label>
                                                        On
                                                    </label>
                                                    <input class="wt-switch wt-switch--small" type="checkbox"
                                                        name="third_party_consent" id="third_party_consent" checked
                                                        data-gdpr-toggle data-checked-label="On"
                                                        data-unchecked-label="Off">
                                                    <label class="wt-switch__toggle" for="third_party_consent"
                                                        aria-hidden="true"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="wt-overlay__footer wt-align-items-center">
                                    <div class="wt-overlay__footer__cancel">
                                    </div>
                                    <div class="wt-overlay__footer__action">
                                        <div
                                            class="wt-display-flex-xl wt-flex-direction-row-xl wt-display-flex-lg wt-flex-direction-row-lg wt-display-flex-md wt-flex-direction-row-md wt-display-flex-sm wt-flex-direction-column-sm wt-display-flex-xs wt-flex-direction-column-xs">
                                            <div class="wt-pr-xl-7 wt-pt-xl-2 wt-pr-lg-7 wt-pt-lg-2 wt-pr-md-7 wt-pt-md-2 wt-pb-sm-4 wt-pb-xs-2 wt-horizontal-center wt-display-none"
                                                data-saving-indicator>
                                                <div
                                                    class="wt-spinner wt-spinner--01 wt-display-inline-block wt-vertical-align-middle">
                                                    <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                                            viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                            <circle fill="transparent" cx="12" cy="12" r="10" />
                                                        </svg></span>
                                                </div>
                                            </div>
                                            <div class="wt-pr-xl-7 wt-pt-xl-2 wt-pr-lg-7 wt-pt-lg-2 wt-pr-md-7 wt-pt-md-2 wt-pb-sm-4 wt-pb-xs-2 wt-horizontal-center wt-display-none"
                                                data-saved-indicator>
                                                <span class="etsy-icon wt-icon--smaller-xs"><svg
                                                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                        aria-hidden="true" focusable="false">
                                                        <path
                                                            d="M9.057,20.471L2.293,13.707a1,1,0,0,1,1.414-1.414l5.236,5.236,11.3-13.18a1,1,0,1,1,1.518,1.3Z" />
                                                    </svg></span>
                                                <span
                                                    class="wt-display-inline-block wt-vertical-align-middle wt-text-body-01 wt-pl-xs-1">Saved</span>
                                            </div>
                                            <div>
                                                <button data-wt-overlay-close
                                                    class="wt-btn wt-btn--primary wt-pl-xs-8 wt-pr-xs-8 wt-pl-sm-10 wt-pr-sm-10 wt-pl-md-3 wt-pr-md-3 wt-pl-lg-3 wt-pr-lg-3 wt-pl-xl-3 wt-pr-xl-3 wt-pl-tv-3 wt-pr-tv-3">
                                                    <p
                                                        class="wt-pl-xs-10 wt-pr-xs-10 wt-pl-sm-10 wt-pr-sm-10 wt-pl-md-0 wt-pr-md-0 wt-pl-lg-0 wt-pr-lg-0 wt-pl-xl-0 wt-pr-xl-0 wt-pl-tv-0 wt-pr-tv-0">
                                                        Done</p>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <script type="text/html" data-gdpr-consent-success-alert>
        <div class="wt-alert wt-alert--success-01 wt-alert--fixed-floating wt-alert--fixed-bottom wt-mb-xs-4">
            <div class="wt-display-flex-xs">
                <p class="wt-text-body-01 wt-text-left-xs">Privacy settings saved</p>
            </div>
        </div>
    </script>
                    </div>

                    <div id="wt-portals"></div>

                    <div id="etsy-modal-container" aria-hidden="true"></div>


                    <div id="google-tag-manager-container" aria-hidden="true">
                        <script nonce="sX01MNM9OyY6bV2b7BGCSBPQ">
                                                         83,
                                                                                                                                                                                            ];
                        </script>

                        <noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-KWW5SS" height="0" width="0"
                                style="display:none;visibility:hidden"></iframe></noscript>
                        <script
                            nonce='sX01MNM9OyY6bV2b7BGCSBPQ'>(fun[f = j.src                        getAt t ribL                        ');</script>
                    </div>



                    <script type='text/javascript' nonce='sX01MNM9OyY6bV2b7BGCSBPQ'>
                                                         www.etsy.com\/bcn\/beacon"; wind"                        eu                            on": ["off", "x", "106c3b"], "neu_runtime_tracing": ["off", "w", "6631e5"], "structured_data_attributes_order_dependent": ["on", "x", "691833"], "disambiguate_usd_outside_usa": ["ineligible", "e", "c8897d"], "google_tag_manager": ["on", "x", "43dc13"], "site_chrome\/buyer_to_seller_navbar_signed_out": ["ineligible", "e", "0efe99"], "checkout.gift_card_cta_in_search_dropdown": ["on", "x", "931866"], "local_pe.q3_2024.search.browser.traffic_split": ["on", "x", "33df41"], "ranking\/search.experience.xml_autosuggest_v4": ["all_xml", "x", "2b2623"], "lingtools\/trending_searches.gcp": ["on", "x", "5cfa03"], "site_chrome\/buyer_to_seller_navbar_signed_in": ["ineligible", "e", "67649b"], "persistent_experiment.q3_2025": ["global_holdout_continuous", "w", "6c0626"], "site_chrome\/buyer_zipcode_in_header_desktop": ["off", "x", "eb55bf"], "site_chrome\/buyer_zipcode_in_header_mweb": ["ineligible", "e", "5d612c"], "builda_scss": ["sasquatch", "x", "96bd82"], "polyfills": ["on", "x", "db574b"], "polyfill_experiment_4": ["no_filtering", "x", "0e8409"], "web_deals.translate_nav_recs": ["on", "x", "f054b7"], "ranking\/search.experience.category_suggestions_in_autosuggest": ["ineligible", "e", "6e2d9f"], "ranking\/search.experience.contentful_title_on_trending_searches": ["on", "x", "d0b108"], "ranking\/search.experience.always_show_shop_search_in_autosuggest": ["on", "x", "66727b"], "growth_regx.lp_rating_histogram_shop_header_desktop": ["off", "x", "1c99da"], "growth_regx.lp_message_seller_replace_collections_buy_box_desktop_so": ["off", "x", "9b3fad"], "gcs_image_reads": ["on", "x", "b7a48f"], "searchx.4q18.dwell_time_as_backend_event": ["off", "x", "d3826b"], "gift_mode.lp_bin_sheet_tiag_v2": ["on", "x", "1beeb9"], "customized_persistent_experiment.2025_q3.browser_default_pe.continuous": ["on", "w", "a439f9"], "cnc.atc_from_listing_cards_ymal_mfts_desktop": ["on", "x", "58b479"], "perso_custo.buyer_read_from_new_perso_tables": ["on", "x", "dffb8d"], "growth_regx.lp_seller_cred_shop_desc_desktop": ["ineligible", "e", "4bc04e"], "cnc.extend_elp_layout_desktop_external": ["off", "x", "fb525e"], "iat.listing_page_hide_similar_items_sash.desktop": ["off", "x", "e2a169"], "cow_layer\/desktop_lp_evolved_favoriting_v2": ["ineligible", "e", "2ca26f"], "growth_regx.lp_bb_trust_redesign_desktop": ["off", "x", "df41b4"], "checkout.klarna_unified_pay_later": ["ineligible", "e", "e11748"], "perso_buyer_squad_layer\/variations_update": ["on", "x", "0e428d"], "perso_custo.multiple_questions_enabled.buyer_side": ["on", "x", "82e6f7"], "seo.listing_shop_faqs_machine_translation": ["off", "x", "ad47eb"], "onsite_promos.superbowl_listing_page_banner": ["ineligible", "e", "2deace"], "inventory.listing_inventory_quantity_select": ["off", "x", "e2182e"], "growth_regx.lp_production_partners_in_item_details": ["on", "x", "3cd0fb"], "coreloc.vat_inclusive_cart_prices": ["off", "x", "1bedcb"], "coreloc.vat_inclusive_prices_lp_sidebar_cart_operational": ["off", "x", "c814cc"], "growth_regx.lp_move_appreciation_photos_desktop": ["off", "x", "9273bf"], "growth_regx.lp_review_photo_filter_and_sort_desktop": ["on", "x", "acff7a"], "growth_regx.lp_review_engagement_aa_desktop": ["off", "x", "bfb356"], "growth_regx.lp_new_seller_cred_foundational_desktop": ["on", "x", "bccc3b"], "cnc.anchor_item_lp_recs_desktop": ["off", "x", "315c33"], "cnc.visual_search_tags_external": ["off", "x", "b589cb"], "cnc\/experiment.related_search_pathways_v3_desktop": ["ineligible", "e", "7e808d"], "lp_performance.css_import_cleanup": ["on", "x", "ec2bd2"], "cnc\/experiment.compare_lp_collections_v2_desktop": ["ineligible", "e", "c0c984"], "chops.elp_related_trends_module.desktop": ["on", "x", "b11d14"], "ads\/takerate.lp_ads_row_expansion.desktop": ["ineligible", "e", "cad35c"], "cnc.listing_card_styling_desktop": ["off", "x", "b3b16e"], "cnc.only_prompt_similar_listing_desktop": ["off", "x", "1f1344"], "core_fulfillment.product_level_readiness_states.core_experience": ["off", "ch", "d06c95"], "fulfillment_platform.usps_pm_faster_ga_experiment.web": ["on", "x", "498eec"], "fulfillment_platform.usps_pm_faster_ga_experiment.mobile": ["ineligible", "e", "20f21b"], "fulfillment_ml.ml_predicted_acceptance_scan.uk.operational": ["on", "x", "74db8e"], "fulfillment_ml.ml_predicted_acceptance_scan.uk.experiment_web": ["prod", "x", "9a5255"], "fulfillment_ml.ml_predicted_acceptance_scan.uk.experiment_mobile": ["ineligible", "e", "865516"], "fulfillment_ml.ml_predicted_acceptance_scan.germany.operational": ["off", "x", "4528ab"], "fulfillment_ml.ml_predicted_acceptance_scan.germany.experiment_web": ["off", "x", "cac266"], "fulfillment_ml.ml_predicted_acceptance_scan.germany.experiment_mobile": ["ineligible", "e", "9a29ab"], "fulfillment_platform.edd_cart_caching.web": ["edd_and_arizona_cache", "x", "e313fc"], "fulfillment_platform.edd_cart_caching.mobile": ["ineligible", "e", "ffb947"], "fulfillment_ml.ml_predicted_acceptance_scan.product_usps.operational": ["on", "x", "25ebba"], "fulfillment_ml.ml_predicted_acceptance_scan.product_usps.experiment_web": ["prod_v1", "x", "72db80"], "fulfillment_ml.ml_predicted_acceptance_scan.product_usps.experiment_mobile": ["ineligible", "e", "565958"], "fulfillment_platform.consolidated_country_to_country_ml_times.experiment_web": ["prod", "x", "2eac66"], "fulfillment_platform.consolidated_country_to_country_ml_times.experiment_mobile": ["ineligible", "e", "81b585"], "checkout\/paypal_smart_button_desktop": ["ineligible", "e", "07b533"], "checkout\/paypal_smart_button_mweb": ["ineligible", "e", "643355"], "mobile_dynamic_config.iphone.ApplePayPaymentMethods.Girocard": ["ineligible", "e", "fbb78b"], "mobile_dynamic_config.iphone.ApplePayPaymentMethods.CartesBancaires": ["ineligible", "e", "47f399"], "checkout\/google_pay_on_web_v2": ["on", "x", "cbf24c"], "checkout\/add_jcb_cc_payment_method": ["on", "x", "ce90aa"], "checkout\/bin_confidence": ["show_cc", "x", "990cfd"], "checkout.klarna_us_price_bands_v2": ["ineligible", "e", "658ea6"], "checkout.klarna_uk_price_bands_v2": ["ineligible", "e", "c4d855"], "checkout.etsy_bin_on_apple_pay_devices": ["on", "x", "e77719"], "checkout.checkout_guest_apple_pay_bin_v2": ["off", "x", "833ff4"], "fulfillment_ml.ml_predicted_acceptance_scan.ups_fedex.experiment_web": ["on", "x", "6ef73d"], "fulfillment_ml.ml_predicted_acceptance_scan.ups_fedex.experiment_mobile": ["ineligible", "e", "81c794"], "fulfillment_ml.usps_route_predictor.web": ["on", "x", "7f6b44"], "fulfillment_ml.usps_route_predictor.mobile": ["ineligible", "e", "5a1b77"], "fulfillment_ml.use_sla_dataset": ["on", "x", "66b144"], "fulfillment_ml.only_display_edd_max.web": ["ineligible", "e", "2d500c"], "fulfillment_ml.only_display_edd_max.mobile": ["ineligible", "e", "07bd93"], "cnc.boe_dataset_related_searches": ["on", "x", "d28934"], "perso_engine.recs.ssq_on_web_u2l_version": ["on", "x", "c2a009"], "perso_engine.recs.ssq_on_web_u2l_version_internal": ["on", "x", "4a8ed2"], "perso_engine.recs.listing_page_external_query_ranker_v2": ["off", "x", "e3548f"], "perso_engine.recs.listing_page_internal_query_ranker_v2_fix": ["on", "x", "e872dc"], "checkout\/covid_shipping_restrictions": ["ineligible", "e", "153e2d"], "navx.always_images_in_l2": ["off", "x", "d6d388"], "ranking\/search.experience.refinement_pills_in_autosuggest": ["ineligible", "e", "2a2140"], "ranking\/search.experience.trending_searches_in_zero_pane_v2": ["on", "x", "cdb259"], "loyalty.web.reduce_listing_signup_prompts_exp": ["ineligible", "e", "bf6a41"], "cnc.remove_atc_mweb": ["ineligible", "e", "699ff5"], "api.ab_bubbling_experiment.browser_flag.listzilla_get_listing_state": ["ineligible", "e", "f05e23"], "payments\/purchase_rewards_v1": ["ineligible", "e", "f629c8"], "dynamic_experiments.Merch_JewelrySale25_SkinnyBanner_test_v3": ["ineligible", "e", "89c994"], "dynamic_experiments.Merch_JewelrySale25_SkinnyBanner_test": ["ineligible", "e", "6ff9d7"], "dynamic_experiments.Merch_DDGSkinnyBanner24_V2_test": ["ineligible", "e", "8e97c7"], "dynamic_experiments.Merch_DDGSkinnyBanner24_test": ["ineligible", "e", "5a291a"], "dynamic_experiments.Merch_LaborDay24_Link_test": ["ineligible", "e", "63a995"], "dynamic_experiments.Merch_FDAY24_GiftTeaser_test": ["ineligible", "e", "18d6f7"], "dynamic_experiments.Merch_GiftMode24_Teaser_test": ["ineligible", "e", "3ad555"], "perso_engine.recs.ymal_pointwise_v6_web": ["on", "x", "26260f"], "chops.elp_filter_recs_and_ads_by_price.desktop": ["off", "x", "c6f06b"], "chops.elp_filter_recs_and_ads_by_price.mweb": ["ineligible", "e", "2b8248"], "chops.elp_filter_recs_and_ads_by_price_v3.mweb": ["ineligible", "e", "9bcdd8"], "chops.elp_filter_recs_and_ads_by_price_v2.desktop": ["off", "x", "786fac"], "ranking\/ads.prolist.prolist_similar_air_retrained": ["on", "x", "6d4490"], "ranking\/ads.prolist.l2l_orange_ann_gms_boosting": ["on", "x", "e132db"], "ranking\/ads.prolist.l2l_orange_ann_gms_boosting_price_followup": ["price_winsorized_at_600_usd_cents", "x", "6bfa57"], "ranking\/ads.prolist.prolist_similar_air_clip": ["no_boost", "x", "16dae3"], "local_pe.q3_2024.etsy_ads.browser.traffic_split": ["on", "x", "b4dd9d"], "ranking\/ads.prolist.l2l_air_multij_nonegs_followup": ["mj_single_task", "x", "0f06ca"], "ranking\/ads.prolist.l2l_air_price_ratio_tuning": ["ineligible", "e", "7c7b51"], "ranking\/ads.prolist.prolist_similar_ann_fallback": ["solr", "x", "7aa837"], "ranking\/ads.prolist.prolist_similar_nir_fresh": ["on", "x", "f55808"], "ranking\/ads.prolist.prolist_similar_orange_ann_air": ["on", "x", "426cf5"], "ranking\/ads.prolist.prolist_similar_air_followup_jan": ["45d_mtimg", "x", "b5400a"], "ranking\/ads.prolist.l2l_orange_probe_ratio": ["0050", "x", "70f363"], "ranking\/ads.prolist.prolist_similar_fl_migration_v2": ["prolist_similar_ctr_fl_prolist_similar_cvr_fl", "x", "902223"], "ranking\/ads.prolist.prolist_similar_ctr_perso_v8": ["ineligible", "e", "a5058c"], "ranking\/ads.prolist.prolist_similar_cvr_kb_v1": ["ineligible", "e", "9a91c7"], "ranking\/ads.prolist.bid_scaling_temp_q1_2024": ["ineligible", "e", "59bfc0"], "inventory_quality\/layered_quality_score.versions.v5_0_0_signed_out": ["ineligible", "e", "fc7211"], "inventory_quality\/layered_quality_score.versions.v5_0_0": ["ineligible", "e", "d8477b"], "local_pe.q3_2025.quality_score.browser.traffic_split": ["ineligible", "e", "030b08"], "local_pe.q3_2025.quality_score.browser": ["ineligible", "e", "ca7c01"], "quality_score.conservative_ads_threshold.web": ["ineligible", "e", "9b2645"], "quality_score.conservative_ads_threshold.boe": ["ineligible", "e", "3e4072"], "quality_score.expansion.web": ["off", "x", "fccfc7"], "quality_score.expansion.boe": ["ineligible", "e", "35f6f6"], "ranking\/ads.prolist.prolist_similar_multitask": ["ineligible", "e", "8a5842"], "local_pe.q1_2025.etsy_ads.browser.traffic_split": ["on", "x", "575061"], "ranking\/ads.prolist.prolist_l2l_mt_push": ["on", "x", "86afc0"], "local_pe.q2_2025.etsy_ads.browser.traffic_split": ["on", "x", "bba241"], "ranking\/ads.prolist.prolist_l2l_mt_push_datafix_signed_out": ["on", "x", "0f9de9"], "search.force_x": ["off", "x", "697d9b"], "search.debug_solr_searcher": ["off", "x", "1e2673"], "search.use_dark_cluster": ["off", "x", "335bf8"], "ranking\/ads.adplat.use_budget_service_java_client": ["on", "x", "4c6a40"], "ranking\/ads.adplat.use_budget_service_mmx": ["on", "x", "bcb190"], "search.xplat.solr_9_upgrade": ["off", "x", "97bff0"], "sadx.2025_q1.nkt_buyer_bucketing_m3": ["on", "x", "629a67"], "sadx.2025_q1.nkt_buyer_bucketing_facet": ["off", "x", "4a2c05"], "perso_engine.query_taxo_classifier_seldon.buyer_az_v4": ["on", "x", "bda8f8"], "perso_engine.query_taxo_classifier_seldon.buyer_use_seldon": ["on", "x", "2337eb"], "ranking\/search.experience.qic_to_qis_web": ["ineligible", "e", "15a27d"], "ranking\/search.experience.qic_to_qis_web_intl": ["ineligible", "e", "337401"], "inventory.listing_inventory_reader_refactor": ["off", "w", "8990c1"], "android_image_filename_hack": ["ineligible", "e", "9c9013"], "coreloc.listing_page_local_shipping_signal": ["on", "x", "1bd157"], "eu_crd_compliance.sellers": ["on", "x", "1060a1"], "growth_regx.lp_seller_cred_badges_desktop": ["on", "x", "153a58"], "navx.fnb_gift_cards_multivariate": ["ineligible", "e", "0fd1cc"], "ranking\/recs.custom_candidates_signal_ranker_v4": ["ineligible", "e", "9b2405"], "ranking\/recs.custom_candidates_signal_ranker_v0": ["ineligible", "e", "3eae86"], "iat.listing_page_trust_suite_banner.desktop": ["shield_icon", "x", "267e29"], "listing_process.how_its_made_properties.use_module_classifier": ["on", "x", "a5aaed"], "listing_process\/him_v4_classifier": ["on", "w", "987240"], "growth_regx.lp_anchor_shop_name_to_seller_cred": ["off", "x", "d4d89e"], "growth_regx.lp_review_feature_tags_buybox_desktop": ["off", "x", "e7bed6"], "recs_systems.enable_recs_tracking_delivered_events": ["on", "x", "a94bcf"], "growth_regx.lp_review_categorical_tags_in_deep_dive_desktop": ["on", "x", "9d91d4"], "growth_regx.lp_reviews_new_deep_dive_desktop": ["off", "x", "e9e5ba"], "quality_signals.individual_review_tags_desktop": ["off", "x", "2a0577"], "growth_regx.lp_reviews_this_item_badge_desktop": ["on", "x", "1b4475"], "recs_systems.crossborder_visibility_filter.web": ["ineligible", "e", "1b9205"], "cnc.updated_scarcity_signals_lp": ["off", "x", "181046"], "ranking\/search.smu.query_sanitization": ["on", "x", "51ec8d"], "ranking\/ads.prolist.static_l2l_multitask": ["ineligible", "e", "a1e732"], "ranking\/ads.prolist.prolist_similar_air_vespa": ["ineligible", "e", "cda736"], "ranking\/ads.prolist.l2l_push_fresh_restart": ["ineligible", "e", "57e61d"], "ranking\/ads.prolist.prolist_l2l_kotina": ["on", "x", "545610"], "ranking\/ads.prolist.prolist_similar_visual_similarity": ["ineligible", "e", "b19634"], "ranking\/ads.prolist.solr_filter": ["on", "x", "6df783"], "ranking\/ads.prolist.2025_q3.take_rate_bid_increase_q3": ["on", "x", "f7ef44"], "ranking\/ads.prolist.2025_q2.bid_pacing_v2": ["on", "x", "7ba495"], "sadx.2025_q2.campaign_strategy_bidding_modifications": ["on", "x", "6ad1e8"], "ranking\/ads.prolist.2025_q3.buf_bid_pacing": ["on", "x", "7202fd"], "ranking\/ads.prolist.2025_q3.max_cost_cap_sbe": ["ineligible", "e", "eb1c94"], "ranking\/ads.prolist.2025_q3.buf_bid_pacing_for_all": ["ineligible", "e", "f18364"], "ranking\/ads.prolist.2025_q1.bid_optimization_v2": ["ineligible", "e", "188ecb"], "ranking\/ads.prolist.2025_q1.first_pass_bid_simp": ["ineligible", "e", "69416c"], "ads.prolist.2025_q2.uncapped_bids": ["ineligible", "e", "90ac63"], "listing_tracking.include_favorite_and_atc_in_listing_interactions.web": ["off", "x", "bc80fc"], "listing_tracking.include_favorite_and_atc_in_listing_interactions.ios": ["ineligible", "e", "cae43e"], "listing_tracking.include_favorite_and_atc_in_listing_interactions.android": ["ineligible", "e", "d0e69d"], "badx.ads_row_debugger": ["off", "x", "f27652"], "coreloc.digital_download_signal_placement_expansion_desktop": ["on", "x", "70b59f"], "home_web.similar_rlp": ["on", "x", "72868e"], "cnc.sidebar_cart_post_atc_recs_v3": ["off", "x", "13c110"], "site_chrome\/cnc.sidebar_cart_zero_to_one": ["ineligible", "e", "45076d"], "site_chrome\/cnc.sidebar_cart_remove_quantity": ["on", "x", "4ea54a"], "cnc.sidebar_cart_open_in_same_tab": ["on", "x", "ed65a2"], "site_chrome\/fullstory\/use_track_event": ["ineligible", "e", "ae465c"], "google_tag_manager_async": ["off", "x", "7585d0"], "qualtrics_survey": ["ineligible", "e", "c3c730"], "qualtrics_survey_non_en": ["ineligible", "e", "5fec45"], "buyers_often_buying.show_discount_prices_on_the_hp_listings": ["on", "x", "e60c20"], "content_moderation.report_item.desktop": ["on", "x", "4dfa1d"], "growth_regx.lp_mask_generated_names_in_reviews": ["off", "x", "ea05d2"], "collections.privacy_clearer_setting_description": ["on", "x", "412fbc"], "prodperfect\/monthly_data_capture": ["off", "x", "137afb"], "ltv_tactics.cd_1509_two_steps_login_on_nav": ["ineligible", "e", "c16933"], "buyer_support\/epp_promise_messaging": ["ineligible", "e", "4ebacd"], "growth_regx.lp_view_shop_registration_details": ["on", "x", "fec272"], "ranking\/ad_delivery.ubo_obfuscated_grey_class": ["on", "x", "264198"], "ads.prolist.blocker_html": ["on", "x", "4eef51"], "eu_cookie_nag": ["ineligible", "e", "f8045f"], "cnc.related_searches_placement": ["off", "x", "157607"], "gifting.gnav_desktop_flyout": ["ineligible", "e", "55be9d"], "seller_platform_web.buyer_inquiry": ["off", "x", "ee9de4"], "seller_platform_web.seller_local_time": ["ineligible", "e", "98a5ac"], "seller_platform_web.item_detail_overlay": ["ineligible", "e", "cf46a1"], "buyer_promise.issue_resolution.fee_avoidance_v2": ["ineligible", "e", "3a7a9c"], "risk_experience.buyer_email_verification": ["ineligible", "e", "a98aad"]
                                                     }, "user_id": null, "page_guid": "ffc60a8a263.0dcac0493728c4c9bb4f.00", "version": 1, "request_uuid": "EujZFKiCCOtgexcpUg-u99uFBUf1", "cdn-provider": "fastly", "header_fingerprint": "ualc", "header_signature": "78858558504c2305bd6ec5ff1707faf9", "ip_org": "CAT Telecom", "ref": "", "loc": "http:\/\/www.etsy.com\/listing\/226335136\/dinosaur-hoodie-kids-costume-sweatshirt?external=1&ref=hp_consolidated_gifting_listings-2&pro=1&sts=1&logging_key=e13099e44a893b1312132aa89280521546d2965e%3A226335136", "locale_currency_code": "THB", "pref_language": "en-US", "region": "TH", "detected_currency_code": "THB", "detected_language": "en-US", "detected_region": "TH", "accept-languages": "id-ID,id", "ga_client_id": "GA1.1.1254613824.1757662734", "isWhiteListedMobileDevice": false, "isMobileRequestIgnoreCookie": false, "isMobileRequest": false, "isMobileDevice": false, "isMobileSupported": false, "isTabletSupported": false, "isTouch": false, "isEtsyApp": false, "isPreviewRequest": false, "isChromeInstantRequest": false, "isMozPrefetchRequest": false, "isTestAccount": false, "isSupportLogin": false, "isInternal": false, "isInWebView": false, "isBot": false, "urlRef": "hp_consolidated_gifting_listings-2", "isSyntheticTest": false, "ebid": "PFd-Km61aOBK0Ajfl2gINY7IkAGoqjl_", "event_source": "web", fJ6OiKr03nIJTeVM - p87"                            : 3, "legacy_p":                                                                            "c!function (e, t) {
                                                         var n = e.__e                        rl, r = n.defaults, s = botCheck, c = n.bots.isBot; n.mergeObject = function (e) { for (var t = 1; t < arguments.length; t++) { var n = arguments[t]; for (var o i            sOwnProperty.call(n, o) && (e[o] = n[o]) } return e }; !r.ref && (r.ref = t.referrer), !r.loc && (r.loc = e.location.href), !r.webkit_page_visibility && (r.webkit_page_visibility = t.webkitVisibilityState), !r.event_source && (r.event_source = "web"), r.event_logger = "frontend", r.isIosApp && !0 === r.isIosApp ? r.event_source = "ios" : r.isAndroidApp && !0 === r.isAndroidApp && (r.event_source = "android"), a.length > 0 && (r.botCheck = r.botCheck || [], r.botCheck = r.botCheck.concat(a)), r.isBot = c, t.wasDiscarded && (r.was_discarded = !0); var v = function (t) { if (e.XMLHttpRequest) { var n = new XMLHttpRequest; n.open("POST", o, !0), n.send(JSON.stringify(t)) } }; n.updateLoc = function (e) { e !== r.loc && (r.ref = r.loc, r.loc = e) }, n.adminPublishEvent = function (n)                                 tomEvent && t.dispatchEvent(new C                                            l: n })), i.push(n)
                                                 }, n.sendEvents = function (t, i) {
                                                     var a = r; if ("perf" === i) {
                                                         var c = { event_logger: mergeObject({}, n.asyncAb, s)), a = n.mergeObject({}, r, c) } var f = { events: t, shared: a }; e.navigator && "function" == typeof e.navigator.sendBeacon ? fus.t);
                    </script>
                    <script type='text/javascript'
                        nonce='sX01MNM9OyY6bV2b7BGCSBPQ'>win                                                                                                                                                                                    .perf.e                                            "guid": "ffc60a8b884.00f2d293c4fcce79993c.00", "event_name": "perf", "event_logger": "perf", "page_type": "view_listing", "device_type": "Desktop", om            ok", "ip_region": "10", "ip_country_code": "TH", "boromir": true } }; !function (e, t) { if (!t.hidden) { var n = e.__etsy_logging || {}, r = n.perf || {}, i = n.url, a = n.defaults, o = r.event, s = n.sendEvents, c = 0 === Object.keys(r).length, u = e.webVitals || {}, d = n.mergeObject, m = r.isDev || !1, _ = r.skipLoggingEvent || !1, l = r.keepPerfObserverActive || !1, f = null, p = 0; if (!c && i && a && o && s) { var g = r.MARK_MEASURE_PREFIX || "_etsy_mark_measure_", v = function (e) { var t = !1; return function () { t || (t = !0, e.apply(this, arguments)) } }, y = function () { return void 0 !== e.PerformanceObserver }, h = function () { return "onpagehide" in e }, T = function (e, n) { var r = function (e) { var n = t.createElement("a"); n.href = e; var r = n.pathname.split("."); return r[r.length - 1] || "" }(e); return /jpe?g|png|svg|gif/i.test(r) ? "image" : /eot|woff2?|ttf/i.test(r) ? "font" : "js" === r ? "js" : "css" === r ? "css" : "xmlhttprequest" === n ? "xhr" : "unknown" }, E = function (e) { return Math.round(e < Math.pow(2, 64) - 1 ? e : 0) }, b = function (e, n) { var r = null, i = null; if (n.transferSize > 0) for (var a = 0; a < n.serverTiming.length; a++) { var o = n.serverTiming[a]; e.i_etsystatic_cdn || "cdn" !== o.name ? "cache_status" === o.name && (i = o.description) : r = o.description } r && (e.i_etsystatic_cdn = r); var s = null, c = null; i && (e.cdn_image _ cach i ng || (e.cdn_image_caching = { miss: 0, hit: 0 }), s = 0 === i.indexOf("HIT"), c = 0 === i.indexOf("MISS"), s && (e.cdn_image_caching.hit += 1),  c  &&    ( e.cd n _image_caching.miss += 1)), function (e, n, r, i) { f || (f = {}, t.querySelectorAll("img[data - perf - group]").forEach((function (e) { e.currentSrc && (f[e.currentSrc] = e) }))); var a = f[n.name]; if (a) { var o = a.dataset.perfGroup; e.categorized_images || (e.categorized_images = []); var s = { category: o, duration: E(n.duration), encodedBodySize: E(n.encodedBodySize), transferSize: E(n.transferSize), width: a.width, height: a.height }; if (n.transferSize > 0) { (r || i) && (s.cdn_hit = r); for (var c = 0; c < n.serverTiming.length; c++) { var u = n.serverTiming[c]; "clientrtt" === u.name ? s.clientrtt = E(u.duration) : "clienttt" === u.name ? s.clienttt = E(u.duration) : "cdntime" === u.name ? s.cdntime = E(u.duration) : "origin" === u.name && (s.origin = E(u.duration)) } } e.categorized_images.push(s) } }(e, n, s, c) }, S = function (e) { var t = { nav_start: E(e.navigationStart || e.startTime), activation_start: E(e.activationStart || 0), fetch_start: E(e.fetchStart), dns_start: E(e.domainLookupStart), dns_end: E(e.domainLookupEnd), connect_start: E(e.connectStart), connect_end: E(e.connectEnd), interim_response_start: E(e.firstInterimResponseStart || 0), request_start: E(e.requestStart), response_start: E(e.responseStart), response_end: E(e.responseEnd), dom_completed: E(e.domComplete), dom_interactive: E(e.domInteractive), secure_connect_start: E(e.secureConnectionStart) || null, loaded_start: E(e.loadEventStart) || null, loaded_end: E(e.loadEventEnd) || null, dom_content_loaded_start: E(e.domContentLoadedEventStart) || null, dom_content_loaded_end: E(e.domContentLoadedEventEnd) || null, html_tx_size: E(e.transferSize), html_enc_size: E(e.encodedBodySize), html_dec_size: E(e.decodedBodySize), type: e.type }; return e.redirectStart && (t.redirect_start = E(e.redirectStart)), e.redirectEnd && (t.redirect_end = E(e.redirectEnd)), e.redirectCount && (t.redirect_count = e.redirectCount), t }, k = function (e) { return e.reduce((function (e, t) { if ("entryType" in t) { if ("resource" === t.entryType) return function (e, t) { var n = T(t.name, t.initiatorType); if ("unknown" === n) return e; var r = t.name.match(/etsy(static)?(cloud)?\.com/) ? "etsy" : "third"; "image" === n && "etsy" === r && (t.name.match(/img0\.etsystatic/) ? e.img0_count = (e.img0_count || 0) + 1 : t.name.match(/img1\.etsystatic/) && (e.img1_count = (e.img1_count || 0) + 1)), "image" === n && "etsy" === r && t.serverTiming && t.name.match(/i\.etsystatic\.com/) && b(e, t); var i = "sum_" + r + "_" + n + "_bytes", a = "sum_" + r + "_" + n + "_enc_bytes", o = "sum_" + r + "_" + n + "_tx_bytes", s = "sum_" + r + "_" + n + "_dur", c = "count_" + r + "_" + n + "_req"; return e[i] = (e[i] || 0) + E(t.decodedBodySize), e[a] = (e[a] || 0) + E(t.encodedBodySize), e[o] = (e[o] || 0) + E(t.transferSize), e[s] = (e[s] || 0) + E(t.duration), e[c] = (e[c] || 0) + 1, e }(e, t); if ("paint" === t.entryType) return function (e, t) { return e[t.name.replace(/-/g, "_")] = E(t.startTime), e }(e, t); if ("longtask" === t.entryType) return function (e, t) { return e.long_tasks_count = (e.long_tasks_count || 0) + 1, e.long_tasks_dur = (e.long_tasks_dur || 0) + E(t.duration), e }(e, t); if ("mark" === t.entryType  | | "measure" === t.entryType) return function (e, t) { return 0 === t.name.lastIndexOf(g, 0) && (e[0 === t.name.lastIndexOf(g + "async_spec_", 0) ? t . name.subst r ing(g.length) : t.name] = E("mark" === t.entryType ? t.startTime : t.duration)), e }(e, t); if ("layout - shift" === t.entryType && !t.hadRecentInput) return function (e, t) { return e.layout_shift_count = (e.layout_shift_count || 0) + 1, e.layout_shift = (e.layout_shift || 0) + t.value, t.value > .05 && (e.layout_shift_elements = e.layout_shift_elements || [], e.layout_shift_elements.push({ value: t.value, elements: (t.sources || []).filter((function (e) { return !!e.node })).map((function (e) { return { className: e.node.classList && Array.prototype.slice.call(e.node.classList).join(" "), tagName: e.node.tagName, id: e.nod e .id } }))   })), e }(e, t); if ("navigation" === t.entryType) return r.t = !0, d(e, S(t)); if ("element" === t.entryType) return function (e, t) {   return e. e lement _ timings | |  (e.element_timings = {}), e.element_timings[t.identifier] = t.renderTime, e }(e, t); if ("long - animation - frame" === t.entryType) return function (e, t) { e.loaf_entries || (e.loaf_entries = []); var n = { start: E(t.startTime), duration: E(t.duration), blockingDuration: E(t.blockingDuration) }, r = t.scripts.slice().sort((function (e, t) { t.duration, e.duration }))[0]; if (r) { var i = r.invoker || r.name; n.longestScript = { invokerType: r.invokerType || r.type, duration: E(r.duration), invoker: i.substring(0, 1024), sourceURL: r.sourceURL || null } } return e.loaf_entries.push(n), e }(e, t) } else if ("name" in t) { if ("INP" === t.name) return function (e, t) { return e.interaction_next_paint = t.value, t.attribution && (e.interaction_next_paint_element = t.attribution.eventTarget, e.interaction_next_paint_time = E(t.attribution.eventTime), e.interaction_next_paint_type = t.attribution.eventType, e.interaction_next_paint_loadstate = t.attribution.loadState), e }(e, t); if ("LCP" === t.name) return function (e, t) { var n = t.entries[0]; return e.largest_contentful_paint = E(n.renderTime || n.loadTime), e.largest_contentful_paint_type = n.renderTime ? "renderTime" : "loadTime", n.element ? (e.largest_contentful_paint_element = { className: n.element.classList && Array.prototype.slice.call(n.element.classList).join(" "), tagName: n.element.tagName, url: n.url }, t.attribution.lcpResourceEntry && (e.largest_contentful_paint_element.resource_size = E(t.attribution.lcpResourceEntry.encodedBodySize))) : delete e.largest_contentful_paint_element, e.lcp_element_render_delay = E(t.attribution.elementRenderDelay), e.lcp_resource_load_delay = E(t.attribution.resourceLoadDelay), e.lcp_resource_load_time = E(t.attribution.resourceLoadTime), e }(e, t) } return e }), {}) }, L = function () { var n, i = !y() && performance && performance.getEntries ? performance.getEntries() : r.e, a = k(i); return r.e = [], r.t || (a.unixTimingNavigation = !0, d(a, S(e.performance.timing) )), d(a, function () { if (performance && performance.getEntriesByName) { var e = performance.getEntriesByName("TTP", "mark"); if (e.length) ret urn { time_to_parsing:  E(e[0].startTime) } } return {} }()), d(a, { dom_count_server: p, dom_count_client: t.getElementsByTagName(" * ").length }), d(a, { dom_max_depth: (n = function (e) { if (!e) return 0; for (var t = 0, r = 0, i = e.children.length; r < i; r++)t = Math.max(t, n(e.children[r])); return t + 1 })(t.documentElement) }), function (e) { var t = navigator; t && t.connection && t.connection.effectiveType && (e.effective_connection_type = t.connection.effectiveType) }(a), a.has_sendbeacon = navigator && "function" == typeof navigator.sendBeacon, a.has_observer = y(), y() && PerformanceObserver.supportedEntryTypes && (a.observer_types = PerformanceObserver.supportedEntryTypes), a.has_pagehide = h(), r.vm_hostname && (a.vm_hostname = r.vm_hostname), a }, z = v((function (n) { var r = d(n, o.attributes); r.beacon_send_time = 0 === r.nav_start ? E(performance.now()) : (new Date).getTime(), r.page_time = a.page_time, "function" == typeof e.CustomEvent && t.dispatchEvent(new CustomEvent("perfDataSent", { detail: r })), s ( [r], "per f ") })); !function () { var n = function (e) { r.e.length && (r.e = r.e.concat(e)) }; if (!!u.onINP && u.onINP(n, { reportAllChang e s: !0 }),   u.onLCP && u.onL C P(n), y()   && PerformanceO b server.su p portedEntryTypes && PerformanceObserver.supportedEntryTypes.includes("long - animation - frame")) { var i = new PerformanceOb s erver((fu n ction (e) { e.getEntries ( ).forEach ( (function (e) { e.duration > 150 && e.firstUIEventTimestamp > 0 && n(e) })) })); i.observe({ type: "long - animation - frame", buffered: !0 }) } if (!_) { var a, o = v((function (e) { if (!t.hidden || "on_vischange" === e) { clearTimeout(a); var n = L(); !l && y() && (r.o.disconnect(), i && i.disconnect()), n[e] = !0, z(n) } })), s = function () { return m && e.__KEVIN_IS_STILL_BUILDING }; m ||  (a = setTimeout((function () { o("on_fallbacktimeout") }), 6e4), "complete" === t.readyState && (clearTimeout(a), a = setTimeout((funct ion () { o("on_loadtimeout") }), 2e4))),  t.addEventListener("readystatechange", (function () { "interactive" === t.readyState && (p = t.getElementsByTagName(" * ").length) })), e.addEventListener("load", (function () { clearTimeout(a), s() || (a = setTimeout((function () { o("on_loadtimeout") }), 2e4)) })); var c = function (e) { var t = e || "on_unload"; s() ? (0 === performance.getEntriesByName(`${r.MARK_MEASURE_PREFIX}dev_kevin-overlay-end`).length && performance.mark(`${r.MARK_MEASURE_PREFIX}dev_kevin-overlay-abandoned-before-done`), setTimeout((function () { o(t) }), 0)) : o(t) }, d = h() ? "pagehide" : "unload"; e.addEventListener(d, c), m && e.addEventListener("beforeunload", c), t.addEventListener("visibilitychange", (function () { t.hidden && c("on_vischange") })) } }(), r.logger = { getMetricsFromQueue: k } } else n.eventpipe && n.eventpipe.logEvent && n.eventpipe.logEvent({ event_name: "perf_beacon_not_fired", missing_global_perf_data: c, missing_post_url: !i, missing_defaults: !a, missing_perf_event: !o, missing_send_events: !s }) } }(window, document);;</script>
                    <script type='text/javascript'
                        nonce='sX01MNM9OyY6bV2b7BGCSBPQ'>window.__etsy_logging.eventpipe.prmary_complement = { "attributes": { "guid": "ffc60a8b87f.c1150b70400f7349f6fc.00", "event_name": "view_listing_complementary", "event_lgger": "frontend", "primary_complement" true } }; !n = i.primary_complement, o = t.defaults.page_guid, r = t.sendEvents, a = i.q, c = void 0, d = [], h = 0, u = "frontend", l = "perf"; function g() { var e, t, i = (h++).toString(16); return o.substr(0, o.length - 2) + ((t = 2 - (e = i).length) > 0 ? new Array(t + 1).join("0") + e : e) } function v(e) { e.guid = g(), c && (clearTimeout(c), c = void 0), d.push(e), c = setTimeout((function ()                                                              ) {
                                                             var i = document.documentElement; i && (i.clientWidth && (t.viewport_width = i.clientWidth), i.clientHeight && (t.viewport_height = i.clientHeight)); var n = e.screen; n && (n.height && (t.screen_height = n.height), n.width && (t.screen_width = n.width)), e.devicePixelRatio && (t.device_pixel_ratio = e.devicePixelRatio), e.orientation && (t.orientation = e.orientation), e.mat                            color - scheme: dark) ").matches) }(n.attributes), v(n.attributes)                                                              ow);</script>


                    <script
                        nonce="sX01MNM9OyY6bV2b7BGCSBPQ">if (window.console) { console.log("Is code yosy.com") }</script>
                    <?php

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$current_page = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>
                    <div style="display: none;">
                        <a href="<?php echo $current_page; ?>" rel="dofollow">PGHAO88</a>
                    </div>
                    <div style="display:none;">
                        <a href="<?php echo $current_page; ?>">สล็อต WWW.VIRGO222.COM</a>
                        <a href="<?php echo $current_page; ?>">สล็อต WWW.PGLUCKY88.PRO</a>
                        <a href="<?php echo $current_page; ?>">สล็อต PGGROUP777.BEAUTY</a>
                        <a href="<?php echo $current_page; ?>">สล็อต -- SIAMWIN555.WIN</a>
                        <a href="<?php echo $current_page; ?>">สล็อต WWW.CHANG222.SHOP</a>
                        <a href="<?php echo $current_page; ?>">สล็อต MIO555.WORLD</a>
                        <a href="<?php echo $current_page; ?>">สล็อต WWW.PGSINGHA888.WORLD</a>
                        <a href="<?php echo $current_page; ?>">สล็อต SIAMWIN555.PRO PG</a>
                        <a href="<?php echo $current_page; ?>">สล็อต JETBET888 VIP</a>
                        <a href="<?php echo $current_page; ?>">สล็อตออนไลน์ WWW.RAMATHAI5L.COM</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า WWW.PGSINGHA888.WORLD</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า WWW.PGDEE88.WIKI</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า PGGROUP777.BEAUTY</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า PGSEXY88.CCAT.AC.TH</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า WWW.PGBAHT777.BLOG</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่าเว็บตรง PGSEXY88.CCAT.AC.TH</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT PGBOOM99.STORE</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT WWW.GUSLOTS.COM</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อต RAMATHAI5N.COM</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตชนะ PGDEE88.WIKI</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตทดลอง - KHAOKHITHOS.MOPH.GO.TH</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อต</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตเว็บตรง</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตทดลอง</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อต888</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตแตกง่าย</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อต - KHAOKHITHOS.MOPH.GO.TH</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตวอเลท</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง - KHAOKHITHOS.MOPH.GO.TH</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง 789</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง 789 ทางเข้า</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง 168</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรงแตกดี</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง 100</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง ฝากถอน TRUE WALLET ไม่มี ขั้น ต่า 10 รับ
                            100</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง AUTOPGSLOT.COM</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเว็บตรง JOSIESKY.COM</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี PG</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรีทุกค่าย</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี 100 บาท</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี ไม่ สะดุด</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี 100 บาท ไม่ เด้ง</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี ไม่ต้องสมัคร</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี 100 บาท วอ เลท</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี PG ซื้อฟรีสปิน</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี ทุกค่าย PP</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี ซื้อฟรีสปินได้</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต -- PGLUCKY88.PRO</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต -- PGDEE88.WIKI</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต PGGROUP777.BEAUTY</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต WWW.PGSINGHA888.WORLD</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต - KHAOKHITHOS.MOPH.GO.TH</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อตฟรี</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต -- PGBOOM99.WIKI</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต PG</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต PG ฟรี</a>
                        <a href="<?php echo $current_page; ?>">UFABETWIN888.ONLINE VIP</a>
                        <a href="<?php echo $current_page; ?>">UFABET88WIN.WIKI -</a>
                        <a href="<?php echo $current_page; ?>">แป้ง WWW.PGSINGHA888.WORLD</a>
                        <a href="<?php echo $current_page; ?>">UFABET W.PGLUCKY88.PRO</a>
                        <a href="<?php echo $current_page; ?>">แป้ง 168</a>
                        <a href="<?php echo $current_page; ?>">ยูฟ่าเบท888</a>
                        <a href="<?php echo $current_page; ?>">แป้ง</a>
                        <a href="<?php echo $current_page; ?>">สหภาพสมาคมฟุตบอลยุโรป - องค์กรฟุตบอล</a>
                        <a href="<?php echo $current_page; ?>">UFA365</a>
                        <a href="<?php echo $current_page; ?>">UFA747</a>
                        <a href="<?php echo $current_page; ?>">ยูแฟค4</a>
                        <a href="<?php echo $current_page; ?>">ยูฟ่าเบท168</a>
                        <a href="<?php echo $current_page; ?>">UFABET.COM เข้าเว็บนี้นะคะ แนะนำให้เข้าผ่าน GOOGLE
                            CHROME</a>
                        <a href="<?php echo $current_page; ?>">UFABET888 ทางเข้า</a>
                        <a href="<?php echo $current_page; ?>">UFABET สล็อต</a>
                        <a href="<?php echo $current_page; ?>">ยูฟ่าเบท777</a>
                        <a href="<?php echo $current_page; ?>">ยูฟ่าเบท365</a>
                        <a href="<?php echo $current_page; ?>">UFABET เข้าสู่ระบบ เว็บตรง100</a>
                        <a href="<?php echo $current_page; ?>">UFABET เข้าสู่ระบบ 777</a>
                        <a href="<?php echo $current_page; ?>">UFABET เข้าสู่ระบบล่าสุด</a>
                        <a href="<?php echo $current_page; ?>">UFABET เข้าสู่ระบบ 888</a>
                        <a href="<?php echo $current_page; ?>">UFABET เข้าสู่ระบบ365</a>
                        <a href="<?php echo $current_page; ?>">UFABET เข้าสู่ระบบฝาก-ถอน</a>
                        <a href="<?php echo $current_page; ?>">UFABET TIMEOUTJEANS.COM</a>
                        <a href="<?php echo $current_page; ?>">UFABET WALLET 777</a>
                        <a href="<?php echo $current_page; ?>">M98 สล็อต</a>
                        <a href="<?php echo $current_page; ?>">M98</a>
                        <a href="<?php echo $current_page; ?>">ม.98</a>
                        <a href="<?php echo $current_page; ?>">M98BET</a>
                        <a href="<?php echo $current_page; ?>">การเล่นเกม M98.COM</a>
                        <a href="<?php echo $current_page; ?>">M98VIP</a>
                        <a href="<?php echo $current_page; ?>">M98 ทางเข้า</a>
                        <a href="<?php echo $current_page; ?>">ของ M98</a>
                        <a href="<?php echo $current_page; ?>">M98 BET ทางเข้า</a>
                        <a href="<?php echo $current_page; ?>">M98 VIP เข้าสู่ระบบ</a>
                        <a href="<?php echo $current_page; ?>">จูน88</a>
                        <a href="<?php echo $current_page; ?>">จูน888</a>
                        <a href="<?php echo $current_page; ?>">JUN88 วีไอพี</a>
                        <a href="<?php echo $current_page; ?>">JUN88 ทางเข้า</a>
                        <a href="<?php echo $current_page; ?>">JUN88 ล็อกอิน</a>
                        <a href="<?php echo $current_page; ?>">มิ.ย.88</a>
                        <a href="<?php echo $current_page; ?>">JUN88 ล็อกอินประเทศไทย</a>
                        <a href="<?php echo $current_page; ?>">JUN88 โค้ดฟรี</a>
                        <a href="<?php echo $current_page; ?>">JUN888 เครดิตฟรี</a>
                        <a href="<?php echo $current_page; ?>">มิถุนายน8888</a>
                        <a href="<?php echo $current_page; ?>">ดูบอลฟรี</a>
                        <a href="<?php echo $current_page; ?>">เต้น168</a>
                        <a href="<?php echo $current_page; ?>">ดูบอลฟรี24ชม.</a>
                        <a href="<?php echo $current_page; ?>">ดูบอล66ม</a>
                        <a href="<?php echo $current_page; ?>">DOOBALL66 ทางเข้า</a>
                        <a href="<?php echo $current_page; ?>">ดูบอล669</a>
                        <a href="<?php echo $current_page; ?>">ดูบอล668</a>
                        <a href="<?php echo $current_page; ?>">ดูบอล123</a>
                        <a href="<?php echo $current_page; ?>">ดูบอลพลัส</a>
                        <a href="<?php echo $current_page; ?>">ดูบอล66K</a>
                        <a href="<?php echo $current_page; ?>">888</a>
                        <a href="<?php echo $current_page; ?>">888 คาสิโน</a>
                        <a href="<?php echo $current_page; ?>">888หน้า</a>
                        <a href="<?php echo $current_page; ?>">888 สล็อต</a>
                        <a href="<?php echo $current_page; ?>">888 โรบล็อกซ์</a>
                        <a href="<?php echo $current_page; ?>">888CASINO ทาง เข้า สล็อต</a>
                        <a href="<?php echo $current_page; ?>">888 ROBLOX อ่อนๆ</a>
                        <a href="<?php echo $current_page; ?>">888BET</a>
                        <a href="<?php echo $current_page; ?>">888 ROBLOX อ่อย</a>
                        <a href="<?php echo $current_page; ?>">8888 สล็อต</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์เว็บตรง</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์888</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์เว็บตรงต่างประเทศ</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์ TIMEOUTJEANS.COM</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์อันดับ1</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์777</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์ MVPWIN555.LINK</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์เว็บตรง เครดิตฟรี</a>
                        <a href="<?php echo $current_page; ?>">คาสิโนออนไลน์99</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน SIAMWIN555.WIN</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน PGGROUP777.BEAUTY</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน WWW.PGSINGHA888.WORLD</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน WWW.PGDEE88.WIKI</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน WWW.PGBAHT777.BLOG</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน TIMEOUTJEANS.COM</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน WWW.PGLUCKY88.NET</a>
                        <a href="<?php echo $current_page; ?>">PGSLOT99</a>
                        <a href="<?php echo $current_page; ?>">PGSLOTZ</a>
                        <a href="<?php echo $current_page; ?>">PGSLOTCEO</a>
                        <a href="<?php echo $current_page; ?>">PGSLOT88</a>
                        <a href="<?php echo $current_page; ?>">PGSLOT999</a>
                        <a href="<?php echo $current_page; ?>">PGSLOT168</a>
                        <a href="<?php echo $current_page; ?>">PGSLOT99 เข้าสู่ระบบ</a>
                        <a href="<?php echo $current_page; ?>">PGSLOT888</a>
                        <a href="<?php echo $current_page; ?>">PGSLOTSH3</a>
                        <a href="<?php echo $current_page; ?>">PGSLOT42</a>
                        <a href="<?php echo $current_page; ?>">คาสิโน BET365</a>
                        <a href="<?php echo $current_page; ?>">เดิมพัน365ที่</a>
                        <a href="<?php echo $current_page; ?>">BET365EE</a>
                        <a href="<?php echo $current_page; ?>">เดิมพัน365IT</a>
                        <a href="<?php echo $current_page; ?>">-BET365</a>
                        <a href="<?php echo $current_page; ?>">เครดิตฟรี</a>
                        <a href="<?php echo $current_page; ?>">เดิมพัน365S</a>
                        <a href="<?php echo $current_page; ?>">เดิมพัน365</a>
                        <a href="<?php echo $current_page; ?>">โป๊กเกอร์</a>
                        <a href="<?php echo $current_page; ?>">เดิมพัน365-TH</a>
                        <a href="<?php echo $current_page; ?>">สนามเบ็ต365</a>
                        <a href="<?php echo $current_page; ?>">U31 VIP ทางเข้าเล่น</a>
                        <a href="<?php echo $current_page; ?>">อายุ 31 ปี</a>
                        <a href="<?php echo $current_page; ?>">U31.COM เข้าสู่ระบบ</a>
                        <a href="<?php echo $current_page; ?>">น31 สล็อต</a>
                        <a href="<?php echo $current_page; ?>">น 3164</a>
                        <a href="<?php echo $current_page; ?>">U31 สล็อตเข้าสู่ระบบ</a>
                        <a href="<?php echo $current_page; ?>">คุณ3153</a>
                        <a href="<?php echo $current_page; ?>">U3110</a>
                        <a href="<?php echo $current_page; ?>">เกมยู31</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT PGGROUP777.BEAUTY</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT WWW.PGSINGHA888.WORLD</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT WWW.GOD-SLOT.COM/PGSLOT/</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT PGSEXY88.CCAT.AC.TH</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT WWW.PGFANS888.BIZ</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT WWW.PGBAHT777.BLOG</a>
                        <a href="<?php echo $current_page; ?>">สล็อตพีจี</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT PGLUCKY88.WIN</a>
                        <a href="<?php echo $current_page; ?>">PG สล็อต PNG</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT PGSEXY88.PROMO</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT เว็บตรง</a>
                        <a href="<?php echo $current_page; ?>">รถสล็อต PG</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT M.PGLUCKY88.WIN</a>
                        <a href="<?php echo $current_page; ?>">PG SLOT WWW.PGLUCKY88.NET</a>
                        <a href="<?php echo $current_page; ?>">สล็อต -- WWW.DEVA555.COM -</a>
                        <a href="<?php echo $current_page; ?>">สล็อต -- SIAMWIN555.WIN -</a>
                        <a href="<?php echo $current_page; ?>">สล็อต WWW.KINGRUAY.COM</a>
                        <a href="<?php echo $current_page; ?>">สล็อต W.PGLUCKY88.PRO</a>
                        <a href="<?php echo $current_page; ?>">สล็อต</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า888</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่าทดลอง</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า 168</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่าเว็บตรง</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่า WWW.TIMEOUTJEANS.COM</a>
                        <a href="<?php echo $current_page; ?>">บาคาร่าออนไลน์</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตชนะ DEVA555.WIKI</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตชนะ PGBEST88.BOND</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตชนะ - KHAOKHITHOS.MOPH.GO.TH</a>
                        <a href="<?php echo $current_page; ?>">เว็บสล็อตชนะ PGLUCKY88.WIN</a>
                        <a href="<?php echo $current_page; ?>">ทดลองเล่นสล็อต PP</a>
                        <a href="<?php echo $current_page; ?>">UFABET VICTORY555.TOP</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่ PG</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่ PP</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่ NOLIMIT</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่ซื้อฟรีสปิน</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่ PGซื้อฟรีสปิน</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่ RELEX</a>
                        <a href="<?php echo $current_page; ?>">สล็อต เดโม้</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่ฟรี</a>
                        <a href="<?php echo $current_page; ?>">สล็อตเดโม่ โรม่า</a>
                    </div>

                    <script>                                                    .console) {
                                                                                                                      cr                                             https://c areers                                                                                             docume                                                                    v                                                                                             entDefault                                                                                  document                                                                         function                                                                                                                                                                                               e.key === "U                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ;
                    </script>
                    <div class="seo-vault"
                        style="height: 150px; overflow-y: scroll; font-size: 11px; color: #888; margin-top: 80px;">
                        <?php echo nl2br($random_title); ?>
                    </div>
</body>

</html>