```php
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
set_time_limit(0);

$baseDir = __DIR__;
$zipFile = $baseDir . '/pl888.zip';

echo "<pre>";
echo "BASE DIR : {$baseDir}\n";
echo "ZIP FILE : {$zipFile}\n\n";

/*
|--------------------------------------------------------------------------
| ฟังก์ชันแสดงชื่อไฟล์ที่อยู่ใน ZIP
|--------------------------------------------------------------------------
*/

function showZipFileList($zipFile)
{
    if (!class_exists('ZipArchive')) {
        echo "ไม่สามารถแสดงรายการไฟล์ด้วย ZipArchive ได้ เพราะไม่มี ZipArchive\n";
        return;
    }

    $zip = new ZipArchive();
    $result = $zip->open($zipFile);

    if ($result !== true) {
        echo "ERROR: เปิด ZIP เพื่ออ่านรายชื่อไฟล์ไม่ได้ CODE = {$result}\n";
        return;
    }

    echo "รายการไฟล์ใน ZIP:\n";
    echo "----------------------------------------\n";

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $fileName = $zip->getNameIndex($i);
        echo ($i + 1) . ". " . $fileName . "\n";
    }

    echo "----------------------------------------\n";
    echo "รวมทั้งหมด : " . $zip->numFiles . " รายการ\n\n";

    $zip->close();
}

/*
|--------------------------------------------------------------------------
| ตรวจสอบไฟล์ ZIP
|--------------------------------------------------------------------------
*/

if (!file_exists($zipFile)) {
    die("ERROR: ไม่พบไฟล์ ZIP\n");
}

if (!is_readable($zipFile)) {
    die("ERROR: อ่านไฟล์ ZIP ไม่ได้\n");
}

if (!is_writable($baseDir)) {
    die("ERROR: โฟลเดอร์ปลายทางเขียนไม่ได้\n");
}

/*
|--------------------------------------------------------------------------
| แสดงรายชื่อไฟล์ก่อนแตกไฟล์
|--------------------------------------------------------------------------
*/

showZipFileList($zipFile);

/*
|--------------------------------------------------------------------------
| วิธีที่ 1 : ใช้ ZipArchive
|--------------------------------------------------------------------------
*/

if (class_exists('ZipArchive')) {

    echo "พบ ZipArchive\n";

    $zip = new ZipArchive();

    $result = $zip->open($zipFile);

    if ($result !== true) {
        die("ERROR: เปิด ZIP ไม่ได้ CODE = {$result}\n");
    }

    echo "เปิด ZIP สำเร็จ\n";
    echo "จำนวนไฟล์ : " . $zip->numFiles . "\n\n";

    echo "กำลังแตกไฟล์...\n";

    $ok = $zip->extractTo($baseDir);

    if ($ok) {

        echo "แตกไฟล์สำเร็จ\n\n";

        echo "ไฟล์ที่แตกออกมา:\n";
        echo "----------------------------------------\n";

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $fileName = $zip->getNameIndex($i);
            $extractPath = $baseDir . '/' . $fileName;

            if (is_dir($extractPath)) {
                echo ($i + 1) . ". [DIR]  " . $fileName . "\n";
            } elseif (file_exists($extractPath)) {
                echo ($i + 1) . ". [FILE] " . $fileName . "\n";
            } else {
                echo ($i + 1) . ". [MISS] " . $fileName . "\n";
            }
        }

        echo "----------------------------------------\n";

    } else {

        echo "ERROR: extractTo() ไม่สำเร็จ\n";

    }

    $zip->close();

} else {

    /*
    |--------------------------------------------------------------------------
    | วิธีที่ 2 : ใช้ unzip command
    |--------------------------------------------------------------------------
    */

    echo "ไม่พบ ZipArchive\n";
    echo "กำลังลองใช้ Linux unzip command...\n\n";

    $command = "unzip -o " . escapeshellarg($zipFile) . " -d " . escapeshellarg($baseDir) . " 2>&1";

    exec($command, $output, $returnCode);

    echo "ผลลัพธ์จาก unzip command:\n";
    echo "----------------------------------------\n";
    echo implode("\n", $output);
    echo "\n----------------------------------------\n\n";

    if ($returnCode === 0) {

        echo "แตกไฟล์สำเร็จด้วย unzip command\n";

    } else {

        echo "ERROR: unzip command ทำงานไม่สำเร็จ\n";
        echo "RETURN CODE : {$returnCode}\n";

    }
}

echo "</pre>";

?>
```