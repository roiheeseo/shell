<?php
date_default_timezone_set('Asia/Bangkok');

$currentDate = date('Y-m-d');
$lastmod     = date('Y-m-d');

$dataFile = 'hajar.txt';
$baseUrl  = 'https://knowledgebase.cmru.ac.th/function/?gyg=';

// ===== ตรวจสอบไฟล์ =====
if (!file_exists($dataFile)) {
    die("ไม่พบไฟล์ $dataFile");
}

$lines = file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
if (!$lines) {
    die("hajar.txt ไม่มีข้อมูล");
}

// ===== ตั้งค่าการแบ่งไฟล์ =====
$limitPerFile = 18000;
$fileCount    = 1;
$urlCount     = 0;
$sitemapFiles = [];

// ===== เปิดไฟล์แรก =====
$currentSitemapName = "sitemap-{$fileCount}.xml";
$sitemapFiles[] = $currentSitemapName;

$sitemapFile = fopen($currentSitemapName, 'w');
if (!$sitemapFile) {
    die("ไม่สามารถสร้างไฟล์ sitemap ได้");
}

fwrite($sitemapFile, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
fwrite($sitemapFile, "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n");

// ===== วนลูปสร้าง URL =====
foreach ($lines as $slug) {

    $slug = trim($slug);
    if ($slug === '') continue;

    // ถ้าครบ 20,000 → ปิดไฟล์เดิม เปิดไฟล์ใหม่
    if ($urlCount >= $limitPerFile) {

        fwrite($sitemapFile, "</urlset>");
        fclose($sitemapFile);

        $fileCount++;
        $urlCount = 0;

        $currentSitemapName = "sitemap-{$fileCount}.xml";
        $sitemapFiles[] = $currentSitemapName;

        $sitemapFile = fopen($currentSitemapName, 'w');
        fwrite($sitemapFile, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        fwrite($sitemapFile, "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n");
    }

    $sitemapLink = $baseUrl . rawurlencode($slug);

    fwrite($sitemapFile, "  <url>\n");
    fwrite($sitemapFile, "    <loc>" . htmlspecialchars($sitemapLink, ENT_QUOTES | ENT_XML1, 'UTF-8') . "</loc>\n");
    fwrite($sitemapFile, "    <lastmod>{$lastmod}</lastmod>\n");
    fwrite($sitemapFile, "    <changefreq>weekly</changefreq>\n");
    fwrite($sitemapFile, "    <priority>0.8</priority>\n");
    fwrite($sitemapFile, "  </url>\n");

    $urlCount++;
}

// ===== ปิดไฟล์สุดท้าย =====
fwrite($sitemapFile, "</urlset>");
fclose($sitemapFile);


// =================================================
// สร้าง sitemap_index.xml
// =================================================

$indexFileName = "sitemap_index.xml";
$indexFile = fopen($indexFileName, 'w');

fwrite($indexFile, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
fwrite($indexFile, "<sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n");

foreach ($sitemapFiles as $file) {

    $loc = "https://knowledgebase.cmru.ac.th/function/" . $file;

    fwrite($indexFile, "  <sitemap>\n");
    fwrite($indexFile, "    <loc>{$loc}</loc>\n");
    fwrite($indexFile, "    <lastmod>{$lastmod}</lastmod>\n");
    fwrite($indexFile, "  </sitemap>\n");
}

fwrite($indexFile, "</sitemapindex>");
fclose($indexFile);


// =================================================
// สร้าง robots.txt
// =================================================

$robotsContent  = "User-agent: *\n";
$robotsContent .= "Allow: /\n";
$robotsContent .= "Sitemap: https://knowledgebase.cmru.ac.th/function/sitemap_index.xml\n";

file_put_contents("robots.txt", $robotsContent);


// ===== เสร็จ =====
echo "สร้าง sitemap สำเร็จ\n";
echo "จำนวนไฟล์ย่อย: " . count($sitemapFiles) . " ไฟล์\n";
echo "ไฟล์หลัก: sitemap_index.xml\n";
?>
