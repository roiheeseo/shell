<?php
function getFileRowCount($filename)
{
    $file = fopen($filename, "r");
    $rowCount = 0;

    while (!feof($file)) {
        fgets($file);
        $rowCount++;
    }

    fclose($file);

    return $rowCount;
}

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

if (isset($fullUrl)) {
    $parsedUrl = parse_url($fullUrl);
    $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
    $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
    $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
    $baseUrl = $scheme . "://" . $host . $path;

    $urlAsli = str_replace("get-sitemap.php", "", $baseUrl);

    $judulFile = "siam.txt";
    if (!file_exists($judulFile)) {
        die("File siam.txt tidak ditemukan");
    }

    $jumlahBaris = getFileRowCount($judulFile);
    $fileLines = file($judulFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    $maxPerSitemap = 15000;
    $chunks = array_chunk($fileLines, $maxPerSitemap);

    date_default_timezone_set('Asia/Bangkok');
    $currentTime = date('Y-m-d\TH:i:sP');

    $sitemapFiles = [];

    foreach ($chunks as $chunkIndex => $chunkLines) {
        $sitemapNumber = $chunkIndex + 1;
        $sitemapName = "sitemap_th" . $sitemapNumber . ".xml";
        $sitemapFiles[] = $sitemapName;

        $sitemapFile = fopen($sitemapName, "w");
        fwrite($sitemapFile, '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL);
        fwrite($sitemapFile, '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL);

        foreach ($chunkLines as $judul) {
            $sitemapLink = $urlAsli . '?siam=' . urlencode($judul);

            fwrite($sitemapFile, '  <url>' . PHP_EOL);
            fwrite($sitemapFile, '    <loc>' . htmlspecialchars($sitemapLink, ENT_QUOTES | ENT_XML1, 'UTF-8') . '</loc>' . PHP_EOL);
            fwrite($sitemapFile, '    <lastmod>' . $currentTime . '</lastmod>' . PHP_EOL);
            fwrite($sitemapFile, '    <changefreq>daily</changefreq>' . PHP_EOL);
            fwrite($sitemapFile, '  </url>' . PHP_EOL);
        }

        fwrite($sitemapFile, '</urlset>' . PHP_EOL);
        fclose($sitemapFile);
    }

    $sitemapIndexFile = fopen("sitemap_index.xml", "w");
    fwrite($sitemapIndexFile, '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL);
    fwrite($sitemapIndexFile, '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL);

    foreach ($sitemapFiles as $sitemapName) {
        fwrite($sitemapIndexFile, '  <sitemap>' . PHP_EOL);
        fwrite($sitemapIndexFile, '    <loc>' . htmlspecialchars($urlAsli . $sitemapName, ENT_QUOTES | ENT_XML1, 'UTF-8') . '</loc>' . PHP_EOL);
        fwrite($sitemapIndexFile, '    <lastmod>' . $currentTime . '</lastmod>' . PHP_EOL);
        fwrite($sitemapIndexFile, '  </sitemap>' . PHP_EOL);
    }

    fwrite($sitemapIndexFile, '</sitemapindex>' . PHP_EOL);
    fclose($sitemapIndexFile);

    $robotsTxt = "User-agent: *" . PHP_EOL;
    $robotsTxt .= "Allow: /" . PHP_EOL;
    $robotsTxt .= "Sitemap: " . $urlAsli . "sitemap_index.xml" . PHP_EOL;
    file_put_contents('robots.txt', $robotsTxt);

    echo "ROIHEE SEO";
} else {
    echo "https://google.com.";
}
?>