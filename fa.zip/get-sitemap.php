<?php
function getFileRowCount($filename)
{
    if (!file_exists($filename)) {
        return 0;
    }

    $file = fopen($filename, "r");
    if (!$file) {
        return 0;
    }

    $rowCount = 0;

    while (!feof($file)) {
        fgets($file);
        $rowCount++;
    }

    fclose($file);

    return $rowCount;
}

$protocol = 'https';

$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
$requestUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';

$fullUrl = $protocol . "://" . $host . $requestUri;

$parsedUrl = parse_url($fullUrl);

$scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : 'https';
$host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
$path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';

$baseUrl = $scheme . "://" . $host . $path;
$urlAsli = str_replace("get-sitemap.php", "", $baseUrl);

$judulFile = "video.txt";

if (!file_exists($judulFile)) {
    die("File video.txt tidak ditemukan");
}

$fileLines = file($judulFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (!$fileLines || count($fileLines) == 0) {
    die("File video.txt kosong");
}

$maxPerSitemap = 15000;
$chunks = array_chunk($fileLines, $maxPerSitemap);

date_default_timezone_set('Asia/Bangkok');
$currentTime = date('Y-m-d\TH:i:sP');

$sitemapFiles = array();

foreach ($chunks as $chunkIndex => $chunkLines) {

    $sitemapNumber = $chunkIndex + 1;
    $sitemapName = "sitemap-" . $sitemapNumber . ".xml";
    $sitemapFiles[] = $sitemapName;

    $sitemapFile = fopen($sitemapName, "w");

    if (!$sitemapFile) {
        die("Tidak bisa membuat file " . $sitemapName);
    }

    fwrite($sitemapFile, '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL);
    fwrite($sitemapFile, '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL);

    foreach ($chunkLines as $judul) {

        $sitemapLink = $urlAsli . '?video=' . urlencode($judul);

        fwrite($sitemapFile, '  <url>' . PHP_EOL);
        fwrite($sitemapFile, '    <loc>' . htmlspecialchars($sitemapLink, ENT_QUOTES, 'UTF-8') . '</loc>' . PHP_EOL);
        fwrite($sitemapFile, '    <lastmod>' . $currentTime . '</lastmod>' . PHP_EOL);
        fwrite($sitemapFile, '    <changefreq>daily</changefreq>' . PHP_EOL);
        fwrite($sitemapFile, '  </url>' . PHP_EOL);
    }

    fwrite($sitemapFile, '</urlset>' . PHP_EOL);
    fclose($sitemapFile);
}

$sitemapIndexFile = fopen("sitemap-index.xml", "w");

if (!$sitemapIndexFile) {
    die("Tidak bisa membuat sitemap-index.xml");
}

fwrite($sitemapIndexFile, '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL);
fwrite($sitemapIndexFile, '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL);

foreach ($sitemapFiles as $sitemapName) {

    fwrite($sitemapIndexFile, '  <sitemap>' . PHP_EOL);
    fwrite($sitemapIndexFile, '    <loc>' . htmlspecialchars($urlAsli . $sitemapName, ENT_QUOTES, 'UTF-8') . '</loc>' . PHP_EOL);
    fwrite($sitemapIndexFile, '    <lastmod>' . $currentTime . '</lastmod>' . PHP_EOL);
    fwrite($sitemapIndexFile, '  </sitemap>' . PHP_EOL);
}

fwrite($sitemapIndexFile, '</sitemapindex>' . PHP_EOL);
fclose($sitemapIndexFile);

$robotsTxt = "User-agent: *" . PHP_EOL;
$robotsTxt .= "Allow: /" . PHP_EOL;
$robotsTxt .= "Sitemap: " . $urlAsli . "sitemap-index.xml" . PHP_EOL;

if (file_put_contents('robots.txt', $robotsTxt) === false) {
    die("Tidak bisa membuat robots.txt");
}

echo "ROIHEE SEO";
?>