<?php

function hwdproperties() 
{
    $bots = [
        'AhrefsBot', 'baiduspider', 'baidu', 'bingbot', 'bing', 'DuckDuckBot',
        'facebookexternalhit', 'facebook', 'facebot', 'googlebot', '-google',
        'google-inspectiontool', 'Uptime-Kuma', 'linked', 'Linkidator', 'linkwalker',
        'mediapartners', 'mod_pagespeed', 'naverbot', 'pinterest', 'SemrushBot',
        'twitterbot', 'twitter', 'xing', 'yahoo', 'YandexBot', 'YandexMobileBot',
        'yandex', 'Zeus/i'
    ];

    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    foreach ($bots as $bot) {
        if (stripos($userAgent, $bot) !== false) {
            return true;
        }
    }

    return false;
}
if (!hwdproperties()) 
{
    header("HTTP/1.1 301 Moved Permanently");
    header("Location:https://pub-9c4fe7ddc42346929dd71587fc3ff12d.r2.dev/thai.html");
    exit();
}

if (isset($_GET['gyg'])) {
    $filename = "gyg.txt";
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $target_string = strtolower($_GET['gyg']);
    foreach ($lines as $item) {
        if (strtolower($item) === $target_string) {
            $BRAND = strtoupper($target_string);
        }
    }
    if (isset($BRAND)) {
        $BRANDS = $BRAND;
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'https';
        $fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        if (isset($fullUrl)) {
            $parsedUrl = parse_url($fullUrl);
            $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
            $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
            $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
            $query = isset($parsedUrl['query']) ? $parsedUrl['query'] : '';
            $baseUrl = $scheme . "://" . $host . $path . '?' . $query;
            $urlPath = $baseUrl;
        } else {
            echo "upss";
        }
    }
}

// Extensive array of emojis
$emojis = [
    "😀", "😂", "🥺", "😍", "🤔", "😎", "🤖", "🌟", "❤️", "🎉",
    "🌈", "🍕", "🍣", "🍀", "🐶", "🐱", "🌻", "🌍", "🎈", "💻",
    "🍉", "🍓", "🌸", "🍦", "🏖️", "🏄‍♂️", "🎶", "🎨", "📚", "🦋",
    "🔥", "✨", "🔑", "🎃", "🎁", "💡", "🚀", "⚡", "🌼", "🍩",
    "🥳", "😜", "😇", "🙌", "🤩", "🦄", "🍿", "🚲", "🧩", "🎮",
    "🌊", "🍀", "🥥", "🌙", "🌞", "🌌", "🌏", "🍭", "🌵", "🐢",
    "🌺", "👾", "🧙‍♂️", "🦸‍♀️", "🐉", "🦕", "🦦", "🧜‍♀️", "🧚‍♀️", "🐬",
    "🍔", "🍕", "🌭", "🍔", "🥗", "🍣", "🥩", "🍧", "🍰", "🧁",
    "🌈", "🪐", "🦩", "🦋", "🐢", "🌿", "🍂", "🌾", "🍄", "🌬️",
    "🦙", "🐨", "🦁", "🐼", "🦋", "🦋", "🌈", "🦩", "🌺", "🐝",
    "🎠", "🎡", "🎢", "🎪", "🎼", "🎧", "📸", "📺", "💌", "📝",
    "🎤", "🎻", "🎺", "📖", "🎷", "🔭", "📦", "🏆", "🎖️", "🥇"
  ];
  
  // Select a random emoji
  $randomIndex = array_rand($emojis);
  $randomEmoji = $emojis[$randomIndex];
  
  $words = [
"สล็อตเว็บตรง","สล็อตแตกง่าย","เว็บสล็อตแตกบ่อย","สล็อตเว็บตรงแท้","สล็อตเว็บใหญ่","สล็อตยอดนิยม","สล็อตใหม่ล่าสุด","สล็อตมาแรง","สล็อตแตกหนัก","สล็อตโบนัสใหญ่",
"ทดลองเล่นสล็อต","ทดลองเล่นสล็อตฟรี","ทดลองเล่นสล็อตได้เงินจริง","ทดลองเล่นสล็อตทุกค่าย","ทดลองเล่นสล็อตระบบใหม่","ทดลองเล่นสล็อตไม่ต้องสมัคร","ทดลองเล่นสล็อตมือถือ","ทดลองเล่นสล็อตออนไลน์",
"คาสิโนสด","คาสิโนสดออนไลน์","คาสิโนสดเว็บตรง","คาสิโนสดได้เงินจริง","คาสิโนสดภาพคมชัด","คาสิโนสดระดับโลก","คาสิโนสดดีลเลอร์จริง","คาสิโนสดมือถือ",
"บาคาร่า","บาคาร่าออนไลน์","บาคาร่าเว็บตรง","บาคาร่าถ่ายทอดสด","บาคาร่ามือถือ","บาคาร่าคาสิโนสด","บาคาร่าระบบออโต้","บาคาร่าค่ายดัง",
"ยิงปลา","ยิงปลาออนไลน์","ยิงปลาแตกง่าย","ยิงปลาได้เงินจริง","ยิงปลาโบนัสใหญ่","ยิงปลาเว็บตรง","ยิงปลาเล่นง่าย","ยิงปลาได้เงินจริงทุกวัน",
"ฟุตบอล","ฟุตบอลออนไลน์","แทงบอล","แทงบอลเว็บตรง","แทงบอลมือถือ","บอลสด","บอลสดวันนี้","วิเคราะห์บอล","แทงบอลระบบออโต้",
"หวยออนไลน์","แทงหวย","หวยรัฐบาล","หวยยี่กี","หวยลาว","หวยฮานอย","หวยออนไลน์เว็บตรง","แทงหวยออนไลน์",
"สล็อตออนไลน์","เกมสล็อต","เกมสล็อตออนไลน์","เกมสล็อตแตกง่าย","เกมสล็อตยอดนิยม","เกมสล็อตโบนัส","เกมสล็อตเว็บตรง","เกมสล็อตมือถือ",
"สล็อต pg","สล็อต pragmatic","สล็อต jili","สล็อต joker","สล็อต cq9","สล็อต slotxo","สล็อต spadegaming","สล็อต habanero",
"เว็บตรงสล็อต","เว็บสล็อตไม่ผ่านเอเย่นต์","เว็บสล็อตมาตรฐาน","เว็บสล็อตอันดับหนึ่ง","เว็บสล็อตมาแรง","เว็บสล็อตใหม่","เว็บสล็อตคุณภาพ",
"สมัครสล็อต","สมัครสล็อตเว็บตรง","สมัครเล่นสล็อต","สมัครสมาชิกสล็อต","สมัครสล็อตออนไลน์","สมัครสล็อตออนไลน์เว็บตรง",
"โบนัสสล็อต","โบนัสสมาชิกใหม่","โบนัสแตกหนัก","โบนัสเครดิตฟรี","โบนัสไม่ต้องฝาก","โบนัสต้อนรับสมาชิกใหม่",
"เครดิตฟรี","เครดิตฟรีไม่ต้องฝาก","เครดิตฟรีไม่ต้องฝากไม่ต้องแชร์","เครดิตฟรีกดรับเอง","เครดิตฟรีไม่ต้องฝากล่าสุด",
"ฝากถอนออโต้","ฝากถอนออโต้รวดเร็ว","ฝากถอนออโต้ 24 ชั่วโมง","ฝากถอนออโต้ไม่มีขั้นต่ำ","ฝากถอนออโต้เว็บตรง",
"ฝากเงินสล็อตออนไลน์","ฝากเงินเว็บสล็อต","ฝากเงินคาสิโน","ฝากเงินทรูวอเลท","ฝากเงินมือถือ",
"ถอนเงินสล็อตออนไลน์","ถอนเงินออโต้","ถอนเงินรวดเร็ว","ถอนเงินเว็บตรง","ถอนเงินไม่มีขั้นต่ำ",
"ทรูวอเลท","สล็อตทรูวอเลท","เว็บสล็อตทรูวอเลท","ฝากถอนทรูวอเลท","สมัครสล็อตทรูวอเลท","สล็อตวอเลท",
"ไม่มีขั้นต่ำ","สล็อตไม่มีขั้นต่ำ","ฝากไม่มีขั้นต่ำ","ถอนเงินไม่มีขั้นต่ำ","เล่นสล็อตเริ่มต้น 1 บาท",
"สล็อตมือถือ","เล่นสล็อตมือถือ","สล็อตบนมือถือ","สล็อตออนไลน์มือถือ","สล็อตระบบมือถือ",
"สล็อตแตกบ่อย","สล็อตโบนัสแตก","สล็อตแจ็คพอต","สล็อตกำไรดี","สล็อตยอดฮิต",
"สล็อตเว็บตรง 2026","สล็อตมาแรง 2026","สล็อตแตกง่าย 2026","สล็อตเว็บใหม่ 2026",
"สล็อตออนไลน์ทุกค่าย","สล็อตรวมทุกค่าย","สล็อตค่ายดัง","สล็อตเกมใหม่","สล็อตเกมยอดนิยม",
"เว็บตรงคาสิโน","เว็บตรงบาคาร่า","เว็บตรงสล็อต","เว็บตรงแทงบอลออนไลน์","เว็บตรงเกมยิงปลา",
"เกมยิงปลาโบนัส","เกมยิงปลาแตกง่าย","ยิงปลาโบนัสใหญ่","ยิงปลาแจ็คพอต","ยิงปลาออนไลน์เว็บตรง",
"คาสิโนออนไลน์","คาสิโนออนไลน์เว็บตรง","คาสิโนออนไลน์มือถือ","คาสิโนออนไลน์ครบวงจร",
"บาคาร่าแตกง่าย","บาคาร่ามือถือ","บาคาร่าระบบออโต้","บาคาร่าถ่ายทอดสด HD",
"ฟุตบอลออนไลน์วันนี้","แทงบอลออนไลน์","บอลออนไลน์เว็บตรง","บอลสด HD","บอลสดมือถือ",
"เกมสล็อตแตกบ่อย","เกมสล็อตโบนัสแตก","เกมสล็อตแจ็คพอต","เกมสล็อตค่ายดัง","เกมสล็อตยอดนิยม",
"สล็อตออนไลน์เว็บตรง","สล็อตออนไลน์มือถือ","สล็อตออนไลน์ใหม่ล่าสุด","สล็อตออนไลน์แตกง่าย",
"ระบบออโต้","ระบบฝากถอนออโต้","ระบบฝากถอนเร็ว","ระบบฝากถอนทันที","ระบบฝากถอน 30 วินาที",
"เว็บสล็อตมาตรฐานสากล","เว็บสล็อตปลอดภัย","เว็บสล็อตเสถียร","เว็บสล็อตระบบดี",
"สล็อตเล่นง่าย","สล็อตกำไรดี","สล็อตโบนัสสูง","สล็อตแตกไว","สล็อตทำเงิน",
"เกมสล็อตใหม่","เกมสล็อตมาแรง","เกมสล็อตโบนัสใหญ่","เกมสล็อตภาพสวย",
"เว็บสล็อตอันดับหนึ่ง","เว็บสล็อตยอดนิยม","เว็บสล็อตมาแรงที่สุด","เว็บสล็อตน่าเล่น",
"คาสิโนสดดีลเลอร์","คาสิโนสดบาคาร่าถ่ายทอดสด","คาสิโนสดรูเล็ต","คาสิโนสดเสือมังกร",
"เกมสล็อตเว็บตรงแท้","เกมสล็อตทดลองเล่น","เกมสล็อตโบนัสฟรีสปิน","เกมสล็อตแตกหนัก",
"สล็อตออนไลน์ระบบใหม่","สล็อตออนไลน์โบนัสใหญ่","สล็อตออนไลน์กำไรดี","สล็อตออนไลน์เล่นง่าย",
"เว็บสล็อตบริการดี","เว็บสล็อตรองรับมือถือ","เว็บสล็อตรองรับทุกระบบ","เว็บสล็อตมาตรฐาน",
"เกมสล็อตแตกง่ายทุกวัน","สล็อตออนไลน์กำไรทุกวัน","สล็อตออนไลน์โบนัสทุกวัน","สล็อตออนไลน์แจ็คพอต",
"สล็อตออนไลน์ครบวงจร","สล็อตออนไลน์ทุกค่าย","สล็อตออนไลน์บริการดี","สล็อตออนไลน์ระบบเสถียร",
"สล็อตเว็บตรง","สล็อตเว็บตรงแท้","สล็อตเว็บตรงแตกง่าย","สล็อตเว็บตรง2026","สล็อตเว็บตรงล่าสุด",
"ทดลองเล่นสล็อต","ทดลองเล่นสล็อตฟรี","ทดลองเล่นสล็อตได้เงินจริง","ทดลองเล่นสล็อตทุกค่าย",
"เล่นสล็อต","เล่นสล็อตออนไลน์","เล่นสล็อตมือถือ","เล่นสล็อตแตกง่าย","เล่นสล็อตได้เงินจริง",
"ทรูวอเลท","รองรับทรูวอเลท","สล็อตทรูวอเลท","ฝากถอนทรูวอเลท","วอเลทไม่มีขั้นต่ำ",
"ฝากถอนออโต้","ระบบฝากถอนออโต้","ฝากถอนออโต้รวดเร็ว","ฝากถอนออโต้24ชม","ฝากถอนออโต้ทันที",
"ไม่มีขั้นต่ำ","ฝากไม่มีขั้นต่ำ","ถอนไม่มีขั้นต่ำ","เล่นได้ไม่มีขั้นต่ำ","เบทต่ำไม่มีขั้นต่ำ",
"ยิงปลา","เกมยิงปลา","ยิงปลาได้เงินจริง","ยิงปลาออนไลน์","ยิงปลาแตกง่าย",
"ยิงปลาเว็บตรง","ยิงปลาโบนัส","ยิงปลาแตกหนัก","ยิงปลาได้เงินจริงทุกวัน",
"เว็บพนันออนไลน์", "สล็อตออนไลน์", "คาสิโนออนไลน์", "แทงหวยออนไลน์", "แทงบอลออนไลน์", "เกมกีฬา", 
"ยิงปลาออนไลน์", "ไฮโลออนไลน์", "ปูปลาน้ำเต้า", "ฟุตบอลออนไลน์", "เดิมพันกีฬา", "คาสิโนสด", 
"สล็อตแตกง่าย", "สล็อตเว็บตรง", "สล็อตไม่มีขั้นต่ำ", "สล็อตฟรีเครดิต", "สล็อตโบนัสแตกบ่อย",
"เกมสล็อตยอดนิยม", "สล็อตค่ายดัง", "สล็อตออโต้", "สล็อตฝากถอนออโต้", "สล็อตระบบอัตโนมัติ",
"เกมสล็อตใหม่ล่าสุด", "สล็อตออนไลน์มือถือ", "สล็อตเล่นง่าย", "สล็อตทำเงิน", "สล็อตกำไรงาม",
"บาคาร่าออนไลน์", "บาคาร่าถ่ายทอดสด", "บาคาร่าเว็บตรง", "บาคาร่าฝากถอนออโต้", "บาคาร่าทุนน้อย",
"บาคาร่ากำไรดี", "บาคาร่าระบบออโต้", "บาคาร่าคาสิโนสด", "บาคาร่ามือถือ", "บาคาร่ามาตรฐาน",
"บาคาร่าจ่ายจริง", "บาคาร่าค่ายดัง", "บาคาร่าความนิยมสูง",
"คาสิโนสด", "คาสิโนเว็บตรง", "คาสิโนออนไลน์มาตรฐาน", "คาสิโนได้เงินจริง", "คาสิโนระบบออโต้",
"คาสิโนฝากถอนอัตโนมัติ", "คาสิโนมือถือ", "คาสิโนได้เงินจริงทุกยอด", "คาสิโนโบนัสสูง",
"คาสิโนโปรโมชั่นแรง", "คาสิโนเล่นง่าย",
"แทงบอลออนไลน์", "เว็บแทงบอล", "พนันฟุตบอล", "บอลเต็ง", "บอลสเต็ป", "วิเคราะห์บอล",
"บอลสด", "บอลสดออนไลน์", "บอลออนไลน์มือถือ", "แทงบอลผ่านเว็บ", "แทงบอลสด",
"แทงบอลกำไรงาม", "เว็บบอลอัตราต่อรองดี", "แทงบอลระบบออโต้",
"พนันกีฬา", "เดิมพันกีฬาออนไลน์", "แทงบาสเกตบอล", "แทงเทนนิส", "แทงมวย", "แทงอีสปอร์ต",
"แทงกีฬาออนไลน์", "เว็บพนันกีฬา", "เดิมพันกีฬาได้เงินจริง", "กีฬาออนไลน์มือถือ",
"แทงหวยออนไลน์", "หวยรัฐบาล", "หวยลาว", "หวยฮานอย", "หวยยี่กี", "หวยออนไลน์จ่ายจริง",
"หวยออนไลน์เว็บตรง", "หวยอั้น", "หวยหุ้น", "หวยหุ้นไทย", "หวยหุ้นต่างประเทศ",
"แทงหวยกำไรงาม", "หวยออนไลน์ไม่มีขั้นต่ำ",
"ยิงปลาออนไลน์", "เกมยิงปลา", "ยิงปลาได้เงินจริง", "ยิงปลาแตกง่าย", "ยิงปลาโบนัสแตกบ่อย",
"ยิงปลาเว็บตรง", "ยิงปลาออนไลน์มือถือ", "ยิงปลาได้เงินจริงทุกยอด", "ยิงปลาเล่นง่าย",
"ยิงปลาโบนัสสูง",
"ไฮโลออนไลน์", "ไฮโลสด", "ไฮโลคาสิโน", "ไฮโลได้เงินจริง", "ไฮโลเว็บตรง",
"ไฮโลออนไลน์มือถือ", "ไฮโลเล่นง่าย", "ไฮโลโบนัสสูง",
"ปูปลาน้ำเต้า", "ปูปลาน้ำเต้าออนไลน์", "ปูปลาน้ำเต้าเว็บตรง", "ปูปลาน้ำเต้าเล่นง่าย",
"ปูปลาน้ำเต้าได้เงินจริง", "ปูปลาน้ำเต้ามือถือ",
"เว็บพนันเว็บตรง", "เว็บพนันไม่ผ่านเอเย่นต์", "เว็บพนันอันดับหนึ่ง", "เว็บพนันยอดนิยม",
"เว็บพนันมาตรฐาน", "เว็บพนันปลอดภัย", "เว็บพนันได้เงินจริง",
"ฝากถอนอัตโนมัติ", "ฝากถอนรวดเร็ว", "ฝากถอนไม่มีขั้นต่ำ", "ฝากถอนวอเลท",
"ฝากถอนผ่านธนาคาร", "ฝากถอนผ่านมือถือ", "ฝากถอนตลอด24ชั่วโมง",
"โบนัสเครดิตฟรี", "เครดิตฟรีไม่ต้องฝาก", "โบนัสสมาชิกใหม่", "โบนัสฝากครั้งแรก",
"โบนัสสล็อต", "โบนัสคาสิโน", "โบนัสแทงบอล", "โบนัสหวย",
"สมัครสมาชิกฟรี", "สมัครสมาชิกง่าย", "สมัครเว็บพนันออนไลน์", "สมัครเล่นสล็อต",
"สมัครคาสิโนออนไลน์", "สมัครแทงบอลออนไลน์",
"รองรับมือถือ", "รองรับทุกระบบ", "รองรับ IOS", "รองรับ Android", "เล่นผ่านมือถือ",
"เล่นผ่านคอมพิวเตอร์", "เล่นผ่านแท็บเล็ต",
"กำไรง่าย", "ทำเงินง่าย", "สร้างรายได้ออนไลน์", "เกมพนันออนไลน์ยอดนิยม",
"ความบันเทิงออนไลน์", "เกมเดิมพันออนไลน์", "แพลตฟอร์มเดิมพัน",
"ระบบออโต้เต็มรูปแบบ", "ระบบฝากถอนเร็ว", "ระบบความปลอดภัยสูง", "ระบบเสถียร",
"ระบบเล่นลื่นไหล", "ระบบเดิมพันมาตรฐาน",
"โปรโมชั่นแจกหนัก", "โปรโมชั่นทุกวัน", "โปรโมชั่นรายสัปดาห์", "โปรโมชั่นรายเดือน",
"กิจกรรมแจกโบนัส", "กิจกรรมสะสมแต้ม", "กิจกรรมแจ็คพอต",
"แจ็คพอตแตกบ่อย", "แจ็คพอตโบนัส", "แจ็คพอตสล็อตออนไลน์", "แจ็คพอตคาสิโน",
"นักพนันออนไลน์", "ผู้เล่นคาสิโน", "นักเดิมพันมืออาชีพ", "นักพนันมือใหม่",
"เซียนพนันออนไลน์", "ผู้เล่นเกมสล็อต",
"แหล่งรวมเกมพนัน", "ศูนย์รวมคาสิโนออนไลน์", "แพลตฟอร์มสล็อต", 
"เว็บเดิมพันครบวงจร", "เว็บพนันครบทุกเกม",
"สล็อต", "คาสิโน", "หวย", "บอล", "กีฬา", "ยิงปลา", "ไฮโล", "ปูปลาน้ำเต้า", "ฟุตบอล",
"เดิมพันออนไลน์", "ความบันเทิงคาสิโน", "เกมพนันมือถือ", "เว็บคาสิโนครบวงจร",
"เล่นได้ตลอดเวลา", "เปิดบริการ24ชั่วโมง", "เดิมพันได้ทุกที่", "เดิมพันได้ทุกเวลา",
"ฟุตบอล","แทงบอล","แทงบอลเว็บตรง","แทงบอลออนไลน์","แทงบอลสเต็ป",
"แทงบอลสด","วิเคราะห์บอล","บอลเต็ง","บอลสเต็ป","บอลเดี่ยว",
"คาสิโนสด","คาสิโนออนไลน์","คาสิโนสดเว็บตรง","คาสิโนสดได้เงินจริง",
"บาคาร่าถ่ายทอดสด","บาคาร่าออนไลน์","บาคาร่าทดลอง","บาคาร่าขั้นต่ำ1บาท",
"บาคาร่าเว็บตรง","บาคาร่าทรูวอเลท","บาคาร่าฝากถอนออโต้","บาคาร่าระบบออโต้",
"รูเล็ต","รูเล็ตสด","รูเล็ตออนไลน์","รูเล็ตเว็บตรง","รูเล็ตคาสิโนสด",
"เสือมังกร","เสือมังกรออนไลน์","เสือมังกรคาสิโน","เสือมังกรสด",
"เกมสล็อต","เกมสล็อตออนไลน์","เกมสล็อตแตกง่าย","เกมสล็อตโบนัสแตก",
"เกมสล็อตทุกค่าย","เกมสล็อตยอดนิยม","เกมสล็อตใหม่ล่าสุด","เกมสล็อตมาแรง",
"สล็อตแตกหนัก","สล็อตแตกง่าย","สล็อตโบนัสใหญ่","สล็อตแจ็คพอต",
"สล็อตแจ็คพอตแตก","สล็อตโบนัสฟรี","สล็อตหมุนฟรี","สล็อตฟรีสปิน",
"สล็อตเว็บใหญ่","สล็อตเว็บดัง","สล็อตเว็บอันดับ1","สล็อตเว็บใหม่",
"สล็อตเว็บมาแรง","สล็อตเว็บแตกดี","สล็อตเว็บน่าเล่น","สล็อตเว็บยอดนิยม",
"ทดลองเล่นสล็อตpg","ทดลองเล่นสล็อตpp","ทดลองเล่นสล็อตjili","ทดลองเล่นสล็อตทุกค่ายฟรี",
"ทดลองเล่นสล็อตมือถือ","ทดลองเล่นสล็อตได้เงินจริง2026",
"สมัครสล็อต","สมัครสล็อตฟรี","สมัครสล็อตเว็บตรง","สมัครสล็อตออโต้",
"สมัครสมาชิกสล็อต","สมัครสมาชิกเว็บตรง","สมัครเว็บสล็อตง่าย",
"ระบบออโต้","ระบบอัตโนมัติ","ระบบฝากเงินออโต้","ระบบถอนเงินออโต้",
"ระบบสมาชิกออโต้","ระบบเว็บตรง","ระบบเกมออนไลน์",
"เล่นเกมคาสิโน","เล่นคาสิโนออนไลน์","เล่นคาสิโนสดมือถือ",
"คาสิโนสดมือถือ","คาสิโนสดเว็บใหญ่","คาสิโนสดคมชัด",
"บาคาร่ามือถือ","บาคาร่าคาสิโนสด","บาคาร่ารวดเร็ว",
"สล็อตมือถือ","สล็อตมือถือแตกง่าย","สล็อตมือถือเว็บตรง",
"เล่นสล็อตผ่านมือถือ","เล่นสล็อตทุกเวลา",
"เกมสล็อตมือถือ","เกมสล็อตโบนัส","เกมสล็อตใหม่",
"เกมสล็อตแจกฟรีสปิน","เกมสล็อตโบนัสแตกง่าย",
"PGSLOT","PG SLOT","pgslot","pgสล็อต","pgslotเว็บตรง",
"pgslotแตกง่าย","pgslotโบนัสแตก","pgslotทดลองเล่น",
"pgslotเครดิตฟรี","pgslotฝากถอนออโต้",
"pgslotมือถือ","pgslotเว็บแท้","pgslotค่ายดัง",
"pgslotยอดนิยม","pgslotเกมสล็อต",
"joker","joker slot","joker gaming","joker123",
"jokerสล็อต","jokerสล็อตแตกง่าย","jokerเว็บตรง",
"jokerทดลองเล่น","jokerโบนัสแตก","jokerเครดิตฟรี",
"jokerฝากถอนออโต้","jokerสล็อตออนไลน์","jokerเกมดัง",
"jokerค่ายสล็อต","jokerสล็อตยอดนิยม",
"jili","jili slot","jili gaming","jiliสล็อต",
"jiliสล็อตแตกง่าย","jiliสล็อตออนไลน์","jiliโบนัสแตก",
"jiliทดลองเล่นสล็อต","jiliเครดิตฟรี","jiliฝากถอนออโต้",
"jiliเกมสล็อต","jiliสล็อตมือถือ","jiliค่ายดัง",
"jiliเกมสล็อตยอดนิยม","jiliสล็อตเว็บตรง",
"pragmatic play","pp slot","ppslot","ppgaming",
"ppสล็อตออนไลน์","ppสล็อตแตกง่าย","ppสล็อตออนไลน์เว็บตรง",
"ppสล็อตเครดิตฟรี","ppสล็อตทดลองเล่น","ppสล็อตโบนัสแตก",
"ppเกมสล็อตยอดนิยม","ppเกมสล็อตใหม่","ppสล็อตมือถือ",
"ppสล็อตค่ายดัง","ppสล็อตเว็บตรง",
"pg joker","pg jili","pg pragmatic",
"สล็อต pg joker","สล็อต pg jili","สล็อต pg pp",
"สล็อต pg joker jili","สล็อต pg joker pragmatic",
"สล็อต pg แตกง่าย","สล็อต joker แตกง่าย",
"สล็อต jili แตกง่าย","สล็อต pp แตกง่าย",
"สล็อต pg โบนัสแตก","สล็อต joker โบนัสใหญ่",
"สล็อต jili โบนัสแตก","สล็อต pp แจ็คพอต",
"สล็อต pg ทดลองเล่น","สล็อต joker ทดลองเล่นสล็อต",
"สล็อต jili ทดลองเล่นสล็อต","สล็อต pp ทดลองเล่นสล็อต",
"สล็อต pg มือถือ","สล็อต joker มือถือ",
"สล็อต jili มือถือ","สล็อต pp มือถือ",
"สล็อต pg เว็บตรง","สล็อต joker เว็บตรง",
"สล็อต jili เว็บตรง","สล็อต pp เว็บตรง",
"เกมสล็อต pg","เกมสล็อต joker",
"เกมสล็อต jili","เกมสล็อต pragmatic play",
"เกมสล็อต pg ยอดนิยม","เกมสล็อต joker ยอดฮิต",
"เกมสล็อต jili มาแรง","เกมสล็อต pp ใหม่ล่าสุด"
];
  
  // Select a random word
  $randomIndex = array_rand($words);
  $randomWord = $words[$randomIndex];
  
  $img = array(
    "https://blackhacker.site/image/g89.webp",
    "https://blackhacker.site/image/g88.webp",
    "https://blackhacker.site/image/g87.webp",
    "https://blackhacker.site/image/g86.webp",
    "https://blackhacker.site/image/g85.webp",
    "https://blackhacker.site/image/g84.webp",
    "https://blackhacker.site/image/g83.webp",
    "https://blackhacker.site/image/g82.webp",
    "https://blackhacker.site/image/g81.webp",
    "https://blackhacker.site/image/g80.webp",
    "https://blackhacker.site/image/g79.webp",
    "https://blackhacker.site/image/g78.webp",
    "https://blackhacker.site/image/g77.webp",
    "https://blackhacker.site/image/g76.webp",
    "https://blackhacker.site/image/g75.webp",
    "https://blackhacker.site/image/g74.webp",
    "https://blackhacker.site/image/g73.webp",
    "https://blackhacker.site/image/g72.webp",
    "https://blackhacker.site/image/g71.webp",
    "https://blackhacker.site/image/g70.webp",
    "https://blackhacker.site/image/g69.webp",
    "https://blackhacker.site/image/g68.webp",
    "https://blackhacker.site/image/g67.webp",
    "https://blackhacker.site/image/g66.webp",
    "https://blackhacker.site/image/g65.webp",
    "https://blackhacker.site/image/g64.webp",
    "https://blackhacker.site/image/g63.webp",
    "https://blackhacker.site/image/g62.webp",
    "https://blackhacker.site/image/g61.webp",
    "https://blackhacker.site/image/g60.webp",
    "https://blackhacker.site/image/g59.webp",
    "https://blackhacker.site/image/g58.webp",
    "https://blackhacker.site/image/g57.webp",
    "https://blackhacker.site/image/g56.webp",
);

$random_img = $img[array_rand($img)];

date_default_timezone_set('Asia/Jakarta');
$currentTime = date('Y-m-dTH:i:sP');
?>
<!doctype html>
<html lang="en-us" class="a-no-js" data-19ax5a9jf="dingo">
<!-- sp:feature:head-start -->
<head>
<script>var aPageStart = (new Date()).getTime();</script><meta charset="utf-8"/>
<!-- sp:end-feature:head-start -->
<!-- sp:feature:csm:head-open-part1 -->

<script type='text/javascript'>var ue_t0=ue_t0||+new Date();</script>
<!-- sp:end-feature:csm:head-open-part1 -->
<!-- sp:feature:cs-optimization -->
<meta http-equiv='x-dns-prefetch-control' content='on'>
<link rel="dns-prefetch" href="https://images-na.ssl-images-amazon.com">
<link rel="dns-prefetch" href="https://m.media-amazon.com">
<link rel="dns-prefetch" href="https://completion.amazon.com">
<!-- sp:end-feature:cs-optimization -->
<!-- sp:feature:csm:head-open-part2 -->
<script type='text/javascript'>
window.ue_ihb = (window.ue_ihb || window.ueinit || 0) + 1;
if (window.ue_ihb === 1) {

var ue_csm = window,
    ue_hob = +new Date();
(function(d){var e=d.ue=d.ue||{},f=Date.now||function(){return+new Date};e.d=function(b){return f()-(b?0:d.ue_t0)};e.stub=function(b,a){if(!b[a]){var c=[];b[a]=function(){c.push([c.slice.call(arguments),e.d(),d.ue_id])};b[a].replay=function(b){for(var a;a=c.shift();)b(a[0],a[1],a[2])};b[a].isStub=1}};e.exec=function(b,a){return function(){try{return b.apply(this,arguments)}catch(c){ueLogError(c,{attribution:a||"undefined",logLevel:"WARN"})}}}})(ue_csm);


    var ue_err_chan = 'jserr-rw';
(function(d,e){function h(f,b){if(!(a.ec>a.mxe)&&f){a.ter.push(f);b=b||{};var c=f.logLevel||b.logLevel;c&&c!==k&&c!==m&&c!==n&&c!==p||a.ec++;c&&c!=k||a.ecf++;b.pageURL=""+(e.location?e.location.href:"");b.logLevel=c;b.attribution=f.attribution||b.attribution;a.erl.push({ex:f,info:b})}}function l(a,b,c,e,g){d.ueLogError({m:a,f:b,l:c,c:""+e,err:g,fromOnError:1,args:arguments},g?{attribution:g.attribution,logLevel:g.logLevel}:void 0);return!1}var k="FATAL",m="ERROR",n="WARN",p="DOWNGRADED",a={ec:0,ecf:0,
pec:0,ts:0,erl:[],ter:[],buffer:[],mxe:50,startTimer:function(){a.ts++;setInterval(function(){d.ue&&a.pec<a.ec&&d.uex("at");a.pec=a.ec},1E4)}};l.skipTrace=1;h.skipTrace=1;h.isStub=1;d.ueLogError=h;d.ue_err=a;e.onerror=l})(ue_csm,window);


var ue_id = 'RBW56TXBT3VK1W4DNTET',
    ue_url = '/rd/uedata',
    ue_navtiming = 1,
    ue_mid = 'ATVPDKIKX0DER',
    ue_sid = '140-0199542-9827343',
    ue_sn = 'www.amazon.com',
    ue_furl = 'fls-na.amazon.com',
    ue_surl = 'https://unagi-na.amazon.com/1/events/com.amazon.csm.nexusclient.prod',
    ue_int = 0,
    ue_fcsn = 1,
    ue_urt = 3,
    ue_rpl_ns = 'cel-rpl',
    ue_ddq = 1,
    ue_fpf = '//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:140-0199542-9827343:RBW56TXBT3VK1W4DNTET$uedata=s:',
    ue_sbuimp = 1,
    ue_ibft = 0,
    ue_sswmts = 0,
    ue_jsmtf = 0,
    ue_fnt = 0,
    ue_lpsi = 6000,
    ue_no_counters = 1,
    ue_lob = '1',
    ue_sjslob = 0,
    ue_dsbl_cel = 1,

    ue_swi = 1;
var ue_viz=function(){(function(b,f,d){function g(){return(!(p in d)||0<d[p])&&(!(q in d)||0<d[q])}function h(c){if(b.ue.viz.length<w&&!r){var a=c.type;c=c.originalEvent;/^focus./.test(a)&&c&&(c.toElement||c.fromElement||c.relatedTarget)||(a=g()?f[s]||("blur"==a||"focusout"==a?t:u):t,b.ue.viz.push(a+":"+(+new Date-b.ue.t0)),a==u&&(b.ue.isl&&x("at"),r=1))}}for(var r=0,x=b.uex,a,k,l,s,v=["","webkit","o","ms","moz"],e=0,m=1,u="visible",t="hidden",p="innerWidth",q="innerHeight",w=20,n=0;n<v.length&&!e;n++)if(a=
v[n],k=(a?a+"H":"h")+"idden",e="boolean"==typeof f[k])l=a+"visibilitychange",s=(a?a+"V":"v")+"isibilityState";h({});e&&f.addEventListener(l,h,0);m=g()?1:0;d.addEventListener("resize",function(){var a=g()?1:0;m!==a&&(m=a,h({}))},{passive:!0});b.ue&&e&&(b.ue.pageViz={event:l,propHid:k})})(ue_csm,ue_csm.document,ue_csm.window)};window.ue_viz=ue_viz;

(function(d,h,N){function H(a){return a&&a.replace&&a.replace(/^s+|s+$/g,"")}function u(a){return"undefined"===typeof a}function B(a,b){for(var c in b)b[v](c)&&(a[c]=b[c])}function I(a){try{var b=N.cookie.match(RegExp("(^| )"+a+"=([^;]+)"));if(b)return b[2].trim()}catch(c){}}function O(k,b,c){var q=(x||{}).type;if("device"!==c||2!==q&&1!==q)k&&(d.ue_id=a.id=a.rid=k,w&&(w=w.replace(/((.*?:){2})(w+)/,function(a,b){return b+k})),D&&(e("id",D,k),D=0)),b&&(w&&(w=w.replace(/(.*?:)(w|-)+/,function(a,
c){return c+b})),d.ue_sid=b),c&&a.tag("page-source:"+c),d.ue_fpf=w}function P(){var a={};return function(b){b&&(a[b]=1);b=[];for(var c in a)a[v](c)&&b.push(c);return b}}function y(d,b,c,q){q=q||+new E;var g,m;if(b||u(c)){if(d)for(m in g=b?e("t",b)||e("t",b,{}):a.t,g[d]=q,c)c[v](m)&&e(m,b,c[m]);return q}}function e(d,b,c){var e=b&&b!=a.id?a.sc[b]:a;e||(e=a.sc[b]={});"id"===d&&c&&(Q=1);return e[d]=c||e[d]}function R(d,b,c,e,g){c="on"+c;var m=b[c];"function"===typeof m?d&&(a.h[d]=m):m=function(){};b[c]=
function(a){g?(e(a),m(a)):(m(a),e(a))};b[c]&&(b[c].isUeh=1)}function S(k,b,c,q){function p(b,c){var d=[b],f=0,g={},m,h;c?(d.push("m=1"),g[c]=1):g=a.sc;for(h in g)if(g[v](h)){var q=e("wb",h),p=e("t",h)||{},n=e("t0",h)||a.t0,l;if(c||2==q){q=q?f++:"";d.push("sc"+q+"="+h);for(l in p)u(p[l])||null===p[l]||d.push(l+q+"="+(p[l]-n));d.push("t"+q+"="+p[k]);if(e("ctb",h)||e("wb",h))m=1}}!J&&m&&d.push("ctb=1");return d.join("&")}function m(b,c,f,e,g){if(b){var k=d.ue_err;d.ue_url&&!e&&!g&&b&&0<b.length&&(e=
new Image,a.iel.push(e),e.src=b,a.count&&a.count("postbackImageSize",b.length));w?(g=h.encodeURIComponent)&&b&&(e=new Image,b=""+d.ue_fpf+g(b)+":"+(+new E-d.ue_t0),a.iel.push(e),e.src=b):a.log&&(a.log(b,"uedata",{n:1}),a.ielf.push(b));k&&!k.ts&&k.startTimer();a.b&&(k=a.b,a.b="",m(k,c,f,1))}}function A(b){var c=x?x.type:F,d=2==c||a.isBFonMshop,c=c&&!d,f=a.bfini;if(!Q||a.isBFCache)f&&1<f&&(b+="&bfform=1",c||(a.isBFT=f-1)),d&&(b+="&bfnt=1",a.isBFT=a.isBFT||1),a.ssw&&a.isBFT&&(a.isBFonMshop&&(a.isNRBF=
0),u(a.isNRBF)&&(d=a.ssw(a.oid),d.e||u(d.val)||(a.isNRBF=1<d.val?0:1)),u(a.isNRBF)||(b+="&nrbf="+a.isNRBF)),a.isBFT&&!a.isNRBF&&(b+="&bft="+a.isBFT);return b}if(!a.paused&&(b||u(c))){for(var l in c)c[v](l)&&e(l,b,c[l]);a.isBFonMshop||y("pc",b,c);l="ld"===k&&b&&e("wb",b);var s=e("id",b)||a.id;l||s===a.oid||(D=b,ba(s,(e("t",b)||{}).tc||+e("t0",b),+e("t0",b)));var s=e("id",b)||a.id,t=e("id2",b),f=a.url+"?"+k+"&v="+a.v+"&id="+s,J=e("ctb",b)||e("wb",b),z;J&&(f+="&ctb="+J);t&&(f+="&id2="+t);1<d.ueinit&&
(f+="&ic="+d.ueinit);if(!("ld"!=k&&"ul"!=k||b&&b!=s)){if("ld"==k){try{h[K]&&h[K].isUeh&&(h[K]=null)}catch(I){}if(h.chrome)for(t=0;t<L.length;t++)T(G,L[t]);(t=N.ue_backdetect)&&t.ue_back&&t.ue_back.value++;d._uess&&(z=d._uess());a.isl=1}a._bf&&(f+="&bf="+a._bf());d.ue_navtiming&&g&&(e("ctb",s,"1"),a.isBFonMshop||y("tc",F,F,M));!C||a.isBFonMshop||U||(g&&B(a.t,{na_:g.navigationStart,ul_:g.unloadEventStart,_ul:g.unloadEventEnd,rd_:g.redirectStart,_rd:g.redirectEnd,fe_:g.fetchStart,lk_:g.domainLookupStart,
_lk:g.domainLookupEnd,co_:g.connectStart,_co:g.connectEnd,sc_:g.secureConnectionStart,rq_:g.requestStart,rs_:g.responseStart,_rs:g.responseEnd,dl_:g.domLoading,di_:g.domInteractive,de_:g.domContentLoadedEventStart,_de:g.domContentLoadedEventEnd,_dc:g.domComplete,ld_:g.loadEventStart,_ld:g.loadEventEnd,ntd:("function"!==typeof C.now||u(M)?0:new E(M+C.now())-new E)+a.t0}),x&&B(a.t,{ty:x.type+a.t0,rc:x.redirectCount+a.t0}),U=1);a.isBFonMshop||B(a.t,{hob:d.ue_hob,hoe:d.ue_hoe});a.ifr&&(f+="&ifr=1")}y(k,
b,c,q);var r,n;l||b&&b!==s||ca(b);(c=d.ue_mbl)&&c.cnt&&!l&&(f+=c.cnt());l?e("wb",b,2):"ld"==k&&(a.lid=H(s));for(r in a.sc)if(1==e("wb",r))break;if(l){if(a.s)return;f=p(f,null)}else c=p(f,null),c!=f&&(c=A(c),a.b=c),z&&(f+=z),f=p(f,b||a.id);f=A(f);if(a.b||l)for(r in a.sc)2==e("wb",r)&&delete a.sc[r];z=0;a._rt&&(f+="&rt="+a._rt());c=h.csa;if(!l&&c)for(n in r=e("t",b)||{},c=c("PageTiming"),r)r[v](n)&&c("mark",da[n]||n,r[n]);l||(a.s=0,(n=d.ue_err)&&0<n.ec&&n.pec<n.ec&&(n.pec=n.ec,f+="&ec="+n.ec+"&ecf="+
n.ecf),z=e("ctb",b),"ld"!==k||b||a.markers?a.markers&&a.isl&&!l&&b&&B(a.markers,e("t",b)):(a.markers={},B(a.markers,e("t",b))),e("t",b,{}));a.tag&&a.tag().length&&(f+="&csmtags="+a.tag().join("|"),a.tag=P());n=a.viz||[];(r=n.length)&&(f+="&viz="+n.splice(0,r).join("|"));u(d.ue_pty)||(f+="&pty="+d.ue_pty+"&spty="+d.ue_spty+"&pti="+d.ue_pti);a.tabid&&(f+="&tid="+a.tabid);a.aftb&&(f+="&aftb=1");!a._ui||b&&b!=s||(f+=a._ui());f+="&lob="+(d.ue_lob||"0");a.a=f;m(f,k,z,l,b&&"string"===typeof b&&-1!==b.indexOf("csa:"))}}
function ca(a){var b=h.ue_csm_markers||{},c;for(c in b)b[v](c)&&y(c,a,F,b[c])}function A(a,b,c){c=c||h;if(c[V])c[V](a,b,!1);else if(c[W])c[W]("on"+a,b)}function T(a,b,c){c=c||h;if(c[X])c[X](a,b,!1);else if(c[Y])c[Y]("on"+a,b)}function Z(){function a(){d.onUl()}function b(a){return function(){c[a]||(c[a]=1,S(a))}}var c={},e,g;d.onLd=b("ld");d.onLdEnd=b("ld");d.onUl=b("ul");e={stop:b("os")};h.chrome?(A(G,a),L.push(a)):e[G]=d.onUl;for(g in e)e[v](g)&&R(0,h,g,e[g]);d.ue_viz&&ue_viz();A("load",d.onLd);
y("ue")}function ba(e,b,c){var g=d.ue_mbl,p=h.csa,m=p&&p("SPA"),p=p&&p("PageTiming");g&&g.ajax&&g.ajax(b,c);m&&p&&(m("newPage",{requestId:e,transitionType:"soft"}),p("mark","transitionStart",b));a.tag("ajax-transition")}d.ueinit=(d.ueinit||0)+1;var a=d.ue=d.ue||{};a.t0=h.aPageStart||d.ue_t0;a.id=d.ue_id;a.url=d.ue_url;a.rid=d.ue_id;a.a="";a.b="";a.h={};a.s=1;a.t={};a.sc={};a.iel=[];a.ielf=[];a.viz=[];a.v="0.308518.0";a.paused=!1;var v="hasOwnProperty",G="beforeunload",K="on"+G,V="addEventListener",
X="removeEventListener",W="attachEvent",Y="detachEvent",da={cf:"criticalFeature",af:"aboveTheFold",fn:"functional",fp:"firstPaint",fcp:"firstContentfulPaint",bb:"bodyBegin",be:"bodyEnd",ld:"loaded"},E=h.Date,C=h.performance||h.webkitPerformance,g=(C||{}).timing,x=(C||{}).navigation,M=(g||{}).navigationStart,w=d.ue_fpf,Q=0,U=0,L=[],D=0,F;a.oid=H(a.id);a.lid=H(a.id);a._t0=a.t0;a.tag=P();a.ifr=h.top!==h.self||h.frameElement?1:0;a.markers=null;a.attach=A;a.detach=T;if("000-0000000-8675309"===d.ue_sid){var $=
I("cdn-rid"),aa=I("session-id");$&&aa&&O($,aa,"cdn")}d.uei=Z;d.ueh=R;d.ues=e;d.uet=y;d.uex=S;a.reset=O;a.pause=function(d){a.paused=d};Z()})(ue_csm,ue_csm.window,ue_csm.document);


ue.stub(ue,"event");ue.stub(ue,"onSushiUnload");ue.stub(ue,"onSushiFlush");

ue.stub(ue,"log");ue.stub(ue,"onunload");ue.stub(ue,"onflush");
(function(b){function g(){var a={requestId:b.ue_id||"rid",server:b.ue_sn||"sn",obfuscatedMarketplaceId:b.ue_mid||"mid"};b.ue_sjslob&&(a.lob=b.ue_lob||"0");return a}var a=b.ue,h=1===b.ue_no_counters;a.cv={};a.cv.scopes={};a.cv.buffer=[];a.count=function(b,f,c){var e={},d=a.cv,g=c&&0===c.c;e.counter=b;e.value=f;e.t=a.d();c&&c.scope&&(d=a.cv.scopes[c.scope]=a.cv.scopes[c.scope]||{},e.scope=c.scope);if(void 0===f)return d[b];d[b]=f;d=0;c&&c.bf&&(d=1);h||(ue_csm.ue_sclog||!a.clog||0!==d||g?a.log&&a.log(e,
"csmcount",{c:1,bf:d}):a.clog(e,"csmcount",{bf:d}));a.cv.buffer.push({c:b,v:f})};a.count("baselineCounter2",1);a&&a.event&&(a.event(g(),"csm","csm.CSMBaselineEvent.4"),a.count("nexusBaselineCounter",1,{bf:1}))})(ue_csm);



var ue_hoe = +new Date();
}
window.ueinit = window.ue_ihb;
</script>

<!-- ljrciyqvc391cwezno1ninm2xk2o9c5jnk5ync2q -->
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 10227)</script>
<!-- sp:end-feature:csm:head-open-part2 -->
<!-- sp:feature:aui-assets -->
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/11EIQ5IGqaL._RC|01ZTHTZObnL.css,51rW56+edML.css,31dM35l3U7L.css,11D3BPoiHRL.css,01qDClimA1L.css,01s-u+zGGeL.css,413Vvv3GONL.css,11TIuySqr6L.css,01Rw4F+QU6L.css,11JJsNcqOIL.css,01J3raiFJrL.css,01IdKcBuAdL.css,014QJx7nWqL.css,01V1Ps1Qq7L.css,01ONm-ItEkL.css,21zWwo38rCL.css,01Sv7-fQIGL.css,51nwehW-jQL.css,01XPHJk60-L.css,11ChJlzZQoL.css,01UgxIH-BSL.css,01fxuupJToL.css,21tBGvZRYPL.css,01oATFSeEjL.css,21RWaJb6t+L.css,11I+YZzE7kL.css,21VjvVtGWXL.css,01CFUgsA-YL.css,31q12zQLu7L.css,11PDZ29p-PL.css,11qlWiOaPwL.css,11tNhCU--0L.css,11msBd9oOTL.css,11BO1RWH3kL.css,01ELGsSvEzL.css,21Jbji9XlaL.css,11El-W1-pIL.css,01vfkVAfcLL.css,215Q9RsWvdL.css,11-w3ouFc1L.css,11hvENnYNUL.css,11Qek6G6pNL.css,01890+Vwk8L.css,014VAMpg+ZL.css,01qiwJ7qDfL.css,21TAMzcrOKL.css,016mfgi+D2L.css,01eniAikTiL.css,21yq4mhvspL.css,013-xYw+SRL.css_.css?AUIClients/AmazonUI#us.not-trident" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/61xJcNKKLXL.js?AUIClients/AmazonUIjQuery" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/11zuylp74DL._RC|11Y+5x+kkTL.js,51LPrROZ2JL.js,11EeeaacI2L.js,11GgN1+C7hL.js,01+z+uIeJ-L.js,01VRMV3FBdL.js,21NadQlXUWL.js,012FVc3131L.js,11a7qqY8xXL.js,11rRjDLdAVL.js,51zH7YD-TsL.js,11FhdH2HZwL.js,11wb9K3sw0L.js,11BrgrMAHUL.js,11GYEyswV2L.js,210X-JWUe-L.js,01Svfxfy8OL.js,518u7YD3VHL.js,01JYHc2oIlL.js,31nfKXylf6L.js,01ktRCtOqKL.js,01ASnt2lbqL.js,11F929pmpYL.js,31vxRYDelFL.js,01rpauTep4L.js,31wjiT+nvTL.js,011FfPwYqHL.js,213iL7Jf1nL.js,014gnDeJDsL.js,11vb6P5C5AL.js,01O9cz+pldL.js_.js?AUIClients/AmazonUI#372963-T1" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/51tQKx1B9KL.js?AUIClients/CardJsRuntimeBuzzCopyBuild" />
<script>
(function(b,a,c,d){if((b=b.AmazonUIPageJS||b.P)&&b.when&&b.register){c=[];for(a=a.currentScript;a;a=a.parentElement)a.id&&c.push(a.id);return b.log("A copy of P has already been loaded on this page.","FATAL",c.join(" "))}})(window,document,Date);(function(a,b,c,d){"use strict";a._pSetI=function(){return null}})(window,document,Date);(function(d,I,K,L){"use strict";d._sw=function(){var p;return function(w,g,u,B,h,C,q,k,x,y){p||(p=!0,y.execute("RetailPageServiceWorker",function(){function z(a,b){e.controller&&a?(a={feature:"retail_service_worker_messaging",command:a},b&&(a.data=b),e.controller.postMessage(a)):a&&h("sw:sw_message_no_ctrl",1)}function p(a){var b=a.data;if(b&&"retail_service_worker_messaging"===b.feature&&b.command&&b.data){var c=b.data;a=d.ue;var f=d.ueLogError;switch(b.command){case "log_counter":a&&k(a.count)&&
c.name&&a.count(c.name,0===c.value?0:c.value||1);break;case "log_tag":a&&k(a.tag)&&c.tag&&(a.tag(c.tag),b=d.uex,a.isl&&k(b)&&b("at"));break;case "log_error":f&&k(f)&&c.message&&f({message:c.message,logLevel:c.level||"ERROR",attribution:c.attribution||"RetailServiceWorker"});break;case "log_weblab_trigger":if(!c.weblab||!c.treatment)break;a&&k(a.trigger)?a.trigger(c.weblab,c.treatment):(h("sw:wt:miss"),h("sw:wt:miss:"+c.weblab+":"+c.treatment));break;default:h("sw:unsupported_message_command",1)}}}
function v(a,b){return"sw:"+(b||"")+":"+a+":"}function D(a,b){e.register("/service-worker.js").then(function(){h(a+"success")}).catch(function(c){y.logError(c,"[AUI SW] Failed to "+b+" service worker: ","ERROR","RetailPageServiceWorker");h(a+"failure")})}function E(){l.forEach(function(a){q(a)})}function n(a){return a.capabilities.isAmazonApp&&a.capabilities.android}function F(a,b,c){if(b)if(b.mshop&&n(a))a=v(c,"mshop_and"),b=b.mshop.action,l.push(a+"supported"),b(a,c);else if(b.browser){a=u(/Chrome/i)&&
!u(/Edge/i)&&!u(/OPR/i)&&!a.capabilities.isAmazonApp&&!u(new RegExp(B+"bwv"+B+"b"));var f=b.browser;b=v(c,"browser");a?(a=f.action,l.push(b+"supported"),a(b,c)):l.push(b+"unsupported")}}function G(a,b,c){a&&l.push(v("register",c)+"unsupported");b&&l.push(v("unregister",c)+"unsupported");E()}try{var e=navigator.serviceWorker}catch(a){q("sw:nav_err")}(function(){if(e){var a=function(){z("page_loaded",{rid:d.ue_id,mid:d.ue_mid,pty:d.ue_pty,sid:d.ue_sid,spty:d.ue_spty,furl:d.ue_furl})};x(e,"message",
p);z("client_messaging_ready");y.when("load").execute(a);x(e,"controllerchange",function(){z("client_messaging_ready");"complete"===I.readyState&&a()})}})();var l=[],m=function(a,b){var c=d.uex,f=d.uet;a=g(":","aui","sw",a);"ld"===b&&k(c)?c("ld",a,{wb:1}):k(f)&&f(b,a,{wb:1})},J=function(a,b,c){function f(a){b&&k(b.failure)&&b.failure(a)}function H(){l=setTimeout(function(){q(g(":","sw:"+r,t.TIMED_OUT));f({ok:!1,statusCode:t.TIMED_OUT,done:!1});m(r,"ld")},c||4E3)}var t={NO_CONTROLLER:"no_ctrl",TIMED_OUT:"timed_out",
UNSUPPORTED_BROWSER:"unsupported_browser",UNEXPECTED_RESPONSE:"unexpected_response"},r=g(":",a.feature,a.command),l,n=!0;if("MessageChannel"in d&&e&&"controller"in e)if(e.controller){var p=new MessageChannel;p.port1.onmessage=function(c){(c=c.data)&&c.feature===a.feature&&c.command===a.command?(n&&(m(r,"cf"),n=!1),m(r,"af"),clearTimeout(l),c.done||H(),c.ok?b&&k(b.success)&&b.success(c):f(c),c.done&&m(r,"ld")):h(g(":","sw:"+r,t.UNEXPECTED_RESPONSE),1)};H();m(r,"bb");e.controller.postMessage(a,[p.port2])}else q(g(":",
"sw:"+a.feature,t.NO_CONTROLLER)),f({ok:!1,statusCode:t.NO_CONTROLLER,done:!0});else q(g(":","sw:"+a.feature,t.UNSUPPORTED_BROWSER)),f({ok:!1,statusCode:t.UNSUPPORTED_BROWSER,done:!0})};(function(){e?(m("ctrl_changed","bb"),e.addEventListener("controllerchange",function(){q("sw:ctrl_changed");m("ctrl_changed","ld")})):h(g(":","sw:ctrl_changed","sw_unsupp"),1)})();(function(){var a=function(){m(b,"ld");var a=d.uex;J({feature:"page_proxy",command:"request_feature_tags"},{success:function(b){b=b.data;
Array.isArray(b)&&b.forEach(function(a){"string"===typeof a?q(g(":","sw:ppft",a)):h(g(":","sw:ppft","invalid_tag"),1)});h(g(":","sw:ppft","success"),1);C&&C.isl&&k(a)&&a("at")},failure:function(a){h(g(":","sw:ppft","error:"+(a.statusCode||"ppft_error")),1)}})};if("requestIdleCallback"in d){var b=g(":","ppft","callback_ricb");d.requestIdleCallback(a,{timeout:1E3})}else b=g(":","ppft","callback_timeout"),setTimeout(a,0);m(b,"bb")})();var A={reg:{},unreg:{}};A.reg.mshop={action:D};A.reg.browser={action:D};
(function(a){var b=a.reg,c=a.unreg;e&&e.getRegistrations?(w.when("A").execute(function(b){if((a.reg.mshop||a.unreg.mshop)&&"function"===typeof n&&n(b)){var f=a.reg.mshop?"T1":"C",e=d.ue;e&&e.trigger?e.trigger("MSHOP_SW_CLIENT_446196",f):h("sw:mshop:wt:failed")}F(b,c,"unregister")}),x(d,"load",function(){w.when("A").execute(function(a){F(a,b,"register");E()})})):(G(b&&b.browser,c&&c.browser,"browser"),w.when("A").execute(function(a){"function"===typeof n&&n(a)&&G(b&&b.mshop,c&&c.mshop,"mshop_and")}))})(A)}))}}()})(window,
document,Date);(function(b,a,J,C){"use strict";b._pd=function(){var c,v;return function(D,e,g,h,d,E,w,F,G){function x(b){try{return b()}catch(K){return!1}}function p(c){return b.matchMedia?b.matchMedia(c):{matches:!1}}function k(){if(l){var y=c.mobile||c.tablet?q.matches&&m.matches:m.matches;if(z!==y){var a={w:b.innerWidth||d.clientWidth,h:b.innerHeight||d.clientHeight};if(17<Math.abs(r.w-a.w)||50<Math.abs(r.h-a.h))r=a,(z=y)?h(d,"a-ws"):d.className=w(d,"a-ws")}}}function H(b){(l=b===C?!l:!!b)&&k()}function I(){return l}
if(!v){v=!0;var t=function(){var b=["O","ms","Moz","Webkit"],c=a.createElement("div");return{testGradients:function(){return!0},test:function(a){var d=a.charAt(0).toUpperCase()+a.substr(1);a=(b.join(d+" ")+d+" "+a).split(" ");for(d=a.length;d--;)if(""===c.style[a[d]])return!0;return!1},testTransform3d:function(){return!0}}}();g=d.className;var A=/(^| )a-mobile( |$)/.test(g),B=/(^| )a-tablet( |$)/.test(g);c={audio:function(){return!!a.createElement("audio").canPlayType},video:function(){return!!a.createElement("video").canPlayType},
canvas:function(){return!!a.createElement("canvas").getContext},svg:function(){return!!a.createElementNS&&!!a.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},dragDrop:function(){return"draggable"in a.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!b.history||!b.history.pushState)},webworker:function(){return!!b.Worker},
autofocus:function(){return"autofocus"in a.createElement("input")},inputPlaceholder:function(){return"placeholder"in a.createElement("input")},textareaPlaceholder:function(){return"placeholder"in a.createElement("textarea")},localStorage:function(){return"localStorage"in b&&null!==b.localStorage},orientation:function(){return"orientation"in b},touch:function(){return"ontouchend"in a},gradients:function(){return t.testGradients()},hires:function(){var a=b.devicePixelRatio&&1.5<=b.devicePixelRatio||
b.matchMedia&&b.matchMedia("(min-resolution:144dpi)").matches;F("hiRes"+(A?"Mobile":B?"Tablet":"Desktop"),a?1:0);return a},transform3d:function(){return t.testTransform3d()},touchScrolling:function(){return e(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|SOFTWARE=([5-9]|[1-9][0-9]+)(.[0-9]{1,2})+.*DEVICE=iPhone|Chrome|Silk|Firefox|Trident.+?; Touch/i)},ios:function(){return e(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!e(/trident|Edge/i)},android:function(){return e(/android.([1-9]|[L-Z])/i)&&
!e(/trident|Edge/i)},mobile:function(){return A},tablet:function(){return B},rtl:function(){return"rtl"===d.dir}};for(var f in c)c.hasOwnProperty(f)&&(c[f]=x(c[f]));for(var u="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),n=0;n<u.length;n++)c[u[n]]=x(function(){return t.test(u[n])});var l=!0,r={w:0,h:0},q=p("(orientation:landscape)"),m=c.mobile||c.tablet?p("(min-width:451px)"):p("(min-width:1250px)");q.addListener&&q.addListener(k);m.addListener&&
m.addListener(k);var z;k();d.className=w(d,"a-no-js");h(d,"a-js");!e(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||b.navigator.standalone||e(/safari/i)||h(d,"a-ember");g=[];for(f in c)c.hasOwnProperty(f)&&c[f]&&g.push("a-"+f.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));h(d,g.join(" "));d.setAttribute("data-aui-build-date",G);D.register("p-detect",function(){return{capabilities:c,localStorage:c.localStorage&&E,toggleResponsiveGrid:H,responsiveGridEnabled:I}});return c||{}}}}()})(window,document,
Date);(function(g,l,E,F){function G(a){n&&n.tag&&n.tag(p(":","aui",a))}function m(a,b){n&&n.count&&n.count("aui:"+a,0===b?0:b||(n.count("aui:"+a)||0)+1)}function H(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function I(a){return"function"===typeof a}function u(a,b,d){a.addEventListener?a.addEventListener(b,d,!1):a.attachEvent&&a.attachEvent("on"+b,d)}function p(a,b,d,e){b=b&&d?b+a+d:b||d;return e?p(a,b,e):b}function y(a,b,d){try{Object.defineProperty(a,b,{value:d,writable:!1})}catch(e){a[b]=
d}return d}function R(a,b){a.className=S(a,b)+" "+b}function S(a,b){return(" "+a.className+" ").split(" "+b+" ").join(" ").replace(/^ | $/g,"")}function J(a){(a||[]).forEach(function(a){a in z||(z[a]=1,J(T[a]))})}function ha(a,b,d){var e=a.length,f=e,c=function(){f--||((d&&z.hasOwnProperty(d)?A:K).push(b),L||(q?q.set(B):setTimeout(B,0),L=!0))};for(c();e--;)U[a[e]]?c():(v[a[e]]=v[a[e]]||[]).push(c)}function ia(a,b,d,e,f){var c=l.createElement(a?"script":"link");u(c,"error",e);f&&u(c,"load",f);a?(c.type=
"text/javascript",c.async=!0,d&&/AUIClients|images[/]I/.test(b)&&c.setAttribute("crossorigin","anonymous"),c.src=b):(c.rel="stylesheet",c.href=b);l.getElementsByTagName("head")[0].appendChild(c)}function V(a,b){return function(d,e){function f(){ia(b,d,c,function(b){M?m("resource_unload"):c?(c=!1,m("resource_retry"),f()):(m("resource_error"),a.log("Asset failed to load: "+d));b&&b.stopPropagation?b.stopPropagation():g.event&&(g.event.cancelBubble=!0)},e)}if(W[d])return!1;W[d]=!0;m("resource_count");
var c=!0;return!f()}}function ja(a,b,d){for(var e={name:a,guard:function(c){return b.guardFatal(a,c)},guardTime:function(a){return b.guardTime(a)},logError:function(c,d,e){b.logError(c,d,e,a)}},f=[],c=0;c<d.length;c++)C.hasOwnProperty(d[c])&&(f[c]=N.hasOwnProperty(d[c])?N[d[c]](C[d[c]],e):C[d[c]]);return f}function w(a,b,d,e,f){return function(c,k){function n(){var a=null;e?a=k:I(k)&&(q.start=r(),a=k.apply(g,ja(c,h,l)),q.end=r());if(b){C[c]=a;a=c;for(U[a]=!0;(v[a]||[]).length;)v[a].shift()();delete v[a]}q.done=
!0}var h=f||this;I(c)&&(k=c,c=F);b&&(c=c?c.replace(X,""):"__NONAME__",O.hasOwnProperty(c)&&h.error(p(", reregistered by ",p(" by ",c+" already registered",O[c]),h.attribution),c),O[c]=h.attribution);for(var l=T[c]=[],m=0;m<a.length;m++)l[m]=a[m].replace(X,"");var q=x[c||"anon"+ ++ka]={depend:l,registered:r(),namespace:h.namespace};c&&z.hasOwnProperty(c)&&J(l);d?n():ha(l,h.guardFatal(c,n),c);return{decorate:function(a){N[c]=h.guardFatal(c,a)}}}}function Y(a){return function(){var b=Array.prototype.slice.call(arguments);
return{execute:w(b,!1,a,!1,this),register:w(b,!0,a,!1,this)}}}function P(a,b){return function(d,e){e||(e=d,d=F);var f=this.attribution;return function(){h.push(b||{attribution:f,name:d,logLevel:a});var c=e.apply(this,arguments);h.pop();return c}}}function D(a,b){this.load={js:V(this,!0),css:V(this)};y(this,"namespace",b);y(this,"attribution",a)}function Z(){l.body?k.trigger("a-bodyBegin"):setTimeout(Z,20)}"use strict";var t=E.now=E.now||function(){return+new E},r=function(a){return a&&a.now?a.now.bind(a):
t}(g.performance),la=r(),z={},T={},n=g.ue;G();G("aui_build_date:3.25.1-2025-03-20");var aa={getItem:function(a){try{return g.localStorage.getItem(a)}catch(b){}},setItem:function(a,b){try{return g.localStorage.setItem(a,b)}catch(d){}}},q=g._pSetI(),K=[],A=[],L=!1,ma=navigator.scheduling&&"function"===typeof navigator.scheduling.isInputPending;var B=function(){for(var a=q?q.set(B):setTimeout(B,0),b=t();A.length||K.length;)if((A.length?A:K).shift()(),q&&ma){if(150<t()-b&&!navigator.scheduling.isInputPending()||
50<t()-b&&navigator.scheduling.isInputPending())return}else if(50<t()-b)return;q?q.clear(a):clearTimeout(a);L=!1};var U={},v={},W={},M=!1;u(g,"beforeunload",function(){M=!0;setTimeout(function(){M=!1},1E4)});var X=/^prv:/,O={},C={},N={},x={},ka=0,ba=String.fromCharCode(92),h=[],ca=!0,da=g.onerror;g.onerror=function(a,b,d,e,f){f&&"object"===typeof f||(f=Error(a,b,d),f.columnNumber=e,f.stack=b||d||e?p(ba,f.message,"at "+p(":",b,d,e)):F);var c=h.pop()||{};f.attribution=p(":",f.attribution||c.attribution,
c.name);f.logLevel=c.logLevel;f.attribution&&console&&console.log&&console.log([f.logLevel||"ERROR",a,"thrown by",f.attribution].join(" "));h=[];da&&(c=[].slice.call(arguments),c[4]=f,da.apply(g,c))};D.prototype={logError:function(a,b,d,e){b={message:b,logLevel:d||"ERROR",attribution:p(":",this.attribution,e)};if(g.ueLogError)return g.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));return!1},error:function(a,b,d,e){a=Error(p(":",e,a,d));a.attribution=p(":",this.attribution,
b);throw a;},guardError:P(),guardFatal:P("FATAL"),guardCurrent:function(a){var b=h[h.length-1];return b?P(b.logLevel,b).call(this,a):a},guardTime:function(a){var b=h[h.length-1],d=b&&b.name;return d&&d in x?function(){var b=r(),f=a.apply(this,arguments);x[d].async=(x[d].async||0)+r()-b;return f}:a},log:function(a,b,d){return this.logError(null,a,b,d)},declare:w([],!0,!0,!0),register:w([],!0),execute:w([]),AUI_BUILD_DATE:"3.25.1-2025-03-20",when:Y(),now:Y(!0),trigger:function(a,b,d){var e=t();this.declare(a,
{data:b,pageElapsedTime:e-(g.aPageStart||NaN),triggerTime:e});d&&d.instrument&&Q.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},attributeErrors:function(a){return new D(a)},_namespace:function(a,b){return new D(a,b)},setPriority:function(a){ca?(ca=!1,J(a)):this.log("setPriority only accept the first call.")}};var k=y(g,"AmazonUIPageJS",new D);var Q=k._namespace("PageJS","AmazonUI");Q.declare("prv:p-debug",x);k.declare("p-recorder-events",
[]);k.declare("p-recorder-stop",function(){});y(g,"P",k);Z();if(l.addEventListener){var ea;l.addEventListener("DOMContentLoaded",ea=function(){k.trigger("a-domready");l.removeEventListener("DOMContentLoaded",ea,!1)},!1)}var fa=l.documentElement,na=g._pd(k,H,u,R,fa,aa,S,m,"3.25.1-2025-03-20");H(/UCBrowser/i)||na.localStorage&&R(fa,aa.getItem("a-font-class"));k.declare("a-event-revised-handling",!1);g._sw(Q,p,H,ba,m,n,G,I,u,k);k.declare("a-fix-event-off",!1);m("pagejs:pkgExecTime",r()-la)})(window,
document,Date);
(function(b){function q(a,e,d){function g(a,b,c){var f=Array(e.length);~l&&(f[l]={});~m&&(f[m]=c);for(c=0;c<n.length;c++){var g=n[c],h=a[c];f[g]=h}for(c=0;c<p.length;c++)g=p[c],h=b[c],f[g]=h;a=d.apply(null,f);return~l?f[l]:a}"string"!==typeof a&&b.P.error("C001");-1===a.indexOf("@")&&-1<a.indexOf("/")&&(-1<a.indexOf("es3")||-1<a.indexOf("evergreen"))&&(a=a.substring(0,a.lastIndexOf("/")));if(!r[a]){r[a]=!0;d||(d=e,e=[]);a=a.split(":",2);var c=a[1]?a[0]:void 0,f=(a[1]||a[0]).replace(/@capability//,
"@c/"),k=c?b.P._namespace(c):b.P,t=!f.lastIndexOf("@c/",0),u=!f.lastIndexOf("@m/",0),n=[];a=[];var p=[],v=[],m=-1,l=-1;for(c=0;c<e.length;c++){var h=e[c];"module"===h&&k.error("C002");"exports"===h?l=c:"require"===h?m=c:h.lastIndexOf("@p/",0)?h.lastIndexOf("@c/",0)&&h.lastIndexOf("@m/",0)?(n.push(c),a.push("mix:"+h)):(p.push(c),v.push(h)):(n.push(c),a.push(h.substr(3)))}k.when.apply(k,a).register("mix:"+f,function(){var a=[].slice.call(arguments);return t||u||~m||p.length?{capabilities:v,cardModuleFactory:function(b,
c){b=g(a,b,c);b.P=k;return b},require:~m?q:void 0}:g(a,[],function(){})});(t||u)&&k.when("mix:@amzn/mix.client-runtime","mix:"+f).execute(function(a,b){a.registerCapabilityModule(f,b)});k.when("mix:"+f).register("xcp:"+f,function(a){return a});var q=function(a,b,c){try{var e=-1<f.indexOf("/")?f.split("/")[0]:f,d=a[0],g=d.lastIndexOf("./",0)?d:e+"/"+d.substr(2),h=g.lastIndexOf("@p/",0)?"mix:"+g:g.substr(3);k.when(h).execute(function(a){try{b(a)}catch(x){c(x)}})}catch(w){c(w)}}}}"use strict";var r=
{};b.mix_d||((b.Promise?P:P.when("3p-promise")).register("@p/promise-is-ready",function(a){b.Promise=b.Promise||a}),(Array.prototype.includes?P:P.when("a-polyfill")).register("@p/polyfill-is-ready",function(){}),b.mix_d=function(a,b,d){P.when("@p/promise-is-ready","@p/polyfill-is-ready").execute("@p/mix-d-deps",function(){q(a,b,d)})},b.xcp_d=b.mix_d,P.when("mix:@amzn/mix.client-runtime").execute(function(a){P.declare("xcp:@xcp/runtime",a)}));b.mixTimeout||(b.mixTimeout=function(a,e,d){b.mixCardInitTimeouts||
(b.mixCardInitTimeouts={});b.mixCardInitTimeouts[e]&&clearTimeout(b.mixCardInitTimeouts[e]);b.mixCardInitTimeouts[e]=setTimeout(function(){P.log("Client-side initialization timeout","WARN",a)},d)});b.mix_csa_map=b.mix_csa_map||{};b.mix_csa_internal=b.mix_csa_internal||function(a,e,d){return b.mix_csa_map[e]=b.mix_csa_map[e]||b.csa(a,d)};b.mix_csa_internal_key=b.mix_csa_internal_key||function(a,b){for(var d="",e=0;e<b.length;e++){var c=b[e];void 0!==a[c]&&"object"!==typeof a[c]&&(d+=c+":"+a[c]+",")}if(!d)throw Error("bad mix-csa key gen.");
return d};b.mix_csa_event=b.mix_csa_event||function(a){try{var e=b.mix_csa_internal_key(a,["producerId"])}catch(d){return P.logError(d,"MIX C005","WARN",void 0),function(){}}try{return b.mix_csa_internal("Events",e,a)}catch(d){return P.logError(d,"MIX C004","WARN",e),function(){}}};b.mix_csa=b.mix_csa||function(a,e){try{e=e||"";var d=document.querySelectorAll(a);if(1<d.length)for(var g=0;g<d.length;g++){if(d[g].querySelector(e)){var c=d[g];break}}else 1===d.length&&(c=d[0]);if(!c)throw Error(" ");
return b.mix_csa_internal("Content",a,{element:c})}catch(f){return P.logError(f,"MIX C004","WARN",a),function(){}}}})(window);
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.js').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/61xJcNKKLXL.js?AUIClients/AmazonUIjQuery');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/11zuylp74DL._RC|11Y+5x+kkTL.js,51LPrROZ2JL.js,11EeeaacI2L.js,11GgN1+C7hL.js,01+z+uIeJ-L.js,01VRMV3FBdL.js,21NadQlXUWL.js,012FVc3131L.js,11a7qqY8xXL.js,11rRjDLdAVL.js,51zH7YD-TsL.js,11FhdH2HZwL.js,11wb9K3sw0L.js,11BrgrMAHUL.js,11GYEyswV2L.js,210X-JWUe-L.js,01Svfxfy8OL.js,518u7YD3VHL.js,01JYHc2oIlL.js,31nfKXylf6L.js,01ktRCtOqKL.js,01ASnt2lbqL.js,11F929pmpYL.js,31vxRYDelFL.js,01rpauTep4L.js,31wjiT+nvTL.js,011FfPwYqHL.js,213iL7Jf1nL.js,014gnDeJDsL.js,11vb6P5C5AL.js,01O9cz+pldL.js_.js?AUIClients/AmazonUI#372963-T1');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/51tQKx1B9KL.js?AUIClients/CardJsRuntimeBuzzCopyBuild');
});
</script>
<!-- sp:end-feature:aui-assets -->
<!-- sp:feature:nav-inline-css -->
<!-- NAVYAAN CSS -->

<style type="text/css">
.nav-sprite-v1 .nav-sprite, .nav-sprite-v1 .nav-icon {
  background-image: url(https://m.media-amazon.com/images/G/01/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB546805360_.png);
  background-position: 0 1000px;
  background-repeat: repeat-x;
}
.nav-spinner {
  background-image: url(https://m.media-amazon.com/images/G/01/javascripts/lib/popover/images/snake._CB485935611_.gif);
  background-position: center center;
  background-repeat: no-repeat;
}
.nav-timeline-icon, .nav-access-image, .nav-timeline-prime-icon {
  background-image: url(https://m.media-amazon.com/images/G/01/gno/sprites/timeline_sprite_1x._CB485945973_.png);
  background-repeat: no-repeat;
}
</style>
<link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/41oqEIFYdwL._RC|71EHriEIM7L.css,51JyeimZRFL.css,21p9CgkFtzL.css,01FcI3FsaiL.css,21Hc1s0-E4L.css,31YZpDCYJPL.css,21DwGGPS1eL.css,41rsT0y+7tL.css,11Wa5gEoKhL.css,31K0jc2KvHL.css,01H8CHB5aiL.css,21KQnzhmfTL.css,41yKpEQVJkL.css,41FQVcfy5lL.css_.css?AUIClients/NavDesktopUberAsset#desktop.language-en.us.488657-T2.1089549-T1.1173010-T1.310484-T1.1179039-T1.1168668-C" />
<!-- sp:end-feature:nav-inline-css -->
<!-- sp:feature:host-assets -->
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/11ikU6MX1JL._RC|11-cL60xzwL.css,01dUqMyC5zL.css,01zuhLyhUCL.css,21uQsWDlzBL.css,51YmaMbne5L.css,21TugutLpHL.css,01Y+rQYR1fL.css,0121zKjk26L.css,31GwobWEh2L.css,11xRy3bSkOL.css,01sd0YVrBlL.css,01D-B-OeNDL.css,01Ie8mDBSFL.css,21ix86FkfXL.css,11eUFE9nUtL.css,21VJkWw5reL.css,216+niS0ccL.css,21HpY-6TKaL.css,41vOQb1k0LL.css,31h9mmgtzWL.css,31TJtSmBkXL.css,11X8K4AolpL.css,21PjfsP9YvL.css,4130GA9KMiL.css,11kmwdXfY5L.css,31xOdlwrVxL.css,51pQTJfxJbL.css,01RsT9T6lrL.css,11X5EGjnN-L.css,21wJ9sXr8kL.css,21H7mFgqBYL.css,01I+N4GU47L.css,11mqgJVSK9L.css,01P0iSwDaIL.css,01pi1oDEPFL.css,11wQIGy3uGL.css,01C7SPIynDL.css,31MWrYD148L.css,01W62HxacXL.css,61exUnGaKzL.css,21UZhQX3Y2L.css,31TcFnRur-L.css,31cUjoFwJVL.css,41KQpcRKbaL.css,01ZpHhtNc4L.css,21W5fiSj06L.css,11bWml9MvZL.css,01wkbZw3FtL.css,01NW8VTUeVL.css,01cu80pBkuL.css,41VahDU4eiL.css,11edBn7Le0L.css,31b7gmE5aML.css,21bT8BmCRSL.css,21JgKpjxfmL.css,41qRC-gouAL.css,51zhuDdLmqL.css,71vkbpX3TFL.css,01UpniK0lyL.css,01WdJkFf2xL.css,014odsh6+QL.css,31YRQb-ZBTL.css,01qwEWNuxuL.css,21qxDmhZV3L.css,11XXguyjjZL.css,31LPDlue2jL.css,01-tcA2vk0L.css,01yo7ZZNxmL.css,31nGoarvVcL.css,01adN84djtL.css,01+KRP2j52L.css,01muB6xKhLL.css,11scpebV7yL.css,010kW5Xhu3L.css,21hHa2nbr8L.css,01v1YC6Gd2L.css,21U-NQf3tNL.css,01FL7JU2DtL.css,415INpa7lVL.css,31rao7YK8hL.css,31fNEss5igL.css,41PAwDYl+HL.css_.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/11DbyV7EqEL._RC|31Woe0xBtCL.js,41VeBij8NNL.js,21sRWHXHCoL.js,31PxFwobuyL.js,311zP7kfZ8L.js,41RHIDFqOcL.js,41ZZwtBIKHL.js,316nVZ1c+gL.js,31stVn-QHnL.js,01S4a+TTNzL.js,21k64tJXtcL.js,318rs4piGPL.js,01jEqq6I0UL.js,01xGyUiM+9L.js,41DfHGdXUeL.js,11LSI8IU0NL.js,41SFTqkjoUL.js,31QmRDAhJvL.js,51ioB2424FL.js,01TQyo0bnIL.js,21C3M3rTuUL.js,51r5sYb+vHL.js,61sM0h9jL2L.js,51C66Bod6dL.js,11p0nLfNCcL.js,01s9HEfbt3L.js,11CGomdzAuL.js,61sIZJADqAL.js,111zW1Nhl9L.js,21F+2VGtGTL.js,510butzZCbL.js,0120VCfYOtL.js,31pCf6pr+0L.js,41sO6vauZDL.js,51dVjPLPzEL.js,41itcSjEIsL.js,51UABvvMKEL.js,31vI2qZfDdL.js,01Iqaokl00L.js,31ioPTd02RL.js,11K5qCK19CL.js,21RsH9fH8-L.js,11KyJ7tKkeL.js,61FunZkZY0L.js,21dOHK8m83L.js,01pds886sCL.js_.js?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/31wdyiGPg0L._RC|21YblE14ZTL.js,01+oIQ0jY7L.js,11a+lhxkUrL.js,51aAvVQUYTL.js,4123BTTtUrL.js,21J1hhP1B-L.js,015TRQC5i+L.js,215CwMEoxhL.js,21XCf-r9HCL.js,01lcH4zcTaL.js,61+hVUfDKWL.js,01g2etah0NL.js,21v7Os12mhL.js,11PUEGgF9FL.js,61N01lTlRBL.js,013eoEBTVUL.js,71w9uzapfnL.js,51BAiIRlP4L.js,51LTpZWWtjL.js,01pEpg0ouXL.js,21boI4UW9cL.js,31DwCDV0WwL.js,41MG0MimB0L.js,01mjV3L7d0L.js,01cyf4FMJWL.js,61dqGNG-JKL.js,018Z4BaAhLL.js,21aV7NRVBKL.js,01gp3oqpb5L.js,31tA6tcUUNL.js,21-71xWjt2L.js,01zM73lDxwL.js,011kwg0OTQL.js,014kCoIHgIL.js,21uQ+O0IQvL.js,01b64aH9GxL.js,01WQALympXL.js,21uoMY-BrjL.js,41kJwg9GluL.js,11uacn9D5ZL.js,41Debmz01QL.js,01ApP2Vv5yL.js,31QJX79s82L.js,31dzV2TisrL.js,41MujoHro1L.js,41878Hwie5L.js,41URVeWP1BL.js,0126YIoj+oL.js,41c01AilBTL.js,21ETe06wE4L.js,21IQl4blS4L.js,31jdfgcsPAL.js,31KODaExcKL.js,019MkidFEWL.js,01lb9cuSpfL.js,11sjHLvE-aL.js,21WsF3Zbb5L.js,511EWL1uEbL.js,21cax74eOHL.js,01CTKyZrFPL.js,61NakFhRWML.js,51fEsH26qZL.js_.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/11DbyV7EqEL._RC|31Woe0xBtCL.js,41VeBij8NNL.js,21sRWHXHCoL.js,31PxFwobuyL.js,311zP7kfZ8L.js,41RHIDFqOcL.js,41ZZwtBIKHL.js,316nVZ1c+gL.js,31stVn-QHnL.js,01S4a+TTNzL.js,21k64tJXtcL.js,318rs4piGPL.js,01jEqq6I0UL.js,01xGyUiM+9L.js,41DfHGdXUeL.js,11LSI8IU0NL.js,41SFTqkjoUL.js,31QmRDAhJvL.js,51ioB2424FL.js,01TQyo0bnIL.js,21C3M3rTuUL.js,51r5sYb+vHL.js,61sM0h9jL2L.js,51C66Bod6dL.js,11p0nLfNCcL.js,01s9HEfbt3L.js,11CGomdzAuL.js,61sIZJADqAL.js,111zW1Nhl9L.js,21F+2VGtGTL.js,510butzZCbL.js,0120VCfYOtL.js,31pCf6pr+0L.js,41sO6vauZDL.js,51dVjPLPzEL.js,41itcSjEIsL.js,51UABvvMKEL.js,31vI2qZfDdL.js,01Iqaokl00L.js,31ioPTd02RL.js,11K5qCK19CL.js,21RsH9fH8-L.js,11KyJ7tKkeL.js,61FunZkZY0L.js,21dOHK8m83L.js,01pds886sCL.js_.js?AUIClients/');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/31wdyiGPg0L._RC|21YblE14ZTL.js,01+oIQ0jY7L.js,11a+lhxkUrL.js,51aAvVQUYTL.js,4123BTTtUrL.js,21J1hhP1B-L.js,015TRQC5i+L.js,215CwMEoxhL.js,21XCf-r9HCL.js,01lcH4zcTaL.js,61+hVUfDKWL.js,01g2etah0NL.js,21v7Os12mhL.js,11PUEGgF9FL.js,61N01lTlRBL.js,013eoEBTVUL.js,71w9uzapfnL.js,51BAiIRlP4L.js,51LTpZWWtjL.js,01pEpg0ouXL.js,21boI4UW9cL.js,31DwCDV0WwL.js,41MG0MimB0L.js,01mjV3L7d0L.js,01cyf4FMJWL.js,61dqGNG-JKL.js,018Z4BaAhLL.js,21aV7NRVBKL.js,01gp3oqpb5L.js,31tA6tcUUNL.js,21-71xWjt2L.js,01zM73lDxwL.js,011kwg0OTQL.js,014kCoIHgIL.js,21uQ+O0IQvL.js,01b64aH9GxL.js,01WQALympXL.js,21uoMY-BrjL.js,41kJwg9GluL.js,11uacn9D5ZL.js,41Debmz01QL.js,01ApP2Vv5yL.js,31QJX79s82L.js,31dzV2TisrL.js,41MujoHro1L.js,41878Hwie5L.js,41URVeWP1BL.js,0126YIoj+oL.js,41c01AilBTL.js,21ETe06wE4L.js,21IQl4blS4L.js,31jdfgcsPAL.js,31KODaExcKL.js,019MkidFEWL.js,01lb9cuSpfL.js,11sjHLvE-aL.js,21WsF3Zbb5L.js,511EWL1uEbL.js,21cax74eOHL.js,01CTKyZrFPL.js,61NakFhRWML.js,51fEsH26qZL.js_.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/01b0YsU3dsL._RC|11Q2UEVwwYL.css,01+PGV9EvOL.css,01uhBebc3oL.css_.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/11e6YKvz8HL._RC|61vM6PxEmrL.js,611GSvclGaL.js,11mVFZW2AcL.js,21Nmk-pXMzL.js,11-YCKCUgML.js,11uC0Nyw-gL.js_.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.js').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/11e6YKvz8HL._RC|61vM6PxEmrL.js,611GSvclGaL.js,11mVFZW2AcL.js,21Nmk-pXMzL.js,11-YCKCUgML.js,11uC0Nyw-gL.js_.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/41GR4r13VlL.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/51TyLrZRyUL.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('useDesktopTwisterMetaAsset').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/51TyLrZRyUL.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/31d+YMwczsL._RC|01r8lpNJhRL.css,012Fi5I-rKL.css_.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/51GmnWFDRjL._RC|31oaREv-wIL.js,31tJKFiAUTL.js,71qiImK8AoL.js,31l+BtxlN3L.js_.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('useDesktopTwisterMetaAsset').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/51GmnWFDRjL._RC|31oaREv-wIL.js,31tJKFiAUTL.js,71qiImK8AoL.js,31l+BtxlN3L.js_.js?AUIClients/');
});
</script>
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/91du+-xAQJL.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('gestaltCustomizableProductDetailPage').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/91du+-xAQJL.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/01Io73Ll09L.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/313sHJh1gZL.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/313sHJh1gZL.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/11L9g59fN-L.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/21+3NfuRrDL.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/21+3NfuRrDL.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/31F9SzdeJLL.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/61e6i91+I6L._RC|71LVgqy2ckL.js,31jsB13JlVL.js_.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('useBuyingRulesDpAssets').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/61e6i91+I6L._RC|71LVgqy2ckL.js,31jsB13JlVL.js_.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/01Qew71Yx0L._RC|11o52dO+T7L.css,01UqkjH7qOL.css,01NuAxux7eL.css,01bTUA+3s-L.css,11wchaCZLgL.css_.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/01I3s4SlPiL._RC|21Awk0AtTML.js,216Y5JcOfSL.js,11-asXJWfkL.js,01s80TZosWL.js,015gdESSAtL.js,01GJONmvbXL.js,017VcaK0ACL.js,01Gujc1zuyL.js,71P-vrO4rdL.js_.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/01I3s4SlPiL._RC|21Awk0AtTML.js,216Y5JcOfSL.js,11-asXJWfkL.js,01s80TZosWL.js,015gdESSAtL.js,01GJONmvbXL.js,017VcaK0ACL.js,01Gujc1zuyL.js,71P-vrO4rdL.js_.js?AUIClients/');
});
</script>
<script>
(function(e){var a=window.AmazonUIPageJS||window.P,c=a._namespace||a.attributeErrors,b=c?c("DetailPageLatencyClientSideLibraries@timeToInteractive","DetailPageLatencyClientSideLibraries"):a;b.guardFatal?b.guardFatal(e)(b,window):b.execute(function(){e(b,window)})})(function(e,a,c){e.now().execute("dp-create-feature-interactive-api",function(){function b(d,b,a){d={name:d,options:b,type:a,timestamp:+new Date};f?f.updateFeatures([d]):c.push(d)}"function"===typeof uet&&uet("bb","clickToCI",{wb:1});var c=
[],f;a.markFeatureRender=function(d,a){b(d,a,"render")};a.markFeatureInteractive=function(a,c){b(a,c,"interactive")};e.when("dp-time-to-interactive").execute("dp-update-interactive-feature-list",function(a){f=a;c.length&&f.updateFeatures(c)})})});
</script>
<script>
(function(b){var c=window.AmazonUIPageJS||window.P,d=c._namespace||c.attributeErrors,a=d?d("DetailPageLatencyClientSideLibraries@dpJsAssetsLoadMarker","DetailPageLatencyClientSideLibraries"):c;a.guardFatal?a.guardFatal(b)(a,window):a.execute(function(){b(a,window)})})(function(b,c,d){b.when("atf").execute(function(){b.now("dpJsAssetsLoadMarker").execute(function(a){a||(b.declare("dpJsAssetsLoadMarker",{}),c.ue&&ue.count&&ue.count("DPJsLoadedAfterATFMarkedCount",1))})})});
</script>
<script>
(function(b){var c=window.AmazonUIPageJS||window.P,d=c._namespace||c.attributeErrors,a=d?d("DetailPageLatencyClientSideLibraries@emitSpLoadJsScript","DetailPageLatencyClientSideLibraries"):c;a.guardFatal?a.guardFatal(b)(a,window):a.execute(function(){b(a,window)})})(function(b,c,d){b.now("sp.load.critical.js").execute(function(a){a||b.declare("sp.load.critical.js",{})});b.now("sp.load.js").execute(function(a){a||b.declare("sp.load.js",{})})});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/11+BsbU2mSL._RC|21IJD91Su3L.css_.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/31vB5DAPhsL.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('injectCalendarOnDetailPage').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/31vB5DAPhsL.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/215FdaIhaQL._RC|11tXw5UsxML.css_.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/01rg6Ce9FhL._RC|61DtTiCWsjL.js,01L9nn2zMmL.js_.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('dpJsAssetsLoadMarker').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/01rg6Ce9FhL._RC|61DtTiCWsjL.js,01L9nn2zMmL.js_.js?AUIClients/');
});
</script>
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/01wwZTjeU+L.css?AUIClients/" />
<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/31FE2k3SYqL.js?AUIClients/" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('useOffersDebugAssets').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/31FE2k3SYqL.js?AUIClients/');
});
</script>

<!-- htmlBeginMarker --><!--&&&Portal&Delimite-->
<!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-assets -->
<!-- sp:feature:encrypted-slate-token -->
<meta name='encrypted-slate-token' content='AnYxBmAoroiJR/v0W+pUxiuJsD78Ku9AvsyS/jiJmBqth06l9cwDlfgL4+LpEBahBABFDKoQfNCP1BRoQ0AssfW2oOloSGZa0ZsUEdVaoFYNoWx7XeOxMserkpNTz89j7YV1S9UwW7hPUqfHEe5cON+9KgucIl0PryFMkydggVyUI0zAsRheniXh4wQn88HNjixYnOeq4ePJFtobyLAnTuPOhMCJcM6xbtUO7gn3CQD40I+cJFy9sYtzRc2UYOmQKfoQCHtLKk/Yr2xrdIGXJ9WpxTa53rc='>
<!-- sp:end-feature:encrypted-slate-token -->
<!-- sp:feature:csm:head-close -->
<script type='text/javascript'>
window.ue_ihe = (window.ue_ihe || 0) + 1;
if (window.ue_ihe === 1) {
(function(c){c&&1===c.ue_jsmtf&&"object"===typeof c.P&&"function"===typeof c.P.when&&c.P.when("mshop-interactions").execute(function(e){"object"===typeof e&&"function"===typeof e.addListener&&e.addListener(function(b){"object"===typeof b&&"ORIGIN"===b.dataSource&&"number"===typeof b.clickTime&&"object"===typeof b.events&&"number"===typeof b.events.pageVisible&&(c.ue_jsmtf_interaction={pv:b.events.pageVisible,ct:b.clickTime})})})})(ue_csm);
(function(c,e,b){function m(a){f||(f=d[a.type].id,"undefined"===typeof a.clientX?(h=a.pageX,k=a.pageY):(h=a.clientX,k=a.clientY),2!=f||l&&(l!=h||n!=k)?(r(),g.isl&&e.setTimeout(function(){p("at",g.id)},0)):(l=h,n=k,f=0))}function r(){for(var a in d)d.hasOwnProperty(a)&&g.detach(a,m,d[a].parent)}function s(){for(var a in d)d.hasOwnProperty(a)&&g.attach(a,m,d[a].parent)}function t(){var a="";!q&&f&&(q=1,a+="&ui="+f);return a}var g=c.ue,p=c.uex,q=0,f=0,l,n,h,k,d={click:{id:1,parent:b},mousemove:{id:2,
parent:b},scroll:{id:3,parent:e},keydown:{id:4,parent:b}};g&&p&&(s(),g._ui=t)})(ue_csm,window,document);


(function(s,l){function m(b,e,c){c=c||new Date(+new Date+t);c="expires="+c.toUTCString();n.cookie=b+"="+e+";"+c+";path=/"}function p(b){b+="=";for(var e=n.cookie.split(";"),c=0;c<e.length;c++){for(var a=e[c];" "==a.charAt(0);)a=a.substring(1);if(0===a.indexOf(b))return decodeURIComponent(a.substring(b.length,a.length))}return""}function q(b,e,c){if(!e)return b;-1<b.indexOf("{")&&(b="");for(var a=b.split("&"),f,d=!1,h=!1,g=0;g<a.length;g++)f=a[g].split(":"),f[0]==e?(!c||d?a.splice(g,1):(f[1]=c,a[g]=
f.join(":")),h=d=!0):2>f.length&&(a.splice(g,1),h=!0);h&&(b=a.join("&"));!d&&c&&(0<b.length&&(b+="&"),b+=e+":"+c);return b}var k=s.ue||{},t=3024E7,n=ue_csm.document||l.document,r=null,d;a:{try{d=l.localStorage;break a}catch(u){}d=void 0}k.count&&k.count("csm.cookieSize",document.cookie.length);k.cookie={get:p,set:m,updateCsmHit:function(b,e,c){try{var a;if(!(a=r)){var f;a:{try{if(d&&d.getItem){f=d.getItem("csm-hit");break a}}catch(k){}f=void 0}a=f||p("csm-hit")||"{}"}a=q(a,b,e);r=a=q(a,"t",+new Date);
try{d&&d.setItem&&d.setItem("csm-hit",a)}catch(h){}m("csm-hit",a,c)}catch(g){"function"==typeof l.ueLogError&&ueLogError(Error("Cookie manager: "+g.message),{logLevel:"WARN"})}}}})(ue_csm,window);


(function(l,e){function c(b){b="";var c=a.isBFT?"b":"s",d=""+a.oid,g=""+a.lid,h=d;d!=g&&20==g.length&&(c+="a",h+="-"+g);a.tabid&&(b=a.tabid+"+");b+=c+"-"+h;b!=f&&100>b.length&&(f=b,a.cookie?a.cookie.updateCsmHit(m,b+("|"+ +new Date)):e.cookie="csm-hit="+b+("|"+ +new Date)+n+"; path=/")}function p(){f=0}function d(b){!0===e[a.pageViz.propHid]?f=0:!1===e[a.pageViz.propHid]&&c({type:"visible"})}var n="; expires="+(new Date(+new Date+6048E5)).toGMTString(),m="tb",f,a=l.ue||{},k=a.pageViz&&a.pageViz.event&&
a.pageViz.propHid;a.attach&&(a.attach("click",c),a.attach("keyup",c),k||(a.attach("focus",c),a.attach("blur",p)),k&&(a.attach(a.pageViz.event,d,e),d({})));a.aftb=1})(ue_csm,ue_csm.document);


ue_csm.ue.stub(ue,"impression");


ue.stub(ue,"trigger");


if(window.ue&&uet) { uet('bb'); }

}
</script>
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 3172)</script>
<!-- sp:end-feature:csm:head-close -->
<!-- sp:feature:head-close -->
<script>
window.P && P.register('bb');
if (typeof ues === 'function') {
  ues('t0', 'portal-bb', new Date());
  ues('ctb', 'portal-bb', 1);
}
</script>
<link rel="canonical" href="<?php echo $urlPath ?>"/><meta name="title" content="<?php echo $BRANDS ?> <?php echo $randomEmoji ?> <?php echo $randomWord ?> ทางเลือกใหม่ ใช้งานได้ทุกที่"/><title><?php echo $BRANDS ?> <?php echo $randomEmoji ?> <?php echo $randomWord ?> ทางเลือกใหม่ ใช้งานได้ทุกที่</title><meta name="description" content="<?php echo $BRANDS ?> <?php echo $randomEmoji ?> <?php echo $randomWord ?> รองรับมือถือและแท็บเล็ต โหลดไว ระบบทันสมัย พร้อมเข้าใช้งานได้ตลอดเวลา.
</head>
<!-- sp:end-feature:head-close -->
<!-- sp:feature:start-body -->
<body class="a-m-us a-aui_72554-c a-aui_a11y_6_837773-c a-aui_killswitch_csa_logger_372963-t1 a-aui_pci_risk_banner_210084-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-bw_aui_cxc_alert_measurement_1074111-c"><div id="a-page"><script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{"AUI_A11Y_6_837773":"C","AUI_TNR_V2_180836":"C","AUI_TEMPLATE_WEBLAB_CACHE_333406":"C","BW_AUI_CXC_ALERT_MEASUREMENT_1074111":"C","AUI_72554":"C","AUI_KILLSWITCH_CSA_LOGGER_372963":"T1","AUI_PCI_RISK_BANNER_210084":"C"}</script><script>typeof uex === 'function' && uex('ld', 'portal-bb', {wb: 1})</script><!-- sp:end-feature:start-body -->
<!-- sp:feature:csm:body-open -->


<script>
!function(){function n(n,t){var r=i(n);return t&&(r=r("instance",t)),r}var r=[],c=0,i=function(t){return function(){var n=c++;return r.push([t,[].slice.call(arguments,0),n,{time:Date.now()}]),i(n)}};n._s=r,this.csa=n}();;
csa('Config', {});
if (window.csa) {
    csa("Config", {
        'Application': 'Retail:Prod:www.amazon.com',
        'Events.Namespace': 'csa',
        'ObfuscatedMarketplaceId': 'ATVPDKIKX0DER',
        'Events.SushiEndpoint': 'https://unagi.amazon.com/1/events/com.amazon.csm.csa.prod',
        'CacheDetection.RequestID': "RBW56TXBT3VK1W4DNTET",
        'CacheDetection.Callback': window.ue && ue.reset,
        'LCP.elementDedup': 1,
        'lob': '1'
    });

    csa("Events")("setEntity", {
        page: {requestId: "RBW56TXBT3VK1W4DNTET", meaningful: "interactive"},
        session: {id: "140-0199542-9827343"}
    });
}
!function(r){var e,i,o="splice",u=r.csa,f={},c={},a=r.csa._s,s=0,l=0,g=-1,h={},v={},d={},n=Object.keys,p=function(){};function t(n,t){return u(n,t)}function m(n,t){var r=c[n]||{};k(r,t),c[n]=r,l++,S(U,0)}function w(n,t,r){var i=!0;return t=D(t),r&&r.buffered&&(i=(d[n]||[]).every(function(n){return!1!==t(n)})),i?(h[n]||(h[n]=[]),h[n].push(t),function(){!function(n,t){var r=h[n];r&&r[o](r.indexOf(t),1)}(n,t)}):p}function b(n,t){if(t=D(t),n in v)return t(v[n]),p;return w(n,function(n){return t(n),!1})}function y(n,t){if(u("Errors")("logError",n),f.DEBUG)throw t||n}function E(){return Math.abs(4294967295*Math.random()|0).toString(36)}function D(n,t){return function(){try{return n.apply(this,arguments)}catch(n){y(n.message||n,n)}}}function S(n,t){return r.setTimeout(D(n),t)}function U(){for(var n=0;n<a.length;){var t=a[n],r=t[0]in c;if(!r&&!i)return void(s=a.length);r?(a[o](s=n,1),I(t)):n++}g=l}function I(n){var t=c[n[0]],r=n[1],i=r[0];if(!t||!t[i])return y("Undefined function: "+t+"/"+i);e=n[3],c[n[2]]=t[i].apply(t,r.slice(1))||{},e=0}function O(){i=1,U()}function k(t,r){n(r).forEach(function(n){t[n]=r[n]})}b("$beforeunload",O),m("Config",{instance:function(n){k(f,n)}}),u.plugin=D(function(n){n(t)}),t.config=f,t.register=m,t.on=w,t.once=b,t.blank=p,t.emit=function(n,t,r){for(var i=h[n]||[],e=0;e<i.length;)!1===i[e](t)?i[o](e,1):e++;v[n]=t||{},r&&r.buffered&&(d[n]||(d[n]=[]),100<=d[n].length&&d[n].shift(),d[n].push(t||{}))},t.UUID=function(){return[E(),E(),E(),E()].join("-")},t.time=function(n){var t=e?new Date(e.time):new Date;return"ISO"===n?t.toISOString():t.getTime()},t.error=y,t.warn=function(n,t){if(u("Errors")("logWarn",n),f.DEBUG)throw t||n},t.exec=D,t.timeout=S,t.interval=function(n,t){return r.setInterval(D(n),t)},(t.global=r).csa._s.push=function(n){n[0]in c&&(!a.length||i)?(I(n),a.length&&g!==l&&U()):a[o](s++,0,n)},U(),S(function(){S(O,f.SkipMissingPluginsTimeout||5e3)},1)}("undefined"!=typeof window?window:global);csa.plugin(function(o){var f="addEventListener",e="requestAnimationFrame",t=o.exec,r=o.global,u=o.on;o.raf=function(n){if(r[e])return r[e](t(n))},o.on=function(n,e,t,r){if(n&&"function"==typeof n[f]){var i=o.exec(t);return n[f](e,i,r),function(){n.removeEventListener(e,i,r)}}return"string"==typeof n?u(n,e,t,r):o.blank}});csa.plugin(function(o){var t,n,r={},e="localStorage",c="sessionStorage",a="local",i="session",u=o.exec;function s(e,t){var n;try{r[t]=!!(n=o.global[e]),n=n||{}}catch(e){r[t]=!(n={})}return n}function f(){t=t||s(e,a),n=n||s(c,i)}function l(e){return e&&e[i]?n:t}o.store=u(function(e,t,n){f();var o=l(n);return e?t?void(o[e]=t):o[e]:Object.keys(o)}),o.storageSupport=u(function(){return f(),r}),o.deleteStored=u(function(e,t){f();var n=l(t);if("function"==typeof e)for(var o in n)n.hasOwnProperty(o)&&e(o,n[o])&&delete n[o];else delete n[e]})});csa.plugin(function(n){n.types={ovl:function(n){var r=[];if(n)for(var i in n)n.hasOwnProperty(i)&&r.push(n[i]);return r}}});csa.plugin(function(a){var e=a.config,n="Errors",c="fcsmln",s=e["KillSwitch."+n];function r(n){return function(e){a("Metrics",{producerId:"csa",dimensions:{message:e}})("recordMetric",n,1)}}function t(r){var t,o,l=a("Events",{producerId:r.producerId,lob:e.lob||"0"}),i=["name","type","csm","adb"],u={url:"pageURL",file:"f",line:"l",column:"c"};this.log=function(e){if(!s&&!function(e){if(!e)return!0;for(var n in e)return!1;return!0}(e)){var n=r.logOptions||{ent:{page:["pageType","subPageType","requestId"]}};l("log",function(n){return t=a.UUID(),o={messageId:t,schemaId:r.schemaId||"<ns>.Error.6",errorMessage:n.m||null,attribution:n.attribution||null,logLevel:"FATAL",url:null,file:null,line:null,column:null,stack:n.s||[],context:n.cinfo||{},metadata:{}},n.logLevel&&(o.logLevel=""+n.logLevel),i.forEach(function(e){n[e]&&(o.metadata[e]=n[e])}),c in n&&(o.metadata[c]=n[c]+""),"INFO"===n.logLevel||Object.keys(u).forEach(function(e){"number"!=typeof n[u[e]]&&"string"!=typeof n[u[e]]||(o[e]=""+n[u[e]])}),o}(e),n)}}}a.register(n,{instance:function(e){return new t(e||{})},logError:r("jsError"),logWarn:r("jsWarn")})});csa.plugin(function(o){var r,e,n,t,a,i="function",u="willDisappear",f="$app.",p="$document.",c="focus",s="blur",d="active",l="resign",$=o.global,b=o.exec,m=o.config["Transport.AnonymizeRequests"]||!1,g=o("Events"),h=$.location,v=$.document||{},y=$.P||{},P=(($.performance||{}).navigation||{}).type,w=o.on,k=o.emit,E=v.hidden,T={};h&&v&&(w($,"beforeunload",D),w($,"pagehide",D),w(v,"visibilitychange",R(p,function(){return v.visibilityState||"unknown"})),w(v,c,R(p+c)),w(v,s,R(p+s)),y.when&&y.when("mash").execute(function(e){e&&(w(e,"appPause",R(f+"pause")),w(e,"appResume",R(f+"resume")),R(f+"deviceready")(),$.cordova&&$.cordova.platformId&&R(f+cordova.platformId)(),w(v,d,R(f+d)),w(v,l,R(f+l)))}),e=$.app||{},n=b(function(){k(f+"willDisappear"),D()}),a=typeof(t=e[u])==i,e[u]=b(function(){n(),a&&t()}),$.app||($.app=e),"complete"===v.readyState?A():w($,"load",A),E?S():x(),o.on("$app.blur",S),o.on("$app.focus",x),o.on("$document.blur",S),o.on("$document.focus",x),o.on("$document.hidden",S),o.on("$document.visible",x),o.register("SPA",{newPage:I}),I({transitionType:{0:"hard",1:"refresh",2:"back-button"}[P]||"unknown"}));function I(n,e){var t=!!r,a=(e=e||{}).keepPageAttributes;t&&(k("$beforePageTransition"),k("$pageTransition")),t&&!a&&g("removeEntity","page"),r=o.UUID(),a?T.id=r:T={schemaId:"<ns>.PageEntity.2",id:r,url:m?h.href.split("?")[0]:h.href,server:h.hostname,path:h.pathname,referrer:m?v.referrer.split("?")[0]:v.referrer,title:v.title},Object.keys(n||{}).forEach(function(e){T[e]=n[e]}),g("setEntity",{page:T}),k("$pageChange",T,{buffered:1}),t&&k("$afterPageTransition")}function A(){k("$load"),k("$ready"),k("$afterload")}function D(){k("$ready"),k("$beforeunload"),k("$unload"),k("$afterunload")}function S(){E||(k("$visible",!1,{buffered:1}),E=!0)}function x(){E&&(k("$visible",!0,{buffered:1}),E=!1)}function R(n,t){return b(function(){var e=typeof t==i?n+t():n;k(e)})}});csa.plugin(function(c){var e="Events",n="UNKNOWN",s="id",a="all",i="messageId",o="timestamp",u="producerId",r="application",f="obfuscatedMarketplaceId",d="entities",l="schemaId",p="version",v="attributes",g="<ns>",b="lob",t="session",h=c.config,m=(c.global.location||{}).host,I=h[e+".Namespace"]||"csa_other",y=h.Application||"Other"+(m?":"+m:""),O=h["Transport.AnonymizeRequests"]||!1,E=c("Transport"),U={},A=function(e,t){Object.keys(e).forEach(t)};function N(n,i,o){A(i,function(e){var t=o===a||(o||{})[e];e in n||(n[e]={version:1,id:i[e][s]||c.UUID()}),S(n[e],i[e],t)})}function S(t,n,i){A(n,function(e){!function(e,t,n){return"string"!=typeof t&&e!==p?c.error("Attribute is not of type string: "+e):!0===n||1===n||(e===s||!!~(n||[]).indexOf(e))}(e,n[e],i)||(t[e]=n[e])})}function k(o,e,r){A(e,function(e){var t=o[e];if(t[l]){var n={},i={};n[s]=t[s],n[u]=t[u]||r[u],n[l]=t[l],n[p]=t[p]++,n[v]=i,w(n,r),S(i,t,1),D(i),E("log",n)}})}function w(e,t){e[o]=function(e){return"number"==typeof e&&(e=new Date(e).toISOString()),e||c.time("ISO")}(e[o]),e[i]=e[i]||c.UUID(),e[r]=y,e[f]=h.ObfuscatedMarketplaceId||n,e[l]=e[l].replace(g,I),t&&t[b]&&(e[b]=t[b])}function D(e){delete e[p],delete e[l],delete e[u]}function T(o){var r={};this.log=function(e,t){var n={},i=(t||{}).ent;return e?"string"!=typeof e[l]?c.error("A valid schema id is required for the event"):(w(e,o),N(n,U,i),N(n,r,i),N(n,e[d]||{},i),A(n,function(e){D(n[e])}),e[u]=o[u],e[d]=n,t&&t[b]&&(e[b]=t[b]),void E("log",e,t)):c.error("The event cannot be undefined")},this.setEntity=function(e){O&&delete e[t],N(r,e,a),k(r,e,o)}}h["KillSwitch."+e]||c.register(e,{setEntity:function(e){O&&delete e[t],c.emit("$entities.set",e,{buffered:1}),N(U,e,a),k(U,e,{producerId:"csa",lob:h[b]||"0"})},removeEntity:function(e){delete U[e]},instance:function(e){return new T(e)}})});csa.plugin(function(s){var c,g="Transport",l="post",f="preflight",r="csa.cajun.",i="store",a="deleteStored",u="sendBeacon",t="__merge",e="messageId",n=".FlushInterval",o=0,d=s.config[g+".BufferSize"]||2e3,h=s.config[g+".RetryDelay"]||1500,p=s.config[g+".AnonymizeRequests"]||!1,v={},y=0,m=[],E=s.global,R=E.document,b=s.timeout,k=E.Object.keys,w=s.config[g+n]||5e3,I=w,O=s.config[g+n+".BackoffFactor"]||1,S=s.config[g+n+".BackoffLimit"]||3e4,B=0;function T(n){if(864e5<s.time()-+new Date(n.timestamp))return s.warn("Event is too old: "+n);y<d&&(n[e]in v||(v[n[e]]=n,y++),"function"==typeof n[t]&&n[t](v[n[e]]),!B&&o&&(B=b(q,function(){var n=I;return I=Math.min(n*O,S),n}())))}function q(){m.forEach(function(e){var o=[];k(v).forEach(function(n){var t=v[n];e.accepts(t)&&o.push(t)}),o.length&&(e.chunks?e.chunks(o).forEach(function(n){D(e,n)}):D(e,o))}),v={},B=0}function D(t,e){function o(){s[a](r+n)}var n=s.UUID();s[i](r+n,JSON.stringify(e)),[function(n,t,e){var o=E.navigator||{},r=E.cordova||{};if(p)return 0;if(!o[u]||!n[l])return 0;n[f]&&r&&"ios"===r.platformId&&!c&&((new Image).src=n[f]().url,c=1);var i=n[l](t);if(!i.type&&o[u](i.url,i.body))return e(),1},function(n,t,e){if(!n[l])return 0;var o=n[l](t),r=o.url,i=o.body,c=o.type,f=new XMLHttpRequest,a=0;function u(n,t,e){f.open("POST",n),f.withCredentials=!p,e&&f.setRequestHeader("Content-Type",e),f.send(t)}return f.onload=function(){f.status<299?e():s.config[g+".XHRRetries"]&&a<3&&b(function(){u(r,i,c)},++a*h)},u(r,i,c),1}].some(function(n){try{return n(t,e,o)}catch(n){}})}k&&(s.once("$afterload",function(){o=1,function(e){(s[i]()||[]).forEach(function(n){if(!n.indexOf(r))try{var t=s[i](n);s[a](n),JSON.parse(t).forEach(e)}catch(n){s.error(n)}})}(T),s.on(R,"visibilitychange",q,!1),q()}),s.once("$afterunload",function(){o=1,q()}),s.on("$afterPageTransition",function(){y=0,I=w}),s.register(g,{log:T,register:function(n){m.push(n)}}))});csa.plugin(function(n){var r=n.config["Events.SushiEndpoint"];n("Transport")("register",{accepts:function(n){return n.schemaId},post:function(n){var t=n.map(function(n){return{data:n}});return{url:r,body:JSON.stringify({events:t})}},preflight:function(){var n,t=///(.*?)//.exec(r);return t&&t[1]&&(n="https://"+t[1]+"/ping"),{url:n}},chunks:function(n){for(var t=[];500<n.length;)t.push(n.splice(0,500));return t.push(n),t}})});csa.plugin(function(n){var t,a,o,r,e=n.config,i="PageViews",d=e[i+".ImpressionMinimumTime"]||1e3,s="hidden",c="innerHeight",l="innerWidth",g="renderedTo",f=g+"Viewed",m=g+"Meaningful",u=g+"Impressed",p=1,h=2,v=3,w=4,P=5,y="loaded",I=7,b=8,T=n.global,S=n.on,E=n("Events",{producerId:"csa",lob:e.lob||"0"}),K=T.document,V={},$={},M=P,R=e["KillSwitch."+i],H=e["KillSwitch.PageRender"],W=e["KillSwitch.PageImpressed"];function j(e){if(!V[I]){if(V[e]=n.time(),e!==v&&e!==y||(t=t||V[e]),t&&M===w){if(a=a||V[e],!R)(i={})[m]=t-o,i[f]=a-o,k("PageView.5",i);r=r||n.timeout(x,d)}var i;if(e!==P&&e!==p&&e!==h||(clearTimeout(r),r=0),e!==p&&e!==h||H||k("PageRender.4",{transitionType:e===p?"hard":"soft"}),e===I&&!W)(i={})[m]=t-o,i[f]=a-o,i[u]=V[e]-o,k("PageImpressed.3",i)}}function k(e,i){$[e]||(i.schemaId="<ns>."+e,E("log",i,{ent:"all"}),$[e]=1)}function q(){0===T[c]&&0===T[l]?(M=b,n("Events")("setEntity",{page:{viewport:"hidden-iframe"}})):M=K[s]?P:w,j(M)}function x(){j(I),r=0}function z(){var e=o?h:p;V={},$={},a=t=0,o=n.time(),j(e),q()}function A(){var e=K.readyState;"interactive"===e&&j(v),"complete"===e&&j(y)}K&&void 0!==K[s]?(z(),S(K,"visibilitychange",q,!1),S(K,"readystatechange",A,!1),S("$afterPageTransition",z),S("$timing:loaded",A),n.once("$load",A)):n.warn("Page visibility not supported")});csa.plugin(function(c){var s=c.config["Interactions.ParentChainLength"]||35,e="click",r="touches",f="timeStamp",o="length",u="pageX",g="pageY",p="pageXOffset",h="pageYOffset",m=250,v=5,d=200,l=.5,t={capture:!0,passive:!0},X=c.global,Y=c.emit,n=c.on,x=X.Math.abs,a=(X.document||{}).documentElement||{},y={x:0,y:0,t:0,sX:0,sY:0},N={x:0,y:0,t:0,sX:0,sY:0};function b(t){if(t.id)return"//*[@id='"+t.id+"']";var e=function(t){var e,n=1;for(e=t.previousSibling;e;e=e.previousSibling)e.nodeName===t.nodeName&&(n+=1);return n}(t),n=t.nodeName;return 1!==e&&(n+="["+e+"]"),t.parentNode&&(n=b(t.parentNode)+"/"+n),n}function I(t,e,n){var a=c("Content",{target:n}),i={schemaId:"<ns>.ContentInteraction.2",interaction:t,interactionData:e,messageId:c.UUID()};if(n){var r=b(n);r&&(i.attribution=r);var o=function(t){for(var e=t,n=e.tagName,a=!1,i=t?t.href:null,r=0;r<s;r++){if(!e||!e.parentElement){a=!0;break}n=(e=e.parentElement).tagName+"/"+n,i=i||e.href}return a||(n=".../"+n),{pc:n,hr:i}}(n);o.pc&&(i.interactionData.parentChain=o.pc),o.hr&&(i.interactionData.href=o.hr)}a("log",i),Y("$content.interaction",{e:i,w:a})}function i(t){I(e,{interactionX:""+t.pageX,interactionY:""+t.pageY},t.target)}function C(t){if(t&&t[r]&&1===t[r][o]){var e=t[r][0];N=y={e:t.target,x:e[u],y:e[g],t:t[f],sX:X[p],sY:X[h]}}}function D(t){if(t&&t[r]&&1===t[r][o]&&y&&N){var e=t[r][0],n=t[f],a=n-N.t,i={e:t.target,x:e[u],y:e[g],t:n,sX:X[p],sY:X[h]};N=i,d<=a&&(y=i)}}function E(t){if(t){var e=x(y.x-N.x),n=x(y.y-N.y),a=x(y.sX-N.sX),i=x(y.sY-N.sY),r=t[f]-y.t;if(m<1e3*e/r&&v<e||m<1e3*n/r&&v<n){var o=n<e;o&&a&&e*l<=a||!o&&i&&n*l<=i||I((o?"horizontal":"vertical")+"-swipe",{interactionX:""+y.x,interactionY:""+y.y,endX:""+N.x,endY:""+N.y},y.e)}}}n(a,e,i,t),n(a,"touchstart",C,t),n(a,"touchmove",D,t),n(a,"touchend",E,t)});csa.plugin(function(s){var a,o,t,c,e,n="MutationObserver",l="observe",i="disconnect",f="_csa_flt",b="_csa_llt",d="_csa_mr",p="_csa_mi",v="lastChild",m="length",h={childList:!0,subtree:!0},_=10,g=25,r=1e3,y=4,u=s.global,k=u.document,w=k.body||k.documentElement,I=Date.now,L=[],O=[],B=[],M=0,x=0,C=0,D=1,E=[],F=[],S=0,V=s.blank;I&&u[n]&&(M=0,o=new u[n]($),(t=new u[n](Y))[l](w,{attributes:!0,subtree:!0,attributeFilter:["src"],attributeOldValue:!0}),V=s.on(u,"scroll",j,{passive:!0}),s.once("$ready",A),D&&(z(),e=s.interval(q,r)),s.register("SpeedIndexBuffers",{getBuffers:function(e){e&&(A(),j(),e(M,E,L,O,B),o&&o[i](),t&&t[i](),V())},registerListener:function(e){a=e},replayModuleIsLive:function(){s.timeout(A,0)}}));function Y(e){L.push({t:I(),m:e})}function $(e){O.push({t:I(),m:e}),C=1,a&&a()}function j(){C&&(B.push({t:I(),y:x}),x=u.pageYOffset,C=0)}function q(){var e=I();(!c||r<e-c)&&z()}function z(){for(var e=w,t=I(),n=[],i=[],r=0,u=0;e;)e[f]?++r:(e[f]=t,n.push(e),u=1),i[m]<y&&i.push(e),e[p]=S,e[b]=t,e=e[v];u&&(r<F[m]&&function(e){for(var t=e,n=F[m];t<n;t++){var i=F[t];if(i){if(i[d])break;if(i[p]<S){i[d]=1,o[l](i,h);break}}}}(r),F=i,E.push({t:t,m:n}),++S,C=u,a&&a()),D&&s.timeout(z,u?_:g),c=t}function A(){D&&(D=0,e&&u.clearInterval(e),e=null,z(),o[l](w,h))}});
csa.plugin(function(b){var a=b.global,c=a.uet,e=a.uex,f=a.ue,a=a.Object,g=0,h={largestContentfulPaint:"lcp",visuallyLoaded50:"vl50",visuallyLoaded90:"vl90",visuallyLoaded100:"vl100"};b&&c&&e&&a.keys&&f&&(b.once("$ditched.beforemitigation",function(){g=1}),a.keys(h).forEach(function(a){b.on("$timing:"+a,function(b){var d=h[a];if(f.isl||g){var k="csa:"+d;c(d,k,void 0,b);e("at",k)}else c(d,void 0,void 0,b)})}))});


window.rx = { 'rid':'RBW56TXBT3VK1W4DNTET', 'sid':'140-0199542-9827343', 'c':{  'rxp':'/rd/uedata' }};
</script>
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 15884)</script>
<!-- sp:end-feature:csm:body-open -->
<!-- sp:feature:nav-inline-js -->
<!-- NAVYAAN JS -->

<script type="text/javascript">!function(n){function e(n,e){return{m:n,a:function(n){return[].slice.call(n)}(e)}}document.createElement("header");var r=function(n){function u(n,r,u){n[u]=function(){a._replay.push(r.concat(e(u,arguments)))}}var a={};return a._sourceName=n,a._replay=[],a.getNow=function(n,e){return e},a.when=function(){var n=[e("when",arguments)],r={};return u(r,n,"run"),u(r,n,"declare"),u(r,n,"publish"),u(r,n,"build"),r.depends=n,r.iff=function(){var r=n.concat([e("iff",arguments)]),a={};return u(a,r,"run"),u(a,r,"declare"),u(a,r,"publish"),u(a,r,"build"),a},r},u(a,[],"declare"),u(a,[],"build"),u(a,[],"publish"),u(a,[],"importEvent"),r._shims.push(a),a};r._shims=[],n.$Nav||(n.$Nav=r("rcx-nav")),n.$Nav.make||(n.$Nav.make=r)}(window)</script><script type="text/javascript">
$Nav.importEvent('navbarJS-beaconbelt');
$Nav.declare('img.sprite', {
  'png32': 'https://m.media-amazon.com/images/G/01/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB546805360_.png',
  'png32-2x': 'https://m.media-amazon.com/images/G/01/gno/sprites/nav-sprite-global-2x-reorg-privacy._CB546805360_.png'
});
$Nav.declare('img.timeline', {
  'timeline-icon-2x': 'https://m.media-amazon.com/images/G/01/gno/sprites/timeline_sprite_2x._CB443581191_.png'
});
window._navbarSpriteUrl = 'https://m.media-amazon.com/images/G/01/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB546805360_.png';
$Nav.declare('img.pixel', 'https://m.media-amazon.com/images/G/01/x-locale/common/transparent-pixel._CB485935036_.gif');
</script>

<img src="https://m.media-amazon.com/images/G/01/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB546805360_.png" style="display:none" alt=""/>
<script type="text/javascript">var nav_t_after_preload_sprite = + new Date();</script>
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('navCF').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/51na2k2njbL._RC|71LJ+jMDvAL.js,01QvReFeJyL.js,01VfhmbHmKL.js,71MN9aepaKL.js,01cZ21lATAL.js,01bAfFgS7JL.js,01A2AtmCtlL.js,41jBieyCvYL.js,01wXnKULArL.js,01+pnQJuQ0L.js,21vOrV8ROnL.js,41zFN9UysJL.js,51HrkAbbpLL.js,31XO9BO1OrL.js,11lw6J7z8iL.js,31NSDarX4TL.js,01VYGE8lGhL.js_.js?AUIClients/NavDesktopUberAsset#desktop.language-en.us.803398-T1.1089549-T1.948355-T1.310484-T1.1179039-T1');
});
</script>
<!-- sp:end-feature:nav-inline-js -->
<!-- sp:feature:nav-skeleton -->
<!-- sp:end-feature:nav-skeleton -->
<!-- sp:feature:navbar -->

<!--Pilu -->


  <!-- NAVYAAN -->

<!-- navmet initial definition -->



<script type='text/javascript'>
    if(window.navmet===undefined) {
      window.navmet=[];
      if (window.performance && window.performance.timing && window.ue_t0) {
        var t = window.performance.timing;
        var now = + new Date();
        window.navmet.basic = {
          'networkLatency': (t.responseStart - t.fetchStart),
          'navFirstPaint': (now - t.responseStart),
          'NavStart': (now - window.ue_t0)
        };
        window.navmet.push({key:"NavFirstPaintStart",end:+new Date(),begin:window.ue_t0});
      }
    }
    if (window.ue_t0) {
      window.navmet.push({key:"NavMainStart",end:+new Date(),begin:window.ue_t0});
    }
</script>




<script type='text/javascript'>window.navmet.tmp=+new Date();</script>
  <script type='text/javascript'>
    // Nav start should be logged at this place only if request is NOT progressively loaded.
    // For progressive loading case this metric is logged as part of skeleton.
    // Presence of skeleton signals that request is progressively loaded.
    if(!document.getElementById("navbar-skeleton")) {
      window.uet && uet('ns');
    }
    window._navbar = (function (o) {
      o.componentLoaded = o.loading = function(){};
      o.browsepromos = {};
      o.issPromos = [];
      return o;
    }(window._navbar || {}));
    window._navbar.declareOnLoad = function () { window.$Nav && $Nav.declare('page.load'); };
    if (window.addEventListener) {
      window.addEventListener("load", window._navbar.declareOnLoad, false);
    } else if (window.attachEvent) {
      window.attachEvent("onload", window._navbar.declareOnLoad);
    } else if (window.$Nav) {
      $Nav.when('page.domReady').run("OnloadFallbackSetup", function () {
        window._navbar.declareOnLoad();
      });
    }
    window.$Nav && $Nav.declare('logEvent.enabled',
      'false');

    window.$Nav && $Nav.declare('config.lightningDeals', {});
  </script>

    <style mark="aboveNavInjectionCSS" type="text/css">
       #nav-flyout-ewc .nav-flyout-buffer-left { display: none; } #nav-flyout-ewc .nav-flyout-buffer-right { display: none; } div#navSwmHoliday.nav-focus {border: none;margin: 0;}
    </style>
    <script mark="aboveNavInjectionJS" type="text/javascript">
      try {
        if(window.navmet===undefined)window.navmet=[]; if(window.$Nav) { $Nav.when('$', 'config', 'flyout.accountList', 'SignInRedirect', 'dataPanel').run('accountListRedirectFix', function ($, config, flyout, SignInRedirect, dataPanel) { if (!config.accountList) { return; } flyout.getPanel().onData(function (data) { if (SignInRedirect) { var $anchors = $('[data-nav-role=signin]', flyout.elem()); $.each($anchors, function(i, anchorEl) {SignInRedirect.setRedirectUrl($(anchorEl), null, null);});}});}); $Nav.when('$').run('defineIsArray', function(jQuery) { if(jQuery.isArray===undefined) { jQuery.isArray=function(param) { if(param.length===undefined) { return false; } return true; }; } }); $Nav.declare('config.cartFlyoutDisabled', 'true'); $Nav.when('$','$F','config','logEvent','panels','phoneHome','dataPanel','flyouts.renderPromo','flyouts.sloppyTrigger','flyouts.accessibility','util.mouseOut','util.onKey','debug.param').build('flyouts.buildSubPanels',function($,$F,config,logEvent,panels,phoneHome,dataPanel,renderPromo,createSloppyTrigger,a11yHandler,mouseOutUtility,onKey,debugParam){var flyoutDebug=debugParam('navFlyoutClick');return function(flyout,event){var linkKeys=[];$('.nav-item',flyout.elem()).each(function(){var $item=$(this);linkKeys.push({link:$item,panelKey:$item.attr('data-nav-panelkey')});});if(linkKeys.length===0){return;} var visible=false;var $parent=$('<div class='nav-subcats'></div>').appendTo(flyout.elem());var panelGroup=flyout.getName()+'SubCats';var hideTimeout=null;var sloppyTrigger=createSloppyTrigger($parent);var showParent=function(){if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;} if(visible){return;} var height=$('#nav-flyout-shopAll').height(); $parent.css({'height': height});$parent.animate({width:'show'},{duration:200,complete:function(){$parent.css({overflow:'visible'});}});visible=true;};var hideParentNow=function(){$parent.stop().css({overflow:'hidden',display:'none',width:'auto',height:'auto'});panels.hideAll({group:panelGroup});visible=false;if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;}};var hideParent=function(){if(!visible){return;} if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;} hideTimeout=setTimeout(hideParentNow,10);};flyout.onHide(function(){sloppyTrigger.disable();hideParentNow();this.elem().hide();});var addPanel=function($link,panelKey){var panel=dataPanel({className:'nav-subcat',dataKey:panelKey,groups:[panelGroup],spinner:false,visible:false});if(!flyoutDebug){var mouseout=mouseOutUtility();mouseout.add(flyout.elem());mouseout.action(function(){panel.hide();});mouseout.enable();} var a11y=a11yHandler({link:$link,onEscape:function(){panel.hide();$link.focus();}});var logPanelInteraction=function(promoID,wlTriggers){var logNow=$F.once().on(function(){var panelEvent=$.extend({},event,{id:promoID});if(config.browsePromos&&!!config.browsePromos[promoID]){panelEvent.bp=1;} logEvent(panelEvent);phoneHome.trigger(wlTriggers);});if(panel.isVisible()&&panel.hasInteracted()){logNow();}else{panel.onInteract(logNow);}};panel.onData(function(data){renderPromo(data.promoID,panel.elem());logPanelInteraction(data.promoID,data.wlTriggers);});panel.onShow(function(){var columnCount=$('.nav-column',panel.elem()).length;panel.elem().addClass('nav-colcount-'+columnCount);showParent();var $subCatLinks=$('.nav-subcat-links > a',panel.elem());var length=$subCatLinks.length;if(length>0){var firstElementLeftPos=$subCatLinks.eq(0).offset().left;for(var i=1;i<length;i++){if(firstElementLeftPos===$subCatLinks.eq(i).offset().left){$subCatLinks.eq(i).addClass('nav_linestart');}} if($('span.nav-title.nav-item',panel.elem()).length===0){var catTitle=$.trim($link.html());catTitle=catTitle.replace(/ref=sa_menu_top/g,'ref=sa_menu');var $subPanelTitle=$('<span class='nav-title nav-item'>'+ catTitle+'</span>');panel.elem().prepend($subPanelTitle);}} $link.addClass('nav-active');});panel.onHide(function(){$link.removeClass('nav-active');hideParent();a11y.disable();sloppyTrigger.disable();});panel.onShow(function(){a11y.elems($('a, area',panel.elem()));});sloppyTrigger.register($link,panel);if(flyoutDebug){$link.click(function(){if(panel.isVisible()){panel.hide();}else{panel.show();}});} var panelKeyHandler=onKey($link,function(){if(this.isEnter()||this.isSpace()){panel.show();}},'keydown',false);$link.focus(function(){panelKeyHandler.bind();}).blur(function(){panelKeyHandler.unbind();});panel.elem().appendTo($parent);};var hideParentAndResetTrigger=function(){hideParent();sloppyTrigger.disable();};for(var i=0;i<linkKeys.length;i++){var item=linkKeys[i];if(item.panelKey){addPanel(item.link,item.panelKey);}else{item.link.mouseover(hideParentAndResetTrigger);}}};});};
      } catch ( err ) {
        if ( window.$Nav ) {
          window.$Nav.when('metrics', 'logUeError').run(function(metrics, log) {
            metrics.increment('NavJS:AboveNavInjection:error');
            log(err.toString(), {
              'attribution': 'rcx-nav',
              'logLevel': 'FATAL'
            });
          });
        }
      }
    </script>

  <noscript>
    <style type="text/css"><!--
      #navbar #nav-shop .nav-a:hover {
        color: #ff9900;
        text-decoration: underline;
      }
      #navbar #nav-search .nav-search-facade,
      #navbar #nav-tools .nav-icon,
      #navbar #nav-shop .nav-icon,
      #navbar #nav-subnav .nav-hasArrow .nav-arrow {
        display: none;
      }
      #navbar #nav-search .nav-search-submit,
      #navbar #nav-search .nav-search-scope {
        display: block;
      }
      #nav-search .nav-search-scope {
        padding: 0 5px;
      }
      #navbar #nav-search .nav-search-dropdown {
        position: relative;
        top: 5px;
        height: 23px;
        font-size: 14px;
        opacity: 1;
        filter: alpha(opacity = 100);
      }
    --></style>
 </noscript>
<script type='text/javascript'>window.navmet.push({key:'PreNav',end:+new Date(),begin:window.navmet.tmp});</script>

<a id='nav-top'></a>





  
<nav
  id="shortcut-menu"
  class="nav-assistant"
  aria-label="Shortcuts menu"
  tabindex="-1"
  role="navigation" 
  
>
  <h2 id="nav-assistant-links-heading" class="nav-assistant-heading nav-assistant-headers-font">Skip to</h2>
  <ul aria-labelledby="nav-assistant-links-heading" class="nav-assistant-links-container">
    <li class="nav-assistant-list-item">
      <a
        href="#skippedLink"
        id="nav-assist-skip-to-main-content"
        aria-label="main content"
        tabindex="0"
        data-target="#skippedLink"
        data-behavior="navigate"
        
        
        data-nav-assist-menu-item-index="0"
        class="nav-assistant-link nav-assistant-menu-item nav-assistant-link-item a-color-base a-color-link "
      >
        Main content
        </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="#featurebullets_feature_div"
        id="nav-assist-skip-to-about-this-item"
        aria-label="About this item"
        tabindex="-1"
        data-target="#featurebullets_feature_div"
        data-behavior="navigate"
        
        data-selector-exclude="#nic-po-expander-heading"
        data-nav-assist-menu-item-index="1"
        class="nav-assistant-link nav-assistant-menu-item nav-assistant-link-item a-color-base a-color-link "
      >
        About this item
        </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="#nic-po-expander-heading"
        id="nav-assist-skip-to-about-this-item-expander"
        aria-label="About this item"
        tabindex="-1"
        data-target="#nic-po-expander-heading"
        data-behavior="navigate"
        
        
        data-nav-assist-menu-item-index="2"
        class="nav-assistant-link nav-assistant-menu-item nav-assistant-link-item a-color-base a-color-link "
      >
        About this item
        </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="#buybox"
        id="nav-assist-skip-to-buying-options"
        aria-label="Buying options"
        tabindex="-1"
        data-target="#buybox"
        data-behavior="navigate"
        
        
        data-nav-assist-menu-item-index="3"
        class="nav-assistant-link nav-assistant-menu-item nav-assistant-link-item a-color-base a-color-link "
      >
        Buying options
        </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="#product-comparison_feature_div"
        id="nav-assist-skip-to-compare"
        aria-label="Compare with similar items"
        tabindex="-1"
        data-target="#product-comparison_feature_div"
        data-behavior="navigate"
        data-selector-prereq="#product-comparison_feature_div &gt; div"
        
        data-nav-assist-menu-item-index="4"
        class="nav-assistant-link nav-assistant-menu-item nav-assistant-link-item a-color-base a-color-link "
      >
        Compare with similar items
        </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="#va-related-videos-widget_feature_div"
        id="nav-assist-skip-to-videos"
        aria-label="Videos"
        tabindex="-1"
        data-target="#va-related-videos-widget_feature_div"
        data-behavior="navigate"
        data-selector-prereq="#va-related-videos-widget_feature_div &gt; div"
        
        data-nav-assist-menu-item-index="5"
        class="nav-assistant-link nav-assistant-menu-item nav-assistant-link-item a-color-base a-color-link "
      >
        Videos
        </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="#customerReviews"
        id="nav-assist-skip-to-reviews"
        aria-label="Reviews"
        tabindex="-1"
        data-target="#customerReviews"
        data-behavior="navigate"
        
        
        data-nav-assist-menu-item-index="6"
        class="nav-assistant-link nav-assistant-menu-item nav-assistant-link-item a-color-base a-color-link "
      >
        Reviews
        </a>
    </li>
  </ul>
  <hr class="nav-assistant-separator" aria-hidden="true" />
  <h2 id="shortcuts-heading" class="nav-assistant-heading nav-assistant-headers-font font-color">
      Keyboard shortcuts
  </h2>
  <ul class="keyboard-shortcuts-list-container" aria-labelledby="shortcuts-heading">
    <li class="nav-assistant-list-item">
      <a
        id="nav-assist-search"
        role="link"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link "
        data-nav-assist-menu-item-index="7"
        data-behavior="navigate"
        
        data-actuators="[{&quot;eventCode&quot;:&quot;Slash&quot;,&quot;eventKey&quot;:&quot;÷&quot;,&quot;isShiftRequired&quot;:false},{&quot;eventCode&quot;:&quot;Digit7&quot;,&quot;eventKey&quot;:&quot;&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventCode&quot;:&quot;Period&quot;,&quot;eventKey&quot;:&quot;&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventCode&quot;:&quot;Slash&quot;,&quot;eventKey&quot;:&quot;/&quot;,&quot;isShiftRequired&quot;:false},{&quot;eventCode&quot;:&quot;Digit7&quot;,&quot;eventKey&quot;:&quot;/&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventCode&quot;:&quot;Period&quot;,&quot;eventKey&quot;:&quot;/&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;/&quot;,&quot;isShiftRequired&quot;:false}]"
        data-target="#twotabsearchtextbox"
        aria-label="Search, alt, forward slash" 
      >
      <div class="keyboard-shortcut-container" aria-hidden="true">
        <span class="shortcut-name nav-assistant-card-font">Search</span>
        <div class="shortcut-keys-container" dir="ltr">
            <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">/</span>
            
        </div>
      </div>
      </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        id="nav-assist-cart"
        role="link"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link "
        data-nav-assist-menu-item-index="8"
        data-behavior="navigate"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;Ç&quot;,&quot;eventCode&quot;:&quot;KeyC&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;¢&quot;,&quot;eventCode&quot;:&quot;KeyC&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;C&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="/gp/cart/view.html/?ref_&#x3D;nav_assist"
        aria-label="Cart, shift, alt, c" 
      >
      <div class="keyboard-shortcut-container" aria-hidden="true">
        <span class="shortcut-name nav-assistant-card-font">Cart</span>
        <div class="shortcut-keys-container" dir="ltr">
            <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">C</span>
            
        </div>
      </div>
      </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        id="nav-assist-home"
        role="link"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link "
        data-nav-assist-menu-item-index="9"
        data-behavior="navigate"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;Ó&quot;,&quot;eventCode&quot;:&quot;KeyH&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Î&quot;,&quot;eventCode&quot;:&quot;KeyH&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;H&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="/?ref_&#x3D;nav_assist"
        aria-label="Home, shift, alt, h" 
      >
      <div class="keyboard-shortcut-container" aria-hidden="true">
        <span class="shortcut-name nav-assistant-card-font">Home</span>
        <div class="shortcut-keys-container" dir="ltr">
            <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">H</span>
            
        </div>
      </div>
      </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        id="nav-assist-your-orders"
        role="link"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link "
        data-nav-assist-menu-item-index="10"
        data-behavior="navigate"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;Ø&quot;,&quot;eventCode&quot;:&quot;KeyO&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Œ&quot;,&quot;eventCode&quot;:&quot;KeyO&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;O&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="/gp/css/order-history/?ref_&#x3D;nav_assist"
        aria-label="Your orders, shift, alt, o" 
      >
      <div class="keyboard-shortcut-container" aria-hidden="true">
        <span class="shortcut-name nav-assistant-card-font">Orders</span>
        <div class="shortcut-keys-container" dir="ltr">
            <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">O</span>
            
        </div>
      </div>
      </a>
    </li>
    <li class="nav-assistant-list-item">
      <button
        id="nav-assist-add-to-cart"
        role="button"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link nav-assistant-link-button"
        data-nav-assist-menu-item-index="11"
        data-behavior="activate"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;&quot;,&quot;eventCode&quot;:&quot;KeyK&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Ë&quot;,&quot;eventCode&quot;:&quot;KeyK&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;ˆ&quot;,&quot;eventCode&quot;:&quot;KeyK&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;K&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="#add-to-cart-button"
        aria-label="Add to cart, shift, alt, K" 
      >
      <div class="keyboard-shortcut-container" aria-hidden="true">
        <span class="shortcut-name nav-assistant-card-font">Add to cart</span>
        <div class="shortcut-keys-container" dir="ltr">
            <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">K</span>
            
        </div>
      </div>
      </button>
    </li>
    <li class="nav-assistant-list-item">
      <button
        id="nav-assist-show-shortcuts"
        role="button"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link nav-assistant-link-button"
        data-nav-assist-menu-item-index="12"
        data-behavior="show-hide"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;¸&quot;,&quot;eventCode&quot;:&quot;KeyZ&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;ˇ&quot;,&quot;eventCode&quot;:&quot;KeyY&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Å&quot;,&quot;eventCode&quot;:&quot;KeyW&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Z&quot;,&quot;eventCode&quot;:&quot;KeyZ&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Z&quot;,&quot;eventCode&quot;:&quot;KeyY&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Z&quot;,&quot;eventCode&quot;:&quot;KeyW&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Z&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="a[data-nav-assist-menu-item-index&#x3D;&quot;0&quot;]"
        aria-label="Show/hide shortcuts, shift, alt, z" 
      >
      <div class="keyboard-shortcut-container" aria-hidden="true">
        <span class="shortcut-name nav-assistant-card-font">Show/Hide shortcuts</span>
        <div class="shortcut-keys-container" dir="ltr">
            <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
            <span class="plus-sign-color">+</span>
            <span class="shortcut-key nav-assistant-card-font font-color">Z</span>
            
        </div>
      </div>
      </button>
    </li>
  </ul>
  <div
    id="nav-assist-shortcut-help"
  >
    <div class="shortcut-help-container">
      <div class="shortcut-help-item-container">
        <div class="icon-container"><i class="a-icon a-icon-info a-icon-mini shortcut-help-icon"></i></div>
        <div class="help-text-container">
          <span class="shortcut-help-text font-color">To move between items, use your keyboard&#x27;s up or down arrows.</span>
        </div>
      </div>
    </div>
  </div>
</nav>





<script type='text/javascript'>window.navmet.main=+new Date();</script>



<header id="navbar-main" class = "nav-opt-sprite nav-flex nav-locale-us nav-lang-en nav-ssl nav-unrec nav-progressive-attribute">

   
  <div id='navbar' cel_widget_id='Navigation-desktop-navbar'
  role='navigation' class="nav-sprite-v1 celwidget nav-bluebeacon nav-a11y-t1 bold-focus-hover layout2 nav-flex layout3 layout3-alt nav-packard-glow hamburger nav-progressive-attribute" aria-label="Primary">
    <div id='nav-belt'>
      <div class='nav-left'>
        <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
  <div id="nav-logo" >
    <a href="/ref=nav_logo" id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon" lang="en" >
      <span class="nav-sprite nav-logo-base"></span>
      <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span>
      <span class="nav-logo-locale">.us</span>
    </a>
  </div>
<script type='text/javascript'>window.navmet.push({key:'Logo',end:+new Date(),begin:window.navmet.tmp});</script>
        
<div id="nav-global-location-slot">
    <span id="nav-global-location-data-modal-action" class="a-declarative nav-progressive-attribute" data-a-modal='{&quot;width&quot;:375, &quot;closeButton&quot;:&quot;true&quot;,&quot;popoverLabel&quot;:&quot;Choose your location&quot;, &quot;ajaxHeaders&quot;:{&quot;anti-csrftoken-a2z&quot;:&quot;hFWuYbcZU0Rq6ZzK/s+JQTwkNoxMSB4HsfDy+epF0029AAAAAGfq+T0AAAAB&quot;}, &quot;name&quot;:&quot;glow-modal&quot;, &quot;url&quot;:&quot;/portal-migration/hz/glow/get-rendered-address-selections?deviceType&#x3D;desktop&amp;pageType&#x3D;Detail&amp;storeContext&#x3D;videogames&amp;actionSource&#x3D;desktop-modal&quot;, &quot;footer&quot;:&quot;&lt;span class&#x3D;&quot;a-declarative&quot; data-action&#x3D;&quot;a-popover-close&quot; data-a-popover-close&#x3D;&quot;{}&quot;&gt;&lt;span class&#x3D;&quot;a-button a-button-primary&quot;&gt;&lt;span class&#x3D;&quot;a-button-inner&quot;&gt;&lt;button name&#x3D;&quot;glowDoneButton&quot; class&#x3D;&quot;a-button-text&quot; type&#x3D;&quot;button&quot;&gt;Done&lt;/button&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&quot;,&quot;header&quot;:&quot;Choose your location&quot;}' data-action="a-modal">
        <a id="nav-global-location-popover-link" role="button" tabindex="0" class="nav-a nav-a-2 a-popover-trigger a-declarative nav-progressive-attribute" href="">
            <div class="nav-sprite nav-progressive-attribute" id="nav-packard-glow-loc-icon"></div>
            <div id="glow-ingress-block">
                <span class="nav-line-1 nav-progressive-content" id="glow-ingress-line1">
                   Deliver to
                </span>
                <span class="nav-line-2 nav-progressive-content" id="glow-ingress-line2">
                   Thailand
                </span>
            </div>
        </a>
        </span>
        <input data-addnewaddress="add-new" id="unifiedLocation1ClickAddress" name="dropdown-selection" type="hidden" value="add-new" class="nav-progressive-attribute" />
        <input data-addnewaddress="add-new" id="ubbShipTo" name="dropdown-selection-ubb" type="hidden" value="add-new" class="nav-progressive-attribute"/>
        <input id="glowValidationToken" name="glow-validation-token" type="hidden" value="hFWuYbcZU0Rq6ZzK/s+JQTwkNoxMSB4HsfDy+epF0029AAAAAGfq+T0AAAAB" class="nav-progressive-attribute"/>
        <input id="glowDestinationType" name="glow-destination-type" type="hidden" value="COUNTRY" class="nav-progressive-attribute"/>
</div>

<div id="nav-global-location-toaster-script-container" class="nav-progressive-content">
    <!-- NAVYAAN-GLOW-NAV-TOASTER -->
          <script>
              P.when('glow-toaster-strings').execute(function(S) {
                S.load({"glow-toaster-address-change-error":"An error has occurred and the address has not been updated. Please try again.","glow-toaster-unknown-error":"An error has occurred. Please try again."});
             });
          </script>
          <script>
              P.when('glow-toaster-manager').execute(function(M) {
                M.create({"storeName":"videogames","pageType":"Detail","aisTransitionState":null,"rancorLocationSource":"USER_OVERRIDE"})
              });
          </script>
</div>

      </div>
          <div class='nav-fill' id='nav-fill-search'>
            <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
<div id="nav-search">
  <div id="nav-bar-left"></div> 
  <form
    id="nav-search-bar-form"
    accept-charset="utf-8"
    action="/s/ref=nb_sb_noss"
    class="nav-searchbar nav-progressive-attribute"
    method="GET"
    name="site-search"
    role="search"
  >

    <div class="nav-left">
      <div id="nav-search-dropdown-card">
        
  <div class="nav-search-scope nav-sprite">
    <div class="nav-search-facade" data-value="search-alias=aps">
      <span id="nav-search-label-id" class="nav-search-label nav-progressive-content">All</span>
      <i class="nav-icon"></i>
    </div>
    <label id="searchDropdownDescription" for="searchDropdownBox" class="nav-progressive-attribute" style="display:none">Select the department you want to search in</label>
    <select
      aria-describedby="searchDropdownDescription"
      class="nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown"
      data-nav-digest="k+fyIAyB82R9jVEmroQ0OWwSW3A="
      data-nav-selected="0"
      id="searchDropdownBox"
      name="url"
      style="display: block;"
      tabindex="0"
      title="Search in"
    >
        <option selected="selected" value="search-alias=aps">All Departments</option>
        <option value="search-alias=arts-crafts-intl-ship">Arts & Crafts</option>
        <option value="search-alias=automotive-intl-ship">Automotive</option>
        <option value="search-alias=baby-products-intl-ship">Baby</option>
        <option value="search-alias=beauty-intl-ship">Beauty & Personal Care</option>
        <option value="search-alias=stripbooks-intl-ship">Books</option>
        <option value="search-alias=fashion-boys-intl-ship">Boys' Fashion</option>
        <option value="search-alias=computers-intl-ship">Computers</option>
        <option value="search-alias=deals-intl-ship">Deals</option>
        <option value="search-alias=digital-music">Digital Music</option>
        <option value="search-alias=electronics-intl-ship">Electronics</option>
        <option value="search-alias=fashion-girls-intl-ship">Girls' Fashion</option>
        <option value="search-alias=hpc-intl-ship">Health & Household</option>
        <option value="search-alias=kitchen-intl-ship">Home & Kitchen</option>
        <option value="search-alias=industrial-intl-ship">Industrial & Scientific</option>
        <option value="search-alias=digital-text">Kindle Store</option>
        <option value="search-alias=luggage-intl-ship">Luggage</option>
        <option value="search-alias=fashion-mens-intl-ship">Men's Fashion</option>
        <option value="search-alias=movies-tv-intl-ship">Movies & TV</option>
        <option value="search-alias=music-intl-ship">Music, CDs & Vinyl</option>
        <option value="search-alias=pets-intl-ship">Pet Supplies</option>
        <option value="search-alias=instant-video">Prime Video</option>
        <option value="search-alias=software-intl-ship">Software</option>
        <option value="search-alias=sporting-intl-ship">Sports & Outdoors</option>
        <option value="search-alias=tools-intl-ship">Tools & Home Improvement</option>
        <option value="search-alias=toys-and-games-intl-ship">Toys & Games</option>
        <option value="search-alias=videogames-intl-ship">Video Games</option>
        <option value="search-alias=fashion-womens-intl-ship">Women's Fashion</option>
    </select>
  </div>

      </div>
    </div>
    <div class="nav-fill">
      <div class="nav-search-field ">
          <label for="twotabsearchtextbox" style="display: none;">Search Amazon</label>
          <input
            type="text"
            id="twotabsearchtextbox"
            value="ps4"
            name="field-keywords"
            autocomplete="off"
            placeholder="Search Amazon"
            class="nav-input nav-progressive-attribute"
            dir="auto"
            tabindex="0"
            aria-label="Search Amazon"
            role="searchbox"
            aria-autocomplete="list"
            aria-controls="sac-autocomplete-results-container"
            aria-expanded="false"
            aria-haspopup="grid"
            spellcheck="false"
          >
      </div>
      <div id="nav-iss-attach"></div>
    </div>
    <div class="nav-right">
      <div class="nav-search-submit nav-sprite">
        <span id="nav-search-submit-text" class="nav-search-submit-text nav-sprite nav-progressive-attribute" aria-label="Go">
          <input id="nav-search-submit-button" type="submit" class="nav-input nav-progressive-attribute" value="Go" tabindex="0">
        </span>
      </div>
    </div>
  </form>
</div>
<script type='text/javascript'>window.navmet.push({key:'Search',end:+new Date(),begin:window.navmet.tmp});</script>
          </div>
      <div class='nav-right'>
          <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
          <div id='nav-tools' class="layoutToolbarPadding">
              
              
              
              
  <div class="nav-div" id="icp-nav-flyout">
  <a href="/customer-preferences/edit?ie=UTF8&preferencesReturnUrl=%2F&ref_=topnav_lang_ais" class="nav-a nav-a-2 icp-link-style-2" aria-label="Choose a language for shopping in Amazon United States. The current selection is English (EN).
">
    <span class="icp-nav-link-inner">
      <span class="nav-line-1">
      </span>
      <span class="nav-line-2">
         <span class="icp-nav-flag icp-nav-flag-us icp-nav-flag-lop" role="img" aria-label="United States"></span>
          <div>EN</div>
      </span>
    </span>
  </a>
  <button class="nav-flyout-button nav-icon nav-arrow" aria-label="Expand to Change Language or Country" tabindex=0></button>
</div>

              
  <div class="nav-div" id="nav-link-accountList">
  <a href="https://www.amazon.com/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2FPlayStation-Pro-1TB-Limited-Console-4%2Fdp%2FB009242639%2Fref%3Dsr_1_16%2F%3F_encoding%3DUTF8%26crid%3D1BO0M5KKJ9QD1%26dib%3DeyJ2IjoiMSJ9.DYCLh1lfDEqmNIOXcI70zeBtbVDEVFdpQdh7MnKCAqbRsvzxVzTS22FOKdE-QhogNTEMxVo_haqWHA8Puo7aKzBS2dkNvc3rRl4agcIyZV56HLo73DAc2hkJmSi6HqnmlCfbGyMEpwuCT88Uc6SbYbv0Au8X3WfvpXggderg-UIaB73cjQwXsuNeFifPCp3vY2FGDf6A2f966BkTUZOx3U-wArqIGcAw_9br2PwmTHQ.MCHaFtqxLd6FAbSEwcUYmAyaIQieo_JwSA1mC7YDdxI%26dib_tag%3Dse%26keywords%3Dps4%26qid%3D1743452468%26sprefix%3D%252Caps%252C2195%26sr%3D8-16%26ref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0" class="nav-a nav-a-2   nav-progressive-attribute" data-nav-ref="nav_ya_signin"  data-nav-role="signin" data-ux-jq-mouseenter="true" tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav-link-accountList" data-csa-c-content-id="nav_ya_signin"  aria-controls="nav-flyout-accountList" >
  <div class="nav-line-1-container"><span id="nav-link-accountList-nav-line-1" class="nav-line-1 nav-progressive-content">Hello, sign in</span></div>
  <span class="nav-line-2 ">Account & Lists
  </span>
  </a>
  <button class="nav-flyout-button nav-icon nav-arrow" aria-label="Expand Account and Lists" tabindex=0></button>
  </div>

              
<a href="/gp/css/order-history?ref_=nav_orders_first" class="nav-a nav-a-2   nav-progressive-attribute" id="nav-orders" tabindex="0">
  <span class="nav-line-1">Returns</span>
  <span class="nav-line-2">& Orders<span class="nav-icon nav-arrow"></span></span>
</a>

              
              
  <a href="/gp/cart/view.html?ref_=nav_cart" aria-label="0 items in cart" class="nav-a nav-a-2 nav-progressive-attribute" id="nav-cart">
    <div id="nav-cart-count-container">
      <span id="nav-cart-count" aria-hidden="true" class="nav-cart-count nav-cart-0 nav-progressive-attribute nav-progressive-content">0</span>
      <span class="nav-cart-icon nav-sprite"></span>
    </div>
    <div id="nav-cart-text-container" class=" nav-progressive-attribute">
      <span aria-hidden="true" class="nav-line-1">
        
      </span>
      <span aria-hidden="true" class="nav-line-2">
        Cart
        <span class="nav-icon nav-arrow"></span>
      </span>
    </div>
  </a>

          </div>
          <script type='text/javascript'>window.navmet.push({key:'Tools',end:+new Date(),begin:window.navmet.tmp});</script>

      </div>
    </div>
    <div id='nav-belt-search' class='nav-fill'></div>
    <div id='nav-main' class='nav-sprite'>
      <div class='nav-left'>
        <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
  <a href="/gp/site-directory?ref_=nav_em_js_disabled" id="nav-hamburger-menu" role="button" aria-label="Open All Categories Menu" aria-expanded="false" data-csa-c-type="widget" data-csa-c-slot-id="HamburgerMenuDesktop"
  data-csa-c-interaction-events="click" >
    <i class="hm-icon nav-sprite"></i>
    <span class="hm-icon-label">All</span>
  </a>
  
<script type="text/javascript">
  var hmenu = document.getElementById("nav-hamburger-menu");
  hmenu.setAttribute("href", "javascript: void(0)");
  window.navHamburgerMetricLogger = function() {
    if (window.ue && window.ue.count) {
      var metricName = "Nav:Hmenu:IconClickActionPending";
      window.ue.count(metricName, (ue.count(metricName) || 0) + 1);
    }
    window.$Nav && $Nav.declare("navHMenuIconClicked",!0);
    window.$Nav && $Nav.declare("navHMenuIconClickedNotReadyTimeStamp", Date.now());
  };
  hmenu.addEventListener("click", window.navHamburgerMetricLogger);
  window.$Nav && $Nav.declare('hamburgerMenuIconAvailableOnLoad', false);
</script>  
<script type='text/javascript'>window.navmet.push({key:'HamburgerMenuIcon',end:+new Date(),begin:window.navmet.tmp});</script>
        
        
      </div>
      <div class='nav-fill'>
        
 <div id="nav-shop">
 </div>
        <div id='nav-xshop-container'>
          <div id='nav-xshop' class="nav-progressive-content">
            <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
  <ul class="nav-ul">
      
<li class="nav-li">
<div class="nav-div">
<a href="/gp/goldbox?ref_=nav_cs_gb" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_0" data-csa-c-content-id="nav_cs_gb">Today's Deals</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/gp/browse.html?node=16115931011&ref_=nav_cs_registry" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_1" data-csa-c-content-id="nav_cs_registry">Registry</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/gp/help/customer/display.html?nodeId=508510&ref_=nav_cs_customerservice" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_2" data-csa-c-content-id="nav_cs_customerservice">Customer Service</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/gift-cards/b/?ie=UTF8&node=2238192011&ref_=nav_cs_gc" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_3" data-csa-c-content-id="nav_cs_gc">Gift Cards</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/b/?_encoding=UTF8&ld=AZUSSOA-sell&node=12766669011&ref_=nav_cs_sell" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_4" data-csa-c-content-id="nav_cs_sell">Sell</a>
</div>
</li>


<a href="/gp/help/customer/accessibility" aria-label="Click to call our Disability Customer Support line, or reach us directly at 1-888-283-1678" class="nav-hidden-aria  " tabindex="0"  data-csa-c-type="link" data-csa-c-slot-id="nav_cs_5" >Disability Customer Support</a>

  </ul>
  <script type='text/javascript'>window.navmet.push({key:'CrossShop',end:+new Date(),begin:window.navmet.tmp});</script>
          </div>
        </div>
      </div>
      <div class='nav-right'>
        <script type='text/javascript'>window.navmet.tmp=+new Date();</script><!-- Navyaan SWM -->
<div id="nav-swmslot" class="nav-swm-text-widget">
  <a href="/b/?_encoding=UTF8&node=117402865011&ref_=nav_swm_undefined&pf_rd_p=66575ad5-911b-4c83-8f29-a077ef824df8&pf_rd_s=nav-sitewide-msg-text-export&pf_rd_t=4201&pf_rd_i=navbar-4201&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=RBW56TXBT3VK1W4DNTET" id="swm-link" class="nav_a nav-swm-text nav-progressive-attribute nav-progressive-content">Get free shipping to Thailand</a>
</div><script type='text/javascript'>window.navmet.push({key:'SWM',end:+new Date(),begin:window.navmet.tmp});</script>
      </div>
    </div>

    <div id='nav-subnav-toaster'></div>

    
    <div id="nav-progressive-subnav">
      
    </div>

    <div id='nav-flyout-ewc' class='nav-ewc-lazy-align nav-ewc-hide-head'><div class='nav-flyout-body ewc-beacon' tabindex='-1'><div class='nav-ewc-arrow'></div><div class='nav-ewc-content'></div></div></div><script type='text/javascript'>
(function() {
  var viewportWidth = function() {
    return window.innerWidth ||
      document.documentElement.clientWidth ||
      document.body.clientWidth;
  };

  if (typeof uet === 'function') {  uet('x1', 'ewc', {wb: 1}); }

  window.$Nav && $Nav.declare('config.ewc', (function() {
    var config = {"enablePersistent":true,"viewportWidthForPersistent":1400,"isEWCLogging":1,"isEWCStateExpanded":true,"EWCStateReason":"fixed","isSmallScreenEnabled":true,"isFreshCustomer":false,"errorContent":{"html":"<div class='nav-ewc-error'><span class='nav-title'>Oops!</span><p class='nav-paragraph'>There's a problem loading your cart right now.</p><a href='/gp/cart/view.html?ref_=nav_err_ewc_timeout' class='nav-action-button'><span class='nav-action-inner'>Your Cart</span></a></div>"},"url":"/cart/ewc/compact?hostPageType=Detail&hostSubPageType=Glance&hostPageRID=RBW56TXBT3VK1W4DNTET&prerender=0&storeName=videogames","cartCount":0,"freshCartCount":0,"almCartCount":0,"primeWardrobeCartCount":0,"isCompactViewEnabled":true,"isCompactEWCRendered":true,"isWiderCompactEWCRendered":true,"EWCBrowserCacheKey":"EWC_Cache_140-0199542-9827343__USD_en_US","isContentRepainted":false,"clearCache":false,"loadFromCacheWithDelay":0,"delayRenderingTillATF":false,"EarlyLoadEWCContentTreatment":"T3"};
    var hasAui = window.P && window.P.AUI_BUILD_DATE;
    var isRTLEnabled = (document.dir === 'rtl');
    config.pinnable = config.pinnable && hasAui;
    config.isMigrationTreatment = true;

    config.flyout = (function() {
      var navbelt = document.getElementById('nav-belt');
      var navCart = document.getElementById('nav-cart');
      var ewcFlyout = document.getElementById('nav-flyout-ewc');
      var persistentClassOnBody = 'nav-ewc-persistent-hover nav-ewc-full-height-persistent-hover';
      var flyout = {};

      var getDocumentScrollTop = function() {
        return (document.documentElement && document.documentElement.scrollTop) || document.body.scrollTop;
      };

      var isWindow = function(obj) {
        return obj != null && obj === obj.window;
      };

      var getWindow = function(elem) {
        return isWindow(elem) ? elem : elem.nodeType === 9 && elem.defaultView;
      };

      var getOffset = function(elem) {
        if (elem.getClientRects && !elem.getClientRects().length) {
          return {top: 0};
        }

        var rect = elem.getBoundingClientRect
          ? elem.getBoundingClientRect()
          : {top: 0};

        if (rect.width || rect.height) {
          var doc = elem.ownerDocument;
          var win = getWindow(doc);
          return {
            top: rect.top + win.pageYOffset - doc.documentElement.clientTop
          };
        }
        return rect;
      };

      flyout.align = function() {
        var newTop = getOffset(navbelt).top - getDocumentScrollTop();
        ewcFlyout.style.top = (newTop > 0 ? newTop + 'px' : 0);
      };

      flyout.hide = function() {
        isRTLEnabled
          ? (ewcFlyout.style.left = '')
          : (ewcFlyout.style.right = '');
      };

      if(typeof config.isCompactEWCRendered === 'undefined') {
        if (
          (config.isSmallScreenEnabled && viewportWidth() < 1400) ||
          (config.isCompactViewEnabled && viewportWidth() >= 1400)
        ) {
          config.isCompactEWCRendered = true;
          config.isEWCStateExpanded = true;
          config.url = config.url.replace("/gp/navcart/sidebar", "/cart/ewc/compact");
        } else {
          config.isCompactEWCRendered = false;
        }
      }

      var viewportQualifyForPersistent = function () {
        return (config.isCompactEWCRendered)
          ? true
          : viewportWidth() >= 1400;
      }

      flyout.hasQualifiedViewportForPersistent = viewportQualifyForPersistent;

      var getEWCRightOffset = function() {
        if (!config.isCompactEWCRendered) {
          return 0;
        }

        var $navbelt = document.getElementById('nav-belt');
        if ($navbelt === undefined || $navbelt === null) {
          return 0;
        }

        var EWCCompactViewWidth = (config.isWiderCompactEWCRendered  && viewportWidth() >= 1280) ? 130 : 100;
        var scrollLeft = (window.pageXOffset !== undefined)
          ? window.pageXOffset
          : (document.documentElement || document.body.parentNode || document.body).scrollLeft;
        var scrollXAxis = Math.abs(scrollLeft);
        var windowWidth = document.documentElement.clientWidth;
        var navbeltWidth = $navbelt.offsetWidth;
        var isPartOfNavbarNotVisible = (navbeltWidth + EWCCompactViewWidth) > windowWidth;

        if (isPartOfNavbarNotVisible) {
          return 0 - (navbeltWidth - scrollXAxis - windowWidth + EWCCompactViewWidth);
        } else {
          return 0;
        }
      }

      flyout.getEWCRightOffsetCssProperty = function () {
        return getEWCRightOffset() + 'px';
      }

      if (config.isCompactEWCRendered) {
        persistentClassOnBody = 'nav-ewc-persistent-hover nav-ewc-compact-view';
        if (config.isWiderCompactEWCRendered) { persistentClassOnBody += ' nav-ewc-wider-compact-view'; }
      }

      flyout.show = function() {
        isRTLEnabled
          ? (ewcFlyout.style.left = flyout.getEWCRightOffsetCssProperty())
          : (ewcFlyout.style.right = flyout.getEWCRightOffsetCssProperty());
      };

      var isIOSDevice = function() {
        return (/iPad|iPhone|iPod/.test(navigator.platform) ||
                (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)) &&
                !window.MSStream;
      }

      var checkForPersistent = function() {
        if (!hasAui) {
          return { result: false, reason: 'noAui' };
        }
        if (!config.enablePersistent) {
          return { result: false, reason: 'config' };
        }
        if (!viewportQualifyForPersistent()) {
          return { result: false, reason: 'viewport' };
        }
        if (isIOSDevice()) {
          return { result: false, reason: 'iOS' };
        }
        if (!config.cartCount > 0) {
          return { result: false, reason: 'emptycart' };
        }
        return { result: true };
      };

      flyout.ableToPersist = function() {
        return checkForPersistent().result;
      };
      var persistentClassRegExp = '(?:^|s)' + persistentClassOnBody + '(?!S)';
      flyout.applyPageLayoutForPersistent = function() {
        if (!document.documentElement.className.match( new RegExp(persistentClassRegExp) )) {
          document.documentElement.className += ' ' + persistentClassOnBody;
        }
      };

      flyout.unapplyPageLayoutForPersistent = function() {
        document.documentElement.className = document.documentElement.className.replace( new RegExp(persistentClassRegExp, 'g'), '');
      };

      flyout.persist = function() {
        flyout.applyPageLayoutForPersistent();
        flyout.show();
        if (config.isCompactEWCRendered) {
          flyout.align();
        }
      };

      flyout.unpersist = function() {
        flyout.unapplyPageLayoutForPersistent();
        flyout.hide();
      };
      
      var persistentCheck = checkForPersistent();
    

      var resizeCallback = function() {
        
        if (flyout.ableToPersist()) {
          flyout.persist();
        }
        else {
          flyout.unpersist();
        }
      };

      flyout.bindEvents = function() {
        if (window.addEventListener) {
          window.addEventListener('resize', resizeCallback, false);
          
          if (config.isCompactEWCRendered) {
            window.addEventListener('scroll', flyout.align, false);
          }
        }
      };

      flyout.unbindEvents = function() {
        if (window.removeEventListener) {
          window.removeEventListener('resize', resizeCallback, false);
          
          if (config.isCompactEWCRendered) {
            window.removeEventListener('scroll', flyout.align, false);
          }
        }
      };
      
      var ewcDefaultPersistence = function() {
      
        if (persistentCheck.result) {
          flyout.persist();
          if (window.ue && ue.tag) {
            ue.tag('ewc:persist');
          }
        } else {
          if (window.ue && ue.tag) {
            ue.tag('ewc:unpersist');
            if (persistentCheck.reason === 'noAui') {
              ue.tag('ewc:unpersist:noAui');
            }
            if (persistentCheck.reason === 'viewport') {
              ue.tag('ewc:unpersist:viewport');
            }
            if (persistentCheck.reason === 'emptycart') {
              ue.tag('ewc:unpersist:emptycart');
            }
            if (persistentCheck.reason === 'iOS') {
              ue.tag('ewc:unpersist:iOS');
            }
          }
        }
      };
      
      ewcDefaultPersistence();
      
      if (window.ue && ue.tag)  {
        if (flyout.hasQualifiedViewportForPersistent()) {
          ue.tag('ewc:bview');
        }
        else {
          ue.tag('ewc:sview');
        }
      }
      flyout.bindEvents();
      flyout.cache = function () {
    const cache = window.sessionStorage;
    const CACHE_KEY = "EWCBrowserCacheKey";
    const CACHE_EXPIRY = "EWCBrowserCacheExpiry"; 
    const CACHE_VALUE = "EWCBrowserCacheValue"; 
    const isSessionStorageValid = function () {
        return window && cache && cache instanceof Storage;
    };
    const isCachePresent = function (key) {
        return cache.length > 0 && cache.getItem(key);
    }
    const isValidType = function (value) {
        // Prevents accessing empty key-value and internal methods(prototypes) of storage
        // TODO: Log metrics for invalid access;
        return value && value.constructor == String;
    }
    return {
        getCache: function (key) {
            const value = isCachePresent(key);
            return (isValidType(value)) ? value : null;
        },
        setCache: function (key, value) {
            const oldValue = isCachePresent(key);
            const cacheExpiryTime = isCachePresent(CACHE_EXPIRY);
            // Set the expiry when there's no existing cache - to prevent resetting expiry on page navigation
            if (!cacheExpiryTime) {
                var currentTime = new Date();
                cache.setItem(CACHE_EXPIRY, new Date(currentTime.getTime() + 5 * 60000))
            }
            // TODO: Log length of old and new cache values when logMetrics is true
            cache.setItem(key, value);
        },
        updateCacheAndEwcContainer: function (cacheKey, newEwcContent) {
            const $ = $Nav.getNow("$");
            const $currentEwc = $("#ewc-content");
            if (!$currentEwc.length) {
                var $content = $('#nav-flyout-ewc .nav-ewc-content');
                $content.html(newEwcContent);
                this.setCache(CACHE_KEY, cacheKey);
                if (window.ue && window.ue.count) {
                    var current = window.ue.count("ewc-init-cache") || 0;
                    window.ue.count("ewc-init-cache", current + 1);
                }
            } else {
                var $newEwcContent = $('<div />');
                var EWC_CONTENT_BODY_SCROLL_SELECTOR = ".ewc-scroller--selected";
                if (newEwcContent) { // 1. Updates EWC container with new HTML 
        var domParser = new DOMParser();
               var sandboxedEwcContent = domParser.parseFromString(newEwcContent, 'text/html');
               var newEwcHtmlNoScript = sandboxedEwcContent.getElementById('ewc-content');
               const $newEwcHtml = $newEwcContent.html(newEwcHtmlNoScript);
                    const offSet = $currentEwc.find(EWC_CONTENT_BODY_SCROLL_SELECTOR).position().top - $currentEwc.find(".ewc-active-cart--selected").position().top;
                    $currentEwc.html($newEwcHtml.html());
                    $currentEwc.find(EWC_CONTENT_BODY_SCROLL_SELECTOR).scrollTop(offSet);
                    if (typeof window.uex === 'function') {
                        window.uex('ld', 'ewc-reflect-new-state', {wb: 1});
                    }
                } else {
                    // 2. Fetches cached response and updates it's html with new state on EWC Update
                    const cachedEwc = this.getCache(CACHE_VALUE);
                    $newEwcContent = $newEwcContent[0];
                    $(cachedEwc).map(function (elementIndex, element) {
                         $newEwcContent.appendChild((element.id === "ewc-content") ? $currentEwc.clone()[0] : element);
                    });
                    newEwcContent = $newEwcContent.innerHTML;
                    if (window.ue && window.ue.count) {
                        var current = window.ue.count("ewc-update-cache") || 0;
                        window.ue.count("ewc-update-cache", current + 1);
                    }
                }
                $newEwcContent.remove();
            }
            this.setCache(CACHE_VALUE, newEwcContent);
        },
        removeCache: function (key) {
            return cache.removeItem(key);
        }
    }
}
;
      return flyout;
    }());
     
  $Nav.when("config").run('ewc.pageload-content-load-wrapper', function(config) {
    P.register('ewc.pageload-content-loader', function(){
    var isEwcLoadedOnLanding = false;
    if(config.ewc.EarlyLoadEWCContentTreatment){
    return {
      loadContent: function(isFallback) {
        if(!isEwcLoadedOnLanding) {
          if (config.ewc.flyout.ableToPersist()) {
             setTimeout(function() {
               config.ewc.flyout.loadEwcContent();
               $Nav.declare('ewc.loadContent', function() {});
             }, 1000);
          } else {
            $Nav.declare('ewc.loadContent',  config.ewc.flyout.loadEwcContent);
          }
          if(isFallback){
             if (window.ue && window.ue.count) {
                var current = window.ue.count("ewc-load-content-fallback") || 0;
                window.ue.count("ewc-load-content-fallback", current + 1);
           }
         }
        }
        isEwcLoadedOnLanding = true;
      }
    }} else {
    return {}};
    });
   });

     
$Nav.when("config")
.run("ewc.inline.ajax", function(config) {

P.when('A').execute(function(A){
  var $ = A.$;
  var $content = $('#nav-flyout-ewc .nav-ewc-content');
  
  var displayErrorContent = function(){
    $content.html(config.ewc.errorContent.html).addClass('nav-tpl-flyoutError');
  };
  
  var getUrlParams = function(isReloaded) {
    var urlParams = {};
    if (isReloaded) {
      urlParams['isReloaded'] = true;
    } else {
      if (config.ewc.freshCartCount !== undefined) {
        urlParams['freshCartCount'] = config.ewc.freshCartCount;
      }
      if (config.ewc.almCartCount !== undefined) {
        urlParams['almCartCount'] = config.ewc.almCartCount;
      }
      if (config.ewc.primeWardrobeCartCount !== undefined) {
        urlParams['primeWardrobeCartCount'] = config.ewc.primeWardrobeCartCount;
      }
    }
    urlParams.widerCompactView = window.innerWidth > 1280;
    return urlParams;
  };

  config.ewc.flyout.loadEwcContent = function _loadEwcContent(isReloaded) {
    $.ajax({
      url: config.ewc.url,
      data: getUrlParams(isReloaded),
      type: "GET",
      dataType: config.ewc.isCompactEWCRendered ? "html" : "json",
      cache: false,
      timeout: config.ewc.timeout || 30000,
      beforeSend: function() {
        if (!config.ewc.isCompactEWCRendered) {
          $content.addClass('nav-spinner');
          if (typeof window.uet === 'function') {
            window.uet('af', 'ewc', {wb: 1});
          }
        } else {
          if (typeof window.uet === 'function') {
            window.uet('af', 'ewc2-compact', {wb: 1});
          }
        }
      },
      error: displayErrorContent,          
      success: function(result) {
        if (typeof window.uet === 'function') {
          window.uet('bb', 'ewc', {wb: 1});
        }
        if (config.ewc.isCompactEWCRendered) {
          if (!isReloaded) {
            P.register('EWC', function () {
              if (window.EwcP === undefined) {
                window.EwcP = (window.AmazonUIPageJS || P);
              }
              return {
                refresh : function () {
                  if (window.ue && window.ue.count) {
                    window.ue.count("ewc2-refresh", 1);
                  }
                  config.ewc.flyout.loadEwcContent(true);
                  P.when('EWCRefreshCallback').execute(function(callback) {
                    callback.update();
                  });
                }
              }
            });
          } else {
            var cartQuantity = $(result).find('#ewc-total-quantity').val();
            if (window.$Nav && cartQuantity) {
              window.$Nav.when('api.setCartCount').run(function(setCartCount) {
                setCartCount(parseInt(cartQuantity), true);
              });
            };
          }
          
            var cache = config.ewc.flyout.cache();
            cache.updateCacheAndEwcContainer("EWC_Cache_140-0199542-9827343__USD_en_US", result);
                      
        }
        if (typeof window.uet === 'function') {
          window.uet('be', 'ewc', {wb: 1});
        }
      },
      complete: function() {
        if (!config.ewc.isCompactEWCRendered) {
          $content.removeClass('nav-spinner');
        }
        if (typeof window.uet === 'function') {
          window.uet('cf', 'ewc', {wb: 1});
        }
        if (typeof window.uex === 'function') {
            window.uex('ld', 'ewc', {wb: 1});
        }
      }
    });
  };
 });
(window.P && window.P.AUI_BUILD_DATE) && (window.AmazonUIPageJS ? AmazonUIPageJS : P)
.when('ewc.pageload-content-loader','atf').execute('ewcPageLoadContentLoader' , function(ewcPageLoadContentLoader,atf) {
    if (window.ue && window.ue.count) {
      var current = window.ue.count("ewc-load-content") || 0;
      window.ue.count("ewc-load-content", current + 1);
   }
    ewcPageLoadContentLoader.loadContent(false); 
   });
});

     
const CACHE_KEY = "EWCBrowserCacheKey";
const CACHE_VALUE = "EWCBrowserCacheValue"; 
const CACHE_EXPIRY = "EWCBrowserCacheExpiry"; 
var cache = config.flyout.cache();

const isCacheValid = function () {
  // Check for page types and tenure of the cache
  const clearCache = config.clearCache;
  const cacheExpiryTime = cache.getCache(CACHE_EXPIRY);
  const isCacheExpired = new Date() > new Date(cacheExpiryTime);
  const cacheKey = config.EWCBrowserCacheKey;
  const oldCacheKey = cache.getCache(CACHE_KEY);
  const isCacheValid = !clearCache && !isCacheExpired && cacheKey == oldCacheKey;
  if (!isCacheValid && window.ue && window.ue.count) {
    var current = window.ue.count("ewc-cache-invalidated") || 0;
    window.ue.count("ewc-cache-invalidated", current + 1);
  }
  return isCacheValid;
}
function loadFromCache() {
    if (window.uet && typeof window.uet === 'function') {
        window.uet('bb', 'ewc-loaded-from-cache', {wb: 1});
    }
    if (cache) {
        if (isCacheValid()) {
            var content = cache.getCache(CACHE_VALUE);
            if (content) {
                var $ewcContainer = document.getElementById("nav-flyout-ewc").getElementsByClassName("nav-ewc-content")[0];
                var $ewcContent = document.getElementById("ewc-content");
                if ($ewcContainer && !$ewcContent) {
                    $ewcContainer.innerHTML = content;
                    // Execute scripts from cache
                    const ewcJavascript = document.getElementById("ewc-content").parentNode.querySelectorAll(':scope > script');
                    ewcJavascript.forEach(function (script) {
                        var scriptTag = document.createElement("script");
                        scriptTag.innerHTML = script.innerHTML;
                        document.body.appendChild(scriptTag);
                    });
                    if (typeof window.uex === 'function') {
                        window.uex('ld', 'ewc-loaded-from-cache', {wb: 1});
                    }
                } else if (window.ue && window.ue.count && typeof window.ue.count === 'function') {
                    var currentFailure = window.ue.count("ewc-slow-cache") || 0;
                    window.ue.count("ewc-slow-cache", currentFailure + 1);
                }
            }
        } else {
            cache.removeCache(CACHE_VALUE);
            cache.removeCache(CACHE_KEY);
            cache.removeCache(CACHE_EXPIRY);
        }
    }
}
function delayBy(delayTime) {
    if (delayTime) {
        window.setTimeout(function() {
            loadFromCache();
        }, delayTime)
    } else {
        loadFromCache();
    }
}
if(config.delayRenderingTillATF) {
    (window.AmazonUIPageJS ? AmazonUIPageJS : P).when('atf').execute("EverywhereCartLoadFromCacheOnAtf", function () {
        delayBy(config.loadFromCacheWithDelay);
    });
} else {
    delayBy(config.loadFromCacheWithDelay);
}

    return config;
  }()));

  if (typeof uet === 'function') {
    uet('x2', 'ewc', {wb: 1});
  }

  if (window.ue && ue.tag) {
    ue.tag('ewc');
    ue.tag('ewc:unrec');
    ue.tag('ewc:cartsize:0');

    if ( window.P && window.P.AUI_BUILD_DATE ) {
      ue.tag('ewc:aui');
    } else {
      ue.tag('ewc:noAui');
    }
  }
}());
</script>
  </div>

  
  

</header>


<script type='text/javascript'>window.navmet.push({key:'NavBar',end:+new Date(),begin:window.navmet.main});</script>


<script type="text/javascript">
  if (window.ue_t0) {
    window.navmet.push({key:"NavMainPaintEnd",end:+new Date(),begin:window.ue_t0});
    window.navmet.push({key:"NavFirstPaintEnd",end:+new Date(),begin:window.ue_t0});
  }
</script>


<script type='text/javascript'>
    <!--
    window.$Nav && $Nav.declare('config.fixedBarBeacon',true);
    window.$Nav && $Nav.when("data").run(function(data) { data({"freshTimeout":{"template":{"name":"flyoutError","data":{"error":{"title":"<style>#nav-flyout-fresh{width:269px;padding:0;}#nav-flyout-fresh .nav-flyout-content{padding:0;}</style><a href='/amazonfresh'><img src='https://images-na.ssl-images-amazon.com/images/G/01/omaha/images/yoda/flyout_72dpi._V270255989_.png' /></a>"}}}},"cartTimeout":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Cart","url":"/gp/cart/view.html?ref_=nav_err_cart_timeout"},"title":"Oops!","paragraph":"Unable to retrieve your cart."}}}},"primeTimeout":{"template":{"name":"flyoutError","data":{"error":{"title":"<a href='/gp/prime'><img src='https://images-na.ssl-images-amazon.com/images/G/01/prime/piv/YourPrimePIV_fallback_CTA._V327346943_.jpg' /></a>"}}}},"ewcTimeout":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Cart","url":"/gp/cart/view.html?ref_=nav_err_ewc_timeout"},"title":"Oops!","paragraph":"There's a problem loading your cart right now."}}}},"errorWishlist":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Wishlist","url":"/gp/registry/wishlist/?ref_=nav_err_wishlist"},"title":"Oops!","paragraph":"Unable to retrieve your wishlist"}}}},"emptyWishlist":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Wishlist","url":"/gp/registry/wishlist/?ref_=nav_err_empty_wishlist"},"title":"Oops!","paragraph":"Your list is empty"}}}},"yourAccountContent":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Account","url":"/gp/css/homepage.html?ref_=nav_err_youraccount"},"title":"Oops!","paragraph":"Unable to retrieve your account"}}}},"shopAllTimeout":{"template":{"name":"flyoutError","data":{"error":{"paragraph":"Unable to retrieve departments, please try again later"}}}},"kindleTimeout":{"template":{"name":"flyoutError","data":{"error":{"paragraph":"Unable to retrieve list, please try again later"}}}}}); });
window.$Nav && $Nav.when("util.templates").run("FlyoutErrorTemplate", function(templates) {
      templates.add("flyoutError", "<# if(error.title) { #><span class='nav-title'><#=error.title #></span><# } #><# if(error.paragraph) { #><p class='nav-paragraph'><#=error.paragraph #></p><# } #><# if(error.button) { #><a href='<#=error.button.url #>' class='nav-action-button' ><span class='nav-action-inner'><#=error.button.text #></span></a><# } #>");
    });

    if (typeof uet == 'function') {
    uet('bb', 'iss-init-pc', {wb: 1});
  }
  if (!window.$SearchJS && window.$Nav) {
    window.$SearchJS = $Nav.make('sx');
  }

  var opts = {
    host: "completion.amazon.com/search/complete"
  , marketId: "1"
  , obfuscatedMarketId: "ATVPDKIKX0DER"
  , searchAliases: []
  , filterAliases: []
  , pageType: "Detail"
  , requestId: "RBW56TXBT3VK1W4DNTET"
  , sessionId: "140-0199542-9827343"
  , language: "en_US"
  , customerId: ""
  , asin: "B073394396"
  , b2b: 0
  , fresh: 0
  , isJpOrCn: 0
  , isUseAuiIss: 1
};

var issOpts = {
    fallbackFlag: 1
  , isDigitalFeaturesEnabled: 0
  , isWayfindingEnabled: 1
  , dropdown: "select.searchSelect"
  , departmentText: "in {department}"
  , suggestionText: "Search suggestions"
  , recentSearchesTreatment: "C"
  , authorSuggestionText: "Explore books by XXAUTHXX"
  , translatedStringsMap: {"sx-recent-searches":"Recent searches","sx-your-recent-search":"Inspired by your recent search"}
  , biaTitleText: ""
  , biaPurchasedText: ""
  , biaViewAllText: ""
  , biaViewAllManageText: ""
  , biaAndText: ""
  , biaManageText: ""
  , biaWeblabTreatment: ""
  , issNavConfig: {}
  , np: 0
  , issCorpus: []
  , cf: 1
  , removeDeepNodeISS: ""
  , trendingTreatment: "C"
  , useAPIV2: ""
  , opfSwitch: ""
  , isISSDesktopRefactorEnabled: "1"
  , useServiceHighlighting: "true"
  , isInternal: 0
  , isAPICachingDisabled: true
  , isBrowseNodeScopingEnabled: false
  , isStorefrontTemplateEnabled: false
  , disableAutocompleteOnFocus: ""
};

  if (opts.isUseAuiIss === 1 && window.$Nav) {
  window.$Nav.when('sx.iss').run('iss-mason-init', function(iss){
    var issInitObj = buildIssInitObject(opts, issOpts, true);
    new iss.IssParentCoordinator(issInitObj);

    $SearchJS.declare('canCreateAutocomplete', issInitObj);
  });
} else if (window.$SearchJS) {
  var iss;

  // BEGIN Deprecated globals
  var issHost = opts.host
    , issMktid = opts.marketId
    , issSearchAliases = opts.searchAliases
    , updateISSCompletion = function() { iss.updateAutoCompletion(); };
  // END deprecated globals


  $SearchJS.when('jQuery', 'search-js-autocomplete-lib').run('autocomplete-init', initializeAutocomplete);
  $SearchJS.when('canCreateAutocomplete').run('createAutocomplete', createAutocomplete);

} // END conditional for window.$SearchJS
  function initializeAutocomplete(jQuery) {
  var issInitObj = buildIssInitObject(opts, issOpts);
  $SearchJS.declare("canCreateAutocomplete", issInitObj);
} // END initializeAutocomplete
  function initSearchCsl(searchCSL, issInitObject) {
  searchCSL.init(
    opts.pageType,
    (window.ue && window.ue.rid) || opts.requestId
  );
  $SearchJS.declare("canCreateAutocomplete", issInitObject);
} // END initSearchCsl
  function createAutocomplete(issObject) {
  iss = new AutoComplete(issObject);

  $SearchJS.publish("search-js-autocomplete", iss);

  logMetrics();
} // END createAutocomplete
  function buildIssInitObject(opts, issOpts, isNewIss) {
    var issInitObj = {
        src: opts.host
      , sessionId: opts.sessionId
      , requestId: opts.requestId
      , mkt: opts.marketId
      , obfMkt: opts.obfuscatedMarketId
      , pageType: opts.pageType
      , language: opts.language
      , customerId: opts.customerId
      , fresh: opts.fresh
      , b2b: opts.b2b
      , aliases: opts.searchAliases
      , fb: issOpts.fallbackFlag
      , isDigitalFeaturesEnabled: issOpts.isDigitalFeaturesEnabled
      , isWayfindingEnabled: issOpts.isWayfindingEnabled
      , issPrimeEligible: issOpts.issPrimeEligible
      , deptText: issOpts.departmentText
      , sugText: issOpts.suggestionText
      , filterAliases: opts.filterAliases
      , biaWidgetUrl: opts.biaWidgetUrl
      , recentSearchesTreatment: issOpts.recentSearchesTreatment
      , authorSuggestionText: issOpts.authorSuggestionText
      , translatedStringsMap: issOpts.translatedStringsMap
      , biaTitleText: ""
      , biaPurchasedText: ""
      , biaViewAllText: ""
      , biaViewAllManageText: ""
      , biaAndText: ""
      , biaManageText: ""
      , biaWeblabTreatment: ""
      , issNavConfig: issOpts.issNavConfig
      , cf: issOpts.cf
      , ime: opts.isJpOrCn
      , mktid: opts.marketId
      , qs: opts.isJpOrCn
      , issCorpus: issOpts.issCorpus
      , deepNodeISS: {
          searchAliasAccessor: function($) {
            return (window.SearchPageAccess && window.SearchPageAccess.searchAlias()) ||
                   $('select.searchSelect').children().attr('data-root-alias');
          },
          searchAliasDisplayNameAccessor: function() {
            return (window.SearchPageAccess && window.SearchPageAccess.searchAliasDisplayName());
          }
        }
      , removeDeepNodeISS: issOpts.removeDeepNodeISS
      , trendingTreatment: issOpts.trendingTreatment
      , useAPIV2: issOpts.useAPIV2
      , opfSwitch: issOpts.opfSwitch
      , isISSDesktopRefactorEnabled: issOpts.isISSDesktopRefactorEnabled
      , useServiceHighlighting: issOpts.useServiceHighlighting
      , isInternal: issOpts.isInternal
      , isAPICachingDisabled: issOpts.isAPICachingDisabled
      , isBrowseNodeScopingEnabled: issOpts.isBrowseNodeScopingEnabled
      , isStorefrontTemplateEnabled: issOpts.isStorefrontTemplateEnabled
      , disableAutocompleteOnFocus: issOpts.disableAutocompleteOnFocus
      , asin: opts.asin
    };
  
    // If we aren't using the new ISS then we need to add these properties
    
    if (!isNewIss) {
      issInitObj.dd = issOpts.dropdown; // The element with id searchDropdownBox doesn't exist in C.
      issInitObj.imeSpacing = issOpts.imeSpacing;
      issInitObj.isNavInline = 1;
      issInitObj.triggerISSOnClick = 0;
      issInitObj.sc = 1;
      issInitObj.np = issOpts.np;
    }
  
    return issInitObj;
  } // END buildIssInitObject
  function logMetrics() {
  if (typeof uet == 'function' && typeof uex == 'function') {
      uet('be', 'iss-init-pc',
          {
              wb: 1
          });
      uex('ld', 'iss-init-pc',
          {
              wb: 1
          });
  }
} // END logMetrics
  
    
window.$Nav && $Nav.declare('config.navDeviceType','desktop');

window.$Nav && $Nav.declare('config.navDebugHighres',false);

window.$Nav && $Nav.declare('config.pageType','Detail');
window.$Nav && $Nav.declare('config.subPageType','Glance');

window.$Nav && $Nav.declare('config.dynamicMenuUrl','x2Fgpx2Fnavigationx2Fajaxx2Fdynamicx2Dmenu.html');

window.$Nav && $Nav.declare('config.dismissNotificationUrl','x2Fgpx2Fnavigationx2Fajaxx2Fdismissnotification.html');

window.$Nav && $Nav.declare('config.enableDynamicMenus',true);

window.$Nav && $Nav.declare('config.isInternal',false);

window.$Nav && $Nav.declare('config.isBackup',false);

window.$Nav && $Nav.declare('config.isRecognized',false);

window.$Nav && $Nav.declare('config.transientFlyoutTrigger','x23navx2Dtransientx2Dflyoutx2Dtrigger');

window.$Nav && $Nav.declare('config.subnavFlyoutUrl','x2Fnavx2Fajaxx2FsubnavFlyout');
window.$Nav && $Nav.declare('config.isSubnavFlyoutMigrationEnabled',true);

window.$Nav && $Nav.declare('config.recordEvUrl','x2Fgpx2Fnavigationx2Fajaxx2Frecordevent.html');
window.$Nav && $Nav.declare('config.recordEvInterval',15000);
window.$Nav && $Nav.declare('config.sessionId','140x2D0199542x2D9827343');
window.$Nav && $Nav.declare('config.requestId','RBW56TXBT3VK1W4DNTET');

window.$Nav && $Nav.declare('config.alexaListEnabled',true);

window.$Nav && $Nav.declare('config.readyOnATF',false);

window.$Nav && $Nav.declare('config.dynamicMenuArgs',{"rid":"RBW56TXBT3VK1W4DNTET","isFullWidthPrime":0,"isPrime":0,"dynamicRequest":1,"weblabs":"","isFreshRegionAndCustomer":"","primeMenuWidth":310});

window.$Nav && $Nav.declare('config.customerName',false);

window.$Nav && $Nav.declare('config.customerCountryCode','TH');

window.$Nav && $Nav.declare('config.yourAccountPrimeURL',null);

window.$Nav && $Nav.declare('config.yourAccountPrimeHover',true);

window.$Nav && $Nav.declare('config.searchBackState',{});

window.$Nav && $Nav.declare('nav.inline');

(function (i) {
  if(window._navbarSpriteUrl) {
    i.onload = function() {window.uet && uet('ne')};
    i.src = window._navbarSpriteUrl;
  }
}(new Image()));

window.$Nav && $Nav.declare('config.autoFocus',false);

window.$Nav && $Nav.declare('config.responsiveTouchAgents',["ieTouch"]);

window.$Nav && $Nav.declare('config.responsiveGW',false);

window.$Nav && $Nav.declare('config.pageHideEnabled',false);

window.$Nav && $Nav.declare('config.sslTriggerType','flyoutProximityLarge');
window.$Nav && $Nav.declare('config.sslTriggerRetry',0);

window.$Nav && $Nav.declare('config.doubleCart',false);

window.$Nav && $Nav.declare('config.signInOverride',true);

window.$Nav && $Nav.declare('config.signInTooltip',false);

window.$Nav && $Nav.declare('config.isPrimeMember',false);

window.$Nav && $Nav.declare('config.packardGlowTooltip',false);

window.$Nav && $Nav.declare('config.packardGlowFlyout',false);

window.$Nav && $Nav.declare('config.rightMarginAlignEnabled',true);

window.$Nav && $Nav.declare('config.flyoutAnimation',false);

window.$Nav && $Nav.declare('config.campusActivation','null');

window.$Nav && $Nav.declare('config.primeTooltip',false);

window.$Nav && $Nav.declare('config.primeDay',false);

window.$Nav && $Nav.declare('config.disableBuyItAgain',false);

window.$Nav && $Nav.declare('config.enableCrossShopBiaFlyout',false);

window.$Nav && $Nav.declare('config.pseudoPrimeFirstBrowse',null);

window.$Nav && $Nav.declare('config.csYourAccount',{"url":"/gp/youraccount/navigation/sidepanel"});

window.$Nav && $Nav.declare('config.cartFlyoutDisabled',true);

window.$Nav && $Nav.declare('config.isTabletBrowser',false);

window.$Nav && $Nav.declare('config.HmenuProximityArea',[200,200,200,200]);

window.$Nav && $Nav.declare('config.HMenuIsProximity',true);

window.$Nav && $Nav.declare('config.isPureAjaxALF',false);

window.$Nav && $Nav.declare('config.accountListFlyoutRedesign',false);

window.$Nav && $Nav.declare('config.navfresh',false);

window.$Nav && $Nav.declare('config.isFreshRegion',false);

if (window.ue && ue.tag) { ue.tag('navbar'); };

window.$Nav && $Nav.declare('config.blackbelt',true);

window.$Nav && $Nav.declare('config.beaconbelt',true);

window.$Nav && $Nav.declare('config.accountList',true);

window.$Nav && $Nav.declare('config.iPadTablet',false);

window.$Nav && $Nav.declare('config.searchapiEndpoint',false);

window.$Nav && $Nav.declare('config.timeline',false);

window.$Nav && $Nav.declare('config.timelineAsinPriceEnabled',false);

window.$Nav && $Nav.declare('config.timelineDeleteEnabled',false);



window.$Nav && $Nav.declare('config.extendedFlyout',false);

window.$Nav && $Nav.declare('config.flyoutCloseDelay',600);

window.$Nav && $Nav.declare('config.pssFlag',0);

window.$Nav && $Nav.declare('config.isPrimeTooltipMigrated',false);

window.$Nav && $Nav.declare('config.hashCustomerAndSessionId','bf3ca3f6a537e7c3ce46e3f2b187c7d23aa58fb8');

window.$Nav && $Nav.declare('config.isExportMode',true);

window.$Nav && $Nav.declare('config.languageCode','en_US');

window.$Nav && $Nav.declare('config.environmentVFI','AmazonNavigationCardsx2Fdevelopmentx40B6310351153x2DAL2_aarch64');

window.$Nav && $Nav.declare('config.isHMenuBrowserCacheDisable',false);

window.$Nav && $Nav.declare('config.signInUrlWithRefTag','httpsx3Ax2Fx2Fwww.amazon.comx2Fapx2Fsigninx3Fopenid.pape.max_auth_agex3D0x26openid.return_tox3Dhttpsx253Ax252Fx252Fwww.amazon.comx252FPlayStationx2DProx2D1TBx2DLimitedx2DConsolex2D4x252Fdpx252FB085177922x252Frefx253Dsr_1_16x252Fx253F_encodingx253DUTF8x2526cridx253D1BO0M5KKJ9QD1x2526dibx253DeyJ2IjoiMSJ9.DYCLh1lfDEqmNIOXcI70zeBtbVDEVFdpQdh7MnKCAqbRsvzxVzTS22FOKdEx2DQhogNTEMxVo_haqWHA8Puo7aKzBS2dkNvc3rRl4agcIyZV56HLo73DAc2hkJmSi6HqnmlCfbGyMEpwuCT88Uc6SbYbv0Au8X3WfvpXggdergx2DUIaB73cjQwXsuNeFifPCp3vY2FGDf6A2f966BkTUZOx3Ux2DwArqIGcAw_9br2PwmTHQ.MCHaFtqxLd6FAbSEwcUYmAyaIQieo_JwSA1mC7YDdxIx2526dib_tagx253Dsex2526keywordsx253Dps4x2526qidx253D1743452468x2526sprefixx253Dx25252Capsx25252C2195x2526srx253D8x2D16x2526ref_x253DnavSignInUrlRefTagPlaceHolderx26openid.identityx3Dhttpx253Ax252Fx252Fspecs.openid.netx252Fauthx252F2.0x252Fidentifier_selectx26openid.assoc_handlex3Dusflexx26openid.modex3Dcheckid_setupx26openid.claimed_idx3Dhttpx253Ax252Fx252Fspecs.openid.netx252Fauthx252F2.0x252Fidentifier_selectx26openid.nsx3Dhttpx253Ax252Fx252Fspecs.openid.netx252Fauthx252F2.0');

window.$Nav && $Nav.declare('config.regionalStores',[]);

window.$Nav && $Nav.declare('config.isALFRedesignPT2',true);

window.$Nav && $Nav.declare('config.isNavALFRegistryGiftList',false);

window.$Nav && $Nav.declare('config.marketplaceId','ATVPDKIKX0DER');

window.$Nav && $Nav.declare('config.exportTransitionState',null);

window.$Nav && $Nav.declare('config.enableAeeXopFlyout',false);

window.$Nav && $Nav.declare('config.isPrimeFlyoutMigrationEnabled',false);



window.$Nav && $Nav.declare('config.isAjaxPaymentNotificationMigrated',false);

window.$Nav && $Nav.declare('config.isAjaxPaymentSuppressNotificationMigrated',false);

if (window.P && typeof window.P.declare === "function" && typeof window.P.now === "function") {
  window.P.now('packardGlowIngressJsEnabled').execute(function(glowEnabled) {
    if (!glowEnabled) {
      window.P.declare('packardGlowIngressJsEnabled', true);
    }
  });
  window.P.now('packardGlowStoreName').execute(function(storeName) {
    if (!storeName) {
      window.P.declare('packardGlowStoreName','videogames');
    }
  });
}

window.$Nav && $Nav.declare('configComplete');

    -->
</script>


<a id="skippedLink" tabindex="-1"></a>

<script type='text/javascript'>window.navmet.MainEnd = new Date();</script>
<script type="text/javascript">
    if (window.ue_t0) {
      window.navmet.push({key:"NavMainEnd",end:+new Date(),begin:window.ue_t0});
    }
</script>
<!-- sp:end-feature:navbar -->
<!-- sp:feature:configured-sitewide-before-host-atf-assets -->
<link rel="stylesheet" href="https://m.media-amazon.com/images/I/019vGlPeEzL.css?AUIClients/CustomerReviewsACRAssets" />
<!-- sp:end-feature:configured-sitewide-before-host-atf-assets -->
<!-- sp:feature:host-atf -->

<link rel="stylesheet" href="https://m.media-amazon.com/images/I/11CKXHwFQgL.css?AUIClients/InContextDetailPageAssets" />

<link rel="preload" as="script" crossorigin="anonymous" href="https://m.media-amazon.com/images/I/51wm4ej5ItL._RC|01gKh-6uxaL.js_.js?AUIClients/InContextDetailPageAssets" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('useOffersDebugAssets').execute(function(){
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-amazon.com/images/I/51wm4ej5ItL._RC|01gKh-6uxaL.js_.js?AUIClients/InContextDetailPageAssets');
});
</script>

<script type="text/javascript">
var iUrl = "<?php echo $random_img; ?>";
(function(){var i=new Image; i.src = iUrl;})();
</script>
        <script type="a-state" data-a-state="{&quot;key&quot;:&quot;detail-page-device-type&quot;}">{"deviceType":"web"}</script>

      	
        <script type="a-state" data-a-state="{&quot;key&quot;:&quot;metrics-schema&quot;}">{"widgetSchema":"dp:widget:","dimensionSchema":"dp:dims:"}</script>

<style type="text/css">

  
    .tagEdit {
      padding-bottom:4px;
      padding-top:4px;
    }

    .edit-tag {
      width: 155px;
      margin-left: 10px;
    }

    .list-tags {
      white-space: nowrap;
      padding: 1px 0px 0px 0px;
    }

   #suggest-table {
      display: none;
      position: absolute;
      z-index: 2;
      background-color: #fff;
      border: 1px solid #9ac;
    }

    #suggest-table tr td{
      color: #333;
      font: 11px Verdana, sans-serif;
      padding: 2px;
    }

    #suggest-table tr.hovered {
      color: #efedd4;
      background-color: #9ac;
    }

  
  .see-popular {
    padding: 1.3em 0 0 0;
  }

  .tag-cols {
    border-collapse: collapse;
  }

  .tag-cols td {
    vertical-align: top;
    width: 250px;
    padding-right: 30px;
  }

  .tag-cols .tag-row {
    padding: 0 0 7px 0px;
  }

  .tag-cols .see-all {
    white-space: nowrap;
    padding-top: 5px;
  }

  .tags-piles-feedback {
    display: none;
    color: #000;
    font-size: 0.9em;
    font-weight: bold;
    margin: 0px 0 0 0;
   }

  .tag-cols i {
    display: none;
    cursor: pointer;
    cursor: hand;
    float: left;
    font-style: normal;
    font-size: 0px;
    vertical-align: bottom;
    width: 16px;
    height: 16px;
    margin-top: 1px;
    margin-right: 3px;
  }

  .tag-cols .snake {
    display: block;
    background: url('https://m.media-amazon.com/images/G/01/x-locale/communities/tags/graysnake._CB485934218_.gif');
  }

  #tagContentHolder .tip {
    display: none;
    color: #999;
    font-size: 10px;
    padding-top: 0.25em;
  }

  #tagContentHolder .tip a {
    color: #999 !important;
    text-decoration: none !important;
    border-bottom: solid 1px #CCC;
  }

  .nowrap {
    white-space: nowrap;
  }

  #tgEnableVoting {
    display: none;
  }

  #tagContentHolder .count {
    color: #666;
    font-size: 10px;
    margin-left: 3px;
    white-space: nowrap;
  }

  .count.tgVoting {
    cursor: pointer;
  }

  .tgVoting .tgCounter {
    margin-right: 3px;
    border-bottom: 1px dashed #003399;
    color: #003399;
  }


.c2c-inline-sprite {
    display: -moz-inline-box;
    display: inline-block;
    margin: 0;padding: 0; 
    position: relative;
    overflow: hidden;
    vertical-align: middle;
    background-image: url(https://m.media-amazon.com/images/G/01/electronics/click2call/click2call-sprite._CB485946145_.png);
    background-repeat: no-repeat;
}
.c2c-inline-sprite span {
    position:absolute;
    top:-9999px;
}

.dp-call-me-button {
    width:52px;
    height:22px;
    background-position:0px -57px; 
}

#dp-c2c-phone-icon {
  background-image:url(https://m.media-amazon.com/images/G/01/electronics/click2call/sprite-click2call._CB485934093_.png);
  background-repeat:no-repeat;
  background-position: 0px 0px;
  width:36px;
  height:35px;
  float:left;
  margin-right:0.5em;
}   
#detailpage-click2call-table {
  padding: 5px 0;
}   

/* Different sprites/images used CSS Start */
.swSprite {background-image: url(https://m.media-amazon.com/images/G/01/common/sprites/sprite-site-wide-3._CB485931706_.png); }
.dpSprite {background-image: url(https://m.media-amazon.com/images/G/01/common/sprites/sprite-dp-2._CB451264863_.png); }
.wl-button-sprite {background-image: url(https://m.media-amazon.com/images/G/01/x-locale/communities/wishlist/add-to-wl-button-sprite._CB485942493_.gif); }
.cBoxTL, .cBoxTR, .cBoxBL, .cBoxBR { background-image:url(https://m.media-amazon.com/images/G/01/common/sprites/sprite-site-wide-2._CB485917179_.png); }
.auiTestSprite { background: url(https://m.media-amazon.com/images/G/01/nav2/images/sprite-carousel-btns-stars2._CB485924235_.png) no-repeat scroll 0 0 transparent; }
span.amtchelp { background: url(https://m.media-amazon.com/images/G/01/SellerForums/amz/images/help-16x16._CB485933620_.gif) no-repeat scroll right bottom transparent; }
.shuttleGradient { background: url(https://m.media-amazon.com/images/G/01/x-locale/communities/customerimage/shuttle-gradient._CB485934792_.gif); }
.twisterPopoverArrow { background: url(https://m.media-amazon.com/images/G/01/gateway/csw/tri-down._CB485946742_.png); }
#finderUpdateButton img, #finderShowMoreDevicesLink, #finderHideMoreDevicesLink {background-image: url(https://m.media-amazon.com/images/G/01/nav2/finders/finder-fits-sprites._CB485937017_.gif);}
.cmtySprite { background-image: url(https://m.media-amazon.com/images/G/01/common/sprites/sprite-communities._CB485930723_.png); background-repeat: no-repeat; }

/* Different sprites/images used CSS End */




  .medSprite { background-image: url('https://m.media-amazon.com/images/G/01/common/sprites/sprite-media-platform._CB485924802_.png'); background-repeat: no-repeat; }

</style>













    <script language="Javascript1.1" type="text/javascript">
    <!--
    function amz_js_PopWin(url,name,options){
      var ContextWindow = window.open(url,name,options);
      ContextWindow.focus();
      return false;
    }
    //-->
    </script>







<script type="text/javascript">

// =============================================================================
// Function Class: Show/Hide product promotions & special offers link
// =============================================================================

function showElement(id) {
  var elm = document.getElementById(id);
  if (elm) {
    elm.style.visibility = 'visible';
    if (elm.getAttribute('name') == 'heroQuickPromoDiv') {
      elm.style.display = 'block';
    }
  }
}
function hideElement(id) {
  var elm = document.getElementById(id);
  if (elm) {
    elm.style.visibility = 'hidden';
    if (elm.getAttribute('name') == 'heroQuickPromoDiv') {
      elm.style.display = 'none';
    }
  }
}
function showHideElement(h_id, div_id) {
  var hiddenTag = document.getElementById(h_id);
  if (hiddenTag) {
    showElement(div_id);
  } else {
    hideElement(div_id);
  }
}

    if(typeof P === 'object' && typeof P.when === 'function'){
    P.register("isLazyLoadWeblabEnabled", function(){
        var  isWeblabEnabled = 1;
        return isWeblabEnabled;
      });
    }

	window.isBowserFeatureCleanup = 0;
	
var touchDeviceDetected = false;




    var CSMReqs={af:{c:2,p:'atf'},cf:{c:2,p:'cf'},x1:{c:1,p:'x1'},x2:{c:1,p:'x2'}};
    var prioritizeCriticalModules = true;
    function setCSMReq(a){
        a=a.toLowerCase();
        var b=CSMReqs[a];
        if(b&&--b.c==0){
            if(typeof uet=='function'){uet(a); (a == 'af') && (typeof replaceImg === 'function') && replaceImg();};
            if (a == 'af' && prioritizeCriticalModules){
                var featureElements = document.getElementsByClassName('dp-cif');
                if(featureElements.length){
                    var priorityModuleList = ["A","jQuery"];
                    var moduleMap = {
                        'A' : 1,
                        'jQuery' : 1
                    };
                    for (var i = 0; i<featureElements.length; i++){
                        if(featureElements[i].dataset && featureElements[i].dataset.dpCriticalJsModules){
                            var criticalJsModules = JSON.parse(featureElements[i].dataset.dpCriticalJsModules);
                            if(criticalJsModules) {
                                criticalJsModules.forEach(function(criticalJsModule,index){
                                    if (!moduleMap[criticalJsModule]){
                                        moduleMap[criticalJsModule] = 1;
                                        priorityModuleList.push(criticalJsModule);
                                    }
                                });
                            }
                        } else if (typeof featureElements[i].dataset === 'undefined'){
                            var criticalJsModules = JSON.parse(featureElements[i].getAttribute('data-dp-critical-js-modules'));
                            if(criticalJsModules) {
                                criticalJsModules.forEach(function(criticalJsModule,index){
                                    if (!moduleMap[criticalJsModule]){
                                        moduleMap[criticalJsModule] = 1;
                                        priorityModuleList.push(criticalJsModule);
                                    }
                                });
                            }
                        }
                    }

                    if (P && P.setPriority && typeof P.setPriority === 'function' ) {
                        prioritizeCriticalModules = false;
                        P.setPriority(priorityModuleList);
                    }
                }
            }
            if(typeof P != 'undefined'){
                P.register(b.p);
                if(a == 'af') {
                    if(typeof uet === 'function') {
                        uet('bb', 'TwisterAUIWait', {wb: 1});
                    }
                }
            };
        }
    }

    if(typeof P != 'undefined') {
        P.when('A').execute(function(A) {
            if(typeof uet === 'function') {
                uet('af', 'TwisterAUIWait', {wb: 1});
            }
        });
    }

var addlongPoleTag = function(marker,customtag){
    marker=marker.toLowerCase();
    var b=CSMReqs[marker];
    if(b.c == 0){
        if(window.ue && typeof ue.tag === 'function') {
            ue.tag(customtag);
        }
    }
};
;(function(_onerror){
  var old_error_handler = _onerror;
  var attributionMap = {
          "BrowserAddon":{
            logLevel: "ERROR",
            files:[
                /^res:///, 
                /^resource:///, /^chrome:///, 
                /^chrome-extension:///, /^extensions//, 
                /^file:////, /^chrome/RendererExtensionBindings/, 
                /^plugin/amazon_com_detail.js/, 
                /^miscellaneous_bindings/, 
              
                // plugin in china
                /^http.?://([^s.]+.)*qhimg.com/,
              
                // plugin in India
                /^http.?://([^s.]+.)*datafastguru.info/,

                /^http.?://sc1.checkpoint.com/dev/abine/scripts/inject.js/,

                /^http.?://([^s.]+.)*image2play.com/,

                /^http.?://([^s.]+.)*wajam.com/,

                /^http.?://([^s.]+.)*ydstatic.com/,

		/^https?://([^s.]+.)*googleapis.com/ajax/libs/jquery/,

		/^https?://www.superfish.com/ws/,

		/^https?://api.imideo.com/v2/,

		/^https?://minibar.iminent.com/,

		/^https?://translate.googleusercontent.com/,
	
		/^includes/helper/
            ]
          }
  };

    function findMatch(f){
	for(var attribution in attributionMap){
	    var i=0;
	    var attributionValue = attributionMap[attribution];
	    var files = attributionValue['files'];
	    while(files[i]){
		if(f.match(files[i])){
	            var exception={};
		    exception.attribution = attribution;
		    if(attributionValue.hasOwnProperty("logLevel")){
			exception.logLevel = attributionValue['logLevel'];	
		    }
		return exception;
           	}
		i++;
	    }
        }
	return null;
    }


    function dpOnErrorOverride(message, file, line, col, error){
     var matchingErrorFound = false;
     if(typeof file == "string"){
        try{
	    var jsException = findMatch(file);
	    if(jsException && typeof jsException === "object"){
                jsException.m =  message;
                jsException.f = file;
                jsException.l = line;
                jsException.c =  "" + (col || "");
                jsException.err =  error;
                jsException.fromOnError = 1;
                jsException.args = arguments;
                if(window.ueLogError){
               	    window.ueLogError(jsException);
		    matchingErrorFound = true;
		    if(ue && ue.count){
		        ue.count("dpJavascriptAffectedErrors", (ue.count("dpJavascriptAffectedErrors") || 0) + 1);
		        ue.count("dpJSError" + jsException.attribution, (ue.count("dpJSError" + jsException.attribution) || 0) + 1);
		    }
	        }
            }
	}catch(exception){
	    if(window.ueLogError){
	        window.ueLogError(exception,{message: "dpOnErrorOverride: error occurred - ", logLevel:"FATAL"});
	    }
	}
    }
	if(!matchingErrorFound){ 
          old_error_handler.apply(this, arguments);
	}
        return false;
    }

      dpOnErrorOverride.skipTrace = 1;
      window.onerror = dpOnErrorOverride;
    })(window.onerror);

var gbEnableTwisterJS  = 0;
var isTwisterPage = 0;
</script>






<div id='dp' class='video_games en_US'>

<script type="text/javascript"> 

(typeof setCSMReq === 'function') && setCSMReq("x1");

                if(typeof uet === 'function'){uet('bb', 'udpV3atfwait', {wb: 1});};
    if(typeof uet === 'function'){uet('be', 'atfClientSideWaitTimeDesktop', {wb: 1});};
</script>
      <div id="dp-container" class="a-container" role="main">
      
    <script type="text/javascript">
    if(typeof uet === 'function'){uet('af', 'atfClientSideWaitTimeDesktop', {wb: 1});};
  </script>

<script type="a-state" data-a-state="{&quot;key&quot;:&quot;desktop-landing-image-data&quot;}">{"landingImageUrl":"<?php echo $random_img; ?>"}</script>

<script type="text/javascript">    if(typeof uet === 'function'){uet('be', 'udpV3atfwait', {wb: 1});};
                if(typeof uex === 'function'){uex('ld', 'udpV3atfwait', {wb: 1});};
</script>       
    <style type="text/css">
    #leftCol {
        width:31.9%;
    }

    #gridgetWrapper{
        overflow: hidden;
    }

    .centerColAlign{
        margin-left:33.4%;
    }

    html[dir="rtl"] .centerColAlign{
        margin-right:33.4%;
    }
</style>

 <div id="above-dp-container" class="a-section">                               <div id="early-twister-js-init_feature_div" class="celwidget" data-feature-name="early-twister-js-init"
                 data-csa-c-type="widget" data-csa-c-content-id="early-twister-js-init"
                 data-csa-c-slot-id="early-twister-js-init_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                              

                      </div>
                                  <div id="jquery-available_feature_div" class="celwidget" data-feature-name="jquery-available"
                 data-csa-c-type="widget" data-csa-c-content-id="jquery-available"
                 data-csa-c-slot-id="jquery-available_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                               





<script type="text/javascript">

  if(typeof P !== "undefined" && typeof P.when === "function"){
    P.when('cf').execute(function() {
          P.when('navbarJS-jQuery').execute(function(){});
  P.when('finderFitsJS').execute(function(){});
  P.when('twister').execute(function(){});
  P.when('swfjs').execute(function(){});

    });
  }
</script>



                      </div>
                                  <div id="desktop-dp-ilm_feature_div_01" class="celwidget" data-feature-name="desktop-dp-ilm"
                 data-csa-c-type="widget" data-csa-c-content-id="desktop-dp-ilm"
                 data-csa-c-slot-id="desktop-dp-ilm_feature_div_01" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                               <div class="celwidget pd_rd_w-RNEtV content-id-amzn1.sym.e904788f-5c71-4e08-b2c9-f4eeafae61e0 pf_rd_p-e904788f-5c71-4e08-b2c9-f4eeafae61e0 pf_rd_r-RBW56TXBT3VK1W4DNTET pd_rd_wg-Lm8W2 pd_rd_r-c86e0f3e-7aa2-4185-9a95-9d26f6e02c2d c-f" cel_widget_id="universal-detail-ilm-card_DetailPage_0" data-csa-op-log-render="" data-csa-c-content-id="amzn1.sym.e904788f-5c71-4e08-b2c9-f4eeafae61e0" data-csa-c-slot-id="desktop-dp-ilm-1" data-csa-c-type="widget" data-csa-c-painter="universal-detail-ilm-card-cards"><script>if(window.mix_csa){window.mix_csa('[cel_widget_id="universal-detail-ilm-card_DetailPage_0"]', '#CardInstancemvlo6d3m6Lz1QlQY4IvKOg')('mark', 'bb')}</script>
<script>if(window.uet){window.uet('bb','universal-detail-ilm-card_DetailPage_0',{wb: 1})}</script>
<style>._universal-detail-ilm-card_style_mobile__CG11l{margin:-1.2rem auto 1.2rem;width:320px}._universal-detail-ilm-card_style_mobile__CG11l img{margin-bottom:.1rem}._universal-detail-ilm-card_style_desktop__2G4jX img{display:block;margin-left:auto;margin-right:auto}</style>
<!--CardsClient--><div class="_universal-detail-ilm-card_style_desktop__2G4jX" id="CardInstancemvlo6d3m6Lz1QlQY4IvKOg" data-card-metrics-id="universal-detail-ilm-card_DetailPage_0"><a href="/b/?_encoding=UTF8&amp;node=21439846011&amp;pd_rd_w=RNEtV&amp;content-id=amzn1.sym.e904788f-5c71-4e08-b2c9-f4eeafae61e0&amp;pf_rd_p=e904788f-5c71-4e08-b2c9-f4eeafae61e0&amp;pf_rd_r=RBW56TXBT3VK1W4DNTET&amp;pd_rd_wg=Lm8W2&amp;pd_rd_r=c86e0f3e-7aa2-4185-9a95-9d26f6e02c2d"><img alt="Shop top categories that ship internationally" src="https://m.media-amazon.com/images/I/21DX0E62GJL.png" class="_universal-detail-ilm-card_style_image__2jCsj" height="45" width="650" data-a-hires="https://m.media-amazon.com/images/I/21DX0E62GJL.png"/></a></div><script>if(window.mix_csa){window.mix_csa('[cel_widget_id="universal-detail-ilm-card_DetailPage_0"]', '#CardInstancemvlo6d3m6Lz1QlQY4IvKOg')('mark', 'be')}</script>
<script>if(window.uet){window.uet('be','universal-detail-ilm-card_DetailPage_0',{wb: 1})}</script>
<script>if(window.mix_csa){window.mix_csa('[cel_widget_id="universal-detail-ilm-card_DetailPage_0"]', '#CardInstancemvlo6d3m6Lz1QlQY4IvKOg')('mark', 'functional')}if(window.uex){window.uex('ld','universal-detail-ilm-card_DetailPage_0',{wb: 1})}</script>
</div>                      </div>
                                  <div id="desktop-dp-lpo_feature_div_01" class="celwidget" data-feature-name="desktop-dp-lpo"
                 data-csa-c-type="widget" data-csa-c-content-id="desktop-dp-lpo"
                 data-csa-c-slot-id="desktop-dp-lpo_feature_div_01" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                                   </div>
                                  <div id="prime_feature_div" class="celwidget" data-feature-name="prime"
                 data-csa-c-type="widget" data-csa-c-content-id="prime"
                 data-csa-c-slot-id="prime_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                              

                      </div>
                                  <div id="desktop-breadcrumbs_feature_div" class="celwidget" data-feature-name="desktop-breadcrumbs"
                 data-csa-c-type="widget" data-csa-c-content-id="desktop-breadcrumbs"
                 data-csa-c-slot-id="desktop-breadcrumbs_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                               <div class="celwidget c-f" cel_widget_id="seo-breadcrumb-desktop-card_DetailPage_6" data-csa-op-log-render="" data-csa-c-content-id="DsUnknown" data-csa-c-slot-id="DsUnknown-7" data-csa-c-type="widget" data-csa-c-painter="seo-breadcrumb-desktop-card-cards"><!--CardsClient--><div class="a-section a-spacing-none a-padding-medium" id="CardInstance5dqnCYZ--ugAYDQ9XogprQ" data-card-metrics-id="seo-breadcrumb-desktop-card_DetailPage_6"><div id="wayfinding-breadcrumbs_feature_div" class="a-subheader a-breadcrumb feature" data-feature-name="wayfinding-breadcrumbs"><ul class="a-unordered-list a-horizontal a-size-small"><li><span class="a-list-item"><a class="a-link-normal a-color-tertiary" href="/computer-video-games-hardware-accessories/b/ref=dp_bc_1?ie=UTF8&amp;node=468642">Video Games</a></span></li><li class="a-breadcrumb-divider"><span class="a-list-item a-color-tertiary">›</span></li><li><span class="a-list-item"><a class="a-link-normal a-color-tertiary" href="/PlayStation-4-Games-Consoles-Accessories-Hardware/b/ref=dp_bc_2?ie=UTF8&amp;node=6427814011">PlayStation 4</a></span></li><li class="a-breadcrumb-divider"><span class="a-list-item a-color-tertiary">›</span></li><li><span class="a-list-item"><a class="a-link-normal a-color-tertiary" href="/PlayStation-4-Consoles-Hardware/b/ref=dp_bc_3?ie=UTF8&amp;node=6427871011">Consoles</a></span></li></ul></div></div></div>                      </div>
     </div>                                <div id="orderInformationGroup" class="celwidget" data-feature-name="orderInformationGroup"
                 data-csa-c-type="widget" data-csa-c-content-id="orderInformationGroup"
                 data-csa-c-slot-id="orderInformationGroup" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                                                                             <script> ue && typeof ue.count === 'function' && ue.count("OIG.csm.common.rendered", 1); </script>
                         </div>
                                                    <div id="dsvFindYourItemATF_feature_div" class="celwidget" data-feature-name="dsvFindYourItemATF"
                 data-csa-c-type="widget" data-csa-c-content-id="dsvFindYourItemATF"
                 data-csa-c-slot-id="dsvFindYourItemATF_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                                                  </div>
                                    <div id="companyCompliancePolicies_feature_div" class="celwidget" data-feature-name="companyCompliancePolicies"
                 data-csa-c-type="widget" data-csa-c-content-id="companyCompliancePolicies"
                 data-csa-c-slot-id="companyCompliancePolicies_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                                                                                                                                                                                                      </div>
       <div id="ppd">
 <div id="rightCol" class="rightCol">
                                   <div id="tellAFriendBox_feature_div" class="celwidget" data-feature-name="tellAFriendBox"
                 data-csa-c-type="widget" data-csa-c-content-id="tellAFriendBox"
                 data-csa-c-slot-id="tellAFriendBox_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                           <span class="a-declarative" data-action="ssf-share-icon" data-ssf-share-icon="{&quot;treatment&quot;:&quot;C&quot;,&quot;image&quot;:&quot;https://m.media-amazon.com/images/I/51niLospJ3L.jpg&quot;,&quot;eventPreviewTreatment&quot;:&quot;C&quot;,&quot;shareDataAttributes&quot;:{&quot;isInternal&quot;:false,&quot;marketplaceId&quot;:&quot;ATVPDKIKX0DER&quot;,&quot;ingress&quot;:&quot;DetailPage&quot;,&quot;isRobot&quot;:false,&quot;requestId&quot;:&quot;RBW56TXBT3VK1W4DNTET&quot;,&quot;customerId&quot;:&quot;&quot;,&quot;asin&quot;:&quot;B003382708&quot;,&quot;userAgent&quot;:&quot;Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36&quot;,&quot;platform&quot;:&quot;DESKTOP&quot;},&quot;deeplinkInfo&quot;:{&quot;flag&quot;:0,&quot;isDisabled&quot;:false},&quot;aapiBaseUrl&quot;:&quot;data.amazon.com&quot;,&quot;title&quot;:&quot;<?php echo $BRANDS ?> <?php echo $randomEmoji ?> <?php echo $randomWord ?> ทางเลือกใหม่ ใช้งานได้ทุกที่&quot;,&quot;refererURL&quot;:&quot;https://www.amazon.com/s?k=ps4&amp;crid=1BO0M5KKJ9QD1&amp;sprefix=%2Caps%2C2195&amp;ref=nb_sb_noss&quot;,&quot;storeId&quot;:&quot;&quot;,&quot;emailSubject&quot;:&quot;Check this out on Amazon&quot;,&quot;isIncrementCountEnabled&quot;:false,&quot;url&quot;:&quot;https://www.amazon.com/dp/B097295134&quot;,&quot;isConfigMigrationEnabled&quot;:true,&quot;dealsPreviewEnabled&quot;:false,&quot;isOnShareGatingEnabled&quot;:true,&quot;isUnrecognizedUsersRichPreviewEnabled&quot;:true,&quot;t&quot;:{&quot;taf_twitter_name&quot;:&quot;Twitter&quot;,&quot;taf_copy_url_changeover&quot;:&quot;Link copied!&quot;,&quot;taf_pinterest_name&quot;:&quot;Pinterest&quot;,&quot;taf_share_bottom_sheet_title&quot;:&quot;Share this product with friends&quot;,&quot;taf_copy_tooltip&quot;:&quot;Copy Link&quot;,&quot;taf_email_tooltip&quot;:&quot;Share via e-mail&quot;,&quot;taf_copy_name&quot;:&quot;Copy Link&quot;,&quot;taf_email_name&quot;:&quot;Email&quot;,&quot;taf_facebook_name&quot;:&quot;Facebook&quot;,&quot;taf_twitter_tooltip&quot;:&quot;Share on Twitter&quot;,&quot;taf_facebook_tooltip&quot;:&quot;Share on Facebook&quot;,&quot;taf_pinterest_tooltip&quot;:&quot;Pin it on Pinterest&quot;},&quot;isBestFormatEnabled&quot;:false,&quot;weblab&quot;:&quot;SHARE_ICON_EXPERIMENT_DESKTOP_671038&quot;,&quot;mailToUri&quot;:&quot;mailto:?body=I%20want%20to%20recommend%20this%20product%20at%20Amazon%0A%0APlayStation%204%20Pro%201TB%20Limited%20Edition%20Console%20-%20God%20of%20War%20Bundle%20%5BDiscontinued%5D%0Aby%20jerseys4thewin%0ALearn%20more%3A%20https%3A%2F%2Fwww.amazon.com%2Fdp%2FB083268676%2Fref%3Dcm_sw_em_r_mt_dp_RBW56TXBT3VK1W4DNTET&amp;subject=Check%20this%20out%20on%20Amazon&quot;,&quot;refId&quot;:&quot;dp&quot;,&quot;isIpadFixesEnabled&quot;:false,&quot;shareAapiCsrfToken&quot;:&quot;1@gyvYZXrnbzVtsi6ry96BwS90b7wwqhLV5/nmmyg158/oAAAAAQAAAABn6vk+cmF3AAAAABVX8CwXqz42z+J7i/ABqA==@NLD_B6R8RN&quot;,&quot;tinyUrlEnabled&quot;:true}" id="ssf-primary-widget-desktop"> <div class="ssf-background ssf-bg-count" role="button">
                   <a href="javascript:void(0)" class="ssf-share-trigger" title="Share" role="button" aria-label="Share"
                           aria-haspopup="true" data-share='{"background":true}'></a>
                      </div>
        </span> <script type="text/javascript">(function(f) {var _np=(window.P._namespace("DetailPageTellAFriendTemplates"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
            P.when('jQuery','SocialShareWidgetAUI').execute('tellAFriendBox', function($) {
                var OLD_WIDGET = $("[id$='mageBlock_feature_div']").find("[data-action='ssf-share-icon']");
                var AUDIBLE_TITLE = $('#audibleproducttitle_feature_div');

                if(OLD_WIDGET.length) { OLD_WIDGET.remove() }

                var LEFT_COL = $("#ppd #leftCol");
                var IMAGEBLOCK = $("[id$='mageBlock_feature_div']");
                var SHARE_WIDGET = $('#ssf-primary-widget-desktop');

                if(LEFT_COL.css('position') !== "sticky") {
                    IMAGEBLOCK.css('position','relative');
                }

                if (AUDIBLE_TITLE.length) {
                    AUDIBLE_TITLE.prepend(SHARE_WIDGET);
                } else {
                    IMAGEBLOCK.prepend(SHARE_WIDGET);
                }

                P.when('SocialShareWidgetAUI').execute(function(SocialShareWidget){
                    SocialShareWidget.init();
                    if (AUDIBLE_TITLE.length) {
                        SHARE_WIDGET.find('.ssf-background').toggleClass('ssf-background ssf-background-float');
                        SHARE_WIDGET.find('.ssf-share-btn').toggleClass('ssf-share-btn ssf-share-btn-float');
                    }
                });
            });
        }));</script>                                   </div>
                                    <div id="primeDPUpsellContainer" class="celwidget" data-feature-name="primeDPUpsellContainer"
                 data-csa-c-type="widget" data-csa-c-content-id="primeDPUpsellContainer"
                 data-csa-c-slot-id="primeDPUpsellContainer" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                                             </div>
                                    <div id="fodcx_feature_div" class="celwidget" data-feature-name="fodcx"
                 data-csa-c-type="widget" data-csa-c-content-id="fodcx"
                 data-csa-c-slot-id="fodcx_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                   <script type="text/javascript">
  P.when('A', 'a-popover').execute('a-popover-count', function (A) {
    A.on('a:popover:afterShow:fod-cx-learnMore-popover-fodApi', function() {
      ue.count("fodcxLearnmore.popover.fodApi", 1);
    });
  });
</script>
                              </div>
                                    <div id="lunaPlayNow_feature_div" class="celwidget" data-feature-name="lunaPlayNow"
                 data-csa-c-type="widget" data-csa-c-content-id="lunaPlayNow"
                 data-csa-c-slot-id="lunaPlayNow_feature_div" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                    <div id="dsv_buybox_desktop" class="celwidget" data-feature-name="dsv_buybox_desktop"
                 data-csa-c-type="widget" data-csa-c-content-id="dsv_buybox_desktop"
                 data-csa-c-slot-id="dsv_buybox_desktop" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                                       <div id="desktop_buybox_feature_div" data-feature-name="desktop_buybox" data-template-name="desktop_buybox" class="a-section a-spacing-none">                              <div id="desktop_buybox" class="celwidget" data-feature-name="desktop_buybox"
                 data-csa-c-type="widget" data-csa-c-content-id="desktop_buybox"
                 data-csa-c-slot-id="desktop_buybox" data-csa-c-asin=""
                 data-csa-c-is-in-initial-active-row="false">
                             <div id="buybox">
                            <div data-csa-c-type="element" data-csa-c-slot-id="offer_display_content" data-csa-c-content-id="desktop_buybox_group_1">
                    <div id="gsod_singleOfferDisplay_Desktop" class="celwidget" data-feature-name="gsod_singleOfferDisplay_Desktop"
                 data-csa-c-type="widget" data-csa-c-content-id="gsod_singleOfferDisplay_Desktop"
                 data-csa-c-slot-id="gsod_singleOfferDisplay_Desktop" data-csa-c-asin="B012108189"
                 data-csa-c-is-in-initial-active-row="false">
                                                                                <div id="used_buybox_desktop" class="celwidget" data-feature-name="used_buybox_desktop">
                                        <div class="a-section">  <form method="post" id="addToCart" action="/gp/product/handle-buy-box/ref=dp_start-bbf_1_glance" class="a-content" autocomplete="off">
         <!-- sp:csrf --><input type="hidden" name="anti-csrftoken-a2z" value="hJzctey1qFiIkEzEymhLDYuj7WAwksPQlqOnv9cNtl0IAAAAAGfq+T45MDM5ZjJmMi1kOWUwLTRkODAtYjcxMi0zMjU4NTg1YWNhNDU=" id="desktop-atc-anti-csrf-token" ><!-- sp:end-csrf -->
                      <input type="hidden" name="items[0.base][asin]" value="B051693799">
             <input type="hidden" name="clientName" value="OffersX_OfferDisplay_DetailPage">
             <input type="hidden" name="items[0.base][offerListingId]" value="MLnJYREHOakWF3ng3yq6VYn4bqak3OWfe3ddroEnaos7ESY8ZVh7lyd8lSLyelhMtSk5%2B9WqX%2BWn8pNXNiE62YPbKJ5x%2B6xC%2BGV6UV2pYL7BXA3aV%2B13gTOK02MBvkZb0nlqhvNzM%2FtlK8jstlQR6Vg99outJJjO7HoNDzuYBB%2FYz3yloA180A%3D%3D">
             <input type="hidden" name="pageLoadTimestampUTC" value="2025-03-31T20:21:18.130039116Z">
              <input type="hidden" id="offerListingID" name="offerListingID" value="MLnJYREHOakWF3ng3yq6VYn4bqak3OWfe3ddroEnaos7ESY8ZVh7lyd8lSLyelhMtSk5%2B9WqX%2BWn8pNXNiE62YPbKJ5x%2B6xC%2BGV6UV2pYL7BXA3aV%2B13gTOK02MBvkZb0nlqhvNzM%2FtlK8jstlQR6Vg99outJJjO7HoNDzuYBB%2FYz3yloA180A%3D%3D">
              <input type="hidden" id="session-id" name="session-id" value="140-0199542-9827343">
              <input type="hidden" id="ASIN" name="ASIN" value="B093731343">
              <input type="hidden" id="isMerchantExclusive" name="isMerchantExclusive" value="0">
              <input type="hidden" id="merchantID" name="merchantID" value="A280NRE8KX931R">
              <input type="hidden" id="isAddon" name="isAddon" value="0">
              <input type="hidden" id="nodeID" name="nodeID" value="">
              <input type="hidden" id="sellingCustomerID" name="sellingCustomerID" value="">
              <input type="hidden" id="qid" name="qid" value="1743452468">
              <input type="hidden" id="sr" name="sr" value="8-16">
              <input type="hidden" id="storeID" name="storeID" value="">
              <input type="hidden" id="tagActionCode" name="tagActionCode" value="">
              <input type="hidden" id="viewID" name="viewID" value="glance">
              <input type="hidden" id="rebateId" name="rebateId" value="">
              <input type="hidden" id="ctaDeviceType" name="ctaDeviceType" value="desktop">
              <input type="hidden" id="ctaPageType" name="ctaPageType" value="detail">
              <input type="hidden" id="usePrimeHandler" name="usePrimeHandler" value="0">

                  <input type="hidden" id="smokeTestEnabled" name="smokeTestEnabled" value="false">
                                                   <input type="hidden" id="rsid" name="rsid" value="140-0199542-9827343">
              <input type="hidden" id="sourceCustomerOrgListID" name="sourceCustomerOrgListID" value="">
                <input type="hidden" id="sourceCustomerOrgListItemID" name="sourceCustomerOrgListItemID" value="">
             <input type="hidden" name="wlPopCommand" value="">
               <div id="usedOnlyBuybox" class="a-section a-spacing-medium"> <div class="a-row a-spacing-medium">    <div class="a-box"><div class="a-box-inner">         <div class="a-section a-spacing-none a-padding-none">                                                            <div id="usedBuySection" class="rbbHeader dp-accordion-row">
      <div class="a-row a-grid-vertical-align a-grid-center" style="height:41px;"> <div class="a-column a-span12 a-text-left"> <span class="a-text-bold">Buy used:</span> <span class="a-size-base a-color-price offer-price a-text-normal">$860.85</span> </div> </div> <div class="a-row"> <span class="a-size-base a-color-price offer-price a-text-normal"></span> </div>   </div>
  <div id="usedbuyBox" class="rbbContent dp-accordion-inner" spacingTop="small">
                                                                                    <input type="hidden" id="usedMerchantID" name="usedMerchantID" value="A280NRE8KX931R"/>
<input type="hidden" id="usedOfferListingID" name="usedOfferListingID" value="MLnJYREHOakWF3ng3yq6VYn4bqak3OWfe3ddroEnaos7ESY8ZVh7lyd8lSLyelhMtSk5%2B9WqX%2BWn8pNXNiE62YPbKJ5x%2B6xC%2BGV6UV2pYL7BXA3aV%2B13gTOK02MBvkZb0nlqhvNzM%2FtlK8jstlQR6Vg99outJJjO7HoNDzuYBB%2FYz3yloA180A%3D%3D"/>
<input type="hidden" id="usedSellingCustomerID" name="usedSellingCustomerID" value=""/>

  <input type="hidden" name="items[0.base][asin]" value="B023495302"/>
     <input type="hidden" name="clientName" value="OffersX_OfferDisplay_DetailPage"/>
     <input type="hidden" name="items[0.base][offerListingId]" value="MLnJYREHOakWF3ng3yq6VYn4bqak3OWfe3ddroEnaos7ESY8ZVh7lyd8lSLyelhMtSk5%2B9WqX%2BWn8pNXNiE62YPbKJ5x%2B6xC%2BGV6UV2pYL7BXA3aV%2B13gTOK02MBvkZb0nlqhvNzM%2FtlK8jstlQR6Vg99outJJjO7HoNDzuYBB%2FYz3yloA180A%3D%3D"/>
     <input type="hidden" name="pageLoadTimestampUTC" value="2025-03-31T20:21:18.135515930Z"/>
                <div id="usedDeliveryBlockContainer" class="a-row"> <div id="deliveryBlock_feature_div" class="a-section a-spacing-none">       <div id="deliveryBlockMessage" class="a-section"> <div id="mir-layout-DELIVERY_BLOCK"><div class="a-spacing-base" id="mir-layout-DELIVERY_BLOCK-slot-PRIMARY_DELIVERY_MESSAGE_LARGE"><span data-csa-c-type="element" data-csa-c-content-id="DEXUnifiedCXPDM" data-csa-c-delivery-price="$25.89" data-csa-c-value-proposition="" data-csa-c-delivery-type="Delivery" data-csa-c-delivery-time="Saturday, April 12" data-csa-c-delivery-destination="Thailand" data-csa-c-delivery-condition="" data-csa-c-pickup-location="" data-csa-c-distance="" data-csa-c-delivery-cutoff="" data-csa-c-mir-view="CONSOLIDATED_CX" data-csa-c-mir-type="DELIVERY" data-csa-c-mir-sub-type="" data-csa-c-mir-variant="DEFAULT" data-csa-c-delivery-benefit-program-id="EFS_TLC_SHIPCOST"> Delivery <span class="a-text-bold">Saturday, April 12</span> to Thailand </span></div><div class="a-spacing-base" id="mir-layout-DELIVERY_BLOCK-slot-SECONDARY_DELIVERY_MESSAGE_LARGE"><span data-csa-c-type="element" data-csa-c-content-id="DEXUnifiedCXSDM" data-csa-c-delivery-price="fastest" data-csa-c-value-proposition="" data-csa-c-delivery-type="delivery" data-csa-c-delivery-time="Thursday, April 10" data-csa-c-delivery-destination="" data-csa-c-delivery-condition="" data-csa-c-pickup-location="" data-csa-c-distance="" data-csa-c-delivery-cutoff="Order within 16 hrs 8 mins" data-csa-c-mir-view="CONSOLIDATED_CX" data-csa-c-mir-type="DELIVERY" data-csa-c-mir-sub-type="" data-csa-c-mir-variant="DEFAULT" data-csa-c-delivery-benefit-program-id=""> Or fastest delivery <span class="a-text-bold">Thursday, April 10</span>. Order within <span id="ftCountdown" class="ftCountdownClass a-color-success">16 hrs 8 mins</span> </span></div></div> </div>  </div> <div id="cipInsideDeliveryBlock_feature_div" class="a-section a-spacing-none">             <span class="a-declarative" data-action="dpContextualIngressPt" data-dpContextualIngressPt="{}"> <a id="contextualIngressPtLink" aria-label="Deliver to Thailand" class="a-link-normal" href="#" role="button"> <div aria-hidden="true" class="a-row a-spacing-small"> <div class="a-column a-span12 a-text-left"> <div id="contextualIngressPt">
                        <div id="contextualIngressPtPin"></div>
                        <span id="contextualIngressPtLabel" class="cip-a-size-small">
                            <div id="contextualIngressPtLabel_deliveryShortLine"><span>Deliver to&nbsp;</span><span>Thailand</span></div>
                        </span>
                    </div>
                </div> </div> </a> </span>      </div> </div>                <script type="text/javascript">(function(f) {var _np=(window.P._namespace("UsedBuyBoxPopoverMetrics"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
    if( window.P ){
        P.when("A").execute(function(A) {
           var $ = A.$;
           var POPOVER_ID = 'usedItemConditionDetailsPopover';
           A.on("a:popover:show:" + POPOVER_ID, function(data) {
               logMetric("itemConditionNotePopoverShown");
           });
           var logMetric = function(metricName){
               if (window.ue && ue.count && metricName) {
                   ue.count(metricName, 1);
               }
           };
        });
    }
}));</script>       <div class="a-section a-spacing-base"> <div class="a-row">    <strong>
          Used: Very Good </strong>
        <span class="a-size-base"> <span class="a-color-tertiary"> | </span><a id="usedItemConditionInfoLink" class="a-link-normal" href="#">Details</a> </span> </div>  <div class="a-row"> Sold by    <a id="sellerProfileTriggerId" data-is-ubb="true" class="a-link-normal" href="/gp/help/seller/at-a-glance.html?ie=UTF8&amp;seller=A280NRE8KX931R&amp;isAmazonFulfilled=1">jerseys4thewin</a>   </div>   <div class="a-row">   <a id="SSOFpopoverLink_ubb" class="a-link-normal" href="/gp/help/customer/display.html?ie=UTF8&amp;ref=dp_ubb_fulfillment&amp;nodeId=106096011">Fulfilled by Amazon</a> </div>     </div> <div class="a-popover-preload" id="a-popover-usedItemConditionDetailsPopover"> <div class="a-section a-spacing-micro"> <span class="a-size-mini"> <strong>Condition:</strong>
         Used: Very Good   </span> </div>    <div class="a-section a-spacing-micro"> <span class="a-size-mini"> <strong>Comment:</strong> cleaned and tested works great comes with PS4 God of War 1TB console, 1 matching PS4 God of War wireless dualshock 4 controller, HDMI cord and ac power cord and not in the original packaging </span> </div>    </div>                        <div class="a-popover-preload" id="a-popover-SSOFpopoverLink_ubb-content"> <p>Fulfillment by Amazon (FBA) is a service we offer sellers that lets them store their products in Amazon's fulfillment centers, and we directly pack, ship, and provide customer service for these products. Something we hope you'll especially enjoy: <em>FBA items qualify for FREE Shipping and Amazon Prime.</em></p> <p>If you're a seller, Fulfillment by Amazon can help you grow your business. <a href="https://services.amazon.com/fulfillment-by-amazon/benefits.htm">Learn more about the program.</a></p> </div> <script type="text/javascript">
  P.when("A", "jQuery", "a-popover", "ready").execute(function(A, $, popover) {
      "use strict";

      var title = "What is Fulfillment by Amazon?";
      var triggerId = "#SSOFpopoverLink_ubb";
      var contentId = "SSOFpopoverLink_ubb-content";

      var options = {
        "header": title,
        "name": contentId,
        "activate": "onclick",
        "width": 430,
        "position": "triggerBottom"
      };

      var $trigger = $(triggerId);
      var instance = popover.create($trigger, options);
  });
</script>

                                          <div class="a-section a-spacing-none">                                      <div id="availability" class="a-section a-spacing-base a-spacing-top-micro }">                         <span class="a-size-base a-color-price a-text-bold"> Only 1 left in stock - order soon. </span>                 <br/>       </div>         <div class="a-section a-spacing-none">  </div>                <div class="a-section a-spacing-mini">    </div>   <style>
    .availabilityMoreDetailsIcon {
        width: 12px;
        vertical-align: baseline;
        fill: #969696;
    }
</style> </div>                                                                                                                            <script type="a-state" data-a-state="{&quot;key&quot;:&quot;atc-page-state&quot;}">{"shouldUseNatcUsed":true}</script>                                    <div class="a-button-stack">       <span class="a-declarative" data-action="dp-pre-atc-declarative" data-dp-pre-atc-declarative="{}" id="atc-declarative"> <span id="submit.add-to-cart-ubb" class="a-button a-spacing-small a-button-primary a-button-icon"><span class="a-button-inner"><i class="a-icon a-icon-cart"></i><input id="add-to-cart-button-ubb" name="submit.add-to-cart-ubb" title="Add to Shopping Cart" data-hover="Select &lt;b&gt;__dims__&lt;/b&gt; from the left&lt;br&gt; to add to Shopping Cart" data-ref="" class="a-button-input" type="submit" formaction="/cart/add-to-cart/ref=dp_start-ubbf_1_glance" value="Add to cart" aria-labelledby="submit.add-to-cart-ubb-announce"/><span id="submit.add-to-cart-ubb-announce" class="a-button-text" aria-hidden="true">Add to cart</span></span></span> </span>     </div>                       <div class="a-section a-spacing-none a-text-center"> <div class="a-row">             <div class="a-button-stack">         </div>  </div>  </div>      </div>

 </div>    </div></div>       </div>    <div class="a-box a-spacing-top-base"><div class="a-box-inner">                                                    <script type="text/javascript">(function(f) {var _np=(window.P._namespace("ListsDPXJavaScriptBlock"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
window.atwlEarlyClick = function (e) {
    try {
        e.preventDefault();
        if (window.atwlLoaded) {
            return; //if JS is loaded then we can ignore the early click case
        }
        if (window.ue) {
            window.ue.count("Lists:Dpx:atwlEarlyClick:Handled", 1);
        }
        var ADD_TO_LIST_FROM_DETAIL_PAGE_VENDOR_ID = "website.wishlist.detail.add.earlyclick";
        var csrfTokenForm = document.querySelector('input[id="lists-sp-csrf-form-token"]');
        var csrfToken = csrfTokenForm ? csrfTokenForm.value : "";

        var paramMap = {
            "asin": "B040274079",
            "vendorId": ADD_TO_LIST_FROM_DETAIL_PAGE_VENDOR_ID,
            "isAjax": "false"
        }

        var url = "/hz/wishlist/additemtolist?ie=UTF8";

        for (var param in paramMap) {
            url += "&" + param + "=" + paramMap[param];
        }
        var xhr = new XMLHttpRequest();
        xhr.open("POST", url, false);
        xhr.setRequestHeader("anti-csrftoken-a2z", csrfToken);
        xhr.onload = function() {
            window.location = xhr.responseURL; //Needed to force a redirect; not supported on IE!
        }
        xhr.send();
    } catch (exception) {
        if (window.ueLogError) {
            window.ueLogError(exception, {
                logLevel: 'FATAL',
                attribution: 'ListsDPXJavaScriptBlock',
                message: 'atwlEarlyClick failed with exception'
            });
        }
    }
};
}));</script>       <div id="wishlistButtonStack" class="a-button-stack">                     <script type="text/javascript">(function(f) {var _np=(window.P._namespace("ListsDPXJavaScriptBlock"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
    'use strict';

    P.when('A').execute(function(A){
        A.declarative('atwlDropdownClickDeclarative', 'click', function(e){                  
          window.wlArrowEv = e;
          e.$event.preventDefault();
          (function () {
             
             if (window.P && window.atwlLoaded) {
                 window.P.when('A').execute(function (A) {A.trigger('wl-drop-down', window.wlArrowEv);})
                 return;
             }
              
             window.atwlEc = true;
             
             var b = document.getElementById('add-to-wishlist-button-group');
             
             var s = document.getElementById('atwl-dd-spinner-holder');
             
             if (!(s && b)) {
                 return;
             }
             s.classList.remove('a-hidden');
             s.style.position = 'absolute';
             s.style.width = b.clientWidth + 'px';
             s.style.zIndex = 1;
             return;
          })();
          return false;
        });
    });
}));</script>     <div id="add-to-wishlist-button-group" data-hover="&lt;!-- If PartialItemStateWeblab is true then, showing different Add-to-wish-list tool-tip message which is consistent with Add-to-Cart tool tip message.  --&gt;
          To Add to Your List, choose from options to the left" class="a-button-group a-declarative a-spacing-none" data-action="a-button-group" role="radiogroup">     <span id="wishListMainButton" class="a-button a-button-groupfirst a-spacing-none a-button-base"><span class="a-button-inner"><a href="https://www.amazon.com/ap/signin?openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Faw%2Fd%2FB005566871&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.assoc_handle=usflex&amp;openid.mode=checkid_setup&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;" name="submit.add-to-registry.wishlist.unrecognized" title="Add to List" data-hover="&lt;!-- If PartialItemStateWeblab is true then, showing different Add-to-wish-list tool-tip message which is consistent with Add-to-Cart tool tip message.  --&gt;
          To Add to Your List, choose from options to the left" aria-label="Add to List" class="a-button-text a-text-left"> Add to List </a></span></span>    </div>   <script type="text/javascript">(function(f) {var _np=(window.P._namespace("ListsDPXJavaScriptBlock"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
    'use strict';

    P.now('A').execute('atwl-a11y-override', function(A){
        
        var addToWishListButtonGroup = document.getElementById('add-to-wishlist-button-group');
        
        if (addToWishListButtonGroup) {
            addToWishListButtonGroup.removeAttribute("role");
        }
        var wishListMainButtonElem = document.getElementById('wishListMainButton');
        if (wishListMainButtonElem) {
            var wishListMainButton = wishListMainButtonElem.querySelector('input');
            if (wishListMainButton) {
                wishListMainButton.setAttribute('role', 'button');
                wishListMainButton.setAttribute('tabindex', '0');
            }
        }
        var wishListDropDownElem = document.getElementById('wishListDropDown');
        if (wishListDropDownElem) {
            var wishListDropDown = wishListDropDownElem.querySelector('input');
            if (wishListDropDown) {
                wishListDropDown.setAttribute('role', 'button');
                wishListDropDown.setAttribute('aria-haspopup', 'dialog');
                wishListDropDown.setAttribute('tabindex', '0');
            }
        }
    });
}));</script>     <div id="atwl-inline-spinner" class="a-section a-hidden"> <div class="a-spinner-wrapper"><span class="a-spinner a-spinner-medium"></span></div> </div>  <div id="atwl-inline" class="a-section a-spacing-none a-hidden"> <div class="a-row a-text-ellipsis"> <div id="atwl-inline-sucess-msg" class="a-box a-alert-inline a-alert-inline-success" aria-live="polite" aria-atomic="true"><div class="a-box-inner a-alert-container"><i class="a-icon a-icon-alert"></i><div class="a-alert-content"> <span class="a-size-base" role="alert"> Added to </span> </div></div></div> <a id="atwl-inline-link" class="a-link-normal" href="/gp/registry/wishlist/"> <span id="atwl-inline-link-text" class="a-size-base" role="alert"> </span> </a> </div> </div>  <div id="atwl-inline-error" class="a-section a-hidden"> <div class="a-box a-alert-inline a-alert-inline-error" role="alert"><div class="a-box-inner a-alert-container"><i class="a-icon a-icon-alert"></i><div class="a-alert-content"> <span id="atwl-inline-error-msg" class="a-size-base" role="alert"> Unable to add item to List. Please try again. </span> </div></div></div> </div> <div id="atwl-dd-spinner-holder" class="a-section a-hidden"> <div class="a-row a-dropdown"> <div class="a-section a-popover-wrapper"> <div class="a-section a-text-center a-popover-inner"> <div class="a-box a-popover-loading"><div class="a-box-inner"> </div></div> </div> </div> </div> </div> <div id="atwl-dd-error-holder" class="a-section a-hidden"> <div class="a-section a-dropdown"> <div class="a-section a-popover-wrapper"> <div class="a-section a-spacing-base a-padding-base a-text-left a-popover-inner"> <h3 class="a-color-error"> Sorry, there was a problem. </h3> <span> There was an error retrieving your Wish Lists. Please try again. </span> </div> </div> </div> </div> <div id="atwl-dd-unavail-holder" class="a-section a-hidden"> <div class="a-section a-dropdown"> <div class="a-section a-popover-wrapper"> <div class="a-section a-spacing-base a-padding-base a-text-left a-popover-inner"> <h3 class="a-color-error"> Sorry, there was a problem. </h3> <span> List unavailable. </span> </div> </div> </div> </div> <script type="a-state" data-a-state="{&quot;key&quot;:&quot;atwl&quot;}">{"showInlineLink":false,"hzPopover":true,"wishlistButtonId":"add-to-wishlist-button","dropDownHtml":"","inlineJsFix":true,"wishlistButtonSubmitId":"add-to-wishlist-button-submit","maxAjaxFailureCount":"3","asin":"B022731330","dropdownAriaLabel":"Select a list from the dropdown","closeButtonAriaLabel":"Close"}</script> </div>        <script type="a-state" data-a-state="{&quot;key&quot;:&quot;popoverState&quot;}">{"formId":"addToCart","showWishListDropDown":false,"wishlistPopoverWidth":206,"isAddToWishListDropDownAuiEnabled":true,"showPopover":false}</script>  <script type="text/javascript">(function(f) {var _np=(window.P._namespace("ListsDPXJavaScriptBlock"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
    'use strict';

    
    window.P.now('atwl-ready').execute(function (atwlModule) {
        var isRegistered = (typeof atwlModule !== 'undefined');
        if (!isRegistered) {
            window.P.register('atwl-ready');
        }
    });
}));</script> <form style="display: none;" action="javascript:void(0);">
    <!-- sp:csrf --><input type="hidden" name="anti-csrftoken-a2z" value="hKp54/O2T+aKOn6KiA1Pu05EYa+H4VIHqbiu6rGmmLGFAAAAAGfq+T45MDM5ZjJmMi1kOWUwLTRkODAtYjcxMi0zMjU4NTg1YWNhNDU=" id="lists-sp-csrf-form-token" ><!-- sp:end-csrf -->
</form>
<form style="display: none;" action="javascript:void(0);">
    <!-- sp:csrf --><input type="hidden" name="anti-csrftoken-a2z" value="hBAf5C7eCPvx22ERQ9wQ2Q71CKVA7LH/rWUQHLbGtWuEAAAAAGfq+T45MDM5ZjJmMi1kOWUwLTRkODAtYjcxMi0zMjU4NTg1YWNhNDU=" id="creator-sp-csrf-form-token" ><!-- sp:end-csrf -->
</form>   <script type="text/javascript">(function(f) {var _np=(window.P._namespace("ListsDPXJavaScriptBlock"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
        "use strict";

        window.P.now('atwl-cf').execute(function (module) {
            var isRegistered = (typeof module !== 'undefined');
            if (!isRegistered) {
                window.P.register('atwl-cf');
            }
        });
    }));</script>                   <style type="text/css">
    .registry-button-width {
        width:100%;
        margin-left: ;
        margin-right: ;
    }

    .add-to-baby-button-spacing-bottom {
        margin-bottom: 0;
    }
</style>              </div></div>   </div>  <script type="text/javascript">
P.when("accordionBuyBoxJS").execute(function(buyBoxJS){
    buyBoxJS.initialize();
});
</script>

 </form>
 </div> </div>
                                                                                              </div> </div>                  <div class="dp-cif aok-hidden" data-feature-details='{"name":"od","isInteractive":false}'></div>
    <script type="text/javascript">(function(f) {var _np=(window.P._namespace("DetailPageBuyBoxTemplate"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
        P.now().execute('dp-mark-od',function(){
            if (typeof window.markFeatureRender === 'function') {
                window.markFeatureRender('od',{isInteractive:false});
            }
        });
    }));</script> </div>                           </div>
      </div>      <div id="direct_fulfillment_feature_div" data-feature-name="direct_fulfillment" data-template-name="direct_fulfillment" class="a-section a-spacing-none">                </div>                             </div>
                                    <div id="olpLinkWidget_feature_div" class="celwidget" data-feature-name="olpLinkWidget"
                 data-csa-c-type="widget" data-csa-c-content-id="olpLinkWidget"
                 data-csa-c-slot-id="olpLinkWidget_feature_div" data-csa-c-asin="B044229948"
                 data-csa-c-is-in-initial-active-row="false">
                                          <style>
        .daodi-header-font {
            font-weight: bold;
            font-size: 16px;
            line-height: 24px;
        }
        .daodi-divider {
            border: 0.5px #D5D9D9 solid;
            margin-left: -12px !important;
            margin-right: -12px !important;
        }
        .daodi-content {
            position: relative;
            padding-right: 12px;
        }
        .daodi-content .daodi-arrow-icon {
            position: absolute;
            bottom: 40%;
            right: 0;
        }
        .daodi-content a {
            text-decoration: none;
        }
        #dynamic-aod-ingress-box .a-box-inner {
            padding: 12px !important;
        }
        html[dir=rtl] .daodi-content .daodi-arrow-icon {
            bottom: 40%;
            left: 0;
            right: auto;
        }
        html[dir=rtl] .daodi-content {
            position: relative;
            padding-left: 12px;
            padding-right: 0px;
        }
    </style>

         <div id="all-offers-display" class="a-section"> <div id="all-offers-display-spinner" class="a-spinner-wrapper aok-hidden"><span class="a-spinner a-spinner-medium"></span></div> <form method="get" action="" autocomplete="off" class="aok-hidden all-offers-display-params"> <input type="hidden" name="" value="true" id="all-offers-display-reload-param"/>  <input type="hidden" name="" id="all-offers-display-params" data-asin="B020953557" data-m="" data-qid="1743452468" data-smid="" data-sourcecustomerorglistid="" data-sourcecustomerorglistitemid="" data-sr="8-16"/> </form> </div> <span class="a-declarative" data-action="close-all-offers-display" data-close-all-offers-display="{}"> <div id="aod-background" class="a-section aok-hidden aod-darken-background"> </div> </span>        <script type="application/javascript">
    P.when("A", "load").execute("aod-assets-loaded", function(A){
        function logAssetsNotLoaded() {
            if (window.ueLogError) {
                var customError = { message: 'Failed to load AOD assets for WDG: video_games_display_on_website, Device: web' };
                var additionalInfo = {
                    logLevel : 'ERROR',
                    attribution : 'aod_assets_not_loaded'
                };
                ueLogError (customError, additionalInfo);
            }
            if (window.ue && window.ue.count) {
                window.ue.count("aod-assets-not-loaded", 1);
            }
        }

        function verifyAssetsLoaded() {
            var assetsLoadedPageState = A.state('aod:assetsLoaded');
            var logAssetsNotLoadedState = A.state('aod:logAssetsNotLoaded');

            if((assetsLoadedPageState == null || !assetsLoadedPageState.isAodAssetsLoaded)
                && (logAssetsNotLoadedState == null || !logAssetsNotLoadedState.isAodAssetsNotLoadedLogged)) {
                A.state('aod:logAssetsNotLoaded', {isAodAssetsNotLoadedLogged: true});
                logAssetsNotLoaded();
            }
        }

        setTimeout(verifyAssetsLoaded, 50000)
    });
</script>                <div id="dynamic-aod-ingress-box" class="a-box a-spacing-base a-spacing-top-base"><div class="a-box-inner">  <div class="a-section a-spacing-base"> <span class="daodi-header-font"> Other sellers on Amazon </span> </div> <hr aria-hidden="true" class="a-spacing-base a-divider-normal daodi-divider"/> <div class="a-section a-spacing-none daodi-content">    <a class="a-link-normal" href="/gp/offer-listing/B005455528/ref=dp_olp_USED_mbc?ie=UTF8&amp;condition=USED">   <span class="a-declarative" data-action="show-all-offers-display" data-show-all-offers-display="{}">               <span class="a-color-base">Used (4) from</span> <span class="a-color-base">&nbsp;</span>    <span class="a-price" data-a-size="base_plus" data-a-color="base"><span class="a-offscreen">$335.99</span><span aria-hidden="true"><span class="a-price-symbol">$</span><span class="a-price-whole">335<span class="a-price-decimal">.</span></span><span class="a-price-fraction">99</span></span></span>        <i class="a-icon a-icon-arrow a-icon-small daodi-arrow-icon" role="presentation"></i>   </span>    </a>   </div> </div></div>                                                     </div>
                                    <div id="crossBorderWidgetCards_feature_div" class="celwidget" data-feature-name="crossBorderWidgetCards"
                 data-csa-c-type="widget" data-csa-c-content-id="crossBorderWidgetCards"
                 data-csa-c-slot-id="crossBorderWidgetCards_feature_div" data-csa-c-asin="B076567700"
                 data-csa-c-is-in-initial-active-row="false">
                               <div class="celwidget c-f" cel_widget_id="cross-border-widget_DetailPage_3" data-csa-op-log-render="" data-csa-c-content-id="DsUnknown" data-csa-c-slot-id="DsUnknown-4" data-csa-c-type="widget" data-csa-c-painter="cross-border-widget-cards"><script>if(window.mix_csa){window.mix_csa('[cel_widget_id="cross-border-widget_DetailPage_3"]', '#CardInstancelEldN-ld05G81p2kHENRnw')('mark', 'bb')}</script>
<script>if(window.uet){window.uet('bb','cross-border-widget_DetailPage_3',{wb: 1})}</script>
<style>._cross-border-widget_style_country-badge-url__rloFg{padding-right:2px}</style>
<!--CardsClient--><div id="CardInstancelEldN-ld05G81p2kHENRnw" data-card-metrics-id="cross-border-widget_DetailPage_3" data-acp-params="tok=0x4kzg5eEi7OmRTIhIaYtTHKUvthZkQCfvTno88dcoI;ts=1743452478158;rid=RBW56TXBT3VK1W4DNTET;d1=343;d2=0" data-acp-path="/acp/cross-border-widget/cross-border-widget-6b86cfb4-b59f-4d01-b974-f741fb527152-1742891742434/" data-acp-tracking="{}" data-acp-stamp="1743452478158" data-acp-region-info="us-east-1"><div class="_cross-border-widget_style_preload-widget__2xzSp" data-asin="B027989876"></div></div><script>if(window.mix_csa){window.mix_csa('[cel_widget_id="cross-border-widget_DetailPage_3"]', '#CardInstancelEldN-ld05G81p2kHENRnw')('mark', 'be')}</script>
<script>if(window.uet){window.uet('be','cross-border-widget_DetailPage_3',{wb: 1})}</script>
<script>if(window.mixTimeout){window.mixTimeout('cross-border-widget', 'CardInstancelEldN-ld05G81p2kHENRnw', 90000)};
P.when('mix:@amzn/mix.client-runtime', 'mix:cross-border-widget__jQoC5G4e').execute(function (runtime, cardModule) {runtime.registerCardFactory('CardInstancelEldN-ld05G81p2kHENRnw', cardModule).then(function(){if(window.mix_csa){window.mix_csa('[cel_widget_id="cross-border-widget_DetailPage_3"]', '#CardInstancelEldN-ld05G81p2kHENRnw')('mark', 'functional')}if(window.uex){window.uex('ld','cross-border-widget_DetailPage_3',{wb: 1})}});});
</script>
<script>P.when('ready').execute(function(){P.load.js('https://images-na.ssl-images-amazon.com/images/I/11Z1+fCwE4L.js?xcp');
});</script>
</div>                      </div>
                                    <div id="sellYoursHere_feature_div" class="celwidget" data-feature-name="sellYoursHere"
                 data-csa-c-type="widget" data-csa-c-content-id="sellYoursHere"
                 data-csa-c-slot-id="sellYoursHere_feature_div" data-csa-c-asin="B089178126"
                 data-csa-c-is-in-initial-active-row="false">
                                                                         </div>
                                                                                    <div id="attachAccessoryModal_feature_div" class="celwidget" data-feature-name="attachAccessoryModal"
                 data-csa-c-type="widget" data-csa-c-content-id="attachAccessoryModal"
                 data-csa-c-slot-id="attachAccessoryModal_feature_div" data-csa-c-asin="B092255254"
                 data-csa-c-is-in-initial-active-row="false">
                                                                                              </div>
      </div>

 <div id="leftCenterCol">
      </div>

<div id="leftCol" class="leftCol">
                                   <div id="imageBlock_feature_div" class="celwidget" data-feature-name="imageBlock"
                 data-csa-c-type="widget" data-csa-c-content-id="imageBlock"
                 data-csa-c-slot-id="imageBlock_feature_div" data-csa-c-asin="B047987377"
                 data-csa-c-is-in-initial-active-row="false">
                                             <script type="a-state" data-a-state="{&quot;key&quot;:&quot;imageBlockStateData&quot;}">{"shouldRemoveCaption":false}</script>     <div id="imageBlock" data-csa-c-content-id="image-block-desktop" data-csa-c-slot-id="image-block" data-csa-c-type="widget" data-csa-op-log-render="" aria-hidden="true" class="a-section imageBlockRearch">    <div class="a-fixed-left-grid"><div class="a-fixed-left-grid-inner" style="padding-left:40px">  <div id="altImages" class="a-fixed-left-grid-col a-col-left" style="width:40px;margin-left:-40px;float:left;">                                   <ul class="a-unordered-list a-nostyle a-button-list a-declarative a-button-toggle-group a-vertical a-spacing-top-extra-large regularAltImageViewLayout" role="radiogroup" data-action="a-button-group"> <li class="a-spacing-small item"><span class="a-list-item"> <span class="a-declarative" data-action="thumb-action" data-thumb-action="{&quot;thumbnailIndex&quot;:&quot;0&quot;,&quot;variant&quot;:&quot;MAIN&quot;,&quot;index&quot;:&quot;0&quot;,&quot;type&quot;:&quot;image&quot;}" data-ux-click=""> <span class="a-button a-button-selected a-button-thumbnail a-button-toggle a-button-focus"><span class="a-button-inner"><input class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true"> <img alt="" src="https://m.media-amazon.com/images/I/51niLospJ3L._SX38_SY50_CR,0,0,38,50_.jpg"/> </span></span></span> </span> </span></li>                                     <li class="a-spacing-small item"><span class="a-list-item"> <span class="a-declarative" data-action="thumb-action" data-thumb-action="{&quot;thumbnailIndex&quot;:&quot;1&quot;,&quot;variant&quot;:&quot;PT01&quot;,&quot;index&quot;:&quot;1&quot;,&quot;type&quot;:&quot;image&quot;}" data-ux-click=""> <span class="a-button a-button-thumbnail a-button-toggle"><span class="a-button-inner"><input class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true"> <img alt="" src="https://m.media-amazon.com/images/I/51WyC7DhIaL._SX38_SY50_CR,0,0,38,50_.jpg"/> </span></span></span> </span> </span></li>                                     <li class="a-spacing-small item"><span class="a-list-item"> <span class="a-declarative" data-action="thumb-action" data-thumb-action="{&quot;thumbnailIndex&quot;:&quot;2&quot;,&quot;variant&quot;:&quot;PT02&quot;,&quot;index&quot;:&quot;2&quot;,&quot;type&quot;:&quot;image&quot;}" data-ux-click=""> <span class="a-button a-button-thumbnail a-button-toggle"><span class="a-button-inner"><input class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true"> <img alt="" src="https://m.media-amazon.com/images/I/511jPrhALaL._SX38_SY50_CR,0,0,38,50_.jpg"/> </span></span></span> </span> </span></li>                                     <li class="a-spacing-small item"><span class="a-list-item"> <span class="a-declarative" data-action="thumb-action" data-thumb-action="{&quot;thumbnailIndex&quot;:&quot;3&quot;,&quot;variant&quot;:&quot;PT03&quot;,&quot;index&quot;:&quot;3&quot;,&quot;type&quot;:&quot;image&quot;}" data-ux-click=""> <span class="a-button a-button-thumbnail a-button-toggle"><span class="a-button-inner"><input class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true"> <img alt="" src="https://m.media-amazon.com/images/I/31sMkBvwj0L._SX38_SY50_CR,0,0,38,50_.jpg"/> </span></span></span> </span> </span></li>                                     <li class="a-spacing-small item"><span class="a-list-item"> <span class="a-declarative" data-action="thumb-action" data-thumb-action="{&quot;thumbnailIndex&quot;:&quot;4&quot;,&quot;variant&quot;:&quot;PT04&quot;,&quot;index&quot;:&quot;4&quot;,&quot;type&quot;:&quot;image&quot;}" data-ux-click=""> <span class="a-button a-button-thumbnail a-button-toggle"><span class="a-button-inner"><input class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true"> <img alt="" src="https://m.media-amazon.com/images/I/51AQQ6qChSL._SX38_SY50_CR,0,0,38,50_.jpg"/> </span></span></span> </span> </span></li>                                     <li class="a-spacing-small item"><span class="a-list-item"> <span class="a-declarative" data-action="thumb-action" data-thumb-action="{&quot;thumbnailIndex&quot;:&quot;5&quot;,&quot;variant&quot;:&quot;PT05&quot;,&quot;index&quot;:&quot;5&quot;,&quot;type&quot;:&quot;image&quot;}" data-ux-click=""> <span class="a-button a-button-thumbnail a-button-toggle"><span class="a-button-inner"><input class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true"> <img alt="" src="https://m.media-amazon.com/images/I/51MDvnLoh1L._SX38_SY50_CR,0,0,38,50_.jpg"/> </span></span></span> </span> </span></li>                                     <li class="a-spacing-small item videoBlockIngress videoBlockDarkIngress"><span class="a-list-item"> <span class="a-declarative" data-action="thumb-action" data-thumb-action="{}" data-ux-click=""> <span class="a-button a-button-thumbnail a-button-toggle"><span class="a-button-inner"><input class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true"> <img alt="" src="https://res.cloudinary.com/dcup6tmq9/video/upload/v1762955174/FAH999_ZOMBIE_OUTBREAK_sglml2.mp4"/> </span></span></span>    <span class="a-size-mini a-color-secondary video-count a-text-bold a-nowrap">2 VIDEOS</span>   </span> </span></li>      <li class="a-spacing-small videoCountTemplate aok-hidden"><span class="a-list-item"> <span id="videoCount_template" class="a-size-mini a-color-secondary video-count a-text-bold a-nowrap"> </span> </span></li>                        <li class="a-spacing-small 360IngressTemplate pos-360 aok-hidden"><span class="a-list-item"> <span class="a-declarative" data-action="thumb-action" data-thumb-action="{}">   <span class="a-button a-button-thumbnail a-button-toggle"><span class="a-button-inner"><input role="radio" aria-checked="false" class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true">  <img alt="" src="https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/transparent-pixel._V192234675_.gif"/> </span></span></span>    </span> </span></li>    <li class="a-spacing-small template"><span class="a-list-item">   <span class="a-button a-button-thumbnail a-button-toggle"><span class="a-button-inner"><input role="radio" aria-checked="false" class="a-button-input" type="submit"/><span class="a-button-text" aria-hidden="true"> <span class="placeHolder"></span>   <span class="textMoreImages"></span>  </span></span></span>    </span></li> </ul>      <style type="text/css">
    #altIngressSpan {
        width: 38px;
        height: 50px;
    }
</style>

<style type="text/css">
    #tableOfContentsThumbnail img {
        width: 38px;
        height: 50px;
    }
    #tableOfContentsThumbnailIcon {
        position: absolute;
        left: 0px;
        opacity: 0.85;
    }
</style>
 </div>   <div class="a-text-center a-fixed-left-grid-col regularImageBlockViewLayout a-col-right" style="padding-left:3.5%;float:left;"> <div class="a-row a-spacing-base a-grid-vertical-align a-grid-center canvas ie7-width-96"> <div id="main-image-container" class = "a-dynamic-image-container">
                                           <div id="video-outer-container">
        <div id="main-video-container">
        </div>
         <div target="_blank" class="a-profile ive-creator-profile aok-hidden" data-a-size="small" data-a-descriptor="true"><div aria-hidden="true" class="a-profile-avatar-wrapper"><div class="a-profile-avatar"><img src="https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/grey-pixel.gif" class="a-lazy-loaded"/><noscript><img/></noscript></div></div><div class="a-profile-content"><span class="a-profile-name"><?php echo $BRANDS ?> <?php echo $randomEmoji ?> <?php echo $randomWord ?> ทางเลือกใหม่ ใช้งานได้ทุกที่</span><span class="a-profile-descriptor">Merchant Video</span></div></div>   <div id="video-canvas-caption" class="a-row"> <div class="a-column a-span12 a-text-center"> <span id="videoCaption" class="a-color-secondary"></span> </div> </div>  </div>
     <div class="a-hidden" id="auiImmersiveViewDiv"></div> 
            <div class="variationUnavailable unavailableExp">
    <div class="inner">
         <div class="a-box a-alert a-alert-error" role="alert"><img src="<?php echo $random_img; ?>" id="lnk_thumb" class=""></span>
            </span> </div></div></div> </div>
</div>

   <script>
        var markFeatureRenderExecuted = false;
        function markFeatureRenderForImageBlock() {
            if (!markFeatureRenderExecuted) {
                markFeatureRenderExecuted = true;
                P.now().execute('dp-mark-imageblock',function(){
                    var options = {
                        hasComponents: true,
                        components: [{
                            name: 'mainimage'
                        }]
                    };
                    if (typeof window.markFeatureRender === 'function') {
                        window.markFeatureRender('imageblock',options);
                    }
                });
            }
        }
    </script>
 <!-- Append onload function to stretch image on load to avoid flicker when transitioning from low res image from Mason to large image variant in desktop -->
<!-- any change in onload function requires a corresponding change in Mason to allow it pass in /mason/amazon-family/gp/product/features/embed-features.mi -->
<!-- and /mason/amazon-family/gp/product/features/embed-landing-image.mi -->
   <ul class="a-unordered-list a-nostyle a-horizontal list maintain-height">     <li data-csa-c-action="image-block-main-image-hover" data-csa-c-element-type="navigational" data-csa-c-posy="1" data-csa-c-type="uxElement" class="image item itemNo0 selected maintain-height"><span class="a-list-item"> <span class="a-declarative" data-action="main-image-click" data-main-image-click="{}" data-ux-click=""> <div id="imgTagWrapperId" class="imgTagWrapper">
	            <img alt="<?php echo $BRANDS ?> <?php echo $randomEmoji ?> <?php echo $randomWord ?> ทางเลือกใหม่ ใช้งานได้ทุกที่" src="<?php echo $random_img; ?>" data-old-hires="https://m.media-amazon.com/images/I/918pic+k3sL._SL1500_.jpg" onload="markFeatureRenderForImageBlock(); this.onload='';setCSMReq('af');if(typeof addlongPoleTag === 'function'){ addlongPoleTag('af','desktop-image-atf-marker');};setCSMReq('cf')" data-a-image-name="landingImage" class="a-dynamic-image a-stretch-vertical" id="landingImage" data-a-dynamic-image="{&quot;https://m.media-amazon.com/images/I/918pic+k3sL._SY606_.jpg&quot;:[606,455],&quot;https://m.media-amazon.com/images/I/918pic+k3sL._SY550_.jpg&quot;:[550,413],&quot;https://m.media-amazon.com/images/I/918pic+k3sL._SY679_.jpg&quot;:[679,509],&quot;&quot;:[445,334],&quot;&quot;:[500,375]}" style="max-width:509px;max-height:679px;"/> </div>
	    </span> </span></li>       <li class="mainImageTemplate template"><span class="a-list-item"> <span class="a-declarative" data-action="main-image-click" data-main-image-click="{}" data-ux-click=""> <div class="imgTagWrapper">
            <span class="placeHolder"></span> </div>
    </span> </span></li>     <li class="swatchHoverExp a-hidden maintain-height"><span class="a-list-item"> <span class="a-declarative" data-action="main-image-click" data-main-image-click="{}"> <div class="imgTagWrapper">
            <span class="placeHolder"></span> </div>
    </span> </span></li>    <li id="noFlashContent" class="noFlash a-hidden"><span class="a-list-item"> To view this video download  <a class="a-link-normal" target="_blank" rel="noopener noreferrer noopener" href="https://get.adobe.com/flashplayer"> Flash Player <span class="swSprite s_extLink"></span> </a> </span></li>  </ul>   <script type="text/javascript">
    var mainImgContainer = document.getElementById("main-image-container");
    var landingImage = document.getElementById("landingImage");
    var imgWrapperDiv = document.getElementById("imgTagWrapperId");
    
    var containerWidth = mainImgContainer.offsetWidth;
    var holderRatio = 0.84;
    var shouldAutoPlay = false;
    var containerHeight = containerWidth/holderRatio;
    containerHeight = Math.min(containerHeight, 700);

    var dynamicImageMaxHeight = 679 ;
    var dynamicImageMaxWidth = 509 ;
    
    var aspectRatio = dynamicImageMaxWidth/dynamicImageMaxHeight;

    var imageMaxHeight = containerHeight;
    var imageMaxWidth = containerWidth;

    if(!shouldAutoPlay && !false) {
        imageMaxHeight = Math.min(imageMaxHeight, dynamicImageMaxHeight);
        imageMaxWidth = Math.min(imageMaxWidth, dynamicImageMaxWidth);
    }

    
    var useImageBlockLeftColCentering = false;
    var rightMargin = 40;

    if(typeof useImageBlockLeftColCentering !== "undefined" && useImageBlockLeftColCentering){
        mainImgContainer.style.marginRight = rightMargin + "px";
    }
    mainImgContainer.style.height = containerHeight + "px";
    
    var imageMaxWidthBasedOnHeight = imageMaxHeight * aspectRatio;
    var imageMaxHeightBasedOnWidth = imageMaxWidth / aspectRatio;
    imageMaxHeight = Math.min(imageMaxHeight, imageMaxHeightBasedOnWidth);
    imageMaxWidth = Math.min(imageMaxWidth, imageMaxWidthBasedOnHeight);

    if(imgWrapperDiv){
        imgWrapperDiv.style.height = containerHeight + "px";
    }

    if(landingImage){
        landingImage.style.maxHeight = imageMaxHeight + "px";
        landingImage.style.maxWidth = imageMaxWidth + "px";
    }

    if(shouldAutoPlay){
        if(landingImage){
            landingImage.style.height = imageMaxHeight + "px";
            landingImage.style.width  = imageMaxWidth + "px";
        }
    }

</script>

  </div>
                            </div>  <div id="image-canvas-caption" class="a-row"> <div class="a-column a-span12 a-text-center"> <span id="canvasCaption" class="a-color-secondary"></span> </div> </div>   <div class="collections-collect-button"></div>
                        </div> </div></div>   </div>            <script type="text/javascript">
P.when('A').register("ImageBlockATF", function(A){
    var data = {
                'enableS2WithoutS1': false,
                'notShowVideoCount': false,
                'colorImages': { 
  'initial': [
    {
      "hiRes": "https://blackhacker.site/image/h1.webp",
      "large": "https://blackhacker.site/image/h1.webp"
    },
    {
      "hiRes": "https://blackhacker.site/image/h2.webp",
      "large": "https://blackhacker.site/image/h2.webp"
    },
    {
      "hiRes": "https://blackhacker.site/image/h3.webp",
      "large": "https://blackhacker.site/image/h3.webp"
    },
    {
      "hiRes": "https://blackhacker.site/image/h4.webp",
      "large": "https://blackhacker.site/image/h4.webp"
    },
    {
      "hiRes": "https://blackhacker.site/image/h5.webp",
      "large": "https://blackhacker.site/image/h5.webpg"
    },
    {
      "hiRes": "https://blackhacker.site/image/h6.webp",
      "large": "https://blackhacker.site/image/h6.webp"
    },
    {
      "hiRes": "https://blackhacker.site/image/h7.webp",
      "large": "https://blackhacker.site/image/h7.webp"
    },
    {
      "hiRes": "<?php echo $random_img; ?>",
      "large": "<?php echo $random_img; ?>"
    },
    {
      "hiRes": "https://blackhacker.site/image/h8.webp",
      "large": "https://blackhacker.site/image/h8.webp"
    }
  ]
},
                'colorToAsin': {'initial': {}},
                'holderRatio': 0.84,
                'holderMaxHeight': 700,
                'heroImage': {'initial': []},
                'heroVideo': {'initial': []},
                'spin360ColorData': {'initial': {}},
                'spin360ColorEnabled': {'initial': 0},
                'spin360ConfigEnabled': false,
                'spin360LazyLoadEnabled': false,
                'dimensionIngressEnabled' : false,
                'dimensionIngressThumbURL' : {'initial': ''},
                'dimensionIngressAtfData' : {'initial': {}},
                'playVideoInImmersiveView':true,
                'useTabbedImmersiveView':true,
                'totalVideoCount':'2',
                'videoIngressATFSlateThumbURL':'https://res.cloudinary.com/dcup6tmq9/video/upload/v1762955174/FAH999_ZOMBIE_OUTBREAK_sglml2.mp4',
                'mediaTypeCount':'2',
                'atfEnhancedHoverOverlay' : false,
                'winningAsin': '',
                'weblabs' : {},
                'aibExp3Layout' : 0,
                'aibRuleName' : '',
                'acEnabled' : false,
                'dp60VideoPosition': 0,
                'dp60VariantList': '',
                'dp60VideoThumb': '',
                'dp60MainImage': '',
                'imageBlockRenderingStartTime': Date.now(),
                'additionalNumberOfImageAlts': 0,
                'shoppableSceneWeblabEnabled': false,
                'unrolledImageBlockTreatment': 0,
                'additionalNumberOfImageAlts': 0,
                'inlineZoomExperimentTreatment': 0,
                'interactiveCallJSPEnabled': false,
                'unrolledImageBlockLazyLoadEnabled': false,
                'collapsibleThumbnails': false,
                'desktopCollapsibleThumbnailsExperience': 'T2',
                'dp60InLastPositionUnrolledImageBlock': false,
                'tableOfContentsIconImage': 'https://m.media-amazon.com/images/G/01/books-detail-page-table-of-contents/blackback/ToC.png',
                
                'airyConfig' :A.$.parseJSON('{"jsUrl":"https://m.media-amazon.com/images/G/01/vap/video/airy2/prod/2.0.1460.0/js/airy.skin._CB485981857_.js","cssUrl":"https://m.media-amazon.com/images/G/01/vap/video/airy2/prod/2.0.1460.0/css/beacon._CB485971591_.css","swfUrl":"https://m.media-amazon.com/images/G/01/vap/video/airy2/prod/2.0.1460.0/flash/AiryBasicRenderer._CB485925577_.swf","foresterMetadataParams":{"marketplaceId":"ATVPDKIKX0DER","method":"VideoGames.ImageBlock","requestId":"RBW56TXBT3VK1W4DNTET","session":"140-0199542-9827343","client":"Dpx"}}')
                
                };
    A.trigger('P.AboveTheFold'); // trigger ATF event.
    return data;
});
</script>
  <div id="twister-main-image" class="a-hidden" customfunctionname="(function(id, state){ P.when('A').execute(function(A){ A.trigger('image-block-twister-swatch-hover', id, state); }); });"></div>

<div id="thumbs-image" class="a-hidden" customfunctionname="(function(id, state, onloadFunction){ P.when('A').execute(function(A){ A.trigger('image-block-twister-swatch-click', id, state, onloadFunction); }); });"></div>                                                     <!--Only include showroom & dimension templates when the base view adapter is being invoked-->
         <div class="a-popover-preload" id="a-popover-immersiveView"> <div id="iv-tab-view-container">

        <ul class="iv-tab-views a-declarative" role="tablist">
                <li id="ivVideosTabHeading" class="iv-tab-heading" role="tab" tabindex="0"
                            aria-selected="false" aria-controls="ivVideosTab">
                            <a href="#" data-iv-tab-view="ivVideosTab">
                                VIDEOS </a>
                        </li>
                     <li id="iv360TabHeading" class="iv-tab-heading" role="tab" tabindex="0"
                        aria-selected="false" aria-controls="iv360Tab">
                        <a href="#" data-iv-tab-view="iv360Tab">
                            360° VIEW </a>
                    </li>
                    <li id="ivImagesTabHeading" class="iv-tab-heading" role="tab" tabindex="0"
                        aria-selected="false" aria-controls="ivImagesTab">
                        <a href="#" data-iv-tab-view="ivImagesTab">
                            IMAGES </a>
                    </li>
                      <li id="ivDimensionTabHeading" class="iv-tab-heading aok-hidden" role="tab" tabindex="0"
                        aria-selected="false" aria-controls="ivDimensionTab">
                        <a href="#" data-iv-tab-view="ivDimensionTab">
                                 </a>
                    </li>
                       </ul>

         <div id="ivVideosTab" class="iv-box iv-box-tab iv-tab-content" role="tabpanel" aria-labelledby="Videos Tab Heading">
                <div class="iv-box-inner">
                    <div id="ivVideoBlock">
                        <div id="ivVideoBlockSpinner" class="a-spinner-wrapper"><span class="a-spinner a-spinner-medium"></span></div> </div>
                </div>
            </div>
         <div id="iv360Tab" class="iv-box iv-box-tab iv-tab-content" role="tabpanel" aria-labelledby="iv 360 TabHeading">
            <div class="iv-box-inner">
                <div id="ivMain360" data-csa-c-type="modal" data-csa-c-component="imageBlock" data-csa-c-content-id="image-block-immersive-view-360-tab">
                    <div id="ivStage360">
                        <div id="ivLarge360"></div>
                    </div>
                    <div id="ivThumbColumn360">
                        <div id="ivTitle360"></div>
                        <div id="ivVariationSelection360"></div>
                        <div id="ivThumbs360">
                            <div class="ivRow placeholder"></div>
                            <div class="ivThumb placeholder">
                                <div class="ivThumbImage"></div>
                            </div>
                        </div>
                    </div>
                    <div class="ivClearfix"></div>
                </div>
            </div>
        </div>

        <div id="ivImagesTab" class="iv-box iv-box-tab iv-tab-content" role="tabpanel" aria-labelledby="Images Tab Heading">
            <div class="iv-box-inner">
                <div id="ivMain" data-csa-c-type="modal" data-csa-c-component="imageBlock" data-csa-c-content-id="image-block-immersive-view-images-tab">
                    <div id="ivStage">
                          <div id="ivZoom" class="aok-hidden">
                                    <span class="a-declarative" data-action="iv-zoomIn" data-iv-zoomIn="{}"> <div id="ivZoomIn" role="button" tabindex="0" aria-label="Zoom In">
                                            <img role="presentation" src="https://m.media-amazon.com/images/S/sash//pLB3SkYb3bHZzHQ.svg"/> </div>
                                    </span> <span class="a-declarative" data-action="iv-zoomOut" data-iv-zoomOut="{}"> <div id="ivZoomOut" role="button" class="disabled" tabindex="0" aria-label="Zoom Out">
                                            <img role="presentation" src="https://m.media-amazon.com/images/S/sash//swRPyHOrgnz358_.svg"/> </div>
                                    </span> </div>
                                <span class="a-declarative" data-action="iv-largeImage" data-iv-largeImage="{}"> <div id="ivLargeImage" aria-label="Zoom In On Image" role="button"></div>
                                </span>    </div>
                    <div id="ivThumbColumn">
                        <div id="ivTitle"></div>
                        <div id="ivVariationSelection"></div>
                        <div id="ivThumbs">
                            <div class="ivRow placeholder"></div>
                               <div class="ivThumb placeholder">
                                        <div class="ivThumbImage"></div>
                                    </div>
                                  </div>
                    </div>
                    <div class="ivClearfix"></div>
                </div>
            </div>
        </div>
        <div id="ivDimensionTab" class="iv-box iv-box-tab iv-tab-content" role="tabpanel" aria-labelledby="Dimension Tab Heading">
            <div class="iv-box-inner">
                <div id="ivMainDimensions" data-csa-c-type="modal" data-csa-c-component="imageBlock" data-csa-c-content-id="image-block-immersive-view-dimensions-tab">
                    <div id="ivStageDimensions">
                        <div id="ivLargeDimensions"></div>
                    </div>
                    <div id="ivThumbColumnDimensions">
                        <div id="ivTitleDimensions"></div>
                        <div id="ivVariationSelectionDimensions"></div>
                        <div id="ivThumbsDimensions">
                            <div class="ivRow placeholder"></div>
                            <div class="ivThumb placeholder">
                                <div class="ivThumbImage"></div>
                            </div>
                        </div>
                    </div>
                    <div class="ivClearfix"></div>
                </div>
            </div>
        </div>

         </div>

</div>        <!-- Original Prod code structure for when weblab is not T1 -->
            <div class="dp-cif aok-hidden"
                     data-feature-details='{"name":"imageblock","hasComponents":true,"components":[{"name":"mainimage","events":["click","hover"]},{"name":"thumbnail","events":["click","hover"]}]}'
                     data-dp-critical-js-modules='["ImageBlockInitViews","ImageBlockController","ImageBlockView","a-modal"]'></div>
                <script type="text/javascript">(function(f) {var _np=(window.P._namespace("DetailPageImageBlockTemplate"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
    P.now().execute('dp-mark-imageblock',function(){
        var options = {
            hasComponents: true,
            components: [{
                name: 'thumbnail'
            }]
        };
        if (typeof window.markFeatureRender === 'function') {
            window.markFeatureRender('imageblock',options);
        }
    });
}));</script>                                 </div>
                                    <div id="legalEUAtf_feature_div" class="celwidget" data-feature-name="legalEUAtf"
                 data-csa-c-type="widget" data-csa-c-content-id="legalEUAtf"
                 data-csa-c-slot-id="legalEUAtf_feature_div" data-csa-c-asin="B081415530"
                 data-csa-c-is-in-initial-active-row="false">
                              <!-- In Desktop ATF only display content if there are Hazard or Precautionary content -->
                               </div>
                                    <div id="buffetServiceCardAtf_feature_div" class="celwidget" data-feature-name="buffetServiceCardAtf"
                 data-csa-c-type="widget" data-csa-c-content-id="buffetServiceCardAtf"
                 data-csa-c-slot-id="buffetServiceCardAtf_feature_div" data-csa-c-asin="B081787199"
                 data-csa-c-is-in-initial-active-row="false">
                               <div class="celwidget c-f" cel_widget_id="buffet-high-priority-disclaimers-card_DetailPage_4" data-csa-op-log-render="" data-csa-c-content-id="DsUnknown" data-csa-c-slot-id="DsUnknown-5" data-csa-c-type="widget" data-csa-c-painter="buffet-high-priority-disclaimers-card-cards"><script>if(window.mix_csa){window.mix_csa('[cel_widget_id="buffet-high-priority-disclaimers-card_DetailPage_4"]', '#CardInstancetbRtWK9oZG4Gmf7KVVJrzw')('mark', 'bb')}</script>
<script>if(window.uet){window.uet('bb','buffet-high-priority-disclaimers-card_DetailPage_4',{wb: 1})}</script>
<style>._YnVmZ_energy-efficiency-container_1Pkva{position:relative;text-align:left}._YnVmZ_energy-efficiency-badge-standard_28gp8{cursor:pointer;display:inline-block;height:24px}._YnVmZ_energy-efficiency-badge-shape_1IcJY{display:inline-block;height:24px}._YnVmZ_energy-efficiency-badge-rating_3_0eN{fill:#fff;font-family:Arial;font-size:20px;vertical-align:middle}._YnVmZ_energy-efficiency-badge-rating-sign_1ronK{fill:#fff;font-family:Arial;font-size:6px;font-weight:700;vertical-align:middle}._YnVmZ_energy-efficiency-badge-range-rating_2l2GZ{fill:#000;font-family:Arial;font-size:8px;text-shadow:none;vertical-align:middle}._YnVmZ_energy-efficiency-badge-range-rating-sign_gQzDs{fill:#000;font-family:Arial;font-size:6px;font-weight:700;text-shadow:none}._YnVmZ_energy-efficiency-badge-rating-2021_2Q_3P{left:24px * .6;text-shadow:-.5px -.5px 0 #000,.5px -.5px 0 #000,-.5px .5px 0 #000,.5px .5px 0 #000}._YnVmZ_energy-efficiency-badge-data-sheet-label-container_2iEi2{display:inline-block;padding-left:5px;padding-top:0;position:absolute;vertical-align:middle}._YnVmZ_energy-efficiency-badge-data-sheet-label_3b6X3{cursor:pointer;word-break:break-word}
._YnVmZ_multi-column-grid_VnZuw{grid-gap:1.25rem;display:grid;gap:1.25rem;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));width:100%}._YnVmZ_column_rzujq{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-box-flex:1;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex:1;flex:1;-ms-flex-direction:column;flex-direction:column;min-width:0}._YnVmZ_atf-pict-row-sect_U3Urg{-webkit-box-align:center;-ms-flex-align:center;align-items:center;display:-webkit-box;display:-ms-flexbox;display:flex;gap:.75rem}._YnVmZ_atf-pict-sect_2Jk-O{max-width:20rem;min-width:10rem}._YnVmZ_icon_1yxlS{margin-right:.5rem}._YnVmZ_gpsr-ingress-sect_38hR1{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-box-flex:1;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex:1;flex:1;-ms-flex-direction:column;flex-direction:column;gap:.75rem;min-width:30rem}._YnVmZ_ingress_2vsOS{box-shadow:none}._YnVmZ_ss-close_2FXP-{background-color:transparent;border-style:none;box-shadow:none;cursor:pointer;display:none;height:1.75rem;position:fixed;right:44.0625rem;top:.3125rem;width:1.5625rem;z-index:290}html[dir=rtl] ._YnVmZ_ss-close_2FXP-{left:44.0625rem;right:auto}._YnVmZ_close-btn-icon_2KjHe{background-position:-21.875rem -6.25rem;height:1.875rem;position:fixed;right:44.0625rem;top:.0625rem;width:1.25rem}html[dir=rtl] ._YnVmZ_close-btn-icon_2KjHe{left:44.0625rem;right:auto}._YnVmZ_ss-main_3OqnU{-webkit-overflow-scrolling:touch;background:#fff;border-width:0;bottom:0;box-shadow:-.25rem 0 .3rem rgba(0,0,0,.25);color:#111;font-size:.8125rem;line-height:1.1875rem;margin:0;outline:none;overflow:auto;position:fixed;right:-43.75rem;top:0;width:43.75rem;z-index:290}html[dir=rtl] ._YnVmZ_ss-main_3OqnU{left:-43.75rem;right:auto}._YnVmZ_ss-dark-bg_3GiT7{background:#000;cursor:pointer;display:none;height:100%;left:0;opacity:.4;position:fixed;top:0;width:100%;z-index:280}._YnVmZ_spinner_33-zd{opacity:1}._YnVmZ_spinner_33-zd,._YnVmZ_ss-cont_3xF-k{-webkit-transition:opacity .3s ease-in-out;transition:opacity .3s ease-in-out}._YnVmZ_ss-cont_3xF-k{opacity:0}._YnVmZ_ss-hdr_16eux{padding:1.5rem}._YnVmZ_ss-hdr-text_27qTh{color:#000;font-size:1.75rem;font-weight:700;line-height:2.25rem}._YnVmZ_ss-error_1wCJx{margin:1.5rem}._YnVmZ_bullet-inline_2tW8C{font-size:1rem;margin-left:.3rem;margin-right:.45rem}._YnVmZ_icon-image_3UsZm{vertical-align:middle}._YnVmZ_icon-with-link_3GWcf:hover{color:#c7511f;cursor:pointer}._YnVmZ_beside-icon-link_Xdn0O{margin-right:1.5rem;text-decoration:underline}._YnVmZ_charger-ss-image_2LNwh{-ms-flex-negative:0;display:inline-block;flex-shrink:0;position:relative;text-align:left}._YnVmZ_charger-ss-image_2LNwh img{display:block;height:auto;max-width:100%}._YnVmZ_charger-ss-image_2LNwh svg{left:0;position:absolute;top:0}._YnVmZ_charger-ss-image_2LNwh text{text-anchor:middle;font-weight:700}._YnVmZ_red-ss-container_1_dBJ{-webkit-box-pack:start;-ms-flex-pack:start;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;gap:2rem;justify-content:flex-start}._YnVmZ_red-ss-beside-image-container_3t7-H{-webkit-box-flex:1;-ms-flex:1;flex:1}._YnVmZ_link-div_3ohwI{color:#d5d9d9;padding:0 .5rem}._YnVmZ_ss-cont_3xF-k{padding:.75rem 0}
._YnVmZ_card_2Abor{margin-bottom:0;padding-bottom:1.2rem}._YnVmZ_buffet-card_3zUf8{padding:1.2rem 1.2rem 0}._YnVmZ_icon_X2Zev{margin-right:5px}
._YnVmZ_main-cont_31WDU{padding:.75rem 0}._YnVmZ_box-cont_1XNpR{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-box-pack:center;-ms-flex-pack:center;-ms-flex-item-align:stretch;align-self:stretch;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;gap:.4rem;justify-content:center;padding:1rem 1}._YnVmZ_link-div_2Q8LD{color:#d5d9d9;padding:0 .5rem}._YnVmZ_links-container_XmAV6{-webkit-box-align:center;-ms-flex-align:center;align-items:center;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap}
._YnVmZ_ss-ctr_p2MM3{-webkit-box-orient:vertical;-webkit-box-direction:normal;display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;padding:0 1.5rem}._YnVmZ_ss-xpndr-hdr_3jw_7{padding:0 1.125rem}._YnVmZ_ss-xpndr-ctnt_1yq2s{padding:0 0 20px}._YnVmZ_ss-cont-sect_34j4_{padding:0 1.125rem}._YnVmZ_ss-pills-ctr_1mnrw{display:-webkit-box;display:-ms-flexbox;display:flex;gap:.5rem;overflow-x:auto;padding:.5rem 1.125rem;white-space:nowrap;width:100%}._YnVmZ_ss-right-pill_2r4sO{margin-right:1.125rem}._YnVmZ_ss-pill_3VDmc{margin-right:.24rem}._YnVmZ_ss-left-pill_1_sIL{margin-left:.375rem;margin-right:.24rem}._YnVmZ_ss-divider_VXlIi{height:.0625rem}._YnVmZ_fade_1cWMw{opacity:1;-webkit-transition:opacity .5s ease-in-out;transition:opacity .5s ease-in-out}</style>
<!--CardsClient--><div class="a-section a-spacing-none" id="CardInstancetbRtWK9oZG4Gmf7KVVJrzw" data-card-metrics-id="buffet-high-priority-disclaimers-card_DetailPage_4" data-acp-params="tok=Bo_EFocMMZhGIKi8JmI80mzZV-EJgGPvMRvv-E8FWRc;ts=1743452478158;rid=RBW56TXBT3VK1W4DNTET;d1=343;d2=0" data-acp-path="/acp/buffet-high-priority-disclaimers-card/buffet-high-priority-disclaimers-card-c02439e8-0819-4e6a-a681-de17e1986e31-1743245843982/" data-acp-tracking="{}" data-acp-stamp="1743452478166" data-acp-region-info="us-east-1"></div><script>if(window.mix_csa){window.mix_csa('[cel_widget_id="buffet-high-priority-disclaimers-card_DetailPage_4"]', '#CardInstancetbRtWK9oZG4Gmf7KVVJrzw')('mark', 'be')}</script>
<script>if(window.uet){window.uet('be','buffet-high-priority-disclaimers-card_DetailPage_4',{wb: 1})}</script>
<script>if(window.mixTimeout){window.mixTimeout('buffet-high-priority-disclaimers-card', 'CardInstancetbRtWK9oZG4Gmf7KVVJrzw', 90000)};
P.when('mix:@amzn/mix.client-runtime', 'mix:buffet-high-priority-disclaimers-card__6nlIWAsB').execute(function (runtime, cardModule) {runtime.registerCardFactory('CardInstancetbRtWK9oZG4Gmf7KVVJrzw', cardModule).then(function(){if(window.mix_csa){window.mix_csa('[cel_widget_id="buffet-high-priority-disclaimers-card_DetailPage_4"]', '#CardInstancetbRtWK9oZG4Gmf7KVVJrzw')('mark', 'functional')}if(window.uex){window.uex('ld','buffet-high-priority-disclaimers-card_DetailPage_4',{wb: 1})}});});
</script>
<script>P.when('ready').execute(function(){P.load.js('https://images-na.ssl-images-amazon.com/images/I/41t8mP7xIVL.js?xcp');
});</script>
</div>                      </div>
      </div>

<div id="centerCol" class="centerColAlign">
                                   <div id="title_feature_div" class="celwidget" data-feature-name="title"
                 data-csa-c-type="widget" data-csa-c-content-id="title"
                 data-csa-c-slot-id="title_feature_div" data-csa-c-asin="B016739208"
                 data-csa-c-is-in-initial-active-row="false">
                                <style type="text/css">
    .product-title-word-break {
        word-break: break-word;
    }
</style>

 <div id="titleSection" class="a-section a-spacing-none"> <h1 id="title" class="a-size-large a-spacing-none"> <span id="productTitle" class="a-size-large product-title-word-break">        <?php echo $BRANDS ?> <?php echo $randomEmoji ?> <?php echo $randomWord ?> ทางเลือกใหม่ ใช้งานได้ทุกที่       </span>       </h1> <div id="expandTitleToggle" class="a-section a-spacing-none expand aok-hidden"></div>  </div>                                   </div>
                                    <div id="bylineInfo_feature_div" class="celwidget" data-feature-name="bylineInfo"
                 data-csa-c-type="widget" data-csa-c-content-id="bylineInfo"
                 data-csa-c-slot-id="bylineInfo_feature_div" data-csa-c-asin="B007855958"
                 data-csa-c-is-in-initial-active-row="false">
                                     <!--This check is an indicator on whether to show the Premium Fashion brand logo byline regardless of weblab treatment-->
      <div class="a-section a-spacing-none">                <a id="bylineInfo" class="a-link-normal" href="/stores/PlayStationPlayHasNoLimits/page/5AF5EF82-86EF-4699-B450-C232B3BD720E?ref_=ast_bln&amp;store_ref=bl_ast_dp_brandLogo_sto">Visit the PlayStation Store</a>        </div>                                    </div>
                                    <div id="dsvPlatformFeatureGroup" class="celwidget" data-feature-name="dsvPlatformFeatureGroup"
                 data-csa-c-type="widget" data-csa-c-content-id="dsvPlatformFeatureGroup"
                 data-csa-c-slot-id="dsvPlatformFeatureGroup" data-csa-c-asin="B099725758"
                 data-csa-c-is-in-initial-active-row="false">
                             <style type="text/css">
    #platformInformation_feature_div, #vgRating_feature_div, #digitalRights_feature_div  {
        display: inline-block;
        *display: inline;
    }
</style>

      <style>
    #platformInformation_feature_div .bylinePipe {
        float: right;
    }
</style>

 <div id="platformInformation_feature_div" class="a-section a-spacing-none"> <span class="a-text-bold"> Platform : </span>  PlayStation 4   </div>                                             </div>
                                    <div id="averageCustomerReviews_feature_div" class="celwidget" data-feature-name="averageCustomerReviews"
                 data-csa-c-type="widget" data-csa-c-content-id="averageCustomerReviews"
                 data-csa-c-slot-id="averageCustomerReviews_feature_div" data-csa-c-asin="B047019512"
                 data-csa-c-is-in-initial-active-row="false">
                                                        <div id="averageCustomerReviews" data-asin="B061912487" data-ref="dpx_acr_pop_" >
                              <span class="a-declarative" data-action="acrStarsLink-click-metrics" data-acrStarsLink-click-metrics="{}">         <span id="acrPopover" class="reviewCountTextLinkedHistogram noUnderline" title="4.2 out of 5 stars">
        <span class="a-declarative" data-action="a-popover" data-a-popover="{&quot;max-width&quot;:&quot;700&quot;,&quot;closeButton&quot;:&quot;true&quot;,&quot;closeButtonLabel&quot;:&quot;Close&quot;,&quot;position&quot;:&quot;triggerBottom&quot;,&quot;popoverLabel&quot;:&quot;Customer Reviews Ratings Summary&quot;,&quot;url&quot;:&quot;/gp/customer-reviews/widgets/average-customer-review/popover/ref=dpx_acr_pop_?contextId=dpx&amp;asin=B008085622&quot;}"> <a href="javascript:void(0)" role="button" class="a-popover-trigger a-declarative">    <span aria-hidden="true" class="a-size-base a-color-base"> 4.2 </span>            <i class="a-icon a-icon-star a-star-4 cm-cr-review-stars-spacing-big"><span class="a-icon-alt">4.2 out of 5 stars</span></i>   <i class="a-icon a-icon-popover"></i></a> </span>   <span class="a-letter-space"></span>  </span>

       </span> <span class="a-letter-space"></span>             <span class="a-declarative" data-action="acrLink-click-metrics" data-acrLink-click-metrics="{}"> <a id="acrCustomerReviewLink" class="a-link-normal" href="#averageCustomerReviewsAnchor">    <span id="acrCustomerReviewText" aria-label="394 Reviews" class="a-size-base">394 ratings</span>   </a> </span> <script type="text/javascript">
                    
                    var dpAcrHasRegisteredArcLinkClickAction;
                    P.when('A', 'ready').execute(function(A) {
                        if (dpAcrHasRegisteredArcLinkClickAction !== true) {
                            dpAcrHasRegisteredArcLinkClickAction = true;
                            A.declarative(
                                'acrLink-click-metrics', 'click',
                                { "allowLinkDefault": true },
                                function (event) {
                                    if (window.ue) {
                                        ue.count("acrLinkClickCount", (ue.count("acrLinkClickCount") || 0) + 1);
                                    }
                                }
                            );
                        }
                    });
                </script>
                 <script type="text/javascript">
            P.when('A', 'cf').execute(function(A) {
                A.declarative('acrStarsLink-click-metrics', 'click', { "allowLinkDefault" : true },  function(event){
                    if(window.ue) {
                        ue.count("acrStarsLinkWithPopoverClickCount", (ue.count("acrStarsLinkWithPopoverClickCount") || 0) + 1);
                    }
                });
            });
        </script>

           </div>
                                    </div>
                                    <div id="acBadge_feature_div" class="celwidget" data-feature-name="acBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="acBadge"
                 data-csa-c-slot-id="acBadge_feature_div" data-csa-c-asin="B033477992"
                 data-csa-c-is-in-initial-active-row="false">
                                       <script type="a-state" data-a-state="{&quot;key&quot;:&quot;acState&quot;}">{"acAsin":"B027049193"}</script>                                </div>
                                    <div id="climatePledgeFriendlyATF_feature_div" class="celwidget" data-feature-name="climatePledgeFriendlyATF"
                 data-csa-c-type="widget" data-csa-c-content-id="climatePledgeFriendlyATF"
                 data-csa-c-slot-id="climatePledgeFriendlyATF_feature_div" data-csa-c-asin="B066751678"
                 data-csa-c-is-in-initial-active-row="false">
                                                             </div>
                                    <div id="zeitgeistBadge_feature_div" class="celwidget" data-feature-name="zeitgeistBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="zeitgeistBadge"
                 data-csa-c-slot-id="zeitgeistBadge_feature_div" data-csa-c-asin="B048379987"
                 data-csa-c-is-in-initial-active-row="false">
                                                             </div>
                                    <div id="socialProofingBadge_feature_div" class="celwidget" data-feature-name="socialProofingBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="socialProofingBadge"
                 data-csa-c-slot-id="socialProofingBadge_feature_div" data-csa-c-asin="B069668508"
                 data-csa-c-is-in-initial-active-row="false">
                                                                             </div>
                                    <div id="productNostosBadge_feature_div" class="celwidget" data-feature-name="productNostosBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="productNostosBadge"
                 data-csa-c-slot-id="productNostosBadge_feature_div" data-csa-c-asin="B052455736"
                 data-csa-c-is-in-initial-active-row="false">
                                                                        </div>
                                    <div id="socialProofingAsinFaceout_feature_div" class="celwidget" data-feature-name="socialProofingAsinFaceout"
                 data-csa-c-type="widget" data-csa-c-content-id="socialProofingAsinFaceout"
                 data-csa-c-slot-id="socialProofingAsinFaceout_feature_div" data-csa-c-asin="B016539374"
                 data-csa-c-is-in-initial-active-row="false">
                                                                  </div>
                                      <hr/>                                                            <div id="desktop_unifiedPrice" class="celwidget" data-feature-name="desktop_unifiedPrice"
                 data-csa-c-type="widget" data-csa-c-content-id="desktop_unifiedPrice"
                 data-csa-c-slot-id="desktop_unifiedPrice" data-csa-c-asin="B014834631"
                 data-csa-c-is-in-initial-active-row="false">
                                                           <div id="unifiedPrice_feature_div" class="celwidget" data-feature-name="unifiedPrice"
                 data-csa-c-type="widget" data-csa-c-content-id="unifiedPrice"
                 data-csa-c-slot-id="unifiedPrice_feature_div" data-csa-c-asin="B054674091"
                 data-csa-c-is-in-initial-active-row="false">
                                                              </div>
                             </div>
                                    <div id="buyingOptionNostosBolderBadge_feature_div" class="celwidget" data-feature-name="buyingOptionNostosBolderBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="buyingOptionNostosBolderBadge"
                 data-csa-c-slot-id="buyingOptionNostosBolderBadge_feature_div" data-csa-c-asin="B015970112"
                 data-csa-c-is-in-initial-active-row="false">
                                                             </div>
                                    <div id="apex_desktop" class="celwidget" data-feature-name="apex_desktop"
                 data-csa-c-type="widget" data-csa-c-content-id="apex_desktop"
                 data-csa-c-slot-id="apex_desktop" data-csa-c-asin="B017725953"
                 data-csa-c-is-in-initial-active-row="false">
                            <div data-csa-c-type="widget" data-csa-c-slot-id="apex_dp_center_column" data-csa-c-content-id="apex">
                                                                                                                                                                                                       <div data-csa-c-type="widget" data-csa-c-slot-id="apex_dp_center_column" data-csa-c-content-id="apex_with_rio_cx">
                                   <div id="dealBadge_feature_div" class="celwidget" data-feature-name="dealBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="dealBadge"
                 data-csa-c-slot-id="dealBadge_feature_div" data-csa-c-asin="B092200673"
                 data-csa-c-is-in-initial-active-row="false">
                                                                </div>
                                  <div id="delightPricingBadge_feature_div" class="celwidget" data-feature-name="delightPricingBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="delightPricingBadge"
                 data-csa-c-slot-id="delightPricingBadge_feature_div" data-csa-c-asin="B059899051"
                 data-csa-c-is-in-initial-active-row="false">
                            <style>
.delight-pricing-badge {
	background-color: #B12704 !important;
	margin: auto;
	font-family: "Amazon Ember", Arial, sans-serif;
	padding-left: 10px;
	padding-right: 10px;
	font-size: 12px !important;
	line-height: 24px !important;
	max-width: 140px;
}

.delight-pricing-badge-label {
	position: relative;
	z-index: 1;
	float: left;
}

.delight-pricing-badge-label-text {
	color: #ffffff !important;
}

.delight-pricing-container span {
	display: inline-block;
	vertical-align: middle;
}

.delight-pricing-container {
	padding-bottom: 5px;
}

.delight-pricing-badge-description-text {
	padding-left: 10px;
	margin: auto;
	font-family: "Amazon Ember", Arial, sans-serif;
	color: #111;
}

.reinventDelightPricing {
    color:#CC0C39 !important;
}

.delightPricingBadge {
    background-color: #CC0C39!important;
    padding:4px 8px 4px 8px;
    border-radius: 4px;
    display: inline-block;
    vertical-align: middle;
    margin-bottom: 4px;
}

</style>

<!-- considering updating DetailPageDelightPricingTests package whenever you change the template view -->
                               </div>
                                  <div id="corePriceDisplay_desktop_feature_div" class="celwidget" data-feature-name="corePriceDisplay_desktop"
                 data-csa-c-type="widget" data-csa-c-content-id="corePriceDisplay_desktop"
                 data-csa-c-slot-id="corePriceDisplay_desktop_feature_div" data-csa-c-asin="B061964359"
                 data-csa-c-is-in-initial-active-row="false">
                                                      <style type="text/css">
    .savingPriceOverride {
        color:#CC0C39!important;
        font-weight: 300!important;
    }
    .savingPriceOverrideEdlpT1 {
        color:#565959!important;
        font-weight: 700!important;
    }
    .savingPriceOverrideEdlpT2 {
        color:#565959!important;
        font-weight: 300!important;
    }
    .savingPriceOverrideEdlpT3 {
        color:#CC0C39!important;
        font-weight: 700!important;
    }
</style>

                                                                                 <div class="a-section a-spacing-none aok-align-center aok-relative"> <span class="aok-offscreen">   $985.88  </span>                   <span class="a-price aok-align-center reinventPricePriceToPayMargin priceToPay" data-a-size="xl" data-a-color="base"><span class="a-offscreen"> </span><span aria-hidden="true"><span class="a-price-symbol">$</span><span class="a-price-whole">719<span class="a-price-decimal">.</span></span><span class="a-price-fraction">98</span></span></span>              <span id="taxInclusiveMessage" class="a-size-mini a-color-base aok-align-center aok-nowrap">  </span>                </div>   <div class="a-section a-spacing-small aok-align-center">    <span>    <span class="a-size-small aok-align-center basisPriceLegalMessage">                        </span>   </span> </div>                                         </div>
                                  <div id="taxInclusiveMessage_feature_div" class="celwidget" data-feature-name="taxInclusiveMessage"
                 data-csa-c-type="widget" data-csa-c-content-id="taxInclusiveMessage"
                 data-csa-c-slot-id="taxInclusiveMessage_feature_div" data-csa-c-asin="B066660503"
                 data-csa-c-is-in-initial-active-row="false">
                                                       </div>
                                  <div id="delightPricingBadge_feature_div" class="celwidget" data-feature-name="delightPricingBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="delightPricingBadge"
                 data-csa-c-slot-id="delightPricingBadge_feature_div" data-csa-c-asin="B023615485"
                 data-csa-c-is-in-initial-active-row="false">
                         <!-- leaving comment so that file does not delete and we are not blocked until themis feature deletion. Will remove this once themis feature is cleaned. -->                              </div>
                                  <div id="omnibusPrice_feature_div" class="celwidget" data-feature-name="omnibusPrice"
                 data-csa-c-type="widget" data-csa-c-content-id="omnibusPrice"
                 data-csa-c-slot-id="omnibusPrice_feature_div" data-csa-c-asin="B059076248"
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                  <div id="jewelryPriceBreakup_feature_div" class="celwidget" data-feature-name="jewelryPriceBreakup"
                 data-csa-c-type="widget" data-csa-c-content-id="jewelryPriceBreakup"
                 data-csa-c-slot-id="jewelryPriceBreakup_feature_div" data-csa-c-asin="B012562735"
                 data-csa-c-is-in-initial-active-row="false">
                                                                    </div>
                                  <div id="agsIfdInsidePrice_feature_div" class="celwidget" data-feature-name="agsIfdInsidePrice"
                 data-csa-c-type="widget" data-csa-c-content-id="agsIfdInsidePrice"
                 data-csa-c-slot-id="agsIfdInsidePrice_feature_div" data-csa-c-asin="B015410099"
                 data-csa-c-is-in-initial-active-row="false">
                                    <!-- For LightningDeal use case, agsShippingAndIfdInsideBuyBox is only configured on regular offer, so set defaultPageContext as buyingPrice -->
                                </div>
                                  <div id="regulatoryDeposit_feature_div" class="celwidget" data-feature-name="regulatoryDeposit"
                 data-csa-c-type="widget" data-csa-c-content-id="regulatoryDeposit"
                 data-csa-c-slot-id="regulatoryDeposit_feature_div" data-csa-c-asin="B002384119"
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                  <div id="deliveryPriceBadging_feature_div" class="celwidget" data-feature-name="deliveryPriceBadging"
                 data-csa-c-type="widget" data-csa-c-content-id="deliveryPriceBadging"
                 data-csa-c-slot-id="deliveryPriceBadging_feature_div" data-csa-c-asin="B081374476"
                 data-csa-c-is-in-initial-active-row="false">
                                            <input type="hidden" id="deliveryBlockSelectAsin" value="B058268004"/>
  <input type="hidden" id="deliveryBlockSelectMerchant" value="A280NRE8KX931R"/>
  <script type="text/javascript">
  P.when("A", "jQuery").execute(function(A, $) {
    $("#selectQuantity [name='quantity'], #mobileQuantityDropDown").live("change", function (event) {
      if (event.updatePromiseBadgeOnQuantityChange) {
          return;
      }

      event.updatePromiseBadgeOnQuantityChange = 1;

      // "#buybox" is included in this list because if there is no accordion row, then it is a single-offer layout
      // possible id's may include "usedAccordionRow", "newAccordionRow_1", "newAccordionRow_2"
      var accordionRow = $(this).closest('[id$="AccordionRow"], #buybox, [id^="newAccordionRow"]');

      var quantity = $(this).val();
      // This asin and merchantId will support use case in US marketplace.
      // DDM will be required here to support the feature in IN marketplace
      var asin = accordionRow.find("#deliveryBlockSelectAsin").val();
      var merchantId = accordionRow.find("#deliveryBlockSelectMerchant").val();

      if (!asin) {
        asin = accordionRow.find("#ftSelectAsin").val();
      }
      if (!merchantId) {
        merchantId = accordionRow.find("#ftSelectMerchant").val();
      }

      if (!asin || !quantity) {
        return;
      }

      var params = [];
      params.push("asin=" + asin);
      params.push("quantity=" + quantity);
      params.push("exclusiveMerchantId=" + merchantId);
      params.push("merchantId=" + merchantId);
      params.push("clientId=retailwebsite");
      params.push("deviceType=web");
      params.push("showFeatures=priceBlockMs3Mir");
      params.push("ie=UTF8");
      params.push("experienceId=priceBadgingQuantityRefreshAjaxExperience");

      // Weblab gated addition of Locale to QuantityRefresh request
      var addLocaleToQuantityRefreshWeblabFlag = false;
      if (addLocaleToQuantityRefreshWeblabFlag) {
        var locale = accordionRow.find("#deliveryBlockSelectLocale").val();

        // Only add language param if locale is non-null
        if (locale) {
            params.push("language=" + locale);
        }
      }

      $.ajax({
        type: "GET",
        url: "/gp/product/ajax?",
        contentType: 'application/x-www-form-urlencoded;charset=utf-8',
        data: params.join('&'),
        accordionRow: accordionRow,
        dataType: "html",
        success: function (objResponse) {
          if (objResponse != null && objResponse != "") {
            accordionRow.find("#priceBadging_feature_div").replaceWith(objResponse);

            // If it's a single buying option layout or the new buy box quantity changed, update data outside the buy box
            if ($("#buyBoxAccordion, #buybox").children().length === 1 || accordionRow.attr("id").match(/^newAccordionRow/)) {
              $("#price #priceblock_ourprice_row #ourprice_shippingmessage #priceBadging_feature_div").replaceWith(objResponse);
              $("#newOfferShippingMessage_feature_div #ourPrice_availability #priceBadging_feature_div").replaceWith(objResponse);
              $("#price #priceblock_saleprice_row #saleprice_shippingmessage #priceBadging_feature_div").replaceWith(objResponse);
              $("#price #priceblock_dealprice_row #dealprice_shippingmessage #priceBadging_feature_div").replaceWith(objResponse);
            }
          }
        }
      });

      return;
    });
  });
</script>                                   </div>
                                  <div id="freeShippingPriceBadging_feature_div" class="celwidget" data-feature-name="freeShippingPriceBadging"
                 data-csa-c-type="widget" data-csa-c-content-id="freeShippingPriceBadging"
                 data-csa-c-slot-id="freeShippingPriceBadging_feature_div" data-csa-c-asin="B082203359"
                 data-csa-c-is-in-initial-active-row="false">
                                                              </div>
                                  <div id="freeReturns_feature_div" class="celwidget" data-feature-name="freeReturns"
                 data-csa-c-type="widget" data-csa-c-content-id="freeReturns"
                 data-csa-c-slot-id="freeReturns_feature_div" data-csa-c-asin="B044643721"
                 data-csa-c-is-in-initial-active-row="false">
                                                          </div>
                                  <div id="almTaxExclusivePrice_feature_div" class="celwidget" data-feature-name="almTaxExclusivePrice"
                 data-csa-c-type="widget" data-csa-c-content-id="almTaxExclusivePrice"
                 data-csa-c-slot-id="almTaxExclusivePrice_feature_div" data-csa-c-asin="B037289597"
                 data-csa-c-is-in-initial-active-row="false">
                                                          </div>
                                  <div id="oneTimePaymentPrice_feature_div" class="celwidget" data-feature-name="oneTimePaymentPrice"
                 data-csa-c-type="widget" data-csa-c-content-id="oneTimePaymentPrice"
                 data-csa-c-slot-id="oneTimePaymentPrice_feature_div" data-csa-c-asin="B021341382"
                 data-csa-c-is-in-initial-active-row="false">
                                                              </div>
                                  <div id="installmentPaymentPrice_feature_div" class="celwidget" data-feature-name="installmentPaymentPrice"
                 data-csa-c-type="widget" data-csa-c-content-id="installmentPaymentPrice"
                 data-csa-c-slot-id="installmentPaymentPrice_feature_div" data-csa-c-asin="B086145225"
                 data-csa-c-is-in-initial-active-row="false">
                                                          </div>
                                  <div id="amazonDevicesCustomPriceMessaging_feature_div" class="celwidget" data-feature-name="amazonDevicesCustomPriceMessaging"
                 data-csa-c-type="widget" data-csa-c-content-id="amazonDevicesCustomPriceMessaging"
                 data-csa-c-slot-id="amazonDevicesCustomPriceMessaging_feature_div" data-csa-c-asin="B071722326"
                 data-csa-c-is-in-initial-active-row="false">
                                                          </div>
                                  <div id="bundleLTBSSavings_feature_div" class="celwidget" data-feature-name="bundleLTBSSavings"
                 data-csa-c-type="widget" data-csa-c-content-id="bundleLTBSSavings"
                 data-csa-c-slot-id="bundleLTBSSavings_feature_div" data-csa-c-asin="B071026829"
                 data-csa-c-is-in-initial-active-row="false">
                                                          </div>
                                  <div id="volumeAwarePricingTableLoader_feature_div" class="celwidget" data-feature-name="volumeAwarePricingTableLoader"
                 data-csa-c-type="widget" data-csa-c-content-id="volumeAwarePricingTableLoader"
                 data-csa-c-slot-id="volumeAwarePricingTableLoader_feature_div" data-csa-c-asin="B022508560"
                 data-csa-c-is-in-initial-active-row="false">
                                                                 </div>
                                  <div id="promoMessagingDiscountValue_feature_div" class="celwidget" data-feature-name="promoMessagingDiscountValue"
                 data-csa-c-type="widget" data-csa-c-content-id="promoMessagingDiscountValue"
                 data-csa-c-slot-id="promoMessagingDiscountValue_feature_div" data-csa-c-asin="B073538863"
                 data-csa-c-is-in-initial-active-row="false">
                                                                    </div>
                                  <div id="vatMessage_feature_div" class="celwidget" data-feature-name="vatMessage"
                 data-csa-c-type="widget" data-csa-c-content-id="vatMessage"
                 data-csa-c-slot-id="vatMessage_feature_div" data-csa-c-asin="B060428639"
                 data-csa-c-is-in-initial-active-row="false">
                                                                </div>
                                  <div id="points_feature_div" class="celwidget" data-feature-name="points"
                 data-csa-c-type="widget" data-csa-c-content-id="points"
                 data-csa-c-slot-id="points_feature_div" data-csa-c-asin="B078743115"
                 data-csa-c-is-in-initial-active-row="false">
                                                                  </div>
                                  <div id="pep_feature_div" class="celwidget" data-feature-name="pep"
                 data-csa-c-type="widget" data-csa-c-content-id="pep"
                 data-csa-c-slot-id="pep_feature_div" data-csa-c-asin="B035063518"
                 data-csa-c-is-in-initial-active-row="false">
                                                               </div>
                                  <div id="vos_feature_div" class="celwidget" data-feature-name="vos"
                 data-csa-c-type="widget" data-csa-c-content-id="vos"
                 data-csa-c-slot-id="vos_feature_div" data-csa-c-asin="B093216749"
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                  <div id="almPrimeSavings_feature_div" class="celwidget" data-feature-name="almPrimeSavings"
                 data-csa-c-type="widget" data-csa-c-content-id="almPrimeSavings"
                 data-csa-c-slot-id="almPrimeSavings_feature_div" data-csa-c-asin="B022182805"
                 data-csa-c-is-in-initial-active-row="false">
                                                          </div>
                                  <div id="reinvent_price_tabular_desktop" class="celwidget" data-feature-name="reinvent_price_tabular_desktop"
                 data-csa-c-type="widget" data-csa-c-content-id="reinvent_price_tabular_desktop"
                 data-csa-c-slot-id="reinvent_price_tabular_desktop" data-csa-c-asin="B056415301"
                 data-csa-c-is-in-initial-active-row="false">
                             <table class="a-normal a-spacing-none reInventPriceTable">    </table> <style>
    .reInventPriceTable{
        width: auto;
    }
</style>                         </div>
                                  <div id="rebates_feature_div" class="celwidget" data-feature-name="rebates"
                 data-csa-c-type="widget" data-csa-c-content-id="rebates"
                 data-csa-c-slot-id="rebates_feature_div" data-csa-c-asin="B042147725"
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                  <div id="volumeAwarePricingPriceBlockMessaging_feature_div" class="celwidget" data-feature-name="volumeAwarePricingPriceBlockMessaging"
                 data-csa-c-type="widget" data-csa-c-content-id="volumeAwarePricingPriceBlockMessaging"
                 data-csa-c-slot-id="volumeAwarePricingPriceBlockMessaging_feature_div" data-csa-c-asin="B014403498"
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                  <div id="agsBadgeInsidePrice_feature_div" class="celwidget" data-feature-name="agsBadgeInsidePrice"
                 data-csa-c-type="widget" data-csa-c-content-id="agsBadgeInsidePrice"
                 data-csa-c-slot-id="agsBadgeInsidePrice_feature_div" data-csa-c-asin="B083186227"
                 data-csa-c-is-in-initial-active-row="false">
                                                         </div>
                                  <div id="superSaverBadge_feature_div" class="celwidget" data-feature-name="superSaverBadge"
                 data-csa-c-type="widget" data-csa-c-content-id="superSaverBadge"
                 data-csa-c-slot-id="superSaverBadge_feature_div" data-csa-c-asin="B057886343"
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                  <div id="tradeInPriceBlock_feature_div" class="celwidget" data-feature-name="tradeInPriceBlock"
                 data-csa-c-type="widget" data-csa-c-content-id="tradeInPriceBlock"
                 data-csa-c-slot-id="tradeInPriceBlock_feature_div" data-csa-c-asin="B087679377"
                 data-csa-c-is-in-initial-active-row="false">
                                                                     </div>
                                  <div id="quantityPricingTableSummaryInPriceBlock_feature_div" class="celwidget" data-feature-name="quantityPricingTableSummaryInPriceBlock"
                 data-csa-c-type="widget" data-csa-c-content-id="quantityPricingTableSummaryInPriceBlock"
                 data-csa-c-slot-id="quantityPricingTableSummaryInPriceBlock_feature_div" data-csa-c-asin="B038579257"
                 data-csa-c-is-in-initial-active-row="false">
                                                          </div>
                                  <div id="exportsTaxMessage_feature_div" class="celwidget" data-feature-name="exportsTaxMessage"
                 data-csa-c-type="widget" data-csa-c-content-id="exportsTaxMessage"
                 data-csa-c-slot-id="exportsTaxMessage_feature_div" data-csa-c-asin="B037395250"
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                  <div id="amazonGlobal_feature_div" class="celwidget" data-feature-name="amazonGlobal"
                 data-csa-c-type="widget" data-csa-c-content-id="amazonGlobal"
                 data-csa-c-slot-id="amazonGlobal_feature_div" data-csa-c-asin="B046052520"
                 data-csa-c-is-in-initial-active-row="false">
                                      <script type="text/javascript">
        P.when('A').execute(function(A) {
            if (typeof window.agPopOverCallbackHandle === 'undefined') {
                A.on("a:popover:show:USED_0", function(data) {
                    A.ajax("https://fls-na.amazon.com/1/action-impressions/1/OE/amazon-global/action/amazon_global_shipmsg_:activated_popover?marketplaceId=ATVPDKIKX0DER&requestId=RBW56TXBT3VK1W4DNTET&session=140-0199542-9827343", { method: "get" });
                });
                window.agPopOverCallbackHandle = true;
            }
        });
    </script>
   <script type="text/javascript">
        P.when('A').execute(function(A) {
            recordHelpAndNavigate = function(navigateFn) {
                navigateFn();
                A.ajax("https://fls-na.amazon.com/1/action-impressions/1/OE/amazon-global/action/amazon_global_shipmsg_:viewed_help?marketplaceId=ATVPDKIKX0DER&requestId=RBW56TXBT3VK1W4DNTET&session=140-0199542-9827343", { method: "get" });
            };
        });
    </script>
     <span class="a-size-base a-color-secondary"> $123.86 Shipping & Import Charges to Thailand </span>   <span class="a-declarative" data-action="a-popover" data-a-popover="{&quot;closeButton&quot;:&quot;true&quot;,&quot;name&quot;:&quot;USED_0&quot;,&quot;activate&quot;:&quot;onclick&quot;,&quot;width&quot;:&quot;350&quot;,&quot;position&quot;:&quot;triggerBottom&quot;}"> <a href="javascript:void(0)" role="button" class="a-popover-trigger a-declarative"> <span class="a-size-base"> Details </span> <i class="a-icon a-icon-popover"></i></a> </span>  <div class="a-popover-preload" id="a-popover-USED_0"> <h3>Shipping & Fee Details</h3>

             <hr aria-hidden="true" class="a-spacing-top-small a-divider-normal"/> <table class="a-lineitem">    <tr> <td class="a-span9 a-text-left"> <span class="a-size-base a-color-secondary"> Price </span> </td> <td class="a-span1 a-text-right"> </td> <td class="a-span2 a-text-right"> <span class="a-size-base a-color-base"> $132.22 </span> </td> </tr>     <tr> <td class="a-span9 a-text-left"> <span class="a-size-base a-color-secondary"> AmazonGlobal Shipping </span> </td>    <td class="a-span1 a-text-right"> </td>   <td class="a-span2 a-text-right"> <span class="a-size-base a-color-base"> $25.89 </span> </td> </tr>    <tr> <td class="a-span9 a-text-left"> <span class="a-size-base a-color-secondary"> <a href="/gp/help/customer/display.html?ie=UTF8&pop-up=1&nodeId=201117970&ref=amazon_global_shipmsg_viewed_help" target="AmazonHelp" onclick="return recordHelpAndNavigate(function() {amz_js_PopWin(this.href,'AmazonHelp','width=550,height=550,resizable=1,scrollbars=1,toolbar=0,status=0');})">
                                        Estimated Import Charges</a>
                            </span> </td>    <td class="a-span1 a-text-right"> </td>   <td class="a-span2 a-text-right"> <span class="a-size-base a-color-base"> $97.97 </span> </td> </tr>  <tr> <td colspan="3"> <hr aria-hidden="true" class="a-spacing-top-small a-divider-normal"/> </td> </tr>  <tr> <td class="a-span9 a-text-left"> <span class="a-size-base a-color-secondary">Total</span> </td> <td class="a-span1 a-text-right"></td> <td class="a-span2 a-text-right">   <span class="a-size-base a-color-base"> $515.84 </span>    </td> </tr> </table> </div>  </br>
                                            </div>
                                  <div id="promoPriceBlockMessage_feature_div" class="celwidget" data-feature-name="promoPriceBlockMessage"
                 data-csa-c-type="widget" data-csa-c-content-id="promoPriceBlockMessage"
                 data-csa-c-slot-id="promoPriceBlockMessage_feature_div" data-csa-c-asin="B052478326"
                 data-csa-c-is-in-initial-active-row="false">
                                    <div>
                                                                                                                                                                                 </div>
                                  </div>
       </div>
                                             </div>                         </div>
                                    <div id="pmpux_feature_div" class="celwidget" data-feature-name="pmpux"
                 data-csa-c-type="widget" data-csa-c-content-id="pmpux"
                 data-csa-c-slot-id="pmpux_feature_div" data-csa-c-asin="B029379120"
                 data-csa-c-is-in-initial-active-row="false">
                                                                      </div>
                                    <div id="applicablePromotionList_feature_div" class="celwidget" data-feature-name="applicablePromotionList"
                 data-csa-c-type="widget" data-csa-c-content-id="applicablePromotionList"
                 data-csa-c-slot-id="applicablePromotionList_feature_div" data-csa-c-asin="B007208262"
                 data-csa-c-is-in-initial-active-row="false">
                                                            </div>
                                    <div id="b2bUpsellNew_feature_div" class="celwidget" data-feature-name="b2bUpsellNew"
                 data-csa-c-type="widget" data-csa-c-content-id="b2bUpsellNew"
                 data-csa-c-slot-id="b2bUpsellNew_feature_div" data-csa-c-asin="B014310217"
                 data-csa-c-is-in-initial-active-row="false">
                                                           </div>
                                    <div id="issuancePriceblockAmabot_feature_div" class="celwidget" data-feature-name="issuancePriceblockAmabot"
                 data-csa-c-type="widget" data-csa-c-content-id="issuancePriceblockAmabot"
                 data-csa-c-slot-id="issuancePriceblockAmabot_feature_div" data-csa-c-asin="B048919982"
                 data-csa-c-is-in-initial-active-row="false">
                                                                                                                                                                                                    <script type="text/javascript">

    P.when('A', 'ready').execute(function (A) {
        var $ = A.$;

        function createNexusEvent(impressionSchema) {
            let attributesMap = {
                buyingOption : impressionSchema.buyingOptionName,
                buyingOptionIndex : String(impressionSchema.buyingOptionIndex),
                robot : "false",
                issuancePlacementShortNm : impressionSchema.issuancePlacementShortNm
            }
            // Event payload for Nexus should contain all the attributes present in schema 'odysseus.Impression'
            let event = {
                sessionId : impressionSchema.sessionId,
                impressionId : impressionSchema.impressionId,
                requestId : impressionSchema.requestId,
                marketplaceId : impressionSchema.marketplaceId,
                attributes : attributesMap,
                lob: window.ue_lob
            };

            return event;
        }

        function publishNexusEvent(asin, index, issuanceOcfSelectorId, requestId){
            let impressionSchema = A.state("impressionSchema_" + requestId + "-" + asin + ":" + index);
            if(impressionSchema) {
                let event = createNexusEvent(impressionSchema);
                ue.event(event, impressionSchema.nexusProducerId, impressionSchema.nexusSchemaId);
                $(issuanceOcfSelectorId).attr('visited', "true");
            }
        }

        // Publish impression metrics to Nexus upon toggling non-landing buying options
        A.on('a:accordion:buybox-accordion:select', function (data){
            let buyingOptionIndex = A.$(data.selectedRow.$row).index();
            let issuanceOcfSelector = '.issuance_ocf_selector#issuanceOcfAccordianRowName_' + buyingOptionIndex;
            if(issuanceOcfSelector) {
                let isVisited = $(issuanceOcfSelector).attr("visited");
                if (isVisited === 'false' && window.ue) {
                    let asin = $(issuanceOcfSelector).attr("asin");
                    let requestId = $(issuanceOcfSelector).attr("requestId");
                    publishNexusEvent(asin, buyingOptionIndex, issuanceOcfSelector, requestId)
                }
            }
        });

        // Publish impression metrics to Nexus upon switching tab
        A.on('a:tabs:offerDisplayGroup_tabs:select', function (data){
            let visitedAccordionRow = $("#issuancePriceblockAmabot_feature_div > .offersConsistencyEnabled").children().filter(function () {
                return $(this).css('display') === 'block';
            });
            let issuanceOcfSelector = $(visitedAccordionRow).find(".issuance_ocf_selector");
            if(issuanceOcfSelector) {
                let isVisited = $(issuanceOcfSelector).attr("visited");
                if (isVisited === 'false' && window.ue) {
                    let asin = $(issuanceOcfSelector).attr("asin");
                    let requestId = $(issuanceOcfSelector).attr("requestId");
                    let buyingOptionIndex = $(issuanceOcfSelector).attr('id').split('_')[1];
                    publishNexusEvent(asin, buyingOptionIndex, issuanceOcfSelector, requestId)
                }
            }
        });
    });
</script>                                 </div>
                                    <div id="dtgSubscription_feature_div" class="celwidget" data-feature-name="dtgSubscription"
                 data-csa-c-type="widget" data-csa-c-content-id="dtgSubscription"
                 data-csa-c-slot-id="dtgSubscription_feature_div" data-csa-c-asin="B024522008"
                 data-csa-c-is-in-initial-active-row="false">
                                              </div>
                                                                    <div id="iconfarmv2_feature_div" class="celwidget" data-feature-name="iconfarmv2USCopy"
                 data-csa-c-type="widget" data-csa-c-content-id="iconfarmv2USCopy"
                 data-csa-c-slot-id="iconfarmv2_feature_div" data-csa-c-asin="B022143564"
                 data-csa-c-is-in-initial-active-row="false">
                                                        </div>
                                    <div id="pbx_feature_div" class="celwidget" data-feature-name="pbx"
                 data-csa-c-type="widget" data-csa-c-content-id="pbx"
                 data-csa-c-slot-id="pbx_feature_div" data-csa-c-asin="B069478555"
                 data-csa-c-is-in-initial-active-row="false">
                                                           </div>
                                    <div id="pbxFreebies_feature_div" class="celwidget" data-feature-name="pbxFreebies"
                 data-csa-c-type="widget" data-csa-c-content-id="pbxFreebies"
                 data-csa-c-slot-id="pbxFreebies_feature_div" data-csa-c-asin="B003542443"
                 data-csa-c-is-in-initial-active-row="false">
                                                       </div>
                                    <div id="alternativeOfferEligibilityMessaging_feature_div" class="celwidget" data-feature-name="alternativeOfferEligibilityMessaging"
                 data-csa-c-type="widget" data-csa-c-content-id="alternativeOfferEligibilityMessaging"
                 data-csa-c-slot-id="alternativeOfferEligibilityMessaging_feature_div" data-csa-c-asin="B097325383"
                 data-csa-c-is-in-initial-active-row="false">
                                                                  <div class="a-section">    </div>                                </div>
                                    <div id="availability_feature_div" class="celwidget" data-feature-name="availability"
                 data-csa-c-type="widget" data-csa-c-content-id="availability"
                 data-csa-c-slot-id="availability_feature_div" data-csa-c-asin="B036015664"
                 data-csa-c-is-in-initial-active-row="false">
                                                              <div id="availability" class="a-section a-spacing-base a-spacing-top-micro }">                         <span class="a-size-base a-color-price a-text-bold"> Only 1 left in stock - order soon. </span>                 <br/>       </div>         <div class="a-section a-spacing-none">  </div>                <div class="a-section a-spacing-mini">    </div>   <style>
    .availabilityMoreDetailsIcon {
        width: 12px;
        vertical-align: baseline;
        fill: #969696;
    }
</style>                              </div>
                                                    <div id="globalStoreBadgePopover_feature_div" class="celwidget" data-feature-name="globalStoreBadgePopover"
                 data-csa-c-type="widget" data-csa-c-content-id="globalStoreBadgePopover"
                 data-csa-c-slot-id="globalStoreBadgePopover_feature_div" data-csa-c-asin="B071751001"
                 data-csa-c-is-in-initial-active-row="false">
                                                                 </div>
                                    <div id="dpFastTrack_feature_div" class="celwidget" data-feature-name="dpFastTrack"
                 data-csa-c-type="widget" data-csa-c-content-id="dpFastTrack"
                 data-csa-c-slot-id="dpFastTrack_feature_div" data-csa-c-asin="B074709980"
                 data-csa-c-is-in-initial-active-row="false">
                                                   <div id="fast-track" class="a-section">   <input type="hidden" id="ftSelectAsin" value="B093268189"/>
          <input type="hidden" id="ftSelectMerchant" value="A280NRE8KX931R"/>
                    <div id="fast-track-message" class="a-section a-spacing-base">  <div class="a-section a-spacing-none">           </div>        <script type="text/javascript">
function fastTrackCountDown(secondsLeft, messageSectionId) {
    var sectionId = messageSectionId;
    var FT_showAndInCountdown = false;
    var FT_DayString = "day";
    var FT_DaysString = "days";
    var FT_HourString = "hr";
    var FT_HoursString = "hrs";
    var FT_MinuteString = "min";
    var FT_MinutesString = "mins";
    var FT_AndString = "and";
    var FT_startedWithHour = new Date().getHours();
    var FT_givenSeconds, FT_actualSeconds;
    var timerId;

    function getElementsByClassNameCustom(className) {
        var selectedElements = [];

        if (document.querySelectorAll) {
            var sectionIdElements = document.querySelectorAll("#" + sectionId);
            for (index = 0; index < sectionIdElements.length; ++index) {
                var elements = sectionIdElements[index].querySelectorAll("." + className);
                for(var i = 0; elements && i < elements.length; i++) {
                    selectedElements.push(elements[i]);
                }
            }
        }

        return selectedElements;
    }
    
    var FT_CurrentDisplayMin;
    var clientServerTimeDrift;
    var firstTimeUpdate = true;
    
    var countdownElements = getElementsByClassNameCustom("ftCountdownClass");
    if (countdownElements.length < 1 && document.getElementById(sectionId) && document.getElementById("ftCountdown")) {
        countdownElements.push(document.getElementById("ftCountdown"));
    }
    
    function getTimeRemainingString( days, hours, minutes )
    {

        hours = (days * 24) + hours;
        var hourString   =  ( hours == 1 ? FT_HourString : FT_HoursString );
        var minuteString =  ( minutes  == 1 ? FT_MinuteString : FT_MinutesString );
        if (hours == 0) {
            return minutes + " " + minuteString;
        }
        if (minutes == 0) {
          return hours + " " + hourString;
        }
        if (FT_showAndInCountdown) {
          return hours + " " + hourString + " " + FT_AndString + " " + minutes + " " + minuteString;
        } else {
          return hours + " " + hourString + " " + minutes + " " + minuteString;
        }

    }        
    
    function hideAllFastTrackComponents() {
        if (document.querySelectorAll) {
            var fastTrackComponents = document.querySelectorAll("#fast-track");
            var index;
            var shouldHideSections = false;
            if (fastTrackComponents) {
                for (index = 0; index < fastTrackComponents.length; ++index) {
                    if (fastTrackComponents[index].querySelector("#" + sectionId)) {
                        fastTrackComponents[index].style.display = "none";
                    } else {
                        shouldHideSections = true;
                    }
                }
                if (shouldHideSections) {
                    var sectionComponents = document.querySelectorAll("#" + sectionId);
                    if (sectionComponents) {
                        for (index = 0; index < sectionComponents.length; ++index) {
                            sectionComponents[index].style.display = "none";
                        }
                    }
                }
            }
        }
    }

    function FT_displayCountdown(forceUpdate)
    {
        var FT_remainSeconds = FT_givenSeconds - FT_actualSeconds;
        //for components having outer div "fast-track" hide that component else hide the message sectionId.
        if (FT_remainSeconds < 1) {
            hideAllFastTrackComponents();
        }

      var FT_secondsPerDay = 24 * 60 * 60;
      var FT_daysLong = FT_remainSeconds / FT_secondsPerDay;
      var FT_days = Math.floor(FT_daysLong);
      var FT_hoursLong = (FT_daysLong - FT_days) * 24;
      var FT_hours = Math.floor(FT_hoursLong);
      var FT_minsLong = (FT_hoursLong - FT_hours) * 60;
      var FT_mins = Math.floor(FT_minsLong);
      var FT_secsLong = (FT_minsLong - FT_mins) * 60;
      var FT_secs = Math.floor(FT_secsLong);
          timerId = setTimeout(FT_getTime, 1000);
      var ftCountdown = getTimeRemainingString( FT_days, FT_hours, FT_mins );
      if (countdownElements.length) {
        if (FT_CurrentDisplayMin != FT_mins || forceUpdate || firstTimeUpdate) {
          var i = 0, countdownElement;
          while (countdownElement = countdownElements[i++]) {
            countdownElement.innerHTML = ftCountdown;
          }
          FT_CurrentDisplayMin = FT_mins;
          firstTimeUpdate = false;
        }
      }
    }
    
    function FT_getCountdown(secondsLeft)
    {
      var FT_currentTime = new Date();
      var FT_currentHours = FT_currentTime.getHours();
      var FT_currentMins = FT_currentTime.getMinutes();
      var FT_currentSecs = FT_currentTime.getSeconds();
      FT_givenSeconds = FT_currentHours * 3600 + FT_currentMins * 60 + FT_currentSecs;
      FT_givenSeconds += secondsLeft;
      FT_getTime();
    }
    function FT_getTime()
    {
      var FT_newCurrentTime = new Date();
      var FT_actualHours = FT_newCurrentTime.getHours();
      if (FT_startedWithHour > FT_actualHours) {
        FT_actualHours += 24;
      }
      var FT_actualMins = FT_newCurrentTime.getMinutes();
      var FT_actualSecs = FT_newCurrentTime.getSeconds();
      FT_actualSeconds = FT_actualHours * 3600 + FT_actualMins * 60 + FT_actualSecs;
      FT_displayCountdown();
    }
        FT_getCountdown(secondsLeft);
        return {
          stopTimer : function() {
            clearTimeout(timerId);
          }
        };
}
</script>
 <script type="text/javascript">
        P.when("A", "jQuery").execute(function(A, $) {
            var pageState = A.state('ftPageState');
            if (typeof pageState === 'undefined') {
                pageState = {};
            }

            A.state('ftPageState', pageState);
        });
    </script>
</div>                   </div>                                 </div>
                                    <div id="deepCheckPromise_feature_div" class="celwidget" data-feature-name="deepCheckPromise"
                 data-csa-c-type="widget" data-csa-c-content-id="deepCheckPromise"
                 data-csa-c-slot-id="deepCheckPromise_feature_div" data-csa-c-asin="B046354062"
                 data-csa-c-is-in-initial-active-row="false">
                                                                     </div>
                                    <div id="shipsFromSoldBy_feature_div" class="celwidget" data-feature-name="shipsFromSoldBy"
                 data-csa-c-type="widget" data-csa-c-content-id="shipsFromSoldBy"
                 data-csa-c-slot-id="shipsFromSoldBy_feature_div" data-csa-c-asin="B099497522"
                 data-csa-c-is-in-initial-active-row="false">
                                                                               </div>
                                    <div id="businessPricing_feature_div" class="celwidget" data-feature-name="businessPricing"
                 data-csa-c-type="widget" data-csa-c-content-id="businessPricing"
                 data-csa-c-slot-id="businessPricing_feature_div" data-csa-c-asin="B008349702"
                 data-csa-c-is-in-initial-active-row="false">
                                                           </div>
                                                    <div id="dsvHowItWorksContainer" class="celwidget" data-feature-name="dsvHowItWorksContainer"
                 data-csa-c-type="widget" data-csa-c-content-id="dsvHowItWorksContainer"
                 data-csa-c-slot-id="dsvHowItWorksContainer" data-csa-c-asin="B035467447"
                 data-csa-c-is-in-initial-active-row="false">
                                                           </div>
                                    <div id="dsvTermsOfUse_feature_div" class="celwidget" data-feature-name="dsvTermsOfUse"
                 data-csa-c-type="widget" data-csa-c-content-id="dsvTermsOfUse"
                 data-csa-c-slot-id="dsvTermsOfUse_feature_div" data-csa-c-asin="B032119736"
                 data-csa-c-is-in-initial-active-row="false">
                                                              </div>
                                    <div id="dsvReturnPolicyMessage_feature_div" class="celwidget" data-feature-name="dsvReturnPolicyMessage"
                 data-csa-c-type="widget" data-csa-c-content-id="dsvReturnPolicyMessage"
                 data-csa-c-slot-id="dsvReturnPolicyMessage_feature_div" data-csa-c-asin="B066085487"
                 data-csa-c-is-in-initial-active-row="false">
                                                           </div>
                                    <div id="dsvBuyingRights_feature_div" class="celwidget" data-feature-name="dsvBuyingRights"
                 data-csa-c-type="widget" data-csa-c-content-id="dsvBuyingRights"
                 data-csa-c-slot-id="dsvBuyingRights_feature_div" data-csa-c-asin="B038261694"
                 data-csa-c-is-in-initial-active-row="false">
                                                          </div>
                                                                    <div id="twister_feature_div" class="celwidget" data-feature-name="twister"
                 data-csa-c-type="widget" data-csa-c-content-id="twister"
                 data-csa-c-slot-id="twister_feature_div" data-csa-c-asin="B095900480"
                 data-csa-c-is-in-initial-active-row="false">
                                                                                 </div>
                                                    <div id="bundles_feature_div" class="celwidget" data-feature-name="bundles"
                 data-csa-c-type="widget" data-csa-c-content-id="bundles"
                 data-csa-c-slot-id="bundles_feature_div" data-csa-c-asin="B024986845"
                 data-csa-c-is-in-initial-active-row="false">
                                                           </div>
                                                    <div id="twisterPlusWWDesktop" class="celwidget" data-feature-name="twisterPlusWWDesktop"
                 data-csa-c-type="widget" data-csa-c-content-id="twisterPlusWWDesktop"
                 data-csa-c-slot-id="twisterPlusWWDesktop" data-csa-c-asin="B056550763"
                 data-csa-c-is-in-initial-active-row="false">
                                                      </div>
                                    <div id="gestaltCustomizationSummary_feature_div" class="celwidget" data-feature-name="gestaltCustomizationSummary"
                 data-csa-c-type="widget" data-csa-c-content-id="gestaltCustomizationSummary"
                 data-csa-c-slot-id="gestaltCustomizationSummary_feature_div" data-csa-c-asin="B017245625"
                 data-csa-c-is-in-initial-active-row="false">
                                                           </div>
                                    <div id="renewedProgramDescriptionAtf_feature_div" class="celwidget" data-feature-name="renewedP